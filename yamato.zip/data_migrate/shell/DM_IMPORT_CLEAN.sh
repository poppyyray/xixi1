#!/bin/sh
. /tools/data_migrate/conf/dm_import_env.conf
RC=$?
if [ ${RC} != "0" ] ;
then
	exit 1
fi

#以下の新本番JP1サーバー上の対象を削除する
rm -f /workflow/batch/error_bak/* 2>/dev/null
rm -f /workflow/batch/jp1/* 2>/dev/null
rm -f /workflow/batch/logs/* 2>/dev/null
rm -f /workflow/batch/logs/report/* 2>/dev/null
rm -f /workflow/batch/maint/m_logs/* 2>/dev/null
rm -f /workflow/batch/pp_bak/* 2>/dev/null
rm -f /workflow/batch/scan_bak/* 2>/dev/null
rm -f /workflow/batch/mes/* 2>/dev/null
rm -f /workflow/batch/tmp/* 2>/dev/null
rm -f /workflow/batch/tmp/user_syncro/* 2>/dev/null
rm -f /workflow/batch/csv/* 2>/dev/null
rm -f /workflow/batch/backup/* 2>/dev/null
rm -f /workflow/batch/maint/m_csv/* 2>/dev/null
rm -f /workflow/batch/maint/m_tmp/* 2>/dev/null
rm -f /workflow/batch/maint/m_tmp/IF_CHECK/* 2>/dev/null
rm -f /shared/reporting/move/* 2>/dev/null
rm -f /shared/reporting/move/ASCA/* 2>/dev/null

#以下の新本番JIRAUサーバー上の対象を削除する
ssh $JIRAU_IP "rm -f /workflow/batch/backup/* 2>/dev/null"
ssh $JIRAU_IP "rm -f /workflow/batch/logs/* 2>/dev/null"
ssh $JIRAU_IP "rm -f /workflow/batch/tmp/* 2>/dev/null"
ssh $JIRAU_IP "rm -f /workflow/batch/attach_bak/* 2>/dev/null"
ssh $JIRAU_IP "rm -f /shared/jira_u/qr/data/* 2>/dev/null"
ssh $JIRAU_IP "rm -rf /shared/jira_u/attachment/* 2>/dev/null"

#以下の新本番JIRARサーバー上の対象を削除する
ssh $JIRAR_IP "rm -f /workflow/batch/backup/* 2>/dev/null"
ssh $JIRAR_IP "rm -f /workflow/batch/logs/* 2>/dev/null"
ssh $JIRAR_IP "rm -f /workflow/batch/tmp/* 2>/dev/null"
ssh $JIRAR_IP "rm -f /shared/jira_r/qr/data/* 2>/dev/null"
ssh $JIRAR_IP "rm -rf /shared/jira_r/attachment/* 2>/dev/null"

echo "クリアー完了"