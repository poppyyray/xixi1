#!/bin/sh

HOME="/tools/data_migrate"

#DB名を取得
dbname=$1

case ${dbname} in
    "jiradbu" | "jiradbr" | "gwdb")
        break
    ;;
    * )
        echo "入力パラメータ不正。下記のようなパラメータを付けてください"
        echo "jiradbu --更新JIRA DB"
        echo "jiradbr --参照JIRA DB"
        echo "gwdb --GATEWAY DB"
        exit 1
    ;;
esac

. /hdcd_removal/decrypt/ASCA_DECRYPT_MANAGER.sh ALL

# 共通関数呼び出し
. ${HOME}/shell/DM_COMMON.sh
rc1=$?

#環境設定を行う
. $CONF_PATH/dm_export_env.conf
rc2=$?

if [ $rc1 != 0 -o $rc2 != 0 ]; then
    exit 1
fi

outlog_func DB-I01001 $dbname

#エクスポートtarファイルパスを構築
tar_name=$WORK_EXPORT/${dbname}.tar.gz
exp_cnt=$WORK_EXPORT/${dbname}_exp_cnt

#すでにエクスポートチェック

if [ -f $exp_cnt -a -f $tar_name ]; then
     tar -tf $tar_name > /dev/null
     if [ $? = 0 ]; then
         outlog_func DB-W01002 $tar_name
         exit 0
     else
         #tarファイルに損害がある場合、そのファイルを削除
         rm -f $tar_name
         rm -f $exp_cnt
     fi
else
     #tarファイルと件数ファイルを削除
     rm -f $tar_name
     rm -f $exp_cnt
fi

#テーブル配置ファイルパスを構築
table_conf=$CONF_PATH/dm_${dbname}_tables.conf

	
#DB接続変量名を構築 JIRADBU_CON JIRADBR_CON GWDB_CON
db_con=$(echo $dbname | tr '[a-z]' '[A-Z]')_CON

start_time=`date +%s`

outlog_func DB-I01003 $dbname
# DBに接続
db2 connect to ${!db_con} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
if [ ${SQLERROR} != 0 ]; then
    echo " ${dbname}へ連続失敗"
    outlog_func DB-E01004 $dbname
    exit 1
fi

db_tmp="$TMP_PATH/$dbname"

#テンプフォルダーを作る
rm -rf $db_tmp
mkdir -p $db_tmp 2>/dev/null

#テーブルエクスポート
exec 3<${table_conf}
while read table_nm<&3
do
    table_nm=`echo ${table_nm} | tr -d '\r'`
    echo " ${dbname}  ${table_nm} 導出中"
    db2 "export to $db_tmp/$table_nm of ixf lobs to $db_tmp lobfile $table_nm modified by lobsinfile select * from $table_nm" >> ${SQLLOG_TMP}
    SQLERROR=$?
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    if [ ${SQLERROR} != 0 ]; then
        echo " ${dbname}  ${table_nm} 導出失敗"
        #テンプファイル
        rm -rf $db_tmp
        outlog_func DB-E01005 $dbname "$table_nm"
        exit 1
    fi
    #EXPORTのファイルを圧縮
    tar -zcf $db_tmp/$table_nm.tar.gz -C $db_tmp/ $table_nm --remove-files
    rc=$?
    if [ $rc != 0 ]; then
        echo " ${dbname}  ${table_nm} 圧縮失敗"
        #テンプファイル
        rm -rf $db_tmp
        outlog_func DB-E01024 ${db_tmp}/${table_nm}
        exit 1
    fi
    echo " ${dbname}  ${table_nm} 導出成功"
done
export_end_time=`date +%s`
outlog_func DB-I01006 $dbname $[ export_end_time - start_time ]

outlog_func DB-I01007 $db_tmp

#圧縮処理
echo " ${dbname} 圧縮処理中"
tar -zcf $tar_name  -C $db_tmp . > /dev/null
if [ $? != 0 ]; then
    echo " ${dbname} 圧縮処理失敗"
    rm -rf $db_tmp
    rm -f $tar_name
    outlog_func DB-E01008 $db_tmp
    exit 1
fi
tar_end_time=`date +%s`
outlog_func DB-I01009 $db_tmp $[ tar_end_time - export_end_time ]

#export件数統計
echo " ${dbname} 導出件数統計中"
rm -f $WORK_EXPORT/${dbname}_exp_cnt
exec 3<${table_conf}
while read table_nm<&3
do
    #改行を削除
    table_nm=`echo ${table_nm} | tr -d '\r'`
    db2 -x "select count(0) from $table_nm" > ${SQLLOG_TMP}
    SQLERROR=$?
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    if [ ${SQLERROR} != 0 ]; then
        echo " ${dbname} 導出件数統計失敗 $table_nm"
        #テンプファイル
        rm -rf $db_tmp
        rm -f $WORK_EXPORT/${dbname}_exp_cnt
        rm -f $tar_name
        outlog_func DB-E01012 $dbname "$table_nm"
        exit 1
    fi
    cnt=`cat ${SQLLOG_TMP}`
    echo "${table_nm} ${cnt}" >> $WORK_EXPORT/${dbname}_exp_cnt
done

outlog_func DB-I01013 $dbname

#接続切断
db2 terminate > ${SQLLOG_TMP}
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

#テンプフォルダー削除
rm -rf $db_tmp

#導出時間タグファイル更新
if [ "$dbname" = "jiradbu" ]; then
    rm -f $CONF_PATH/EXPORT_TAG_*
    touch $CONF_PATH/EXPORT_TAG_`date +%Y%m%d`
fi

end_time=`date +%s`
outlog_func DB-I01011 $dbname $[ end_time - start_time ]
