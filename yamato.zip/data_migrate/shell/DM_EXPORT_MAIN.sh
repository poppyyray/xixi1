#!/bin/sh

HOME="/tools/data_migrate"

param=$1

#入力パラメータチェック
case ${param} in
    "check" | "attachment" | "asca" | "db" | "all" )
    ;;
    * )
        echo "入力パラメータ不正。下記のようなパラメータを付けてください"
        echo "check --環境チェック"
        echo "attachment --JIRA ATTACHMENT導入/導出"
        echo "db --DB 導入/導出"
        echo "asca --ASCA 導入/導出"
        echo "all --上記すべての処理"
        exit 1
    ;;
esac
echo "MAIN導出実行開始"
# 共通関数呼び出し
. ${HOME}/shell/DM_COMMON.sh
rc1=$?

#環境設定を行う
. $CONF_PATH/dm_export_env.conf
rc2=$?

mv ${HOME}/logs/DM_EXPORT_02.sh_jiradbu.log ${HOME}/logs/DM_EXPORT_02.sh_jiradbu_`date +%Y%m%d%H%M%S`.log > /dev/null 2>&1
mv ${HOME}/logs/DM_EXPORT_02.sh_jiradbr.log ${HOME}/logs/DM_EXPORT_02.sh_jiradbr_`date +%Y%m%d%H%M%S`.log > /dev/null 2>&1
mv ${HOME}/logs/DM_EXPORT_02.sh_gwdb.log ${HOME}/logs/DM_EXPORT_02.sh_gwdb_`date +%Y%m%d%H%M%S`.log > /dev/null 2>&1


start_time=`date +%s`
outlog_func DM-I01001 "旧環境" 

#環境チェック
if [ "$param" = "check" ]; then
    echo "環境チェック中"
	sh ${HOME}/shell/DM_CHECK_ENV.sh export
	if [ $? = 0 ]; then
		echo "環境チェック成功"
		outlog_func DM-I01002 "DM_CHECK_ENV.sh" export
		exit 0
	else
		echo "環境チェック失敗"
		outlog_func DM-E01003 "DM_CHECK_ENV.sh" export
		exit 1
	fi
fi

#EXPORTフォルダークリア
if [ "$param" = "all" ]; then
    echo "EXPORTフォルダークリア中"
    rm -rf ${HOME}/export/*
    if [ $? = 0 ]; then
        echo "EXPORTフォルダークリア成功"
    else
        echo "EXPORTフォルダークリア失敗" 
    fi
fi

c_flg=0
#JIRA ATTACHMENT導入/導出
if [ "$param" = "attachment" -o "$param" = "all" ]; then
	echo "JIRAU ATTACHMENT導出開始"
	sh ${HOME}/shell/DM_EXPORT_01.sh jirau
	if [ $? = 0 ]; then
		outlog_func DM-I01002 "DM_EXPORT_01.sh" jirau
		echo "JIRAU ATTACHMENT導出成功"
	else
		outlog_func DM-E01003 "DM_EXPORT_01.sh" jirau
		c_flg=1
		echo "JIRAU ATTACHMENT導出失敗"
	fi

	echo "JIRAR ATTACHMENT導出開始"
	sh ${HOME}/shell/DM_EXPORT_01.sh jirar
	if [ $? = 0 ]; then
		outlog_func DM-I01002 "DM_EXPORT_01.sh" jirar
		echo "JIRAR ATTACHMENT導出成功"
	else
		outlog_func DM-E01003 "DM_EXPORT_01.sh" jirar
		c_flg=1
		echo "JIRAR ATTACHMENT導出失敗"
	fi

	#成果物チェック
	if [ ! -f $WORK_EXPORT/$JIRAU_ATTACHMENT_FILE ]; then
		outlog_func DM-E01005 "DM_EXPORT_01.sh" "$WORK_EXPORT/$JIRAU_ATTACHMENT_FILE"
		c_flg=1
		echo "JIRAU ATTACHMENT導出成果物[$WORK_EXPORT/$JIRAU_ATTACHMENT_FILE]不存在"
	fi

	if [ ! -f $WORK_EXPORT/$JIRAU_ATTACHMENT_COUNT_EXPORT_LIST ]; then
		outlog_func DM-E01005 "DM_EXPORT_01.sh" "$WORK_EXPORT/$JIRAU_ATTACHMENT_COUNT_EXPORT_LIST"
		c_flg=1
		echo "JIRAU ATTACHMENT導出成果物[$WORK_EXPORT/$JIRAU_ATTACHMENT_COUNT_EXPORT_LIST]不存在"	
	fi

	if [ ! -f $WORK_EXPORT/$JIRAR_ATTACHMENT_FILE ]; then
		outlog_func DM-E01005 "DM_EXPORT_01.sh" "$WORK_EXPORT/$JIRAR_ATTACHMENT_FILE"
		c_flg=1
		echo "JIRAR ATTACHMENT導出成果物[$WORK_EXPORT/$JIRAR_ATTACHMENT_FILE]不存在"	
	fi

	if [ ! -f $WORK_EXPORT/$JIRAR_ATTACHMENT_COUNT_EXPORT_LIST ]; then
		outlog_func DM-E01005 "DM_EXPORT_01.sh" "$WORK_EXPORT/$JIRAR_ATTACHMENT_COUNT_EXPORT_LIST"
		c_flg=1
		echo "JIRAR ATTACHMENT導出成果物[$WORK_EXPORT/$JIRAR_ATTACHMENT_COUNT_EXPORT_LIST]不存在"	
		
	fi

fi

#DB 導入/導出
if [ "$param" = "db" -o "$param" = "all" ]; then
	echo "JIRADBU導出開始"
	nohup sh ${HOME}/shell/DM_EXPORT_02.sh jiradbu &
	echo "JIRARDBR導出開始"
	nohup sh ${HOME}/shell/DM_EXPORT_02.sh jiradbr &
	echo "GWDB導出開始"
	nohup sh ${HOME}/shell/DM_EXPORT_02.sh gwdb &
	cpl_flg_jiradbu=0
	cpl_flg_jiradbr=0
 	cpl_flg_gwdb=0
	while [ "1" = "1" ]; 
	do
		for dbname in jiradbu jiradbr gwdb
		do
			flg_name=cpl_flg_$dbname
			if [ ${!flg_name} = 1 ]; then
				continue
			fi
			ps -ef | grep "DM_EXPORT_02.sh $dbname" | grep -v grep 2>&1 > /dev/null
			if [ $? != 0 ]; then
				grep "ERROR" ${HOME}/logs/DM_EXPORT_02.sh_${dbname}.log 2>&1 > /dev/null
				if [ $? = 0 ]; then
					outlog_func DM-E01003 "DM_EXPORT_02.sh" $dbname
					c_flg=1
					echo "$dbname導出失敗"
				else
					outlog_func DM-I01002 "DM_EXPORT_02.sh" $dbname
					echo "$dbname導出成功"
				fi

				#成果物チェック
				if [ ! -f $WORK_EXPORT/${dbname}.tar.gz ]; then
					outlog_func DM-E01005 "DM_EXPORT_02.sh" "$WORK_EXPORT/${dbname}.tar.gz"
					c_flg=1
					echo "$dbname導出成果物[$WORK_EXPORT/${dbname}.tar.gz]がもれる"
				fi

				if [ ! -f $WORK_EXPORT/${dbname}_exp_cnt ]; then
					outlog_func DM-E01005 "DM_EXPORT_02.sh" "$WORK_EXPORT/${dbname}_exp_cnt"
					c_flg=1
					echo "$dbname導出成果物[$WORK_EXPORT/${dbname}_exp_cnt]がもれる"
				fi
				eval $flg_name=1
			fi
		done
		ps -ef | grep "DM_EXPORT_02.sh" | grep -v grep  2>&1 > /dev/null 
		if [ $? != 0 ]; then
			break
		fi
		sleep 30
	done

fi

#ASCA 導入/導出
if [ "$param" = "asca" -o "$param" = "all" ]; then
	echo "ASCA導出開始"
	sh ${HOME}/shell/DM_EXPORT_03.sh asca
	if [ $? = 0 ]; then
		echo "ASCA導出成功"
		outlog_func DM-I01002 "DM_EXPORT_03.sh" asca
	else
		outlog_func DM-E01003 "DM_EXPORT_03.sh" asca
		c_flg=1
		echo "ASCA導出失敗"
	fi

	#成果物チェック
	if [ ! -f $WORK_EXPORT/$ASCA_FILE ]; then
		outlog_func DM-E01005 "DM_EXPORT_03.sh" "$WORK_EXPORT/$ASCA_FILE"
		c_flg=1
		echo "ASCA導出成果物 [$WORK_EXPORT/$ASCA_FILE]が漏れる"
	fi

	if [ ! -f $WORK_EXPORT/$ASCA_COUNT_EXPORT_LIST ]; then
		outlog_func DM-E01005 "DM_EXPORT_03.sh" "$WORK_EXPORT/$ASCA_COUNT_EXPORT_LIST"
		c_flg=1
		echo "ASCA導出成果物 [$WORK_EXPORT/$ASCA_COUNT_EXPORT_LIST]が漏れる"
	fi
fi

end_time=`date +%s`
outlog_func DM-I01004 "旧環境" $[ end_time - start_time ]
exit $c_flg
echo "MAIN導出実行終了"