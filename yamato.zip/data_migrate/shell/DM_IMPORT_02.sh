#!/bin/sh
HOME="/tools/data_migrate"
ID_COL_TBLS=("RP.TB_CHYOHYOUSYUTURYOKUYOUKYUU" "RP.TB_ISSUE_HISTORY")
LOBS_TBLS=("RP.TB_CHYOHYOUSYUTURYOKUYOUKYUU" "JIRASCHEMA.JIRAWORKFLOWS" "JIRASCHEMA.PROPERTYDATA")

#DB名を取得
dbname=$1

#入力パラメータチェック
case ${dbname} in
    "jiradbu" | "jiradbr" | "gwdb")
        break
    ;;
    * )
        echo "入力パラメータ不正。下記のようなパラメータを付けてください"
        echo "jiradbu --更新JIRA DB"
        echo "jiradbr --参照JIRA DB"
        echo "gwdb --GATEWAY DB"
        exit 1
    ;;
esac

. /workflow/auth_mgr/decrypt/ASCA_DECRYPT_MANAGER.sh ALL

# 共通関数呼び出し
. ${HOME}/shell/DM_COMMON.sh
rc1=$?

#環境設定を行う
. $CONF_PATH/dm_import_env.conf
rc2=$?

if [ $rc1 != 0 -o $rc2 != 0 ]; then
    exit 1
fi

outlog_func DB-I02001 $dbname

#エクスポートtarファイルパスを構築
tar_name=$WORK_EXPORT/${dbname}.tar.gz

#テーブル配置ファイルパスを構築
table_conf=$CONF_PATH/dm_${dbname}_tables.conf

#DB接続変量名を構築 JIRADBU_CON JIRADBR_CON GWDB_CON
db_con=$(echo $dbname | tr '[a-z]' '[A-Z]')_CON

if [ ! -f "$tar_name" ]; then
     outlog_func DB-E02002 $tar_name
     exit 1
fi

#開始時間記録
start_time=`date +%s`

outlog_func DB-I02003 $tar_name

db_tmp="$TMP_PATH/$dbname"

#既存の解圧ファイルを削除
rm -rf $db_tmp
mkdir -p $db_tmp 2>/dev/null

#tar解圧する
tar -xzf $tar_name -C $db_tmp > /dev/null
if [ $? != 0 ]; then
    echo "$tar_name解凍失敗"
    rm -rf $db_tmp
    outlog_func DB-E02004 $tar_name
    exit 1
fi
echo "$tar_name解凍成功"
tar_end_time=`date +%s`
outlog_func DB-I02005 $db_tmp $[ tar_end_time - start_time ]


# DBに接続
db2 connect to ${!db_con} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
if [ ${SQLERROR} != 0 ]; then
    echo "$dbnameへ連続失敗"
    rm -rf $db_tmp
    outlog_func DB-E02007 $dbname
    exit 1
fi

outlog_func DB-I02018 $dbname 
#integrity off設定
exec 3<${table_conf}
while read table_nm<&3
do
    #LOBSテーブルチェック
    for tbl in ${LOBS_TBLS[@]};
    do
        if [ "$table_nm" == "$tbl" ]; then
            continue 2
        fi
    done

    db2 set integrity for ${table_nm} off > ${SQLLOG_TMP}
    SQLERROR=$?
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    if [ ${SQLERROR} != 0 ]; then
        echo "$dbname ${table_nm}  set integrity off 失敗"
        rm -rf $db_tmp
        outlog_func DB-E02009 $dbname "$table_nm"
        exit 1
    fi

done
outlog_func DB-I02019 $dbname 

outlog_func DB-I02006 $dbname
#テーブルインポート
exec 3<${table_conf}
while read table_nm<&3
do
    #改行を削除
    table_nm=`echo ${table_nm} | tr -d '\r'`

    #テーブルtarファイルを解圧
    tar -xzf $db_tmp/${table_nm}.tar.gz -C $db_tmp  > /dev/null
    rc=$?
    if [ $rc != 0 ]; then
        echo "${table_nm}.tar.gz 解凍失敗"
        rm -rf $db_tmp
        outlog_func DB-E02025 "$db_tmp/${table_nm}"
        exit 1
    fi

    #テーブルtarファイルを削除
    rm -f $db_tmp/${table_nm}.tar.gz

    #identityoverride必要テーブルチェック
    id_dsp=""
    for tbl in ${ID_COL_TBLS[@]};
    do
        if [ "$table_nm" == "$tbl" ]; then
            id_dsp="identityignore"
            break
        fi
    done

    #LOBSテーブルチェック
    lob_flg=0
    for tbl in ${LOBS_TBLS[@]};
    do
        if [ "$table_nm" == "$tbl" ]; then
            lob_flg=1
            break
        fi
    done

    #非LOBSテーブルの場合
    if [ $lob_flg = 0 ]; then
         db2 load client from $db_tmp/$table_nm OF IXF LOBS FROM $db_tmp/ MODIFIED BY lobsinfile $id_dsp replace INTO $table_nm nonrecoverable > ${SQLLOG_TMP}
         echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    else
    #LOBSテーブルの場合
         db2 import from  $db_tmp/$table_nm OF ixf LOBS FROM $db_tmp/ MODIFIED BY lobsinfile $id_dsp replace INTO $table_nm > ${SQLLOG_TMP}
         echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    fi
    SQLERROR=$?
    if [ ${SQLERROR} != 0 ]; then
        echo "$dbname ${table_nm}導入失敗"
        rm -rf $db_tmp
        outlog_func DB-E02010 "$dbname" "$table_nm"
        exit 1
    fi
    echo "$dbname ${table_nm}導入成功"
    #テーブルファイルを削除
    rm -f $db_tmp/${table_nm}
done
import_end_time=`date +%s`
outlog_func DB-I02012 $dbname $[ import_end_time - tar_end_time ]

outlog_func DB-I02020 $dbname 
#integrity checked設定
exec 3<${table_conf}
while read table_nm<&3
do
    #LOBSテーブルチェック
    for tbl in ${LOBS_TBLS[@]};
    do
        if [ "$table_nm" == "$tbl" ]; then
            continue 2
        fi
    done

    db2 set integrity for $table_nm immediate checked > ${SQLLOG_TMP}
    SQLERROR=$?
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    if [ ${SQLERROR} != 0 ]; then
        echo "$dbname ${table_nm} set integrity checked 失敗"
        rm -rf $db_tmp
        outlog_func DB-E02011 $dbname "$table_nm"
        exit 1
    fi
done

#tablespaceがpending中かチェックする(dbとtableがpending中の場合、select不可のため、チェック不要)
db2 list tablespaces | grep -Ei "pending|ペンディング"
rc=$?
if [ $rc = 0 ]; then
    echo "$dbname tablespace pending中"
    rm -rf $db_tmp
    outlog_func DB-E02014 $dbname
    exit 1
fi

outlog_func DB-I02021 $dbname 

outlog_func DB-I02022 $dbname
rm -f $WORK_IMPORT/${dbname}_imp_cnt
#import件数統計
echo "$dbname import件数統計中"
exec 3<${table_conf}
while read table_nm<&3
do
    table_nm=`echo ${table_nm} | tr -d '\r'`
    db2 -x "select count(0) from $table_nm" > ${SQLLOG_TMP}
    SQLERROR=$?
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    if [ ${SQLERROR} != 0 ]; then
        echo "$dbname  ${table_nm}件数統計失敗"
        rm -rf $db_tmp
        rm -f $WORK_IMPORT/${dbname}_imp_cnt
        outlog_func DB-E02008 $dbname "$table_nm"
        exit 1
    fi
    cnt=`cat ${SQLLOG_TMP}`
    echo "${table_nm} ${cnt}" >> $WORK_IMPORT/${dbname}_imp_cnt
done

outlog_func DB-I02023 $dbname


#import件数チェック
DIFF_FILE $WORK_EXPORT/${dbname}_exp_cnt $WORK_IMPORT/${dbname}_imp_cnt $WORK_IMPORT/${dbname}_imp_chk
if [ $? == 0 ]; then
    outlog_func DB-I02015 ${dbname}
else
    echo "$dbname 件数チェック失敗"
    rm -rf $db_tmp
    outlog_func DB-E02016 ${dbname} $WORK_IMPORT/${dbname}_imp_chk
    exit 1
fi

#接続切断
db2 terminate > ${SQLLOG_TMP}
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

rm -rf $db_tmp
end_time=`date +%s`
outlog_func DB-I02013 ${dbname} $[ end_time - start_time ]

exit 0
