. /tools/data_migrate/conf/dm_export_env.conf
if [ "$?" != "0" ]; then
    exit 1
fi
mount $NFS_PATH /tools/data_migrate/tmp  > /dev/null 2>&1
mount_rc=$?
ls /tools/data_migrate/tmp  > /dev/null 2>&1
ls_rc=$?
if [ "$mount_rc" = "0" ] && [ "$ls_rc" = "0" ]; then
    echo "mount 成功"
    if [ ! -d /tools/data_migrate/tmp/tmp_for_data_migrate ]; then
        mkdir /tools/data_migrate/tmp/tmp_for_data_migrate  > /dev/null 2>&1
        ls /tools/data_migrate/tmp/tmp_for_data_migrate > /dev/null 2>&1
        if [ "$?" = "0" ]; then
            echo "テンプルフォルダー作成成功"
        else
            echo "テンプルフォルダー作成失敗"
        fi
    fi
else
    echo "mount 失敗"
    exit 1
fi
exit 0