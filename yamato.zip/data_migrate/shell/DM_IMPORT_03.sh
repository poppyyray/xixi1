#!/bin/sh
#########################################################################
#環境設定を行う
#########################################################################
HOME="/tools/data_migrate"

# 共通関数呼び出し
. ${HOME}/shell/DM_COMMON.sh
RC1=$?

. ${CONF_PATH}/dm_import_env.conf
RC2=$?

if [ ${RC1} != "0" ] || [ ${RC2} != "0" ]
then
	exit 1
fi

# ${1}より変数を設定する
case ${1} in
	"asca")
		_IP=local
		_NAME=asca
		_TYPE=asca
		_A_PATH=${ASCA_PATH}
		_COUNT_IMPORT_LIST=${ASCA_COUNT_IMPORT_LIST}
		_COUNT_EXPORT_LIST=${ASCA_COUNT_EXPORT_LIST}
		_IMPORT_FILE=${ASCA_FILE}
		;;
	*)
		echo "パラメータ不正[入力したパラメータの定義不正]"
		exit 1
		;;
esac

# 開始メッセージ
outlog_func JA-I01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}

# 全プロセス処理時間の統計変数
pro_time_1=`date +%s`

#インポートファイルの存在をチェックする
if [ ! -f ${WORK_EXPORT}/${_IMPORT_FILE} ]
then
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 2` インポートのtarファイルが存在しない" >> ${LOG_PATH}/${LOG_NAME}
 	# 移行作業失敗のログ
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	exit 1
fi

#転送開始のログ
outlog_func JA-I03001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}

#既存のアタッチメントを削除する。
DELETE_LOCAL_TAR "${_A_PATH}"'/BM07*.zip'
DELETE_LOCAL_TAR "${_A_PATH}"'/BD07*.zip'
if [ $? != "0" ]
then
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 3`　既存ファイルの削除が失敗" >> ${LOG_PATH}/${LOG_NAME}
	# 移行作業失敗のログ
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	exit 1
fi

# 解凍コマンド実施時間の計算変数
pro_time_3=`date +%s`

#解凍作業開始ログ
outlog_func JA-I04001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}

tar -zxf ${WORK_EXPORT}/${_IMPORT_FILE} -C ${_A_PATH} .

if [ $? != "0" ]
then
	outlog_func JA-E04001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 5`" >> ${LOG_PATH}/${LOG_NAME}
	DELETE_LOCAL_TAR "${_A_PATH}"'/BM07*.zip'
	DELETE_LOCAL_TAR "${_A_PATH}"'/BD07*.zip'
	# 移行作業失敗のログ
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	exit 1
fi
#解凍作業終了ログ
outlog_func JA-I04002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} $(( `date +%s` - pro_time_3 ))

#Attachment件数を出力する
CREATE_ASCA_COUNTS ${WORK_IMPORT}/${_COUNT_IMPORT_LIST}
if [ $? != "0" ]
then
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 3` 件数ファイル出力失敗" >> ${LOG_PATH}/${LOG_NAME}	
	DELETE_LOCAL_TAR "${_A_PATH}"'/BM07*.zip'
	DELETE_LOCAL_TAR "${_A_PATH}"'/BD07*.zip'
	# 移行作業失敗のログ
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	exit 1
fi	

#インポートの件数チェックを行う。
if [ ! -f ${WORK_EXPORT}/${_COUNT_EXPORT_LIST} ]
then
	outlog_func JA-E05002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	DELETE_LOCAL_TAR "${_A_PATH}"'/BM07*.zip'
	DELETE_LOCAL_TAR "${_A_PATH}"'/BD07*.zip'
	# 移行作業失敗のログ
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	exit 1
fi 

DIFF_FILE "${WORK_EXPORT}/${_COUNT_EXPORT_LIST}" "${WORK_IMPORT}/${_COUNT_IMPORT_LIST}" "${WORK_IMPORT}/${_COUNT_IMPORT_LIST%_*}_check_result.txt"
if [ $? != "0" ]
then
    outlog_func JA-E05001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	DELETE_LOCAL_TAR "${_A_PATH}"'/BM07*.zip'
	DELETE_LOCAL_TAR "${_A_PATH}"'/BD07*.zip'
	# 移行作業失敗のログ
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	exit 1
fi

outlog_func JA-I05001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}