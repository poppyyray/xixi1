#!/bin/sh

#########################################################################
#環境設定を行う
#########################################################################
HOME="/tools/data_migrate"

# 共通関数呼び出し
. ${HOME}/shell/DM_COMMON.sh
RC1=$?
. ${CONF_PATH}/dm_export_env.conf
RC2=$?
if [ ${RC1} != "0" ] || [ ${RC2} != "0" ]
then
	exit 1
fi
export_or_import_flag=export
# 引数${1}より環境変数を設定する
case ${1} in
	"jirau")
		#parameter名
	    _NAME=attachment
		#更新参照の分岐フラグ
		_TYPE=update
		#ターゲットサーバのIP
		_IP=${JIRAU_IP}
		#リモートのターゲットのパス
		_A_PATH=${JIRAU_A_PATH}
		#リモートのファイル件数のリスト
		_COUNT_EXPORT_LIST=${JIRAU_ATTACHMENT_COUNT_EXPORT_LIST}
		#出力されたファイル名（tarファイル名）
		_EXPORT_FILE=${JIRAU_ATTACHMENT_FILE}
		TAR_TO_FOLDER_GRP=${JIRAU_A_TAR_PATH}
		;;
	"jirar")
		_NAME=attachment
		_TYPE=reference
		_IP=${JIRAR_IP}
		_A_PATH=${JIRAR_A_PATH}
		_COUNT_EXPORT_LIST=${JIRAR_ATTACHMENT_COUNT_EXPORT_LIST}
		_EXPORT_FILE=${JIRAR_ATTACHMENT_FILE}
		TAR_TO_FOLDER_GRP=${JIRAR_A_TAR_PATH}
		;;
	*)
		echo "パラメータ不正[入力したパラメータの定義不正]"
		exit 1
		;;
esac

# 開始メッセージ
outlog_func JA-I01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
# 全プロセス処理時間の統計変数
pro_time_1=`date +%s`

# 圧縮作業開始
# メッセージ出力
outlog_func JA-I02001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}

# ローカルの結果ファイルを削除する
rm -f ${WORK_EXPORT}/${_EXPORT_FILE}
RC1=$?

# リモートの結果ファイルを削除する
REMOTE_EXEC_SH_RSH ${_IP} "rm -f ${TAR_TO_FOLDER_GRP}/${_EXPORT_FILE}"
RC2=$?

if [ ${RC1} != "0" ] || [ ${RC2} != "0" ]
then
	# 削除コマンドの失敗のログ
	outlog_func JA-W01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 2` || コマンド結果:\n`echo ${REMOTE_EXEC_VALUE}`" >>${DETAIL_LOG}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 6` ローカルまたはリモートの結果ファイルの削除失敗 " >> ${LOG_PATH}/${LOG_NAME}
	exit 1
fi

# 圧縮コマンド実施時間の計算変数
pro_time_2=`date +%s`

# 圧縮コマンドの実施
REMOTE_EXEC_SH_RSH ${_IP} "tar -czf  ${TAR_TO_FOLDER_GRP}/${_EXPORT_FILE} -C ${_A_PATH} '.'"
if [ $? != "0" ]
then
	# 圧縮コマンドの失敗のログ
	outlog_func JA-E02001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 4` || コマンド結果:\n`echo ${REMOTE_EXEC_VALUE}`" >>${DETAIL_LOG}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 5` " >> ${LOG_PATH}/${LOG_NAME}
	DELETE_REMOTE_TAR "${_IP}" "${TAR_TO_FOLDER_GRP}/${_EXPORT_FILE}"
	exit 1
fi

# 圧縮作業終了ログ
outlog_func JA-I02002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} $(( `date +%s` - pro_time_2 ))

#転送作業開始ログ
outlog_func JA-I03001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}

# 転送コマンド実施時間の計算変数
pro_time_3=`date +%s`

# 転送コマンドの実施
REMOTE_COPY_RCP ${_IP}:${TAR_TO_FOLDER_GRP}/${_EXPORT_FILE} ${WORK_EXPORT}/${_EXPORT_FILE}

if [ $? != "0" ]
then
	# 転送コマンドの失敗のログ
	outlog_func JA-E03001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	# リモートのtarファイルを削除する
	DELETE_REMOTE_TAR "${_IP}" "${TAR_TO_FOLDER_GRP}/${_EXPORT_FILE}"
	# ローカルの中途半端のtarファイルを削除する
	DELETE_LOCAL_TAR ${WORK_EXPORT}/${_EXPORT_FILE}
	exit 1
fi
outlog_func JA-I03002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} $(( `date +%s` - pro_time_3 ))

#件数を出力する
CREATE_ATTACHMENT_COUNTS ${_IP} ${WORK_EXPORT}/${_COUNT_EXPORT_LIST}
if [ $? != "0" ]
then
	# 移行作業失敗のログ
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 5` 件数ファイル出力失敗" >> ${LOG_PATH}/${LOG_NAME}	
	# リモートのtarファイルを削除する
	DELETE_REMOTE_TAR "${_IP}" "${TAR_TO_FOLDER_GRP}/${_EXPORT_FILE}"
	# ローカルの中途半端のtarファイルを削除する
	DELETE_LOCAL_TAR ${WORK_EXPORT}/${_EXPORT_FILE}
	# 件数ファイルを削除する
	DELETE_LOCAL_TAR ${WORK_EXPORT}/${_COUNT_EXPORT_LIST}
	exit 1
fi

# リモートのファイルを削除する
REMOTE_EXEC_SH_RSH ${_IP} "rm -f ${TAR_TO_FOLDER_GRP}/${_EXPORT_FILE}"

if [ $? != "0" ]
then
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 2` || コマンド結果:\n`echo ${REMOTE_EXEC_VALUE}`"  >> ${LOG_PATH}/${LOG_NAME}
	# 削除コマンドの失敗のログ
	outlog_func JA-W01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
fi

#終了ログ
outlog_func JA-I01002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} $(( `date +%s` - pro_time_1 ))