#!/bin/sh
#########################################################################
#環境設定を行う
#########################################################################
HOME="/tools/data_migrate"

# 共通関数呼び出し
. ${HOME}/shell/DM_COMMON.sh
RC1=$?
. ${CONF_PATH}/dm_export_env.conf
RC2=$?
if [ ${RC1} != "0" ] || [ ${RC2} != "0" ]
then
	exit 1
fi

# 引数${1}より環境変数を設定する
case ${1} in
	"asca")
		_IP=local
		_NAME=asca
		_TYPE=asca
		_A_PATH=${ASCA_PATH}
		_COUNT_EXPORT_LIST=${ASCA_COUNT_EXPORT_LIST}
		_EXPORT_FILE=${ASCA_FILE}	
		;;
	*)
		echo "パラメータ不正[入力したパラメータの定義不正]"
		exit 1
		;;
esac


# 開始メッセージ
outlog_func JA-I01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}

# 全プロセス処理時間の統計変数
pro_time_1=`date +%s`

# 圧縮作業開始
# メッセージ出力
outlog_func JA-I02001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}

# ローカルの結果ファイルを削除する
DELETE_LOCAL_TAR ${WORK_EXPORT}/${_EXPORT_FILE}
if [ $? != "0" ]
then
	# 移行作業失敗のログ
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 4` ローカルの結果ファイルが削除失敗" >> ${LOG_PATH}/${LOG_NAME}	
	exit 1
fi

# 圧縮コマンド実施時間の計算変数
pro_time_2=`date +%s`

# 圧縮コマンドの実施
tar -czf  ${WORK_EXPORT}/${_EXPORT_FILE} -C ${_A_PATH} .
if [ $? != "0" ]
then
	# 圧縮コマンドの失敗のログ
	outlog_func JA-E02001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 4`" >> ${LOG_PATH}/${LOG_NAME}
	# ローカルの中途半端のtarファイルを削除する
	DELETE_LOCAL_TAR ${WORK_EXPORT}/${_EXPORT_FILE}
	# 移行作業失敗のログ
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	exit 1
fi

#　件数を出力する
CREATE_ASCA_COUNTS ${WORK_EXPORT}/${_COUNT_EXPORT_LIST}
if [ $? != "0" ]
then
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 4` 件数ファイル出力失敗" >> ${LOG_PATH}/${LOG_NAME}	
	# ローカルの中途半端のtarファイルを削除する
	DELETE_LOCAL_TAR ${WORK_EXPORT}/${_EXPORT_FILE}
	# 件数ファイルを削除する
	DELETE_LOCAL_TAR ${WORK_EXPORT}/${_COUNT_EXPORT_LIST}
	# 移行作業失敗のログ
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	exit 1
fi

# 圧縮作業終了ログ
outlog_func JA-I02002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} $(( `date +%s` - pro_time_2 ))

outlog_func JA-I01002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} $(( `date +%s` - pro_time_1 ))