rm -rf /tools/data_migrate/tmp/tmp_for_data_migrate > /dev/null 2>&1
echo "テンプフォルダー削除しました"
umount /tools/data_migrate/tmp  > /dev/null 2>&1
umount_rc=$?
if [ "$umount_rc"  = "0" ]; then
    echo " UMOUNT 成功"
else
    echo "UMOUNT 失敗"
fi