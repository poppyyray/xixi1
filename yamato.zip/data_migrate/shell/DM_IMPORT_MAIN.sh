#!/bin/sh

HOME="/tools/data_migrate"

param=$1

#入力パラメータチェック
case ${param} in
    "check" | "attachment" | "asca" |"db" | "all" )
    ;;
    * )
        echo "入力パラメータ不正。下記のようなパラメータを付けてください"
        echo "check --環境チェック"
        echo "attachment --JIRA ATTACHMENT導入/導出"
        echo "db --DB 導入/導出"
        echo "asca --ASCA 導入/導出"
        echo "all --上記すべての処理"
        exit 1
    ;;
esac
echo "MAIN導入処理開始"
mv ${HOME}/logs/DM_IMPORT_02.sh_jiradbu.log ${HOME}/logs/DM_IMPORT_02.sh_jiradbu_`date +%Y%m%d%H%M%S`.log > /dev/null 2>&1
mv ${HOME}/logs/DM_IMPORT_02.sh_jiradbr.log ${HOME}/logs/DM_IMPORT_02.sh_jiradbr_`date +%Y%m%d%H%M%S`.log > /dev/null 2>&1
mv ${HOME}/logs/DM_IMPORT_02.sh_gwdb.log ${HOME}/logs/DM_IMPORT_02.sh_gwdb_`date +%Y%m%d%H%M%S`.log > /dev/null 2>&1

# 共通関数呼び出し
. ${HOME}/shell/DM_COMMON.sh
rc1=$?

#環境設定を行う
. $CONF_PATH/dm_import_env.conf
rc2=$?

if [ $rc1 != 0 -o $rc2 != 0 ]; then
    exit 1
fi
start_time=`date +%s`
outlog_func DM-I01001 "新環境"

#環境チェック
if [ "$param" = "check" -o "$param" = "all" ]; then
    echo "環境チェック処理中"
    sh ${HOME}/shell/DM_CHECK_ENV.sh import
    if [ $? = 0 ]; then
        echo "環境チェック処理成功"
        outlog_func DM-I01002 "DM_CHECK_ENV.sh" import
    else
        echo "環境チェック処理失敗"
        outlog_func DM-E01003 "DM_CHECK_ENV.sh" import
        exit 1
    fi
fi

c_flg=0
#JIRA ATTACHMENT導入/導出
if [ "$param" = "attachment" -o "$param" = "all" ]; then
    echo "JIRAU ATTACHMENT導入中"
    sh ${HOME}/shell/DM_IMPORT_01.sh jirau
    if [ $? = 0 ]; then
        outlog_func DM-I01002 "DM_IMPORT_01.sh" jirau
        echo "JIRAU ATTACHMENT導入成功"
    else
        outlog_func DM-E01003 "DM_IMPORT_01.sh" jirau
        c_flg=1
        echo "JIRAU ATTACHMENT導入失敗"
    fi

    echo "JIRAR ATTACHMENT導入中"
    sh ${HOME}/shell/DM_IMPORT_01.sh jirar
    if [ $? = 0 ]; then
        echo "JIRAR ATTACHMENT導入成功"
        outlog_func DM-I01002 "DM_IMPORT_01.sh" jirar
    else
        echo "JIRAR ATTACHMENT導入失敗"
        outlog_func DM-E01003 "DM_IMPORT_01.sh" jirar
        c_flg=1
    fi
fi


#DB 導入/導出
if [ "$param" = "db" -o "$param" = "all" ]; then
    echo "JIRAU 停止中"
    #JIRAをshutdown
    /workflow/batch/shell/SHUTDOWN_JIRA.sh U
    if [ $? != 0 ]; then
        outlog_func DM-E01026 "更新JIRA"
        echo "JIRAU 停止失敗"
        exit 1
    else
        outlog_func DM-I01028 "更新JIRA"
        echo "JIRAU 停止成功"
    fi

    echo "JIRAR 停止中"
    /workflow/batch/shell/SHUTDOWN_JIRA.sh R
    if [ $? != 0 ]; then
        outlog_func DM-E01026 "参照JIRA"
        echo "JIRAR 停止失敗"
        exit 1
    else
        outlog_func DM-I01028 "参照JIRA"
        echo "JIRAR 停止成功"
    fi

    echo "JIRADBU 導入中"
    nohup sh ${HOME}/shell/DM_IMPORT_02.sh jiradbu &
    echo "JIRADBR 導入中"
    nohup sh ${HOME}/shell/DM_IMPORT_02.sh jiradbr &
    echo "GWDB 導入中"
    nohup sh ${HOME}/shell/DM_IMPORT_02.sh gwdb &

    cpl_flg_jiradbu=0
    cpl_flg_jiradbr=0
    cpl_flg_gwdb=0
    while [ "1" = "1" ]; 
    do
        for dbname in jiradbu jiradbr gwdb
        do
            flg_name=cpl_flg_$dbname
            if [ ${!flg_name} = 1 ]; then
                continue
            fi
            ps -ef | grep "DM_IMPORT_02.sh $dbname" | grep -v grep  2>&1 > /dev/null
            if [ $? != 0 ]; then
                grep "ERROR" ${HOME}/logs/DM_IMPORT_02.sh_${dbname}.log
                if [ $? = 0 ]; then
                    echo "$dbname 導入失敗"
                    outlog_func DM-E01003 "DM_IMPORT_02.sh" $dbname
                    c_flg=1
                else
                    echo "$dbname 導入成功"
                    outlog_func DM-I01002 "DM_IMPORT_02.sh" $dbname
                fi
                eval $flg_name=1
            fi
        done
        ps -ef | grep "DM_IMPORT_02.sh" | grep -v grep 2>&1 > /dev/null
        if [ $? != 0 ]; then
            break
        fi
        sleep 30
    done

    echo "JIRAU 起動中"
    #JIRAをstartup
    /workflow/batch/shell/STARTUP_JIRA.sh U
    if [ $? != 0 ]; then
        outlog_func DM-E01027 "更新JIRA"
        echo "JIRAU 起動失敗"
    else
        outlog_func DM-I01029 "更新JIRA"
        echo "JIRAU 起動成功"
    fi

    echo "JIRAR 起動中"
    /workflow/batch/shell/STARTUP_JIRA.sh R
    if [ $? != 0 ]; then
        outlog_func DM-E01027 "参照JIRA"
        echo "JIRAU 起動失敗"
    else
        outlog_func DM-I01029 "参照JIRA"
        echo "JIRAU 起動成功"
    fi
fi

#ASCA 導入/導出
if [ "$param" = "asca" -o "$param" = "all" ]; then
    echo "ASCA 導入中"
    sh ${HOME}/shell/DM_IMPORT_03.sh asca
    if [ $? = 0 ]; then
        outlog_func DM-I01002 "DM_IMPORT_03.sh" asca
        echo "ASCA 導入成功"
    else
        outlog_func DM-E01003 "DM_IMPORT_03.sh" asca
        c_flg=1
        echo "ASCA 導入失敗"
    fi
fi
end_time=`date +%s`
outlog_func DM-I01004 "新環境" $[ end_time - start_time ]
echo "MAIN導入処理終了"
exit $c_flg