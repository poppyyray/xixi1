#!/bin/sh
export HOME_PATH=/tools/data_migrate
export LOG_PATH=$HOME_PATH/logs
export SHELL_PATH=$HOME_PATH/shell
export TMP_PATH=$HOME_PATH/tmp/tmp_for_data_migrate
export CONF_PATH=$HOME_PATH/conf
export WORK_EXPORT=$HOME_PATH/export
export WORK_IMPORT=$HOME_PATH/import

#更新jiraにてエクスポートされたattachment件数ファイル
export JIRAU_ATTACHMENT_COUNT_EXPORT_LIST=jirau_a_exp_cnt.txt
#更新jiraにてインポートされたattachment件数ファイル
export JIRAU_ATTACHMENT_COUNT_IMPORT_LIST=jirau_a_imp_cnt.txt

#参照jiraにてエクスポートされたattachment件数ファイル
export JIRAR_ATTACHMENT_COUNT_EXPORT_LIST=jirar_a_exp_cnt.txt
#参照jiraにてインポートされたattachment件数ファイル
export JIRAR_ATTACHMENT_COUNT_IMPORT_LIST=jirar_a_imp_cnt.txt

#エクスポートされたasca件数ファイル
export ASCA_COUNT_EXPORT_LIST=asca_exp_cnt.txt
#インポートされたasca件数ファイル
export ASCA_COUNT_IMPORT_LIST=asca_imp_cnt.txt


#更新jiraにてエクスポートされたattachmentのtarファイル
export JIRAU_ATTACHMENT_FILE=JIRAU_ATTACHMENT.tar.gz
#参照jiraにてエクスポートされたattachmentのtarファイル
export JIRAR_ATTACHMENT_FILE=JIRAR_ATTACHMENT.tar.gz
#エクスポートされたascaのtarファイル
export ASCA_FILE=ASCA.tar.gz

DAY_JIRA=-60


# DB名
# GWDB
export GWDB_CON="GWDB user ${A_USER4_ID} using ${A_USER4_PWD}"
# 更新JIRADB
export JIRADBU_CON="JIRADB user ${A_USER2_ID} using ${A_USER2_PWD}"
# 参照JIRADB
export JIRADBR_CON="JIRADBR user ${A_USER3_ID} using ${A_USER3_PWD}"

# ログ
export LOG_NAME=`basename ${0}`_`basename ${1}`.log
# 詳細ログパス
export DETAIL_LOG="${LOG_PATH}/`basename ${0}`_`basename ${1}`_detail_`date +%Y%m%d%H%M%S`.log"
# DBエラー一時ファイル名
export SQLLOG_TMP=${LOG_PATH}/`basename ${0}`_`basename ${1}`.tmp

#########################################################################
# ディスク利用できるサイズチェック関数
# 関数名：CHECK_DISK_FREE_SIZE
# 機能：ディスク利用できるサイズをチェックする
# 引数１：環境区分
# 引数２：サーバIP
# 引数１：ディレクトリ名
# 引数２：最小サイズ（M）
# 戻り値：０－正常
#       1－サイズ不足
#       2－実行異常
#########################################################################
function CHECK_DISK_FREE_SIZE { 
    cflg=$1
    ip=$2
    target_folder=$3
    min_size=$4
    # ディスク利用できるサイズ取得
    if [ "$2" != "localhost" ]; then
	if [ "$1" = "export" ]; then
		REMOTE_EXEC_SH_RSH $ip "df -m $target_folder"
		if [ $? != 0 ]; then
			return 2
		fi
		result=$REMOTE_EXEC_VALUE
	else
		REMOTE_EXEC_SH_SSH $ip "df -m $target_folder"
		if [ $? != 0 ]; then
			return 2
		fi
		result=$REMOTE_EXEC_VALUE
	fi
    else
	result=`df -m $target_folder`
	if [ $? != 0 ]; then
		return 2
	fi
    fi

    # ディスク利用できるサイズチェック
    available=`echo ${result} | awk '{print $(NF-2)}'`
    if [ ${available} -le $min_size ]
    then
        return 1
    else
        return 0
    fi
}

#########################################################################
# ファイル差分作り
# 関数名：CHECK_DISK_FREE_SIZE
# 機能：ディスク利用できるサイズをチェックする
# 引数１：ファイル１
# 引数２：ファイル２
#　引数３：差分結果
# 戻り値：０－正常
#       1－異常
#########################################################################
function DIFF_FILE {
    #差分を作り
    diff -y --suppress-common-line $1 $2 > $3
    RC=$?
    if [ $RC -eq '2' ]
    then
        return 2
    fi
    
    #差分結果チェック
    if [ -s $3 ]; then
        return 1
    fi
    
    return 0
}

###########################################################
# 関数名:outlog_func
#
# 機能:指定されたパスにシェル名.logの名前でログを作成し出力する
#
# 引数
# $1 MSGID
#
# $2 MSG引数
#
# 戻り値
#  0:正常
#  1:異常
#
#
###########################################################
function outlog_func
{

    # ログ名が設定されていない場合呼ばれているシェルをログ名に使用
    if [ ! "${LOG_NAME}" ]; then
            shname=`basename ${0}`
            LOG_NAME=`echo ${shname} | sed "s/.sh//g"`
    fi

	shname=`basename ${0}`

    # ログが存在しない場合作成し権限を変更
    if [ ! -f ${LOG_PATH}/${LOG_NAME} ]; then
            touch ${LOG_PATH}/${LOG_NAME}
            chmod 777 ${LOG_PATH}/${LOG_NAME}
    fi

	error_id=`echo ${1} | cut -b4`

	if [ ${error_id} == "E" ]
	then
	        errorlevel="ERROR"
	elif [ ${error_id} == "W" ]
	then
	        errorlevel="WARNING"
	elif [ ${error_id} == "I" ]
	then
	        errorlevel="INFO"
	elif [ ${error_id} == "F" ]
	then
	        errorlevel="FATAL"
	elif [ ${error_id} == "D" ]
	then
	        errorlevel="DEBUG"
	else
	        echo "エラー出力関数の第一引数に誤りがあります。シェル名[${0}] 第一引数[${1}]"
		return 1
	fi

	logdate=`date "+%Y-%m-%d %H:%M:%S"`

	log_id_msg=`cat ${CONF_PATH}/messges.conf | grep ${1}`
	if [ -z "${log_id_msg}" ]
	then
		echo ${logdate} ${errorlevel} ${shname} "CM-W01001" "メッセージID[${1}]が存在しません。" >> ${LOG_PATH}/${LOG_NAME}
		return 1
	fi

	PARM_CNT=$#
	# 引数の2個目から取得するために初期値を2としている
	MSG_CNT=2
	while (( ${MSG_CNT} <= ${PARM_CNT} ))
	do
		PARM_MSG=`eval echo "\\${${MSG_CNT}}"`

		#%sを引数に変換
		log_id_msg=`echo ${log_id_msg} | sed s@%s@"${PARM_MSG}"@`

		MSG_CNT=`expr $MSG_CNT + 1`
	done

	logmsg="${logdate} ${errorlevel} ${shname} ${log_id_msg}"

	echo ${logmsg} >> ${LOG_PATH}/${LOG_NAME}

	return 0
}

#########################################################################
# 関数名：REMOTE_EXEC_SH_RSH
# 機能：リモートでシェルを実行する
# 引数１：対象IP
# 引数２：パスとシェル名
# 戻り値：０－正常
#		   1－異常
#########################################################################
function REMOTE_EXEC_SH_RSH {

	# 対象IP
	IP=$1
	
	# シェル名
	SH_NAME=$2
	
	# 臨時メッセージ出力ログ
	msg_file1=${TMP_PATH}/`basename ${0}`_ssh_result_`date +%N`.txt
	msg_file2=${TMP_PATH}/`basename ${0}`_ssh_result_`date +%N`.txt
	# リモートシェル実行
	#rsh ${IP} "${SH_NAME}&& echo 'comm_success' 1>&2 ||echo 'comm_failed' 1>&2" >${msg_file1} 2>${msg_file2}
	rsh ${IP} "${SH_NAME}&& echo 'comm_success' 1>&2 ||echo 'comm_failed' 1>&2" >${msg_file1} 2>${msg_file2}

	FC_RC2=`cat ${msg_file2}`
	FC_RC1=`cat ${msg_file1}`
	
	
	
	echo ${FC_RC2} | grep  "comm_success" > /dev/null
	if [ $? = "0" ]
	then
		export REMOTE_EXEC_VALUE=`cat ${msg_file1}`
		rm -f ${msg_file1} ${msg_file2}
		return 0
	fi
	
	export REMOTE_EXEC_VALUE=`cat ${msg_file2}`
	rm -f ${msg_file1} ${msg_file2}
	outlog_func CM-E99026 ${IP} "${SH_NAME}" "${FC_RC2}"
	return 1

}

#########################################################################
# 関数名：REMOTE_COPY
# 機能：リモートでファイルをコピーする
# 引数１：コピー元（[<IP>]:<パス><ファイル名>）
# 引数２：コピー先（[<IP>]:<パス>）
# 戻り値：０－正常
#		   1－異常
#########################################################################
function REMOTE_COPY_RCP {

	# コピー元
	SCP_FROM=$1
	
	# コピー先
	SCP_TO=$2
	
	# リモートファイルコピー
	rcp -p ${SCP_FROM} ${SCP_TO}
	RC=$?
	
	# 戻り値が0以外の場合はエラー
	if [ ${RC} != '0' ]
	then
		outlog_func CM-E99027 ${SCP_FROM} ${SCP_TO} ${RC}
	fi
	
	return ${RC}
}


#########################################################################
# rshコマンドはsshで置き換える
# 関数名：REMOTE_EXEC_SH
# 機能：リモートでシェルを実行する
# 引数１：対象IP
# 引数２：パスとシェル名
# 戻り値：０－正常
#		   1－異常
#########################################################################
function REMOTE_EXEC_SH_SSH {

	# 対象IP
	IP=$1
	
	# シェル名
	SH_NAME=$2
	
	# 臨時メッセージ出力ログ
	msg_file=${TMP_PATH}/`basename ${0}`_ssh_result_`date +%Y%m%d`.txt
	
	# リモートシェル実行
	ssh ${IP} ${SH_NAME} > ${msg_file} 2>&1
	RC=$?
	export REMOTE_EXEC_VALUE=`cat ${msg_file}`
	
	rm -f ${msg_file}
	
	# 戻り値が0以外の場合はエラー
	if [ ${RC} != "0" ]
	then
		outlog_func CM-E99028 "${IP}" "${SH_NAME}" "${RC}" "${REMOTE_EXEC_VALUE}"
	fi
	
	return ${RC}
}

#########################################################################
# rcpコマンドはscpで置き換える
# 関数名：REMOTE_COPY
# 機能：リモートでファイルをコピーする
# 引数１：コピー元（[<IP>]:<パス><ファイル名>）
# 引数２：コピー先（[<IP>]:<パス>）
# 戻り値：０－正常
#		   1－異常
#########################################################################
function REMOTE_COPY_SCP {

	# コピー元
	SCP_FROM=$1
	
	# コピー先
	SCP_TO=$2
	
	# リモートファイルコピー
	scp -p ${SCP_FROM} ${SCP_TO} 
	RC=$?
	
	# 戻り値が0以外の場合はエラー
	if [ ${RC} != '0' ]
	then
		outlog_func CM-E99029 "${SCP_FROM}" "${SCP_TO}" "${RC}"
	fi
	
	return ${RC}
}
#########################################################################
#失敗の共通処理
# 関数名：delete_remote_tar
# 機能：リモートのでファイルを削除する
# 引数１：リモートのIP
# 引数2：ファイルの置場
# 戻り値：０－正常
#		   1－異常
#########################################################################
function DELETE_REMOTE_TAR
{
	_IP=${1}
	_FILE=${2}
	
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} # 移行作業失敗のログ
	#サーバにて中途半端のtarfileを削除する
	case ${export_or_import_flag} in
	"export")
		REMOTE_EXEC_SH_RSH ${_IP} "rm -f ${_FILE}"
		;;
	"import")
		REMOTE_EXEC_SH_SSH ${_IP} "rm -f ${_FILE}"
		;;
	esac		
	
	if [ $? != "0" ]
	then
		outlog_func JA-W01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} # 削除コマンドの失敗のログ
		echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 5`" >> ${LOG_PATH}/${LOG_NAME}		
	fi
}

function DELETE_LOCAL_TAR
{
	rm -rf ${1}
	RC=$?
	if [ ${RC} != "0" ]
	then
		echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 5` ローカルファイルの削除失敗 " >> ${LOG_PATH}/${LOG_NAME}
	fi
	return ${RC}
}


#########################################################################
#attachment件数ファイル作成処理
#########################################################################
#ATTACHMENT_COUNTS_CREATE
function CREATE_ATTACHMENT_COUNTS
{
	_IP=${1}
	_EXPORT_LIST=${2}

	commd="echo -e GC \$( ls ${_A_PATH}/GC 2>/dev/null | wc -l )\\\n"\
"BT \$(ls ${_A_PATH}/BT 2>/dev/null | wc -l)\\\n"\
"CE \$(ls ${_A_PATH}/CE 2>/dev/null | wc -l)\\\n"\
"CT \$(ls ${_A_PATH}/CT 2>/dev/null | wc -l)\\\n"\
"UD \$(ls ${_A_PATH}/UD 2>/dev/null | wc -l)\\\n"\
"GE \$(ls ${_A_PATH}/GE 2>/dev/null | wc -l)"


	case ${export_or_import_flag} in
	"export")
		REMOTE_EXEC_SH_RSH ${_IP} "${commd}"
		;;
	"import")
		REMOTE_EXEC_SH_SSH ${_IP} "${commd}"
		;;
	esac	
	if [ $? != "0" ]
	then
		echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 2` || コマンド結果:\n`echo ${REMOTE_EXEC_VALUE}`" >>${DETAIL_LOG}
		return 1
	fi
	cat /dev/null > ${_EXPORT_LIST}
	OLD_IFS=${IFS}
	IFS='\n'
	echo ${REMOTE_EXEC_VALUE} >> ${_EXPORT_LIST}
	IFS=${OLD_IFS}
	return 0
}

#########################################################################
#asca件数ファイル作成処理
#########################################################################
#ASCA_COUNTS_CREATE
function CREATE_ASCA_COUNTS
{
	cat /dev/null > ${1}
	echo -e ASCA $(ls ${_A_PATH} | grep B[MD]07 | wc -l ) >> ${1}
	if [ $? != "0" ]
	then
		return 1
	fi
	return 0
}
