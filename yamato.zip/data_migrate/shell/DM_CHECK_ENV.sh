#!/bin/sh

HOME="/tools/data_migrate"

#導入導出別
param=$1

#入力パラメータチェック
case ${param} in
    "import" )
         . /workflow/auth_mgr/decrypt/ASCA_DECRYPT_MANAGER.sh ALL
    ;;
    "export" )
         . /hdcd_removal/decrypt/ASCA_DECRYPT_MANAGER.sh ALL
    ;;
    * )
        echo "入力パラメータ不正。下記のようなパラメータを付けてください"
        echo "import --新環境"
        echo "export --旧環境"
        exit 1
    ;;
esac

# 共通関数呼び出し
. ${HOME}/shell/DM_COMMON.sh
rc1=$?

#環境設定を行う
. $CONF_PATH/dm_${param}_env.conf
rc2=$?

if [ $rc1 != 0 -o $rc2 != 0 ]; then
    exit 1
fi

chk_flg=0
outlog_func CK-I01001


#DISKチェック
echo " JIRAU $JIRAU_IP DISKチェック中"
CHECK_DISK_FREE_SIZE $param $JIRAU_IP $JIRAU_A_TAR_PATH $JIRAU_A_MIN_SIZE
RC=$?
if [ $RC = 1 ]; then
    echo " JIRAU DISKチェック失敗"
    outlog_func CK-E01002 "更新JIRA" "$JIRAU_A_MIN_SIZE" "$JIRAU_IP"
    chk_flg=1
elif [ $RC = 2 ]; then
    echo " JIRAU DISKチェック失敗"
    outlog_func CK-E01009 "更新JIRA" $JIRAU_IP
    chk_flg=1
else
    echo " JIRAU DISKチェック成功"
    outlog_func CK-I01003 "更新JIRA" $JIRAU_IP
fi

echo " JIRAR $JIRAR_IP DISKチェック中"
CHECK_DISK_FREE_SIZE $param $JIRAR_IP $JIRAR_A_TAR_PATH $JIRAR_A_MIN_SIZE
RC=$?
if [ $RC = 1 ]; then
    echo " JIRAR DISKチェック失敗"
    outlog_func CK-E01002 "参照JIRA" "$JIRAR_A_MIN_SIZE" "$JIRAR_IP"
    chk_flg=1
elif [ $RC = 2 ]; then
    echo " JIRAR DISKチェック失敗"
    outlog_func CK-E01009 "参照JIRA" $JIRAR_IP
    chk_flg=1
else
    echo " JIRAR DISKチェック成功"
    outlog_func CK-I01003 "参照JIRA" $JIRAR_IP
fi

echo " GW/JP1 DISKチェック中"
CHECK_DISK_FREE_SIZE $param localhost $TMP_PATH $GW_MIN_SIZE
RC=$?
if [ $RC = 1 ]; then
    echo " GW/JP1 DISKチェック失敗"
    outlog_func CK-E01002 "GW" $GW_MIN_SIZE "localhost"
    chk_flg=1
elif [ $RC = 2 ]; then
    echo " GW/JP1 DISKチェック失敗"
    outlog_func CK-E01009 "GW" "localhost"
    chk_flg=1
else
    echo " GW/JP1 DISKチェック成功"
    outlog_func CK-I01003 "GW" "localhost"
fi

#DB接続チェック
db_name=("JIRADBU" "JIRADBR" "GWDB")
for i in "${!db_name[@]}"; do
    #DB接続INFO名を構築(JIRADBU_CON JIRADBR_CON GWDB_CON)
    echo "${db_name[i]} DB接続チェック中"
    db_con=${db_name[i]}_CON
    # DBに接続
    db2 connect to ${!db_con} > ${SQLLOG_TMP}
    SQLERROR=$?
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    if [ ${SQLERROR} != 0 ]; then
        echo "${db_name[i]} DB接続チェック失敗"
        outlog_func CK-E01004 ${db_name[i]}
        chk_flg=1
    else
        echo "${db_name[i]} DB接続チェック成功"
        outlog_func CK-I01005 ${db_name[i]}
    fi

    #tablespaceがpending中かチェックする
    db2 list tablespaces | grep -Ei "pending|ペンディング"
    rc=$?
    if [ $rc = 0 ]; then
        echo "${db_name[i]} tablespace 状態がPENDINDです。ご確認ください"
        outlog_func CK-E01010 ${db_name[i]}
        chk_flg=1
    fi

    echo "${db_name[i]} table pending状態チェック中"
    #tableがpending中かチェックする
    #空ファイルを作成
    touch ${TMP_PATH}/empfile
    exec 3<$CONF_PATH/dm_$(echo ${db_name[i]} | tr '[A-Z]' '[a-z]')_tables.conf
    while read table_nm<&3
    do
         db2 load query table ${table_nm} | grep -Ei "pending|ペンディング"
         rc=$?
         if [ $rc = 0 ]; then
             #load pending状態解除
             db2 load from ${TMP_PATH}/empfile of del replace into ${table_nm} nonrecoverable
             echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
             #set integrity pending状態解除
             db2 set integrity for $table_nm immediate checked > ${SQLLOG_TMP}
             echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
             db2 load query table ${table_nm} | grep -Ei "pending|ペンディング"
             rc=$?
             if [ $rc = 0 ]; then
                 echo "${db_name[i]} table pending状態解除失敗"
                 outlog_func CK-E01011 ${db_name[i]} $table_nm
                 chk_flg=1
             else
                 echo "${db_name[i]} table pending状態解除成功"
                 outlog_func CK-W01012 ${db_name[i]} $table_nm
             fi
         fi
    done
    #空ファイルを削除
    rm -f ${TMP_PATH}/empfile

    #接続切断
    db2 terminate > ${SQLLOG_TMP}
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
done

#JIRA ONLINE CHECK
if [ "${param}" = "import" ]; then
    #更新JIRA
    REMOTE_EXEC_SH_SSH $JIRAU_IP "lssam -nocolor -g RG_JIRA | head -1 | grep '^Online.*IBM'"
    rc1=$?
    if [ $rc1 = 0 ]; then
        echo "JIRAUの状態がONLINEです"
        outlog_func CK-I01007 "更新JIRA" $JIRAU_IP
    else
        echo "JIRAUの状態がOFFLINEです、JIRAをスタートください"
        outlog_func CK-E01006 "更新JIRA" $JIRAU_IP
        chk_flg=1
    fi
    #参照JIRA
    REMOTE_EXEC_SH_SSH $JIRAR_IP "lssam -nocolor -g RG_JIRA | head -1 | grep '^Online.*IBM'"
    rc2=$?
    if [ $rc2 = 0 ]; then
        echo "JIRARの状態がONLINEです"
        outlog_func CK-I01007 "参照JIRA" $JIRAR_IP
    else
        echo "JIRARの状態がOFFLINEです。JIRAをスタートください"
        outlog_func CK-E01006 "参照JIRA" $JIRAR_IP
        chk_flg=1
    fi
fi

outlog_func CK-I01008 

echo "チェック実行終了"

exit $chk_flg