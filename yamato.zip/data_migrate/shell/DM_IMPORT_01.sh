#!/bin/sh

#########################################################################
#環境設定を行う
#########################################################################
HOME="/tools/data_migrate"

# 共通関数呼び出し
. ${HOME}/shell/DM_COMMON.sh
RC1=$?

. ${CONF_PATH}/dm_import_env.conf
RC2=$?

if [ ${RC1} != "0" ] || [ ${RC2} != "0" ];then
	exit 1
fi

export_or_import_flag=import

# 引数${1}より環境変数を設定する
case ${1} in
	"jirau")
	    _NAME=attachment
		#分岐処理のため、設定された変数
		_TYPE=update
		#ターゲットサーバのIP
		_IP=${JIRAU_IP}
		#ターゲットサーバのアタッチメントのパス
		_A_PATH=${JIRAU_A_PATH}
		_COUNT_IMPORT_LIST=${JIRAU_ATTACHMENT_COUNT_IMPORT_LIST}
		_COUNT_EXPORT_LIST=${JIRAU_ATTACHMENT_COUNT_EXPORT_LIST}
		_IMPORT_FILE=${JIRAU_ATTACHMENT_FILE}
		TAR_TO_FOLDER_GRP=${JIRAU_A_TAR_PATH}
		;;
	"jirar")
		_NAME=attachment
		_TYPE=reference
		_IP=${JIRAR_IP}
		_A_PATH=${JIRAR_A_PATH}
		_COUNT_IMPORT_LIST=${JIRAR_ATTACHMENT_COUNT_IMPORT_LIST}
		_COUNT_EXPORT_LIST=${JIRAR_ATTACHMENT_COUNT_EXPORT_LIST}
		_IMPORT_FILE=${JIRAR_ATTACHMENT_FILE}
		TAR_TO_FOLDER_GRP=${JIRAR_A_TAR_PATH}
		;;
	*)
		echo "パラメータ不正[入力したパラメータの定義不正]"
		exit 1
		;;
esac

# 開始メッセージ
outlog_func JA-I01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}

# 全プロセス処理時間の統計変数
pro_time_1=`date +%s`

#インポートファイルの存在をチェックする
if [ ! -f ${WORK_EXPORT}/${_IMPORT_FILE} ]
then
	#ローカルにインポートファイルが存在しません
	outlog_func JA-E06002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} 
 	exit 1
fi
#転送開始のログ
outlog_func JA-I03001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}

# 転送コマンド実施時間の計算変数
pro_time_2=`date +%s`

# 転送コマンドの実施
REMOTE_COPY_SCP "${WORK_EXPORT}/${_IMPORT_FILE}" "${_IP}:${TAR_TO_FOLDER_GRP}/${_IMPORT_FILE}"
if [ $? != "0" ]
then
	# 転送コマンドの失敗のログ
	outlog_func JA-E03001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 5` " >> ${LOG_PATH}/${LOG_NAME}
	DELETE_REMOTE_TAR "${_IP}" "${TAR_TO_FOLDER_GRP}/${_IMPORT_FILE}"
	exit 1
fi
#転送終了のログ
outlog_func JA-I03002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} $(( `date +%s` - pro_time_2 ))

#既存ファイルの削除
REMOTE_EXEC_SH_SSH ${_IP} "rm -rf ${_A_PATH}/BT ${_A_PATH}/CE ${_A_PATH}/CT ${_A_PATH}/GC ${_A_PATH}/GE ${_A_PATH}/UD"
if [ $? != "0" ]
then
	# 削除コマンドの失敗のログ
	outlog_func JA-W01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}　
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 4` || コマンド結果:\n`echo ${REMOTE_EXEC_VALUE}`" >>${DETAIL_LOG}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 6`" >> ${LOG_PATH}/${LOG_NAME}
	# リモートの中途半端のtarファイルを削除する
	DELETE_REMOTE_TAR "${_IP}" "${TAR_TO_FOLDER_GRP}/${_IMPORT_FILE}"
	exit 1
fi

# 解凍コマンド実施時間の計算変数
pro_time_3=`date +%s`

outlog_func JA-I04001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
REMOTE_EXEC_SH_SSH ${_IP} "tar -zxf ${TAR_TO_FOLDER_GRP}/${_IMPORT_FILE} -C ${_A_PATH} ."
if [ $? != "0" ]
then
	outlog_func JA-E04001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 4` || コマンド結果:\n`echo ${REMOTE_EXEC_VALUE}`" >>${DETAIL_LOG}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 5` " >> ${LOG_PATH}/${LOG_NAME}
	DELETE_REMOTE_TAR "${_IP}" "${TAR_TO_FOLDER_GRP}/${_IMPORT_FILE}"
	REMOTE_EXEC_SH_SSH ${_IP} "rm -rf ${_A_PATH}/BT ${_A_PATH}/CE ${_A_PATH}/CT ${_A_PATH}/GC ${_A_PATH}/GE ${_A_PATH}/UD"
	exit 1
fi

#解凍作業終了ログ
outlog_func JA-I04002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH} $(( `date +%s` - pro_time_3 ))

#件数を出力する
CREATE_ATTACHMENT_COUNTS ${_IP} ${WORK_IMPORT}/${_COUNT_IMPORT_LIST}
if [ $? != "0" ]
then
	outlog_func JA-E01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 5` 件数ファイルの出力がエラーになる" >> ${LOG_PATH}/${LOG_NAME}	
	DELETE_REMOTE_TAR "${_IP}" "${TAR_TO_FOLDER_GRP}/${_IMPORT_FILE}"
	REMOTE_EXEC_SH_SSH ${_IP} "rm -rf ${_A_PATH}/BT ${_A_PATH}/CE ${_A_PATH}/CT ${_A_PATH}/GC ${_A_PATH}/GE ${_A_PATH}/UD"
	exit 1
fi


#インポートの件数チェックを行う。
if [ ! -f ${WORK_EXPORT}/${_COUNT_EXPORT_LIST} ]
then
	outlog_func JA-E05002 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	DELETE_REMOTE_TAR "${_IP}" "${TAR_TO_FOLDER_GRP}/${_IMPORT_FILE}"
	REMOTE_EXEC_SH_SSH ${_IP} "rm -rf ${_A_PATH}/BT ${_A_PATH}/CE ${_A_PATH}/CT ${_A_PATH}/GC ${_A_PATH}/GE ${_A_PATH}/UD"
	exit 1
fi 

DIFF_FILE "${WORK_EXPORT}/${_COUNT_EXPORT_LIST}" "${WORK_IMPORT}/${_COUNT_IMPORT_LIST}" "${WORK_IMPORT}/${_COUNT_IMPORT_LIST%_*}_check_result.txt"
if [ $? != "0" ]
then
    outlog_func JA-E05001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
	DELETE_REMOTE_TAR "${_IP}" "${TAR_TO_FOLDER_GRP}/${_IMPORT_FILE}"
	REMOTE_EXEC_SH_SSH ${_IP} "rm -rf ${_A_PATH}/BT ${_A_PATH}/CE ${_A_PATH}/CT ${_A_PATH}/GC ${_A_PATH}/GE ${_A_PATH}/UD"
	exit 1
fi

# リモートのファイルを削除する
REMOTE_EXEC_SH_SSH ${_IP} "rm -f ${TAR_TO_FOLDER_GRP}/${_IMPORT_FILE}"
if [ $? != "0" ]
then
	echo -e "`date "+%Y-%m-%d %H:%M:%S"` ERROR  shell名:`basename ${0}`  行番号:`expr ${LINENO} - 3` || コマンド結果:\n`echo ${REMOTE_EXEC_VALUE}`"  >> ${LOG_PATH}/${LOG_NAME}
	# 削除コマンドの失敗のログ
	outlog_func JA-W01001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}
fi

outlog_func JA-I05001 ${_NAME} ${_TYPE} ${_IP} ${_A_PATH}