#!/bin/bash
################### モジュール説明 #############################################
# モジュール名   ： FILE_ARCHIVE_BACKUP.sh
# システム名     ： ファイルアーカイブ・退避処理
# 業 務 名       ： 共通
# 機 能 名       ： アーカイブ
# 言語           ： bash
# ＯＳ           ： Linux (Red hat)
# 処理概要       ： tarファイルを圧縮し・移動します。
# 特記事項       ： なし
# パラメータ     ： なし
# ログファイル   ： FILE_ARCHIVE_BACKUP.log, FILE_ARCHIVE_BACKUP_YYYYMMDDHHMMSS.log
# リターンコード ： 正常終了(0)
#                  処理異常(1)
# 対象DB         ： なし
#
################### モジュール説明 #############################################
#
################### 改定履歴       #############################################
# 作成者         ： Tang.Xiaodong
# 作成日付       ： 2012-08-20
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
# 1初版     2012-08-20  Tang.Xiaodong                新規作成
# 2		  2013-07-29  Tang.Xiaodong		    mount/unmount追加
# 3       2014-10-23  LiuJian		        mount path変更
# 4
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
################### 改定履歴       #############################################

################################################################################
# 環境設定を行う
################################################################################

# 現在日付取得
ndates=`date "+%Y%m%d%H%M%S"`

# 環境設定ファイルを読み込む
_exec_ksh=/workflow/batch/ini/batch_common_all.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# ログ名設定
detaillog="${LOG_DIR}/FILE_ARCHIVE_BACKUP_detail_${ndates}.log"

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC_ALL.sh

# ファイルアーカイブ関数
# 関数名         ：tar_files
# 処理概要       ：バックアップファイルをハウスキープディレクトリに圧縮する。
# 引数           ：	１、タイプ
# リターンコード ：0(正常)
#                ：1(異常)
# 対象DB         ：なし
function tar_files
{
	# ファイル数を取得する
	file_cnt=`find ${BACKUP_DIR} -name bak_${1}*.tar -type f -print | wc -l`
	if [ "${file_cnt}" = "0" ]
	then
		outlog_func CM-I10304 "${1}"
		return 0
	fi

	# ディレクトリを作成する
	if [ ! -d ${HOUSEKEEP_DIR}/${1}server ]
	then
		mkdir ${HOUSEKEEP_DIR}/${1}server 2>> ${detaillog} 1> /dev/null
	fi

	# ファイルをアーカイブする
	ts=`date "+%Y-%m-%d %H:%M:%S,%N"`
	echo "${ts} Archive:" >> ${detaillog}

	hostname=`hostname -s`
	gz_name="${HOUSEKEEP_DIR}/${1}server/${hostname}_housekeep_${ndates}.gz"
	tar -cvzf ${gz_name} ${BACKUP_DIR}/bak_${1}*.tar >> ${detaillog}  2>&1
	RC=$?
	if [ "$RC" != "0" ]
	then
		outlog_func CM-E10306 ${RC}
		return 1
	fi

	outlog_func CM-I10305 ${gz_name}
	return 0
}



################################################################################
# MAIN処理
################################################################################

# ログをクリアする
cp /dev/null ${LOG_DIR}/FILE_ARCHIVE_BACKUP.log

# 開始メッセージ
outlog_func CM-I10301

# バックアップサーバへmountする
mount ${HOUSEKEEP_DIR} >> ${detaillog} 2>&1
RC=$?
if [ ${RC} -eq 0 ]
then
	outlog_func CM-I10309
else
	outlog_func CM-E10303 ${HOUSEKEEP_DIR} ${RC}
	exit 1
fi

# ファイルをアーカイブする
tar_files "JP_"
RC=$?
if [ "${RC}" != "0" ]
then
	exit 1
fi
tar_files "DL_"
RC=$?
if [ "${RC}" != "0" ]
then
	exit 1
fi

# ファイルを削除する
echo "Delete:" >> ${detaillog}
rm -fv ${BACKUP_DIR}/bak_*.tar  >> ${detaillog} 2>&1
RC=$?
if [ "$RC" != "0" ]
then
	outlog_func CM-E10308 ${RC}
	exit 1
fi
outlog_func CM-I10307

# バックアップディレクトリをUnmountする
umount ${HOUSEKEEP_DIR} >> ${detaillog} 2>&1
RC=$?
if [ ${RC} -eq 0 ]
then
	outlog_func CM-I10310
else
	outlog_func CM-E10311 ${RC}
	exit 1
fi

# 終了メッセージ
outlog_func CM-I10302

# ログを複製する
cp -f ${LOG_DIR}/FILE_ARCHIVE_BACKUP.log ${LOG_DIR}/FILE_ARCHIVE_BACKUP_${ndates}.log
