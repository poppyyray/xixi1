#!/bin/bash
################### モジュール説明 #############################################
# モジュール名   ： FILE_ARCHIVE.sh
# システム名     ： ファイルアーカイブ処理
# 業 務 名       ： 共通
# 機 能 名       ： アーカイブ
# 言語           ： bash
# ＯＳ           ： Linux (Red hat)
# 処理概要       ： 保存期限の切れた指定ファイルをアーカイブ・削除する。
# 特記事項       ： アーカイブ対象設定ファイルが存在すること。
# パラメータ     ： なし
# ログファイル   ： FILE_ARCHIVE.log, FILE_ARCHIVE_YYYYMMDDHHMMSS.log
# リターンコード ： 正常終了(0)
#                  処理異常(1)
# 対象DB         ： なし
#
################### モジュール説明 #############################################
#
################### 改定履歴       #############################################
# 作成者         ： Tang.Xiaodong
# 作成日付       ： 2012-08-17
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
# 1初版     2009-08-17  Tang.Xiaodong                新規作成
# 2
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
################### 改定履歴       #############################################

################################################################################
# 環境設定を行う
################################################################################

# 現在日付取得
ndates=`date "+%Y%m%d%H%M%S"`

# 環境設定ファイルを読み込む
_exec_ksh=/workflow/batch/ini/batch_common_all.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# ログ名設定
detaillog="${LOG_DIR}/FILE_ARCHIVE_detail_${ndates}.log"

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC_ALL.sh

################################################################################
# 個別環境設定を行う
################################################################################
# 処理対象データ設定ファイルを読み込む
export _arclist=${CONF_DIR}/archive.conf

# 臨時ディレクトリ
tmp_dir="${TMP_DIR}/backup_tmp_${ndates}/"

# ファイルバックアップ関数
# 関数名         ：file_backup
# 処理概要       ：保有期限切れたファイルをバックアップする
# 引数           ：	1、ディレクトリ
#				2、ファイル名
#				3、アーカイブ名
#				4、保存日数
#				5、保存行数
#				6、対象定義行数
# リターンコード ：0(正常)
#                ：1(異常)
# 対象DB         ：なし
function file_backup
{
	# アーカイブ名はブランクの場合、処理なし。
	if [ -z "${3}" ]
	then
		outlog_func CM-I10205 ${1} ${6}
		return 0
	fi

	# バックアップ開始メッセージ
	outlog_func CM-I10206 ${1} ${6}

	ts=`date "+%Y-%m-%d %H:%M:%S,%N"`
	echo "${ts} Line ${6} Backup:" >> ${detaillog}

	# 保存行数が０の場合
	if [ "${5}" == "0" ]
	then
		# 保存日数以前のファイルをfind、臨時ディレクトリにコピーする
		find ${1} -maxdepth 1 -name "${2}" -mtime ${4} -type f -print -exec cp -p {} ${tmp_dir} \; >> ${detaillog} 2>&1
		RC=$?
		if [ "${RC}" != "0" ]
		then
			outlog_func CM-E10213 ${RC}
			return 1
		fi
	# 保存行数が０以外の場合
	else
		# ファイルリストをファイルに出力する
		find ${1} -maxdepth 1 -name "${2}" -type f > ${TMP_DIR}/cut_lines_files.txt 2>> ${detaillog}
		RC=$?
		if [ "${RC}" != "0" ]
		then
			outlog_func CM-E10223 ${RC}
			return 1
		fi

		# 保存行数以外の内容を取得する
		while read fname_line
		do
			# ファイルの行数を取得する
			total_line_cnt=`cat ${fname_line} | wc -l`
			RC=$?
			if [ "${RC}" != "0" ]
			then
				outlog_func CM-E10224 "${fname_line}" "${RC}"
				return 1
			fi

			# ファイル行数は保存行数より少ない場合、処理なし
			if [ ${total_line_cnt} -le ${5} ]
			then
				continue
			fi

			# バックアップ行数を取得する
			bkup_line_cnt=$(expr ${total_line_cnt} - ${5})

			# ファイル名の取得（パスを外す）
			file_name="${fname_line##*/}"

			# バックアップ行数の内容を臨時ディレクトリに出力する
			head -n ${bkup_line_cnt} ${fname_line} > ${tmp_dir}${file_name} 2>> ${detaillog}
			RC=$?
			if [ "${RC}" != "0" ]
			then
				outlog_func CM-E10225 "${fname_line}" "${RC}"
				return 1
			fi
			echo ${1}${file_name} >> ${detaillog}
		done < ${TMP_DIR}/cut_lines_files.txt
	fi

	outlog_func CM-I10212

	# ファイル数を取得する
	file_cnt=`find ${tmp_dir} -maxdepth 1 -type f -print | wc -l`
	if [ "${file_cnt}" = "0" ]
	then
		outlog_func CM-I10214
		return 0
	fi

	# 臨時ディレクトリをアーカイブする
	tar_name="${BACKUP_DIR}/bak_${3}_${ndates}.tar"
	tar -cvf ${tar_name} ${tmp_dir} 2>> ${detaillog} 1> /dev/null
	RC=$?
	if [ "$RC" != "0" ]
	then
		outlog_func CM-E10216 ${RC}
		return 1
	fi
	outlog_func CM-I10215 ${tar_name} ${file_cnt}

	# 臨時ディレクトリをクリアする
	find ${tmp_dir} -type f -exec rm -f {} \; 2>> ${detaillog} 1> /dev/null

	# バックアップ終了メッセージ
	outlog_func CM-I10207 ${1} ${6}
}

# ファイル削除関数
# 関数名         ：file_remove
# 処理概要       ：保有期限切れたファイルを削除する
# 引数           ：	1、ディレクトリ
#				2、ファイル名
#				3、保存日数
#				4、保存行数
#				5、対象定義行数
# リターンコード ：0(正常)
#                ：1(異常)
# 対象DB         ：なし
function file_remove
{
	# 削除処理開始メッセージ
	outlog_func CM-I10218 ${1} ${5}

	ts=`date "+%Y-%m-%d %H:%M:%S,%N"`
	echo "${ts} Line ${5} Delete:" >> ${detaillog}

	# 保存日数は０以外の場合、保存日数でfind
	if [ "${3}" != "0" ]
	then
		# 保存行数は０の場合、find結果ファイルを削除する
		find ${1} -maxdepth 1 -name "${2}" -mtime ${3} -type f -print -exec rm -f {} \; >> ${detaillog} 2>&1

		RC=$?
		if [ "${RC}" != "0" ]
		then
			outlog_func CM-E10221 ${RC}
			return 1
		fi
		outlog_func CM-I10220

	# 保存日数は０の場合、保存日数制限ないでfind
	else
		# find結果ファイルリストをファイルに出力する
		find ${1} -maxdepth 1 -name "${2}" -type f > ${TMP_DIR}/cut_lines_files.txt 2>> ${detaillog}
		RC=$?
		if [ "${RC}" != "0" ]
		then
			outlog_func CM-E10223 ${RC}
			return 1
		fi

		# 保存行数の内容を保留する
		while read fname_line
		do
		
			# ファイルの行数を取得する
			total_line_cnt=`cat ${fname_line} | wc -l`
			RC=$?
			if [ "${RC}" != "0" ]
			then
				outlog_func CM-E10224 "${fname_line}" "${RC}"
				return 1
			fi

			# ファイル行数は保存行数より少ない場合、処理なし
			if [ ${total_line_cnt} -le ${4} ]
			then
				continue
			fi
		
			# 保留行数以外の内容を削除する
			tail -n ${4} ${fname_line} > ${TMP_DIR}/hk_tmp 2>> ${detaillog}
			RC=$?
			if [ "${RC}" == "0" ]
			then
				cp -f ${TMP_DIR}/hk_tmp ${fname_line} 2>> ${detaillog}
			fi
			RC=$?
			if [ "${RC}" != "0" ]
			then
				outlog_func CM-E10228 "${fname_line}" "${RC}"
				return 1
			fi
			echo ${fname_line} >> ${detaillog}
		done < ${TMP_DIR}/cut_lines_files.txt
	fi

	# 削除処理終了メッセージ
	outlog_func CM-I10219 ${1} ${5}
}

################################################################################
# MAIN関数
################################################################################
function main
{
    # ディスクフリーサイズのチェック
    CHECK_DISK_FREE_SIZE ${TMP_DIR} ${HOUSEKEEP_MIN_FREE_DISK_SIZE}
	RC=$?
	if [ "${RC}" != "0" ]
	then
		return 1
	fi

    # 定義ファイルチェック
    if [ ! -f ${_arclist} ]
    then
		outlog_func CM-E10203 ${_arclist}
	return 1
    fi

    # 対象情報取得
    lineno=0
    while read line;do
    	# 注釈ラインをブランクに認定
    	if [[ ${line} == "#"* ]]
    	then
    		line=""
    		continue
    	fi
        array[${lineno}]=${line}
        lineno=$(expr ${lineno} + 1)
    done < ${_arclist}

	# 臨時ディレクトリ作成
	rm -rf ${tmp_dir} 2>> ${detaillog} 1> /dev/null
	mkdir ${tmp_dir} 2>> ${detaillog} 1> /dev/null
	RC=$?
	if [ "${RC}" != "0" ]
	then
		outlog_func CM-E10209 ${tmp_dir} ${RC}
		return 1
	fi
	outlog_func CM-I10208 ${tmp_dir}

    # バックアップ・削除処理
    lineno=0
    rtncd="0"
    for i in "${array[@]}";do
		lineno=$(expr ${lineno} + 1)

		# ブランクの行を無視する
		if [ "${i}" == "" ]
		then
			continue
		fi

		# 対象情報エレメント分割
        path=`echo ${i} | awk -F, '{print $1}'`
        fname=`echo ${i} | awk -F, '{print $2}'`
        bkname=`echo ${i} | awk -F, '{print $3}'`
        bklimit=`echo ${i} | awk -F, '{print $4}'`
        line_cnt=`echo ${i} | awk -F, '{print $5}'`

	    # ディレクトリのチェック
	    if [ ! -d ${path} ]
	    then
			continue
	    fi

	    # ファイル名のチェック
	    if [ -z "${fname}" ]
	    then
			continue
	    fi

	    # アーカイブ名のチェック
	    if [ -n "${bkname}" -a "${bkname#JP_*}" == "${bkname}" -a "${bkname#DL_*}" == "${bkname}" ]
	    then
			outlog_func CM-E10204 アーカイブ名 "${bkname}" "${lineno}"
			return 1
	    fi

	    # 保存日数と保存行数のチェック
	    no_symbol="${bklimit#[+-]}"
	    if [ -z "${no_symbol}" -o -n "${no_symbol//[0-9]/}" ]
	    then
			outlog_func CM-E10204 保存日数 "${bklimit}" "${lineno}"
			return 1
	    fi
	    if [ -z "${line_cnt}" -o -n "${line_cnt//[0-9]/}" ]
	    then
			outlog_func CM-E10204 保存行数 "${line_cnt}" "${lineno}"
			return 1
	    fi
	    if [ "${bklimit}" == "0" -a "${line_cnt}" == "0" ]
	    then
	    	outlog_func CM-E10226 "${lineno}"
	    	return 1
	    fi
	    if [ "${bklimit}" != "0" -a "${line_cnt}" != "0" ]
	    then
	    	outlog_func CM-E10227 "${lineno}"
	    	return 1
	    fi

	    # ファイルバックアップ処理
	    file_backup "${path}" "${fname}" "${bkname}" "${bklimit}" "${line_cnt}" "${lineno}"
	    RC=$?
	    if [ "${RC}" != "0" ]
	    then
			return 1
	    fi

	    # ファイル削除処理
	    file_remove "${path}" "${fname}" "${bklimit}" "${line_cnt}" "${lineno}"
	    RC=$?
	    if [ "${RC}" != "0" ]
	    then
			return 1
	    fi

    done

	# 臨時ディレクトリ削除
	rm -rf ${tmp_dir}
	RC=$?
	if [ "${RC}" != "0" ]
	then
		outlog_func CM-W10211 ${tmp_dir} ${RC}
		return 1
	fi
	outlog_func CM-I10210 ${tmp_dir}

    return 0
}

################################################################################
# MAIN処理
################################################################################

# ログをクリアする
cp /dev/null ${LOG_DIR}/FILE_ARCHIVE.log

# 開始メッセージ
outlog_func CM-I10201

# 関数呼び出し
main
RC=$?
if [ "${RC}" != "0" ]
then
    outlog_func CM-E10222

    # ログを複製する
	cp -f ${LOG_DIR}/FILE_ARCHIVE.log ${LOG_DIR}/FILE_ARCHIVE_${ndates}.log

    exit 1
else
    outlog_func CM-I10202

    # ログを複製する
	cp -f ${LOG_DIR}/FILE_ARCHIVE.log ${LOG_DIR}/FILE_ARCHIVE_${ndates}.log

    exit 0
fi
