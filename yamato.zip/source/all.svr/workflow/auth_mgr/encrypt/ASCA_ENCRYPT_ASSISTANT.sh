#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ASCA_ENCRYPT_ASSISTANT.sh
# 業 務 名          ： なし
# 処理概要       ： server.xml生成用シェル
# 特記事項       ：
# パラメータ         ： 無し
# 前提条件       ： 無し
# リターンコード  ： 0             正常終了
#           ： 1             処理異常
# 対象DB    ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： IBM.顧
#
# 作成日付    ： 2010-11-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-11-08 IBM.顧              新規作成
# 2 1.0.1 2014-07-21 劉健                暗号化ツール改修
# 3 1.0.2 2014-10-21 陳楚南            暗号化ツール改修      jira-exclusion.war生成コードを削除する
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################

#環境設定を行う
#共通関数ファイルの存在チェック

# IPファイル(server.properties)導入
_exec_ksh=/workflow/batch/ini/server.properties
if [ ! -f ${_exec_ksh} ]
then
    echo "環境IP設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#復号用シェルを呼出す
. /workflow/auth_mgr/decrypt/ASCA_DECRYPT_MANAGER.sh ALL

#出力ログファイル名
export a_log_name=${ENCRYPT_ASSISTANT_LOG_NM}

##########################################################
# server.xml生成用
##########################################################
# server.xmlのtemplateを目的ディレクトリへコピーする
cp -r ${A_TEMPLATE_DIR}/server.xml ${A_HOME}/key_dc/ 2>&1
RC=$?
case ${RC} in
        0)      outlog_auth_func HD-I00003 ${RC};;
        *)      outlog_auth_func HD-E00003 ${RC}
                exit 1;;
esac

# server.xmlのtemplate部分のパスワードを替える
# 環境wsjrの部分
sed -i 's/JIRADBR_USERNAME/"'"${A_USER3_ID}"'"/' ${A_HOME}/key_dc/server.xml/wsjr/conf/server.xml
RC1=$?

sed -i 's/GWDB_USERNAME/"'"${A_USER4_ID}"'"/' ${A_HOME}/key_dc/server.xml/wsjr/conf/server.xml
RC2=$?

sed -i 's/JIRADBR_PSWD/"'"${A_USER3_PWD}"'"/' ${A_HOME}/key_dc/server.xml/wsjr/conf/server.xml
RC3=$?

sed -i 's/GWDB_PSWD/"'"${A_USER4_PWD}"'"/' ${A_HOME}/key_dc/server.xml/wsjr/conf/server.xml
RC4=$?

if [ ${RC1} == 0 -a ${RC2} == 0 -a ${RC3} == 0 -a ${RC4} == 0 ]
then
	outlog_auth_func HD-I00004 ${RC1} ${RC2} ${RC3} ${RC4}
else
	outlog_auth_func HD-E00004 ${RC1} ${RC2} ${RC3} ${RC4}
	exit 1
fi

# 環境wsjuの部分
sed -i 's/JIRADBU_USERNAME/"'"${A_USER2_ID}"'"/' ${A_HOME}/key_dc/server.xml/wsju/conf/server.xml
RC1=$?

sed -i 's/GWDB_USERNAME/"'"${A_USER4_ID}"'"/' ${A_HOME}/key_dc/server.xml/wsju/conf/server.xml
RC2=$?

sed -i 's/JIRADBU_PSWD/"'"${A_USER2_PWD}"'"/' ${A_HOME}/key_dc/server.xml/wsju/conf/server.xml
RC3=$?

sed -i 's/GWDB_PSWD/"'"${A_USER4_PWD}"'"/' ${A_HOME}/key_dc/server.xml/wsju/conf/server.xml
RC4=$?

if [ ${RC1} == 0 -a ${RC2} == 0 -a ${RC3} == 0 -a ${RC4} == 0 ]
then
	outlog_auth_func HD-I00005 ${RC1} ${RC2} ${RC3} ${RC4}
else
	outlog_auth_func HD-E00005 ${RC1} ${RC2} ${RC3} ${RC4}
	exit 1
fi

# IPキーワード置き換える
sed -i "s/JIRADBU_HOST/${JIRADBU_HOST}/" ${A_HOME}/key_dc/server.xml/wsju/conf/server.xml
RC1=$?

sed -i "s/GWDB_HOST/${GWDB_HOST}/" ${A_HOME}/key_dc/server.xml/wsju/conf/server.xml
RC2=$?

sed -i "s/JIRADBR_HOST/${JIRADBR_HOST}/" ${A_HOME}/key_dc/server.xml/wsjr/conf/server.xml
RC3=$?

sed -i "s/GWDB_HOST/${GWDB_HOST}/" ${A_HOME}/key_dc/server.xml/wsjr/conf/server.xml
RC4=$?

if [ ${RC1} == 0 -a ${RC2} == 0 -a ${RC3} == 0 -a ${RC4} == 0 ]
then
	outlog_auth_func HD-I00010 ${RC1} ${RC2} ${RC3} ${RC4}
else
	outlog_auth_func HD-E00010 ${RC1} ${RC2} ${RC3} ${RC4}
	exit 1
fi

#元のパスを返す
cd ${currentpath}

echo "server.xmlを生成しました。"

exit 0