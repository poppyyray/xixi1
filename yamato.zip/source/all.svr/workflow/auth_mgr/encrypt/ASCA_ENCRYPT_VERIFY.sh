#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ASCA_ENCRYPT_VERIFY.sh
# 業 務 名       ： なし
# 処理概要       ： ユーザーIDとPSWD復号された内容を検証する
# 特記事項       ：
# パラメータ     ： 無し
# 前提条件       ：パラメータが必ず1つあること(USER1~5)
# リターンコード ： 0  正常終了
#                ： 1  処理異常
# 対象DB         ： JIRADB GWDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： jingwei.zhou
#
# 作成日付       ： 2010-12-3
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-12-03 jingwei.zhou             新規作成
# 2 1.0.1 2014-07-20 LiuJian                  暗号化ツール改修
#
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

ARGS=${1}
if [[ ${ARGS} == '' ]]
then
	echo "パラメータを１から５まで入力してください！"
	exit 1
fi
. /workflow/auth_mgr/environment/a_auth_mgr_common.conf
. /workflow/auth_mgr/environment/a_auth_mgr_verify.conf

###############################################################################
# JIRAログイン関数
# 引数１：login.jspファイルを作成するパス.任意 （指定がなければカレントに作成）
# 引数２：作成するcookie名.任意 （指定がなければcookies.txtで作成）
# 引数３：接続先のJIRAのIPアドレスを指定する（指定がなければデフォルト値を使用)
###############################################################################
function jira_login
{
	current_path=`pwd`
	common_login_path=${1}
	common_cookie_name=${2}
	CONNECT_JIRA=${3}

	#ループカウンタ初期化
	_logincount=0

	#クッキー名の指定がなければデフォルト名
	if [ -z "${common_cookie_name}" ]
	then
	     common_cookie_name=${DEFAULT_COOKIE_NAME}
	fi

	#login.jspの出力パスの指定がなければカレントに作成
	if [ -z "${common_login_path}" ]
	then
	     common_login_path=${current_path}
	fi

	#JIRAIPの指定がなければデフォルト値(更新JIRAのIP）を使用
	if [ -z "${CONNECT_JIRA}" ]
	then
	     CONNECT_JIRA=${JIRA_IP}
	fi

	#login.jsp出力パスへ移動
	cd ${common_login_path}

	# wgetコマンドでJIRAへログインを行う
	wget -o ${ROOT_FILE} --save-cookies ${common_cookie_name} --keep-session-cookies --header='Proxy-Connection: keep-alive' --post-data "os_username=${A_USER5_ID}&os_password=${A_USER5_PWD}&os_cookie=true" ${JIRA_IP}login.jsp
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${ROOT_FILE}`" >>${A_DETAIL_LOG}

	while [ ${_logincount} -le ${LOGIN_MAX_LOOP} ]
	do
		# 指定パスに作成されるlogin.jsp*ファイルが存在するか確認
		_find_Loginfile=`find ${common_login_path} -name "login.jsp*" | tee ${ROOT_FILE}`
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${ROOT_FILE}`" >>${A_DETAIL_LOG}
		if [ -z "${_find_Loginfile}" ]
		then
			if [ ${_logincount} -eq ${LOGIN_MAX_LOOP} ]
			then
				#規定回数ループした場合はログイン失敗とみなす。
				return 1
			fi
			_logincount=`expr ${_logincount} + 1`
			# ログイン確認できない場合スリープ(sec)
			sleep ${LOGIN_WAIT_TIME}
		else
			#ログイン成功か判別
			cat ${_find_Loginfile} | grep "incorrect" > /dev/null
			if [ $? = 0 ]
			then
				rm -f ${_find_Loginfile}
				return 1	
			fi
			# login.jsp*のファイルを削除
			rm -f ${_find_Loginfile}
			break
		fi
	done

	#カレントパスを元に戻す
	cd ${current_path}

	return 0
}

case ${ARGS} in 
1)
	#チェックUSER1
	. ${A_HOME}/decrypt/ASCA_DECRYPT_MANAGER.sh USER1
	id ${A_USER1_ID}
	if [ $? != '0' ]
	then
		echo "`date` USER1: 検証失敗" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	else
		echo "`date` USER1: 検証成功" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	fi
;;
2)
	#チェックUSER2
	. ${A_HOME}/decrypt/ASCA_DECRYPT_MANAGER.sh USER2
	db2 connect to jiradb user ${A_USER2_ID} using ${A_USER2_PWD} >> ${A_DETAIL_LOG}
	if [ $? != '0' ]
	then
		echo "`date` USER2: 検証失敗" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	else
		echo "`date` USER2: 検証成功" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	fi
;;
3)
	#チェックUSER3
	. ${A_HOME}/decrypt/ASCA_DECRYPT_MANAGER.sh USER3
	db2 connect to jiradbr user ${A_USER3_ID} using ${A_USER3_PWD} >> ${A_DETAIL_LOG}
	if [ $? != '0' ]
	then
		echo "`date` USER3: 検証失敗" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	else
		echo "`date` USER3: 検証成功" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	fi
;;
4)
	#チェックUSER4
	. ${A_HOME}/decrypt/ASCA_DECRYPT_MANAGER.sh USER4
	db2 connect to gwdb user ${A_USER4_ID} using ${A_USER4_PWD} >> ${A_DETAIL_LOG}
	if [ $? != '0' ]
	then
		echo "`date` USER4: 検証失敗" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	else
		echo "`date` USER4: 検証成功" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	fi
;;
5)
	#チェックUSER5
	. ${A_HOME}/decrypt/ASCA_DECRYPT_MANAGER.sh USER5
	jira_login
	if [ $? != '0' ]
	then
		echo "`date` USER5: 検証失敗" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	else
		echo "`date` USER5: 検証成功" | tee -a ${A_LOG_DIR}/`basename ${0}`.log
	fi
;;
*)
	echo "パラメータが違います！"
;;
esac

exit 0