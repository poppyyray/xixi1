#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ASCA_DECRYPT_MANAGER.sh
# 業 務 名          ： なし
# 処理概要       ： ユーザーIDとPSWD復号された内容を取得
# 特記事項       ：
# パラメータ         ： 無し
# 前提条件       ：パラメータが必ず1つあること(USER1~5)
# リターンコード  ： 0             正常終了
#           ： 1             処理異常
# 対象DB    ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： IBM.顧
#
# 作成日付    ： 2010-11-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-11-08 IBM.顧              新規作成
# 2
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#環境設定を行う
_exec_a_sh=/workflow/auth_mgr/environment/a_auth_mgr_common.conf
if [ ! -f ${_exec_a_sh} ]
then
    echo "共通ファイルが存在しませんでした[${_exec_a_sh}]"
    return 1
fi
. ${_exec_a_sh}

#出力ログファイル名
export a_log_name=${DECRYPT_LOG_NM}

# ----
# 共通関数ファイルの存在チェック
# ----
if [ ! -f ${A_ENV_DIR}/A_AUTH_MGR_COMMON_FUNC.sh ]; then
	echo "共通関数ファイルが存在しません[${_exec_a_sh}]"
	return 1
fi
. ${A_ENV_DIR}/A_AUTH_MGR_COMMON_FUNC.sh

###########################################################
# 関数名:output_decrypt
#
# 機能:USERIDとパスワードを復号する
#
# 引数
# $1 USERタイプ：USER1~5
#
# $2 取得区分： 0：UserId, 1：PWD
#
# 戻り値
#  復号された値を外部フィールドにセットする
#  1:異常
#
# 前提条件:なし
#
###########################################################
function output_decrypt
{
	##########################################################
	# シェール呼出すの引数量の確認
	##########################################################
	if [ $# != 2 ]
	then
		echo "関数指定誤りがある。必ずユーザー区分と取得種類区分を二つで指定してください。"
		return 1
	fi

	# APIを呼出す
	output=`java -classpath "${JAVA_CLASSPATH_D}" com.ibm.jirax.security.DecryptManager $1 $2 2>>${A_LOG_DIR}/${a_log_name}.log`
	RC=$?
	case ${RC} in
	        0)      outlog_auth_func HD-I00002 ${RC};;
	        *)      outlog_auth_func HD-E00002 ${RC}
	                return 1;;
	esac

	# 結果を保存する
	A_AUTH_MGR_RESULT=${output}

	return 0
}
case $1 in

	ALL)
			#初期化
			A_USER1_ID=ERROR
			#取得成功の場合、USER1のユーザーIDを設定する
			output_decrypt USER1 0
			if [ $? = 0 ]
			then
				A_USER1_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER1_IDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER1_PWD=ERROR
			#取得成功の場合、USER1のPSWDを設定する
			output_decrypt USER1 1
			if [ $? = 0 ]
			then
				A_USER1_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER1_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER2_ID=ERROR
			#取得成功の場合、USER2のユーザーIDを設定する
			output_decrypt USER2 0
			if [ $? = 0 ]
			then
				A_USER2_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER2_IDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER2_PWD=ERROR
			#取得成功の場合、USER2のPSWDを設定する
			output_decrypt USER2 1
			if [ $? = 0 ]
			then
				A_USER2_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER2_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER3_ID=ERROR
			#取得成功の場合、USER3のユーザーIDを設定する
			output_decrypt USER3 0
			if [ $? = 0 ]
			then
				A_USER3_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER3_IDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER3_PWD=ERROR
			#取得成功の場合、USER3のPSWDを設定する
			output_decrypt USER3 1
			if [ $? = 0 ]
			then
				A_USER3_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER3_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER4_ID=ERROR
			#取得成功の場合、USER4のユーザーIDを設定する
			output_decrypt USER4 0
			if [ $? = 0 ]
			then
				A_USER4_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER4_IDを設定完了" >>${A_DETAIL_LOG}
			fi

			#初期化
			A_USER4_PWD=ERROR
			#取得成功の場合、USER4のPSWDを設定する
			output_decrypt USER4 1
			if [ $? = 0 ]
			then
				A_USER4_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER4_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER5_ID=ERROR
			#取得成功の場合、USER5のユーザーIDを設定する
			output_decrypt USER5 0
			if [ $? = 0 ]
			then
				A_USER5_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER5_IDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER5_PWD=ERROR
			#取得成功の場合、USER5のPSWDを設定する
			output_decrypt USER5 1
			if [ $? = 0 ]
			then
				A_USER5_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER5_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
	;;
	USER1)
			#初期化
			A_USER1_ID=ERROR
			#取得成功の場合、USER1のユーザーIDを設定する
			output_decrypt USER1 0
			if [ $? = 0 ]
			then
				A_USER1_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER1_IDを設定完了" >>${A_DETAIL_LOG}
			fi

			#初期化
			A_USER1_PWD=ERROR
			#取得成功の場合、USER1のPSWDを設定する
			output_decrypt USER1 1
			if [ $? = 0 ]
			then
				A_USER1_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER1_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
	;;
	USER2)
			#初期化
			A_USER2_ID=ERROR
			#取得成功の場合、USER2のユーザーIDを設定する
			output_decrypt USER2 0
			if [ $? = 0 ]
			then
				A_USER2_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER2_IDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER2_PWD=ERROR
			#取得成功の場合、USER2のPSWDを設定する
			output_decrypt USER2 1
			if [ $? = 0 ]
			then
				A_USER2_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER2_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
	;;
	USER3)
			#初期化
			A_USER3_ID=ERROR
			#取得成功の場合、USER3のユーザーIDを設定する
			output_decrypt USER3 0
			if [ $? = 0 ]
			then
				A_USER3_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER3_IDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER3_PWD=ERROR
			#取得成功の場合、USER3のPSWDを設定する
			output_decrypt USER3 1
			if [ $? = 0 ]
			then
				A_USER3_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER3_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
	;;
	USER4)
			#初期化
			A_USER4_ID=ERROR
			#取得成功の場合、USER4のユーザーIDを設定する
			output_decrypt USER4 0
			if [ $? = 0 ]
			then
				A_USER4_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER4_IDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER4_PWD=ERROR
			#取得成功の場合、USER4のPSWDを設定する
			output_decrypt USER4 1
			if [ $? = 0 ]
			then
				A_USER4_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER4_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
	;;
	USER5)
			#初期化
			A_USER5_ID=ERROR
			#取得成功の場合、USER5のユーザーIDを設定する
			output_decrypt USER5 0
			if [ $? = 0 ]
			then
				A_USER5_ID=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER5_IDを設定完了" >>${A_DETAIL_LOG}
			fi
			
			#初期化
			A_USER5_PWD=ERROR
			#取得成功の場合、USER5のPSWDを設定する
			output_decrypt USER5 1
			if [ $? = 0 ]
			then
				A_USER5_PWD=${A_AUTH_MGR_RESULT}
				echo -e "日付:`date` || shell名:`basename ${0}` || USER5_PWDを設定完了" >>${A_DETAIL_LOG}
			fi
	;;
	*)
			echo -e "日付:`date` || shell名:`basename ${0}` || ${1}:引数設定誤りがあります。" >>${A_DETAIL_LOG}
	;;
esac