#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： module_backup_api.sh
# 業 務 名       ： APIリリース時のバックアップ
# 処理概要       ： APIモジュールのバックアップを作成する
# 特記事項       ：
# パラメータ     ： $1:今回のリリース日 yyyymmdd
#                   $2:バックアップを取るモジュールのversion
#                      (前回のversionを指定)
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2010-03-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-03-16 T.Sakagami              新規作成
# 2 1.0.1 2010-04-14 M.Sato                  パラメータ追加
#                                            webapps追加
# 3 1.0.2 2010-09-15 Yuan Zhiwei             移行対応
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
#バックアップファイル作成ディレクトリ
backup_path=/root/release_bkup

#バックアップ対象ディレクトリ
classes_main_path=/opt/atlassian/jira/atlassian-jira/WEB-INF/classes
lib_main_path=/opt/atlassian/jira/atlassian-jira/WEB-INF/lib
webapps_main_path=/opt/atlassian/jira/webapps


#バックアップファイルのフルパス
backup_classes_dir=${backup_path}/classes.$1.$2
backup_lib_dir=${backup_path}/lib.$1.$2
backup_webapps_dir=${backup_path}/webapps.$1.$2

#########################################################

if [ -z $1 ];then
	echo ""
	echo "###############################################################"
	echo " ERROR! 引数にリリース日が指定されていません"
	echo "###############################################################"
	echo ""
	exit 1
fi

if [ -z $2 ];then
	echo ""
	echo "###############################################################"
	echo " ERROR! 引数にバックアップ対象のversionが指定されていません"
	echo "###############################################################"
	echo ""
	exit 1
fi

echo " "
echo " 開始！"
echo " "
echo " バックアップディレクトリ作成"
echo " "
mkdir ${backup_classes_dir}
mkdir ${backup_lib_dir}
mkdir ${backup_webapps_dir}

echo " 必要ディレクトリをコピー"
echo " "
cp -rp ${classes_main_path} ${backup_classes_dir}
cp -rp ${lib_main_path} ${backup_lib_dir}
cp -rp ${webapps_main_path} ${backup_webapps_dir}

echo " tar.gzファイルを作成"
echo " "
tar -cvzf ${backup_classes_dir}.tar.gz ${backup_classes_dir}

if [ $? = '0' ]
then
    echo " "
    echo " 成功！"
    echo " "
else
    echo " "
    echo " 失敗！！"
    echo " "
fi

tar -cvzf ${backup_lib_dir}.tar.gz ${backup_lib_dir}

if [ $? = '0' ]
then
    echo " "
    echo " 成功！"
    echo " "
else
    echo " "
    echo " 失敗！！"
    echo " "
fi

tar -cvzf ${backup_webapps_dir}.tar.gz ${backup_webapps_dir}

if [ $? = '0' ]
then
    echo " "
    echo " 成功！"
    echo " "
else
    echo " "
    echo " 失敗！！"
    echo " "
fi

echo " tar.gzファイルを確認"
echo " "
ls -ltr ${backup_path}

echo " "
echo " 不必要ファイルを削除"
echo " "
rm -rf ${backup_classes_dir}
rm -rf ${backup_lib_dir}
rm -rf ${backup_webapps_dir}

echo " 削除を確認"
echo " "
ls ${backup_classes_dir}
ls ${backup_lib_dir}
ls ${backup_webapps_dir}

echo " "
echo " 終了！"
echo " "

exit 0

