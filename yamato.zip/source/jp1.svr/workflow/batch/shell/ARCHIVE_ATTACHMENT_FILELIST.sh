#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ARCHIVE_ATTACHMENT_FILELIST.sh 
# 業 務 名       ： なし
# 処理概要       ： FILEATTACHMENTアーカイブシェル(日次)
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0             正常
#                   1             エラー
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Tsuruha
#
# 作成日付       ： 2009-06-01
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2009-06-01 S.Tsuruha                新規作成
# 21.0.1  2010-12-14 jingwei.zhou             エラー処理追加およびログ出力方法変更
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func FA-I01005

# attachmentファイルリストが存在する場合削除する
if [ -f ${CSV_OUT_DIR}/attachment_file_list.csv ]
then
        rm -f ${CSV_OUT_DIR}/attachment_file_list.csv
fi

# 更新JIRAに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# DBエラー
if [ ${SQLERROR} != '0' ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func FA-E01006 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f ${SQLLOG_TMP}

	# エラー終了
	exit 1
fi

db2 -x "export to ${CSV_OUT_DIR}/attachment_file_list.csv of del modified by nochardel 
select pr.pkey,ji.pkey
from
        jiraschema.fileattachment fa
LEFT OUTER JOIN
        jiraschema.jiraissue ji ON
        fa.issueid = ji.id
LEFT OUTER JOIN
        jiraschema.project pr ON
        pr.id = ji.project
where fa.issueid = ji.id 
and date(ji.updated) <= (values current date ${DAY} days) 
and ji.issuestatus = '${STATUS_COMPLETION}'" > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func FA-E01007 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f ${SQLLOG_TMP}

	# エラー終了
	exit 1
fi

db2 terminate

outlog_func FA-I01008

exit 0
