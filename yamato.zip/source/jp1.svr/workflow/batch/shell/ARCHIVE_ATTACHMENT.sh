#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ARCHIVE_ATTACHMENT.sh 
# 業 務 名       ： なし
# 処理概要       ： FILEATTACHMENTアーカイブシェル(日次)
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0             正常
#                   1             エラー
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Tsuruha
# 
# 作成日付       ： 2009-06-01
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2009-06-01 S.Tsuruha                新規作成
# 1.0.1   2010-02-12 Y.Otsuka                 rsh戻り値対応
# 3       2014-06-24 LiuJian                  IP集約管理
# 4       2014-07-28 LiuJian                  更新と参照JIRA Attachment同期と退避 (JP1関連)
# 5       2014-11-17 LiuJian                  誤記訂正
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

###############################################################################
# 出力ログ名設定
export log_name=${ARCHIVE_ATTACHEMENT_LOG}

# ----
# 業務別環境変数設定
# ----

###############################################################################
# main処理開始
###############################################################################

### 開始メッセージ
outlog_func FA-I01001

# 更新JIRA#3からATTACHMENT情報を取得
REMOTE_COPY ${CSV_OUT_DIR}/${ATTACHEMENT_LIST} ${JIRAU_CIP}:${TMP_DIR}
if [ $? != '0' ]
then
    exit 1
fi

REMOTE_EXEC_SH ${JIRAU_CIP} ${SHELL_DIR}/ATTACHMENT_ZIP.sh
if [ $? != '0' ]
then
    exit 1
fi

# 参照JIRA#1へATTACHMENT情報を反映
REMOTE_COPY ${JIRAU_CIP}:${TMP_DIR}/${ATTACHEMENT_JIRA_TAR}.gz ${JIRAR_CIP}:${JIRAR_ATTACHE_PATH}
if [ $? != '0' ]
then
    exit 1
fi

REMOTE_EXEC_SH ${JIRAR_CIP} ${SHELL_DIR}/ATTACHMENT_UNZIP.sh
if [ $? != '0' ]
then
    exit 1
fi

### 終了メッセージ
outlog_func FA-I01002
