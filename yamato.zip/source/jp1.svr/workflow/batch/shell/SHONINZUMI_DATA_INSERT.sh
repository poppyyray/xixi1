#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： SHONINZUMI_DATA_INSERT.sh
# 業 務 名       ： 承認済みデータ登録
# 処理概要       ： 承認済みデータをGW・JIRAに登録
# 特記事項       ： 起動トリガー：JP1により機動
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-07-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-16 T.Sakagami             新規作成
# 2 1.1.0 2009-09-14 Y.Otsuka               ヘッダー追加
# 3 1.2.0 2009-12-21 M.Saiki                importリトライ追加
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################################
# 承認済みデータCSV作成関数 
##########################################################################
function syouninzumi_data {

    #カウント変数初期化
    _ShoninZumi_cnt=0

    while read line
    do
        # 件数をカウント
        _ShoninZumi_cnt=`expr ${_ShoninZumi_cnt} + 1`
        
        # 1行目のファイル名が正しいかチェック 
       if [ ${_ShoninZumi_cnt} == 1 ]
		then
		   line=`echo ${line} | sed -e "s/\r//"`
           line=`echo ${line} | sed -e "s/ //"`
           if [ ${line} != ${FILE_ShoninZumi} ]
			then
		  outlog_func SZ-E02003 ${1}
                return 1
           fi
        # 2行目の件数が正しいかチェック
       elif [ ${_ShoninZumi_cnt} == 2 ]
		then
           line=`echo ${line} | sed -e "s/\r//"`
           line=`echo ${line} | sed -e "s/ //"`
            _line_cnt=`wc -l ${1} | cut -d " " -f 1`

            # 1-3行目はカウントしない
            _line_cnt=`expr ${_line_cnt} - 3`
              # 2行目を数値として扱いたいためexprで０を加算
            line=`expr ${line} + 0`

            # ファイル2行目のファイル件数と実際のファイルの件数を比較
           if [ ${line} != ${_line_cnt} ]
			then
		  outlog_func SZ-E02004 ${1}
                return 1
            fi
             # 件数が0件の場合は処理終了
            if [ ${line} -eq 0 ]
            then
                touch  ${CSV_OUT_DIR}/${FILE_ShoninZumi}.csv 
                return 0
            fi

        # 3行目はブランク行のためなにもしない
       elif [ ${_ShoninZumi_cnt} == 3 ]
		then
            continue
        # 4行目以降は業務データのcsvファイルを作成
        else
             #システム種別
            _system_id=`echo "$line"|cut -b1-2`

             #起票部署
            _kihyo_busyo=`echo "$line"|cut -b3-8`

             #起票年月日
             _kihyo_date=`echo "$line"|cut -b9-16`

             #伝票番号
             _denpyo_num=`echo "$line"|cut -b17-20`

             #タイムスタンプ
            _timestmp=`date +%Y-%m-%d-%H.%M.%S`.000000

            _outline=""
            _outline="${_outline}${_system_id}",
            _outline="${_outline}${_kihyo_busyo}",
            _outline="${_outline}${_kihyo_date}",
            _outline="${_outline}${_denpyo_num}",,,
            _outline="${_outline}${_shname}",
            _outline="${_outline}${_timestmp}",,,

            echo ${_outline} >> ${CSV_OUT_DIR}/${FILE_ShoninZumi}.csv

        fi

    done < ${1}

    return 0
}

#################################################################
# main処理
#################################################################

#環境設定を行う
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ];then
    echo "バッチ環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${SHONINZUMI_MAIN_FLOW_LOG}

outlog_func SZ-I02001

# シェル名
_shname="SHOUNINZUMI_DATA_INSERT.sh"
_tmp="${TMP_DIR}/SHOUNINZUMI_DATA_INSERT.tmp"

# 承認済みデータファイル存在確認
#if [ ! -f ${PP_FILE_PATH}/${FILE_ShoninZumi} ]
#then

	# バックアップファイル名にOKが無いものを取得（正常終了しなかったスキャンファイル）
   _FILE_ShoninZumi_BAK=`ls ${PPFILE_BACKUP_DIR}| grep ${FILE_ShoninZumi} | grep -v OK | head -1`

    # バックアップファイルの末尾が全てOK
    if [ -z ${_FILE_ShoninZumi_BAK} ]
	then

		# 承認済みデータファイルが存在しない
    	#echo "承認済みデータファイルが存在しません。ファイル名[${FILE_ShoninZumi}]"
	outlog_func SZ-W02005 ${FILE_ShoninZumi}
	exit 0


    # バックアップファイルの末尾がOKでないものがある
	else
		# ディレクトリパスを付与
		_FILE_ShoninZumi_BAK="${PPFILE_BACKUP_DIR}/${_FILE_ShoninZumi_BAK}"

        # 承認済みデータファイルCSV作成関数呼び出し
        syouninzumi_data "${_FILE_ShoninZumi_BAK}"

        # エラー判定
       if [ $? != "0" ]
		then
		
	    outlog_func SZ-E02006

	    # CSV削除
	    rm -f ${CSV_OUT_DIR}/${FILE_ShoninZumi}.csv
           exit 1
       fi  

    fi
#else

    # 承認済みデータファイルのバックアップを作成
#    _FILE_ShoninZumi_BAK=${PPFILE_BACKUP_DIR}/${FILE_ShoninZumi}.`date +%Y%m%d%H%M`
#    mv -f ${PP_FILE_PATH}/${FILE_ShoninZumi} ${_FILE_ShoninZumi_BAK}

    # 承認済みデータファイルCSV作成関数呼び出し
#    syouninzumi_data "${_FILE_ShoninZumi_BAK}"

    # エラー判定
#    if [ $? != "0" ]
#	then

#	outlog_func SZ-E02009

		# CSV削除
#		rm -f ${CSV_OUT_DIR}/${FILE_ShoninZumi}.csv

#        exit 1
#    fi
#fi

# DB接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力    
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func SZ-E02007 "${_errmsg}"
    
    # 一時ファイル等の削除

    # CSV削除
    rm -f ${CSV_OUT_DIR}/${FILE_ShoninZumi}.csv

    # エラー終了
    exit 1
fi
echo "" >> ${SQLLOG_TMP}


# 承認済みデータCSVファイルが存在すればDBにインサートを行う
if [ -f ${CSV_OUT_DIR}/${FILE_ShoninZumi}.csv ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do		
		# 承認済みデータCSVインポート
		db2 import from ${CSV_OUT_DIR}/${FILE_ShoninZumi}.csv of del messages ${_tmp} INSERT into ${TABLE_ShoninZumi} > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		
		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${DB_NAME}"

			connectDB ${DB_NAME}

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]  
	then
		# エラーログ出力    
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func SZ-E02008 "${_errmsg}"
		# 一時ファイル等の削除
		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_ShoninZumi}.csv
		# エラー終了
		exit 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# 正常終了したスキャンデータファイルの末尾にOKをつける
	mv -f ${_FILE_ShoninZumi_BAK} ${_FILE_ShoninZumi_BAK}.OK
fi

# DB切断
db2 terminate > /dev/null

# 作成したCSVファイルを削除
rm -f ${CSV_OUT_DIR}/${FILE_ShoninZumi}.csv
#rm -f ${_tmp}

outlog_func SZ-I02002

exit 0
