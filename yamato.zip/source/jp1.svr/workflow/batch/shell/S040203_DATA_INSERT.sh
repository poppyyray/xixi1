#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S040203_DATE_INSERT.sh
# 業 務 名       ： 一般集金(エラー処理）データ登録
# 処理概要       ： 一般集金(エラー処理）データをGWに登録
# 特記事項       ： 起動トリガー：JP1により機動
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-07-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-16 T.Sakagami             新規作成
# 2 1.1.0 2009-09-14 Y.Otsuka               ヘッダー追加
# 3 1.2.0 2009-12-21 M.Saiki                importリトライ追加
# 4 1.3.0 2016-11-02 yuanrui                社員番号6桁->8桁対応
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################################
# 一般集金（エラー処理）CSV作成関数 
##########################################################################
function ippansyukin_error {

    #経費振替カウント変数初期化
	_S040203_cnt=0

    while read line
    do
		# 件数をカウント
        _S040203_cnt=`expr ${_S040203_cnt} + 1`

        # 1行目のファイル名が正しいかチェック 
        if [[ ${_S040203_cnt} == 1 ]];then
			line=`echo ${line} | sed -e "s/\r//"`
			line=`echo ${line} | sed -e "s/ //"`
            if [[ ${line} != ${FILE_S040203} ]];then
                outlog_func GE-E02003 ${1}
                return 1
            fi
        # 2行目の件数が正しいかチェック
        elif [[ ${_S040203_cnt} == 2 ]];then
			line=`echo ${line} | sed -e "s/\r//"`
			line=`echo ${line} | sed -e "s/ //"`
            _line_cnt=`wc -l ${1} | cut -d " " -f 1`

            # 1縲鰀3行目はカウントしない
            _line_cnt=`expr ${_line_cnt} - 3`
              # 2行目を数値として扱いたいためexprで０を加算
            line=`expr ${line} + 0`

            # ファイル2行目のファイル件数と実際のファイルの件数を比較
            if [[ ${line} != ${_line_cnt} ]];then
                outlog_func GE-E02004 ${1}
                return 1
            fi
            
            # 件数が0件の場合は、ファイル名末尾にOKをつけて正常終了
            if [[ ${line} = 0 ]];then
                 mv ${_FILE_S040203_BAK_PATH} ${_FILE_S040203_BAK_PATH}.OK
                 return 0
            fi
        # 3行目はブランク行のためなにもしない
        elif [[ ${_S040203_cnt} == 3 ]];then
            continue
        # 4行目以降は業務データのcsvファイルを作成
        else

            #連番
            _keihi_id=`echo "$line"|cut -b1-14`

            #業務ID
            _file_id=`echo "$line"|cut -b15-21`

			#店所コード
			_shop_cd=`echo "$line"|cut -b22-27`

			#個人番号
			_sd_number=`echo "$line"|cut -b28-35`

			#作業日
			_work_day=`echo "$line"|cut -b36-43`

			#帳票ID
			_tyouhyou_id=`echo "$line"|cut -b44-47`

			#関連帳票番号
			_kanren_tyouhyou=`echo "$line"|cut -b48-57`

			#主管コード
			_syukan_cd=`echo "$line"|cut -b58-63`

			#エリアコード
			_eria_cd=`echo "$line"|cut -b64-69`

			#エラー理由
			_error_reason=`echo "$line"|cut -b70-87`
          _error_reason=`echo ${_error_reason} | sed -e "s/^0*//"`

			#伝票番号
			_denpyou=`echo "$line"|cut -b88-91`

			#入金年月日
			_nyukin_date=`echo "$line"|cut -b92-99`

			#起票部署
			_kihyou_busyo=`echo "$line"|cut -b100-105`

			#顧客コード
			_kokyaku_cd=`echo "$line"|cut -b106-117`

			#分類コード
			_bunrui_cd=`echo "$line"|cut -b118-120`			

			#ヘッダNO
			_head_no=`echo "$line"|cut -b121-126`

			#整理部署
			_seiri_busyo=`echo "$line"|cut -b127-132`

			#請求NO
			_seikyu_no=`echo "$line"|cut -b133-137`

			#請求金額
			_seikyu_kin=`echo "$line"|cut -b138-149`
			_seikyu_kin=`echo ${_seikyu_kin} | sed -e "s/^+*//"`
			_seikyu_kin=`echo ${_seikyu_kin} | sed -e "s/^0*//"`
			#金額が0円の場合
			if [ -z ${_seikyu_kin} ]
			then
				_seikyu_kin="0"
			fi

			#入金金額
			_nyukin_kin=`echo "$line"|cut -b150-161`
			_nyukin_kin=`echo ${_nyukin_kin} | sed -e "s/^+*//"`
			_nyukin_kin=`echo ${_nyukin_kin} | sed -e "s/^0*//"`
			#金額が0円の場合
			if [ -z ${_nyukin_kin} ]
			then
				_nyukin_kin="0"
			fi

			#請求残額
			_seikyu_zan=`echo "$line"|cut -b162-173`
			_seikyu_zan=`echo ${_seikyu_zan} | sed -e "s/^+*//"`
			_seikyu_zan=`echo ${_seikyu_zan} | sed -e "s/^0*//"`
			#金額が0円の場合
			if [ -z ${_seikyu_zan} ]
			then
				_seikyu_zan="0"
			fi

			#タイムスタンプ
			_timestmp=`date +%Y-%m-%d-%H.%M.%S`.000000

			_outline=""
            _outline="${_outline}""${ID_S040203}"-"${_keihi_id}",
            _outline="${_outline}${_file_id}",
            _outline="${_outline}${_shop_cd}",
            _outline="${_outline}${_sd_number}",
            _outline="${_outline}${_work_day}",
            _outline="${_outline}${_tyouhyou_id}",
            _outline="${_outline}${_kanren_tyouhyou}",
            _outline="${_outline}${_syukan_cd}",
            _outline="${_outline}${_eria_cd}",
            _outline="${_outline}${_error_reason}",
            _outline="${_outline}${_denpyou}",
            _outline="${_outline}${_nyukin_date}",
            _outline="${_outline}${_kihyou_busyo}",
            _outline="${_outline}${_kokyaku_cd}",
            _outline="${_outline}${_bunrui_cd}",
            _outline="${_outline}${_head_no}",
            _outline="${_outline}${_seiri_busyo}",
            _outline="${_outline}${_seikyu_no}",
            _outline="${_outline}${_seikyu_kin}",
            _outline="${_outline}${_nyukin_kin}",
            _outline="${_outline}${_seikyu_zan}",,,,,,,,,,
            _outline="${_outline}${_shname}",
            _outline="${_outline}${_timestmp}",,,

            echo ${_outline} >> ${CSV_OUT_DIR}/${FILE_S040203}.csv.euc

        fi

    done < ${1}

	return 0
}

#################################################################
# main処理
#################################################################

#環境設定を行う
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ];then
    echo "バッチ環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# DB登録用シェル名
_shname="S040203_DATA_INSERT.sh"
# 一時ファイル
_tmp="${TMP_DIR}/S040203_DATA_INSERT.tmp"

# 出力ログ名設定
export log_name=${S040203_MAIN_FLOW_LOG}

outlog_func GE-I02001

# 一般集金（エラー処理）PPファイル存在確認
#if [[ ! -f ${PP_FILE_PATH}/${FILE_S040203} ]];then

	# PPバックアップファイル名にOKが無いものを取得（正常終了しなかったPPファイル）
   _FILE_S040203_BAK=`ls ${PPFILE_BACKUP_DIR}| grep ${FILE_S040203} | grep -v OK | head -1`

    # PPバックアップファイルの末尾が全てOK
    if [[ -z ${_FILE_S040203_BAK} ]];then

	# 一般集金（エラー処理）PPファイルが存在しない
    	outlog_func GE-W02005 ${FILE_S040203}

        # 処理対象ファイルが存在しないので終了
        exit 0

    # PPバックアップファイルの末尾がOKでないものがある
	else

		# ディレクトリパスを付与
		_FILE_S040203_BAK_PATH="${PPFILE_BACKUP_DIR}/${_FILE_S040203_BAK}"

	# 文字化けを防ぐためコード変換する
	nkf -e ${_FILE_S040203_BAK_PATH} > "${CSV_OUT_DIR}/${_FILE_S040203_BAK}"

        # 一般集金（エラー処理）CSV作成関数呼び出し
        ippansyukin_error "${CSV_OUT_DIR}/${_FILE_S040203_BAK}"

        # エラー判定
        if [[ $? != "0" ]];then

           outlog_func GE-E02006
			# CSV削除
	   rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv.euc
           exit 1
        fi
	# コード変換したファイルを削除
	rm -f "${CSV_OUT_DIR}/${_FILE_S040203_BAK}"
    fi
#else

    # 一般集金（エラー処理）PPファイルのバックアップを作成
#    _FILE_S040203_BAK=${PPFILE_BACKUP_DIR}/${FILE_S040203}.`date +%Y%m%d%H%M`
    # 文字化けを防ぐためEUCにコード変換して退避
#    nkf -e ${PP_FILE_PATH}/${FILE_S040203} > ${_FILE_S040203_BAK}

    # エラー判定
#    if [ $? != "0" ]
#	then

#        outlog_func GE-E02009

#        exit 1
#    fi

    # バックアップ成功時に送られてきたファイルを削除
#    rm -f ${PP_FILE_PATH}/${FILE_S040203}

    # 一般集金（エラー処理）CSV作成関数呼び出し
#    ippansyukin_error "${_FILE_S040203_BAK}"

    # エラー判定
#    if [[ $? != "0" ]];then

#        outlog_func GE-E02011

		# CSV削除
#		rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv.euc

#        exit 1
#    fi
#fi

# DB接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func GE-E02007 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# CSV削除
	rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv.euc

	# エラー終了
	exit 1
fi
echo "" >> ${SQLLOG_TMP}

# CSVファイルが存在すればDBにインサートを行う
if [[ -f ${CSV_OUT_DIR}/${FILE_S040203}.csv.euc ]];then

	# SJISにコード変換
	nkf -s ${CSV_OUT_DIR}/${FILE_S040203}.csv.euc > ${CSV_OUT_DIR}/${FILE_S040203}.csv

    # エラー判定
    if [ $? != "0" ]
	then

        outlog_func GE-E02010

    	# 一時ファイル等の削除
    	rm -f  ${SQLLOG_TMP}

		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv
		rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv.euc

        exit 1
    fi

	# 一般集金（エラー処理）CSVインポート
	nkf --ic=CP932 --oc=UTF-8 ${CSV_OUT_DIR}/${FILE_S040203}.csv > ${CSV_OUT_DIR}/${FILE_S040203}.csv.utf8
	#db2 import from ${CSV_OUT_DIR}/${FILE_S040203}.csv of del messages ${_tmp} INSERT_UPDATE into ${TABLE_S040203} > ${SQLLOG_TMP}
	
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		db2 import from ${CSV_OUT_DIR}/${FILE_S040203}.csv.utf8 of del messages ${_tmp} INSERT_UPDATE into ${TABLE_S040203} > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${DB_NAME}"

			connectDB ${DB_NAME}

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func GE-E02008 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}

		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv
		rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv.euc
		rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv.utf8

		# エラー終了
		exit 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# 正常終了したPPファイルの末尾にOKをつける
	mv ${_FILE_S040203_BAK_PATH} ${_FILE_S040203_BAK_PATH}.OK
fi

# DB切断
db2 terminate > /dev/null

# 作成したCSVファイルを削除
rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv
rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv.euc
rm -f ${CSV_OUT_DIR}/${FILE_S040203}.csv.utf8

# 一時ファイル削除
rm -f ${_tmp}

outlog_func GE-I02002

exit 0
