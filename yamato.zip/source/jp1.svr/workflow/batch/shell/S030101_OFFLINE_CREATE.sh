#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S030101_OFFLINE_CREATE.sh
# 業 務 名       ： OFFLINE_CREATE機能（入出金材料確認）
# 処理概要       ： GWDBから取得したデータファイルを基に、
#                   JIRADBへの取り込み用CSVファイルを作成し、
#                   DB2のLOADを用いてJIRADBへデータを反映する
# 特記事項       ： JIRAがオンライン稼働中でない場合に起動する
# パラメータ     ： なし
# ログファイル   ： S030101_OFFLINE_CREATE.log
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： GWDB,JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Tsuruha
#
# 作成日付       ： 2009-06-05
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-06-05 S.Tsuruha              新規作成
# 2 1.0.1 2010-01-09 Y.Nagahashi            importエラー出力対応
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
    if [[ -r ${x} ]]
    then
        . ${x}
    else
        echo "Cannot read common env file. ( ${x} )."
        exit 1
    fi
done
# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh /workflow/batch/shell/BATCH_LOAD_COMMON_FUNC_TMP.sh"
for y in ${conf_file_list}
do
        if [[ -r ${y} ]]
        then
            . ${y}
        else
            echo "Cannot read common conf file. ( ${y} )."
            exit 1
        fi
done

# ---- 
# 業務別環境変数設定
# ----
table_name=${TABLE_S030101}                # GWDBの業務別テーブル名
SQL=${SQL_DIR}/S030101_CSV_LOAD.sql        # GWサーバ側DBのCSV抽出SQLファイル
serviceID=10021                            # 業務ID
gyomu_id2=CE                               # 業務ID(2桁)

_wf_project_name=CashFlowEvidenceWorkFlow  # OS_WFENTRYのNAME値

# ----
# LOAD機能共通環境変数読み込み
# ----
. /workflow/batch/ini/batch_load_common.conf

###############################################################################
# CSV作成関数
###############################################################################
add=0 # 連番用変数
function create_load_csv
{
    export env_convey_file="/workflow/batch/tmp/env_convey_file"

    # Perlから見えるように、カウンタ類をexportする。
    export _customfield_valueid_max_jiraid
    export _jiraissueid_max_jiraid
    export _workflowid_max_jiraid
    export _pkey_max_jiraid
    export _os_currentstepid_max_jiraid

    # 以下もexportされていないため、Perlから見えるようにexportする。
    export serviceID
    export gyomu_id2
    export _wf_project_name

    log_exec_line="outlog_func"
    /workflow/batch/perl/S030101_LOAD_CSV.pl ${ichijifile3} |
    while read logline
    do
        if [ -z "${logline}" ]
        then
            eval ${log_exec_line}
            log_exec_line="outlog_func"
        else
            log_exec_line="${log_exec_line} \"${logline}\""
        fi
    done

    # Perlで更新したカウンタを、書き戻す。
    . ${env_convey_file}

    return 0

}

###############################################################################
# main処理開始
###############################################################################
# 出力ログ名設定
export log_name=${S030101_MAIN_FLOW_LOG}

### 開始メッセージ
outlog_func CM-I05001

### メイン処理 ###

# tmp/csv削除
tmp_csv_delete

# jiradb接続
connectDB "${JIRA_DB_NAME}"
if [ $? != 0 ]
then
    exit 1
fi

# jiradb情報抽出
load_export_jiraissueid_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_pkey_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_workflowid_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_os_currentstepid_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_customfield_valueid_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_component_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_projectversion_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_sequence_value_item_Issueid_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_sequence_value_item_osworkflowentryid_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_sequence_value_item_oscurrentstepid_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_sequence_value_item_customfieldvalueid_jiraid
if [ $? != 0 ]
then
    exit 1
fi
load_export_project_pcounter_jiraid
if [ $? != 0 ]
then
    exit 1
fi

# JIRA通番初期値確認
default_check
# jiradb切断
db2 terminate > /dev/null

# gwdb接続
connectDB "${DB_NAME}"
if [ $? != 0 ]
then
    exit 1
fi

# gwdb情報抽出
csv_export
if [ $? != 0 ]
then
    exit 1
fi

# gwdb情報csv化
csv_format
if [ $? != 0 ]
then
    exit 1
fi

# gwdb情報csvからjiradb格納可能csv
IFS_org=${IFS}
IFS=,
create_load_csv
if [ $? != 0 ]
then
    IFS=${IFS_org}
    exit 1
fi
IFS=${IFS_org}

# gwdb切断
db2 terminate > /dev/null

##### No Use Delete 2010/02/25 >>>
##### JIRA/GW、DBバックアップ
#####jiradb_backup
#####if [ $? != 0 ]
#####then
#####    exit 1
#####fi
##### 2009/07/31 GWDBバックアップ・リストア処理削除 start
#####gwdb_backup
#####if [ $? != 0 ]
#####then
#####    exit 1
#####fi
##### 2009/07/31 GWDBバックアップ・リストア処理削除 end
##### No Use Delete 2010/02/25 <<<


# jiradb接続
connectDB "${JIRA_DB_NAME}"
if [ $? != 0 ]
then
    exit 1
fi

# csvロード
loading_csv
if [ $? != 0 ]
then
    exit 1
fi

# sequenceIDアップデート
jira_update
if [ $? != 0 ]
then
    exit 1
fi

# jiradb切断
db2 terminate > /dev/null

# gwdb接続
connectDB "${DB_NAME}"
if [ $? != 0 ]
then
    exit 1
fi

# gwdb(pkey,JIRA反映済カラム)アップデート
GWDB_update
if [ $? != 0 ]
then
    exit 1
fi

# gwdb切断
db2 terminate > /dev/null

# tmp/csv削除
tmp_csv_delete

## 終了メッセージ
outlog_func CM-I05002

exit 0
