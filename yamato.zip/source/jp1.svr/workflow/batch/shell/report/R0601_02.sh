#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0601_02.sh
# 業 務 名       ： RP.TB_ISSUE_HISTORY旧データ退避
# 処理概要       ： RP.TB_ISSUE_HISTORYからバックアップ済データを削除する
# 特記事項       ： JIRAがオンライン稼働中でない場合に起動する
# パラメータ     ： なし
# ログファイル   ：
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Ishii
#
# 作成日付       ： 2009-09-30
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-30 S.Ishii              新規作成
# 2 1.0.1 2010-06-14 K.Kinoshita          SQL修正
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
        if [[ -r ${x} ]]
        then
            . ${x}
        else
            echo "Cannot read common env file. ( ${x} )."
            exit 1
        fi
done
# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
for y in ${conf_file_list}
do
        if [[ -r ${y} ]]
        then
            . ${y}
        else
            echo "Cannot read common conf file. ( ${y} )."
            exit 1
        fi
done

# ----
# 業務別環境変数設定
# ----

##本シェル使用変数は、batch_common.confを参照してください。
##本シェル使用関数は、BATCH_COMMON_FUNC.shを参照してください。

###############################################################################
# RP.TB_ISSUE_HISTORY旧データ削除（アーカイブ処理使用）
# 引数１：ステータスが案件終了のデータの抽出日数を指定する。
# 引数２：commit件数を指定する。
###############################################################################
function ISSUE_HISTORY_DELETE
{
	# 抽出日数
	DAY=$1

	# commit件数
	DELETE_COUNT=$2

	# SQL戻り値確認（処理完了後初期化にも利用）
	SQLSTATUS=0

	# JIRADBのRP.TB_ISSUE_HISTORYからバックアップ済みのデータを削除
	while [ ${SQLSTATUS} -eq 0 ]
	do
		db2 +c "delete from
			rp.tb_issue_history
		where
			sequence_number in
				(select
					sequence_number
				from
					rp.tb_issue_history
				where
					status_id = '${ARC_STATUS_ID}' and create_time < (values current timestamp ${DAY} days)
				fetch first ${DELETE_COUNT} rows only)" > ${SQLLOG_TMP}
		SQLSTATUS=$?
		echo -e "日付:`date` || shell名:R0601_02.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		 #DBエラー
		if [ ${SQLSTATUS} -eq 4  -o ${SQLSTATUS} -eq 8 ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func R6-E01010 "RP.TB_ISSUE_HISTORY" "${_errmsg}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi

		db2 commit > /dev/null

		if [ ${SQLSTATUS} -eq 1 ]
		then
			# 削除件数が0件ならループを抜ける
			break
		fi
	done

	return 0
}

###############################################################################
# main処理開始
###############################################################################

# 出力ログ名設定
export log_name="R0601"

### 開始メッセージ
outlog_func R6-I01006


# JIRADB接続
connectDB "${JIRA_DB_NAME}"
if [ $? != 0 ]
then
    outlog_func R6-E01008 "connectDB"
    exit 1
fi

# RP.TB_ISSUE_HISTORYから抽出済データを削除
# 変数${DAY}に出力対象日数を指定(関数ISSUE_HISTORY_EXPORT_CSVにて指定した出力対象日数と同上)
# 変数{DLETE_COUNT}に削除件数を指定
ISSUE_HISTORY_DELETE ${ARC_2MONTH} ${ARC_DELETE_COUNT}
if [ $? != 0 ]
then
    outlog_func R6-E01009 "ISSUE_HISTORY_DELETE"
    exit 1
fi

db2 terminate > /dev/null

## 終了メッセージ
outlog_func R6-I01007
