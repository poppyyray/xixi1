#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0601_01.sh
# 業 務 名       ： RP.TB_ISSUE_HISTORY旧データ退避
# 処理概要       ： RP.TB_ISSUE_HISTORYからバックアップデータを出力する
# 特記事項       ： JIRAがオンライン稼働中でない場合に起動する
# パラメータ     ： なし
# ログファイル   ： 
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Ishii
#
# 作成日付       ： 2009-09-30
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-30 S.Ishii              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
        if [[ -r ${x} ]]
        then
            . ${x}
        else
            echo "Cannot read common env file. ( ${x} )."
            exit 1
        fi
done
# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
for y in ${conf_file_list}
do
        if [[ -r ${y} ]]
        then
            . ${y}
        else
            echo "Cannot read common conf file. ( ${y} )."
            exit 1
        fi
done

# ---- 
# 業務別環境変数設定
# ----

##本シェル使用変数は、batch_common.confを参照してください。
##本シェル使用関数は、BATCH_COMMON_FUNC.shを参照してください。

###############################################################################
# RP.TB_ISSUE_HISTORY旧データ抽出関数（アーカイブ処理使用）
# 引数１：ステータスが案件終了のデータの抽出日数を指定する。
###############################################################################
function ISSUE_HISTORY_EXPORT_CSV
{
	# 抽出日数
	DAY=$1

	# RP.TB_ISSUE_HISTORYのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
	db2 "export to ${ARC_TB_ISSUE_HISTORY} of del
	select * from RP.TB_ISSUE_HISTORY
	where
	sequence_number IN 
	(select 
		sequence_number 
	from 
		rp.tb_issue_history 
	where 
		status_id = '${ARC_STATUS_ID}' and 
		CREATE_TIME < (values current timestamp ${DAY} days))" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:R0601_01.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R6-E01005 "JIRAISSUE" "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	return 0
}

###############################################################################
# main処理開始
###############################################################################

# 出力ログ名設定
export log_name="R0601"

### 開始メッセージ
outlog_func R6-I01001

# JIRADB接続
connectDB "${JIRA_DB_NAME}"
if [ $? != 0 ]
then
    outlog_func R6-E01003 "connectDB"
    exit 1
fi

# RP.TB_ISSUE_HISTORYデータ抽出
# CSV形式にて出力
# 変数${ARC_2MONTH}に出力対象日数を指定
ISSUE_HISTORY_EXPORT_CSV ${ARC_2MONTH}
if [ $? != 0 ]
then
    outlog_func R6-E01004 "ISSUE_HISTORY_EXPORT_CSV"
    exit 1
fi

db2 terminate > /dev/null

## 終了メッセージ
outlog_func R6-I01002
