#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0201.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 事業所データ更新シェル
# 特記事項       ： 
# パラメータ     ： 無し
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2 1.1.0 2009-12-21 M.Saiki                 importリトライ追加
# 3 1.1.1 2009-12-21 K.Murase                importリトライ追加
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func R2-I01001

# ログファイル設定
createlogfile ${0}
log_main_name=`basename ${0} | sed "s/.sh//g"`
export log_name=${log_main_name}

# GWDBに接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R2-E01003 "${_errmsg}"

    # エラー終了
    exit 1
fi

db2 "export to ${CSV_OUT_DIR}/gwdb_jigyosyo_master.csv of del select * from ${TABLE_jigyosho_master}" > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R2-E01004 "${_errmsg}"

    # エラー終了
    exit 1
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R2-E01005 "${_errmsg}"

    # エラー終了
    exit 1
fi

#インポートコマンドの戻り値が８の場合、３回処理を行う。
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
	db2 "import from ${CSV_OUT_DIR}/gwdb_jigyosyo_master.csv of del messages ${TMP_DIR}/R0201_import.log replace into rp.tb_jigyosho_master" > ${SQLLOG_TMP}
	SQLERROR=$?
	
	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${JIRA_DB_NAME}"
		connectDB ${JIRA_DB_NAME}
		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done
	
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
   	# エラーログ出力
   	_errmsg=`cat ${SQLLOG_TMP}`
   	outlog_func R2-E01006 "${_errmsg}"
   	# エラー終了
   	exit 1
fi

# JIRADB切断
db2 terminate > /dev/null

rm -f ${CSV_OUT_DIR}/gwdb_jigyosyo_master.csv

outlog_func R2-I01002

exit 0
