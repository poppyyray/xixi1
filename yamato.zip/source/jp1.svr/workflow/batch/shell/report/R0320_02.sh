#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0320_02.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 発生日別SD稼動数一覧(月次)CSVデータ出力
# 特記事項       ： 
# パラメータ     ： 無し
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R4-I20001

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R4-E20003 "${_errmsg}"

    # エラー終了
    exit 1
fi

# 日付を取得
_timestmp=`date +%Y%m%d`

# 発生日別SD稼動数一覧(月次)テーブルからデータをexportする
db2 "export to ${OUT_REPORT_TMPDIR}/R0320_${_timestmp}.csv of del select wf_input_date,branch_office_code,region_code,region_name,delivery_center_code,delivery_center_name,count from rp.tb_hasseibi_betsu_sdkadousu_ichiran" > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R4-E20004 "${_errmsg}"

	# エラー終了
	exit 1
fi

# ファイル名に処理日付をセットする
db2 "export to ${OUT_REPORT_TMPDIR}/R0320_DATE of del modified by nochardel select run_date from rp.tb_run_date" >> ${SQLLOG_TMP}
_run_date=`cat ${OUT_REPORT_TMPDIR}/R0320_DATE`
R0320_REPORT_FILENAME=`echo ${R0320_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`

# JIRADB切断
db2 terminate > /dev/null

# UTF-8のCSVファイルをSJISにコード変換する
nkf --ic=UTF-8 --oc=CP932 ${OUT_REPORT_TMPDIR}/R0320_${_timestmp}.csv > ${OUT_REPORT_TMPDIR}/R0320_${_timestmp}.csv.sjis
if [ $? != '0' ]
then
	outlog_func R4-E20007 "${OUT_REPORT_TMPDIR}/R0320_${_timestmp}.csv"
	exit 1
fi

# UTF-8のCSVファイルを削除する
rm -f ${OUT_REPORT_TMPDIR}/R0320_${_timestmp}.csv

# 出力件数を変数に格納
_export_cnt=`tail -2 ${SQLLOG_TMP} | head -1 | awk -F":" '{print $2}'`

outlog_func R4-I20005 ${_export_cnt} ${R0320_REPORT_FILENAME}

# 出力件数を変数に格納
_export_cnt=`tail -2 ${SQLLOG_TMP} | head -1 | awk -F":" '{print $2}'`

outlog_func R4-I20005 ${_export_cnt}

# マウントされているフォルダへCSVファイルを移動する
mv -f ${OUT_REPORT_TMPDIR}/R0320_${_timestmp}.csv.sjis ${OUT_REPORT_DIR}/${R0320_REPORT_FILENAME}
if [ $? != '0' ]
then
	outlog_func R4-E20006 "${OUT_REPORT_DIR}"
	exit 1
fi

# 終了メッセージ
outlog_func R4-I20002

exit 0
