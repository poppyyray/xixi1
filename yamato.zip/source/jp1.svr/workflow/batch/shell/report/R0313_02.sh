#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0313_02.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 処理日数別件数一覧(月次)CSVデータ出力
# 特記事項       ： 
# パラメータ     ： 1:委託先部分レポーティング出力
#                ： 2:案件全体レポーティング出力
#                ： 3:10日毎委託先部分レポーティング出力
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2 1.1.0 2014-03-19 LiuHui                  SLA情報出力（処理達成率・処理日遵守率）対応
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R4-I13001 $1

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" -a "$1" != "3" ]
then
	outlog_func R4-E13008
	exit 1
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R4-E13003 "${_errmsg}"

    # エラー終了
    exit 1
fi

# 日付を取得
_timestmp=`date +%Y%m%d`

# 処理日数別件数一覧(月次)テーブルからデータをexportする
db2 "export to ${OUT_REPORT_TMPDIR}/R0313_${_timestmp}.csv of del select summary_type,process_day,output_date,status,service_id,service_name,count from rp.tb_shorinissuu_betsu_kensu_ichiran" > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R4-E13004 "${_errmsg}"

	# エラー終了
	exit 1
fi

# ファイル名に処理日付をセットする
db2 "export to ${OUT_REPORT_TMPDIR}/R0313_DATE of del modified by nochardel select run_date from rp.tb_run_date" >> ${SQLLOG_TMP}
_run_date=`cat ${OUT_REPORT_TMPDIR}/R0313_DATE`
R0313_01_REPORT_FILENAME=`echo ${R0313_01_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`
R0313_02_REPORT_FILENAME=`echo ${R0313_02_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`

# JIRADB切断
db2 terminate > /dev/null

# 引数1:委託先部分レポーティング出力
# 引数3:10日毎委託先部分レポーティング出力
if [ $1 = '1'  -o $1 = '3' ]
then
	R0313_REPORT_FILENAME=${R0313_01_REPORT_FILENAME}
# 引数2:案件全体レポーティング出力
elif [ $1 = '2' ]
then
	R0313_REPORT_FILENAME=${R0313_02_REPORT_FILENAME}
fi

# UTF-8のCSVファイルをSJISにコード変換する
nkf --ic=UTF-8 --oc=CP932 ${OUT_REPORT_TMPDIR}/R0313_${_timestmp}.csv > ${OUT_REPORT_TMPDIR}/R0313_${_timestmp}.csv.sjis
if [ $? != '0' ]
then
	outlog_func R4-E13007 "${OUT_REPORT_TMPDIR}/R0313_${_timestmp}.csv"
	exit 1
fi

# UTF-8のCSVファイルを削除する
rm -f ${OUT_REPORT_TMPDIR}/R0313_${_timestmp}.csv

# 出力件数を変数に格納
_export_cnt=`tail -2 ${SQLLOG_TMP} | head -1 | awk -F":" '{print $2}'`

outlog_func R4-I13005 ${_export_cnt} ${R0313_REPORT_FILENAME}

# マウントされているフォルダへCSVファイルを移動する
mv -f ${OUT_REPORT_TMPDIR}/R0313_${_timestmp}.csv.sjis ${OUT_REPORT_DIR}/${R0313_REPORT_FILENAME}
if [ $? != '0' ]
then
	outlog_func R4-E13006 "${OUT_REPORT_DIR}"
	exit 1
fi

# 終了メッセージ
outlog_func R4-I13002

exit 0
