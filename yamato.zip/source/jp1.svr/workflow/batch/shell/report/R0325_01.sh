#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0325_01.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 処理完了明細一覧(月次)テーブル作成
# 特記事項       ：
# パラメータ     ： 1:委託先部分レポーティング出力
#                ： 2:案件全体レポーティング出力
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Yang Xi
#
# 作成日付       ： 2010-08-22
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-08-22 Yang Xi              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R3-I25001 $1

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" ]
then
	outlog_func R3-E25006
	exit 1
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R3-E25003 "${_errmsg}"

    # エラー終了
    exit 1
fi

#暦日２日（0:00）
bf_date_02=`db2 -x "select rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day from sysibm.sysdummy1"`
#歴日１日（23:59:59）
date_01=`db2 -x "select rp.fn_last_date(rp.fn_run_date() - 1 months) + 1 day from sysibm.sysdummy1"`
#第二営業日（23:59:59）
business_date_02=`db2 -x "select rp.fn_last_business_date(rp.fn_run_date()) from sysibm.sysdummy1"`

# 引数1:委託先部分レポーティング出力
if [ $1 = '1' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 処理完了明細一覧(月次)テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_shorikanryou_meisai" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E25004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから処理完了明細一覧(月次)テーブルへ対象データをinsertする
	db2 "insert into
	rp.tb_shorikanryou_meisai (
	output_date,
	created_date,
	service_id,
	service_name,
	sequence_number,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	has_form,
	personal_number,
	owner_role_id,
	owner_role_name,
	owner_id,
	status_id,
	status,
	reason_id,
	reason,
	content_id,
	content,
	event_id,
	event,
	sagyoubi,
	issue_create_date,
	has_form_date
	)
	select
		current timestamp,
		created_date,
		service_id,
		service_name,
		sequence_number,
		branch_office_code,
		region_code,
		region_name,
		delivery_center_code,
		delivery_center_name,
		has_form,
		personal_number,
		owner_role_id,
		owner_role_name,
		owner_id,
		status_id,
		status,
		reason_id,
		reason,
		content_id,
		content,
		event_id,
		event,
		sagyoubi,
		(select max(created_date) from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number),
		(select max(created_date) from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number)
		from
		rp.tb_issue_history b
		where (sequence_number,created_date) in (
		select sequence_number,min(created_date) from rp.tb_issue_history
			where (status_id = 'C01' or status_id = 'C03' or status_id = 'D01')
			and create_type = '3'
			and created_date between timestamp('${bf_date_02}') and timestamp('${business_date_02}')
			and complete_flag = 'Y'
			group by sequence_number)
		and sequence_number in (
                	select sequence_number
                	from rp.tb_issue_history 
                	where create_type='1' 
                	and created_date between timestamp('${bf_date_02}') and timestamp('${date_01}') 
                	and complete_flag = 'Y'
                	)" > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E25005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数2:案件全体レポーティング出力
elif [ $1 = '2' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 処理完了明細一覧(月次)テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_shorikanryou_meisai" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E25004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから処理完了明細一覧(月次)テーブルへ対象データをinsertする
	db2 "INSERT INTO 
		RP.TB_SHORIKANRYOU_MEISAI (
        output_date,
        created_date,
        service_id,
        service_name,
        sequence_number,
        branch_office_code,
        region_code,
        region_name,
        delivery_center_code,
        delivery_center_name,
        has_form,
        personal_number,
        owner_role_id,
        owner_role_name,
        owner_id,
        status_id,
        status,
        reason_id,
        reason,
        content_id,
        content,
        event_id,
        event,
        sagyoubi,
        issue_create_date,
        has_form_date
	)
	select
        CURRENT TIMESTAMP,
        created_date,
        service_id,
        service_name,
        sequence_number,
        branch_office_code,
        region_code,
        region_name,
        delivery_center_code,
        delivery_center_name,
        has_form,
        personal_number,
        owner_role_id,
        owner_role_name,
        owner_id,
        status_id,
        status,
        reason_id,
        reason,
        content_id,
        content,
        event_id,
        event,
        sagyoubi,
        (select max(created_date) from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number),
        (select max(created_date) from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number)
	from
        rp.tb_issue_history b
        where status_id = 'E01'
        and create_type = '3'
        and created_date between timestamp('${bf_date_02}') and timestamp('${business_date_02}')
        and complete_flag = 'Y'
        and sequence_number in (
                	select sequence_number
                	from rp.tb_issue_history 
                	where create_type='1' 
                	and created_date between timestamp('${bf_date_02}') and timestamp('${date_01}') 
                	and complete_flag = 'Y'
                	)" > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E25005 "${_errmsg}"

		# エラー終了
		exit 1
	fi
fi

# JIRADB切断
db2 terminate > /dev/null

# 終了メッセージ
outlog_func R3-I25002

exit 0