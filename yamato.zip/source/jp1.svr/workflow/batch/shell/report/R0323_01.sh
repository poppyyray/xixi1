#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0323_01.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 担当者別処理件数一覧(月次)テーブル作成
# 特記事項       ： 
# パラメータ     ： 無し
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2 1.1.0 2009-12-22 K.Murase                importリトライ追加
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R3-I23001

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R3-E23003 "${_errmsg}"

    # エラー終了
    exit 1
fi

#インポートコマンドの戻り値が８の場合、３回処理を行う。
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
	# 担当者別処理件数一覧(月次)テーブルをクリアする
	db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_tantousha_betsu_shorikensu_ichiran" > ${SQLLOG_TMP}
	SQLERROR=$?
	#DBエラー（ループに戻す）　エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${JIRA_DB_NAME}"
		connectDB ${JIRA_DB_NAME}
		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		#正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

# DBエラー
if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R3-E23004 "${_errmsg}"

	# エラー終了
	exit 1
fi

# 履歴テーブルから担当者別処理件数一覧(月次)テーブルへ対象データをinsertする
db2 -tvf ${SQL_DIR}/report/R0323_01.sql > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R3-E23005 "${_errmsg}"

	# エラー終了
	exit 1
fi

# JIRADB切断
db2 terminate > /dev/null

# 終了メッセージ
outlog_func R3-I23002

exit 0
