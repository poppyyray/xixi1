#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0206.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 履歴レコード情報付加
# 特記事項       ： 
# パラメータ     ： 1:月末日の判定を行う。
#                ： 2:第二営業日の判定を行う。
# リターンコード ： 0             対象日
#                   1             対象日以外
#                   2             エラー
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R2-I06001 $1

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" ]
then
	outlog_func R2-E06003
	exit 2
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R2-E06004 "${_errmsg}"

    # エラー終了
    exit 2
fi

# 引数1:月末日の判定を行う。
if [ $1 = '1' ]
then

	db2 -tvf ${SQL_DIR}/report/R0206_01.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R2-E06005 "${_errmsg}"

		# エラー終了
		exit 2
	# 対象日以外の場合
	elif [ ${SQLERROR} -eq 1 ]
	then
		# JIRADB切断
		db2 terminate > /dev/null
		outlog_func R2-I06006
		exit 1
	fi

	outlog_func R2-I06002 "月末日"

# 引数2:第二営業日の判定を行う。
elif [ $1 = '2' ]
then

	db2 -tvf ${SQL_DIR}/report/R0206_02.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R2-E06007 "${_errmsg}"

		# エラー終了
		exit 2
	# 対象日以外の場合
	elif [ ${SQLERROR} -eq 1 ]
	then
		# JIRADB切断
		db2 terminate > /dev/null
		outlog_func R2-I06008
		exit 1
	fi
	outlog_func R2-I06002 "第二営業日"
fi

# JIRADB切断
db2 terminate > /dev/null

exit 0
