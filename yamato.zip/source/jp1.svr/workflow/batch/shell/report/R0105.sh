#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0105.sh
# 業 務 名       ： なし
# 処理概要       ： 帳票キュー監視開始
# 特記事項       ： タイマ起動（起動時刻：07:30）
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ：S.Tsuruha
#
# 作成日付       ：2009-06-01
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-06-01 S.Tsuruha              新規作成
# 2 1.0.1 2010-04-22 H.Someya               コメント修正
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始ログ出力
outlog_func R1-I05001

JAVA_CLASSPATH_REPORT="/shared/reporting/lib/activation.jar:/shared/reporting/lib/commons-discovery-0.2.jar:/shared/reporting/lib/commons-lang-2.3.jar:/shared/reporting/lib/db2jcc.jar:/shared/reporting/lib/ganymed-ssh2-build210.jar:/shared/reporting/lib/javax.wsdl_1.5.1.v200806030408.jar:/shared/reporting/lib/jaxb-api.jar:/shared/reporting/lib/jaxb-impl.jar:/shared/reporting/lib/jaxb-xjc.jar:/shared/reporting/lib/jsr173_1.0_api.jar:/shared/reporting/lib/log4j-1.2.7.jar:/shared/reporting/lib/org.apache.commons.logging_1.0.4.v20080605-1930.jar:/shared/reporting/lib/working-rpc-reporting-plugin-ibm-3.12-1.jar:/shared/reporting/lib/working-rpc-jira-plugin-ibmaddon-3.12-1.jar:/shared/reporting/conf"

# キューテーブル監視
/opt/ibm/db2/V9.5/java/jdk64/bin/java -classpath "${JAVA_CLASSPATH_REPORT}" com.ibm.reporting.JobExecutor >> ${LOG_DIR}/REPORTING_JAVA.log 2>&1
RC=$?
case ${RC} in
        0)      outlog_func R1-I05003 ${RC};;
        *)      outlog_func R1-E05004 ${RC}
                exit 1;;
esac

# 終了ログ出力
outlog_func R1-I05002

exit 0
