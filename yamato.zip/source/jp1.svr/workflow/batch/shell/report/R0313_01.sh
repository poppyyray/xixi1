#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0313_01.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 処理日数別件数一覧(月次)テーブル作成
# 特記事項       ：
# パラメータ     ： 1:委託先部分レポーティング出力
#                ： 2:案件全体レポーティング出力
#                ： 3:10日毎委託先部分レポーティング出力
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2 1.1.0 2014-03-19 LiuHui                  SLA情報出力（処理達成率・処理日遵守率）対応
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R3-I13001 $1

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" -a "$1" != "3" ]
then
	outlog_func R3-E13006
	exit 1
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R3-E01303 "${_errmsg}"

    # エラー終了
    exit 1
fi

# 10日毎指定日レポーティング出力
if [ $1 = '3' ]
then
	first_date=`db2 -x "select rp.fn_first_date(rp.fn_run_date()) + 1 day from sysibm.sysdummy1"`
	# rp.fn_run_date()の返却値がyyyy-mm-dd 00:00:00、出力範囲がyyyy-mm-dd 23:59:39まで
	last_date=`db2 -x "select TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-23.59.59.999999') from sysibm.sysdummy1"`
else
	# 第二営業日レポーティング出力
	first_date=`db2 -x "select rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day from sysibm.sysdummy1"`
	last_date=`db2 -x "select rp.fn_last_date(rp.fn_run_date() - 1 months) + 1 day from sysibm.sysdummy1"`
fi

# 引数1:委託先部分レポーティング出力
# 引数3:10日毎委託先部分レポーティング出力
if [ $1 = '1' -o $1 = '3' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 処理日数別件数一覧(月次)テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_shorinissuu_betsu_kensu_ichiran" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E13004 "${_errmsg}"

		# エラー終了
		exit 1
	fi





	# 履歴テーブルから処理日数別件数一覧(月次)テーブルへ対象データをinsertする
#	db2 -tvf ${SQL_DIR}/report/R0313_01.sql > ${SQLLOG_TMP}
db2 -x +p INSERT INTO \\ <<SQLTEXT >${SQLLOG_TMP}
rp.tb_shorinissuu_betsu_kensu_ichiran( \\
	summary_type, \\
	process_day, \\
	output_date, \\
	status, \\
	service_id, \\
	service_name, \\
	count \\
) \\
SELECT \\
	'委託', \\
	process_day, \\
	CURRENT TIMESTAMP, \\
	status_id ||':'|| status, \\
	service_id, \\
	service_name, \\
	count(*) \\
FROM  \\
	(select  \\
		CASE  \\
		WHEN service_id = '4.4.1' THEN days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') order by created_date asc fetch first 1 rows only)) -  \\
			days((select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number)) \\
		ELSE days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') order by created_date asc fetch first 1 rows only)) -  \\
			days((select created_date from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number)) \\
		END process_day, \\
		status_id, \\
		status, \\
		service_id, \\
		service_name \\
	from \\
		rp.tb_issue_history b \\
	where (sequence_number,created_date) in ( \\
		select sequence_number,min(created_date) from rp.tb_issue_history \\
		where (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') \\
		and sequence_number in (select sequence_number from rp.tb_issue_history where create_type='1' and  \\
			(created_date between  \\
				timestamp('${first_date}') and timestamp('${last_date}'))) \\
		and complete_flag = 'Y' \\
		group by sequence_number) \\
	) \\
GROUP BY \\
	process_day, \\
	status, \\
	status_id, \\
	service_id, \\
	service_name
SQLTEXT

	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E13005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数2:案件全体レポーティング出力
elif [ $1 = '2' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 処理日数別件数一覧(月次)テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_shorinissuu_betsu_kensu_ichiran" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E13004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから処理日数別件数一覧(月次)テーブルへ対象データをinsertする
#	db2 -tvf ${SQL_DIR}/report/R0313_02.sql > ${SQLLOG_TMP}
db2 -x +p INSERT INTO \\ <<SQLTEXT >${SQLLOG_TMP}
rp.tb_shorinissuu_betsu_kensu_ichiran( \\
	summary_type, \\
	process_day, \\
	output_date, \\
	status, \\
	service_id, \\
	service_name, \\
	count \\
) \\
SELECT \\
	'案件', \\
	process_day, \\
	CURRENT TIMESTAMP, \\
	status_id ||':'|| status, \\
	service_id, \\
	service_name, \\
	count(*) \\
FROM  \\
	(select  \\
		days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and status_id = 'E01' and create_type = '3')) -  \\
		days((select created_date from rp.tb_issue_history where create_type = '1' and sequence_number = b.sequence_number)) process_day, \\
		status_id, \\
		status, \\
		service_id, \\
		service_name \\
	from \\
		rp.tb_issue_history b \\
	where (sequence_number,created_date) in ( \\
		select sequence_number,min(created_date) from rp.tb_issue_history \\
		where status_id = 'E01' \\
		and sequence_number in ( \\
			select sequence_number  \\
			from rp.tb_issue_history  \\
			where create_type='1' and  \\
				(created_date between  \\
					timestamp('${first_date}') and timestamp('${last_date}'))) \\
		and complete_flag = 'Y' \\
		group by sequence_number) \\
	) \\
GROUP BY \\
	process_day, \\
	status, \\
	status_id, \\
	service_id, \\
	service_name
SQLTEXT


	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E13005 "${_errmsg}"

		# エラー終了
		exit 1
	fi
fi

# JIRADB切断
db2 terminate > /dev/null

# 終了メッセージ
outlog_func R3-I13002

exit 0

