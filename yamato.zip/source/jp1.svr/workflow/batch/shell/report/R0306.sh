#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0306.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 未処理案件明細(月次)起動シェル
# 特記事項       ： 
# パラメータ     ： 無し
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func R3-I06006

# ログファイル設定
createlogfile ${0}
log_main_name=`basename ${0} | sed "s/.sh//g"`
export log_name=${log_main_name}

/bin/sh ${SHELL_DIR}/report/R0306_01.sh
RETURN_CODE=$?
if [ ${RETURN_CODE} != '0' ]
then
	outlog_func R3-E06007
	exit 1
fi

# レポート出力シェルを呼ぶ
/bin/sh ${SHELL_DIR}/report/R0306_02.sh
RETURN_CODE=$?
if [ ${RETURN_CODE} = '2' ]
then
	outlog_func R3-I06008
    exit 2
elif [ ${RETURN_CODE} != '0' ]
then
	outlog_func R3-E06009
	exit 1
fi

outlog_func R3-I06010

exit 0
