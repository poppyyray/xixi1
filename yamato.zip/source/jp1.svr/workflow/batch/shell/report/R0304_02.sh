#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0304_02.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 発生日別件数一覧(月次、日次)CSVデータ出力
# 特記事項       ： 
# パラメータ     ： 1:変動料金（主管コード別）（月次）
#                ： 2:証憑マッチング基準（月次）
#                ： 3:案件登録基準（月次）
#                ： 4:変動料金（主管コード、店所別）（月次）
#                ： 5:証憑マッチング基準（日次）
#                ： 6:案件登録基準（日次）
#                ： 7:変動料金（主管コード別）（日次）
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R4-I04001 $1

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" -a "$1" != "3" -a "$1" != "4" -a "$1" != "5" -a "$1" != "6" -a "$1" != "7" ]
then
	outlog_func R4-E04008
	exit 1
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R4-E04003 "${_errmsg}"

    # エラー終了
    exit 1
fi

# 日付を取得
_timestmp=`date +%Y%m%d`

# 発生日別件数一覧テーブルからデータをexportする
if [ $1 = '1' -o $1 = '2' -o $1 = '3' -o $1 = '5' -o $1 = '6' -o $1 = '7' ]
then
db2 "export to ${OUT_REPORT_TMPDIR}/R0304_${_timestmp}.csv of del select branch_office_code,region_code,region_name,service_id,service_name,output_date,occur_date,count from rp.tb_hasseibi_betsu_kensu_ichiran" > ${SQLLOG_TMP}
elif [ $1 = '4' ]
then
db2 "export to ${OUT_REPORT_TMPDIR}/R0304_${_timestmp}.csv of del select branch_office_code,region_code,region_name,delivery_center_code,delivery_center_name,service_id,service_name,output_date,occur_date,count from rp.tb_hasseibi_betsu_kensu_ichiran" > ${SQLLOG_TMP}
fi
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R4-E04004 "${_errmsg}"

	# エラー終了
	exit 1
fi

# ファイル名に処理日付をセットする
db2 "export to ${OUT_REPORT_TMPDIR}/R0304_DATE of del modified by nochardel select run_date from rp.tb_run_date" >> ${SQLLOG_TMP}
_run_date=`cat ${OUT_REPORT_TMPDIR}/R0304_DATE`
R0304_01_REPORT_FILENAME=`echo ${R0304_01_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`
R0304_02_REPORT_FILENAME=`echo ${R0304_02_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`
R0304_03_REPORT_FILENAME=`echo ${R0304_03_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`
R0304_04_REPORT_FILENAME=`echo ${R0304_04_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`
R0304_05_REPORT_FILENAME=`echo ${R0304_05_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`
R0304_06_REPORT_FILENAME=`echo ${R0304_06_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`
R0304_07_REPORT_FILENAME=`echo ${R0304_07_REPORT_FILENAME} | sed -e s/rundate/${_run_date}/`

# JIRADB切断
db2 terminate > /dev/null

# 引数1
if [ $1 = '1' ]
then
	R0304_REPORT_FILENAME=${R0304_01_REPORT_FILENAME}
# 引数2
elif [ $1 = '2' ]
then
	R0304_REPORT_FILENAME=${R0304_02_REPORT_FILENAME}
# 引数3
elif [ $1 = '3' ]
then
	R0304_REPORT_FILENAME=${R0304_03_REPORT_FILENAME}
# 引数4
elif [ $1 = '4' ]
then
	R0304_REPORT_FILENAME=${R0304_04_REPORT_FILENAME}
# 引数5
elif [ $1 = '5' ]
then
	R0304_REPORT_FILENAME=${R0304_05_REPORT_FILENAME}
# 引数6
elif [ $1 = '6' ]
then
	R0304_REPORT_FILENAME=${R0304_06_REPORT_FILENAME}
# 引数7
elif [ $1 = '7' ]
then
	R0304_REPORT_FILENAME=${R0304_07_REPORT_FILENAME}
fi

# UTF-8のCSVファイルをSJISにコード変換する
nkf --ic=UTF-8 --oc=CP932 ${OUT_REPORT_TMPDIR}/R0304_${_timestmp}.csv > ${OUT_REPORT_TMPDIR}/R0304_${_timestmp}.csv.sjis
if [ $? != '0' ]
then
	outlog_func R4-E04007 "${OUT_REPORT_TMPDIR}/R0304_${_timestmp}.csv"
	exit 1
fi

# UTF-8のCSVファイルを削除する
rm -f ${OUT_REPORT_TMPDIR}/R0304_${_timestmp}.csv

# 出力件数を変数に格納
_export_cnt=`tail -2 ${SQLLOG_TMP} | head -1 | awk -F":" '{print $2}'`

outlog_func R4-I04005 ${_export_cnt} ${R0304_REPORT_FILENAME}

# マウントされているフォルダへCSVファイルを移動する
mv -f ${OUT_REPORT_TMPDIR}/R0304_${_timestmp}.csv.sjis ${OUT_REPORT_DIR}/${R0304_REPORT_FILENAME}
if [ $? != '0' ]
then
	outlog_func R4-E04006 "${OUT_REPORT_DIR}"
	exit 1
fi

# 終了メッセージ
outlog_func R4-I04002

exit 0
