#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0314_01.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 処理遅延発生明細(月次)テーブル作成
# 特記事項       ：
# パラメータ     ： 1:第二営業日
#                ： 2:指定日
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2 1.1.0 2009-12-21 M.Saiki                 importリトライ追加
# 3 1.1.1 2009-12-21 K.Murase                importリトライ追加
# 4 1.1.2 2014-3-19  LiuHui                  SLA情報出力（処理達成率・処理日遵守率）対応
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R3-I14001 $1

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" ]
then
	outlog_func R3-E14011
	exit 1
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R3-E14003 "${_errmsg}"

    # エラー終了
    exit 1
fi

#インポートコマンドの戻り値が８の場合、３回処理を行う。
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
	# 処理遅延発生明細(月次)テーブルをクリアする
	db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_shorichien_hassei_meisai" > ${SQLLOG_TMP}
	SQLERROR=$?
	#DBエラー（ループに戻す）　エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${JIRA_DB_NAME}"
		connectDB ${JIRA_DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8

	else
		#正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done
# DBエラー
if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R3-E14004 "${_errmsg}"

	# エラー終了
	exit 1
fi

# 履歴テーブルから処理遅延発生明細(月次)テーブルへ対象データをinsertする
#db2 -tvf ${SQL_DIR}/report/R0314_01.sql > ${SQLLOG_TMP}

# 10日毎指定日レポーティング出力
if [ $1 = '2' ]
then
	first_date=`db2 -x "select rp.fn_first_date(rp.fn_run_date()) + 1 day from sysibm.sysdummy1"`
	# rp.fn_run_date()の返却値がyyyy-mm-dd 00:00:00、出力範囲がyyyy-mm-dd 23:59:39まで
	last_date=`db2 -x "select TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-23.59.59.999999') from sysibm.sysdummy1"`
else
	# 第二営業日レポーティング出力
	first_date=`db2 -x "select rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day from sysibm.sysdummy1"`
	last_date=`db2 -x "select rp.fn_last_date(rp.fn_run_date() - 1 months) + 1 day from sysibm.sysdummy1"`
fi

db2 -x +p INSERT INTO \\ <<SQLTEXT >${SQLLOG_TMP}
rp.tb_shorichien_hassei_meisai( \\
	output_date, \\
	created_date, \\
	service_id, \\
	service_name, \\
	sequence_number, \\
	branch_office_code, \\
	region_code, \\
	region_name, \\
	delivery_center_code, \\
	delivery_center_name, \\
	has_form, \\
	personal_number, \\
	owner_role_id, \\
	owner_role_name, \\
	owner_id, \\
	status_id, \\
	status, \\
	reason_id, \\
	reason, \\
	content_id, \\
	content, \\
	event_id, \\
	event, \\
	sagyoubi, \\
	issue_create_date, \\
	has_form_date, \\
	process_day_dairen, \\
	keika_day_issue \\
) \\
select * from ( \\
	select  \\
		CURRENT TIMESTAMP, \\
		c.created_date, \\
		c.service_id, \\
		c.service_name, \\
		c.sequence_number, \\
		c.branch_office_code, \\
		c.region_code, \\
		c.region_name, \\
		c.delivery_center_code, \\
		c.delivery_center_name, \\
		c.has_form, \\
		c.personal_number, \\
		c.owner_role_id, \\
		c.owner_role_name, \\
		c.owner_id, \\
		b.status_id, \\
		b.status, \\
		c.reason_id, \\
		c.reason, \\
		c.content_id, \\
		c.content, \\
		c.event_id, \\
		c.event, \\
		c.sagyoubi, \\
		(select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number), \\
		(select created_date from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number), \\
		CASE  \\
			WHEN b.service_id = '4.4.1' THEN days(b.created_date) -  \\
				days((select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number)) \\
			ELSE days(b.created_date) -  \\
				days((select created_date from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number)) \\
			END as itaku_nissu,	 \\
		days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and status_id = 'E01' and create_type = '3')) -  \\
			days((select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number)) \\
		from \\
			(select * from rp.tb_issue_history \\
	 		where (sequence_number,created_date) in ( \\
			select sequence_number,min(created_date) from rp.tb_issue_history \\
			where (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') \\
		        and sequence_number in (select sequence_number from rp.tb_issue_history where create_type='1' and  \\
			created_date between timestamp('${first_date}') and timestamp('${last_date}')) \\
			and complete_flag = 'Y' group by sequence_number)  \\
			) b, \\
			(select * from rp.tb_issue_history \\
			where (sequence_number,created_date) in ( \\
			select sequence_number,max(created_date) from rp.tb_issue_history \\
			where sequence_number in (select sequence_number from rp.tb_issue_history where create_type='1' and  \\
			created_date between timestamp('${first_date}') and timestamp('${last_date}')) \\
			and complete_flag = 'Y' group by sequence_number)  \\
			) c \\
		where b.sequence_number=c.sequence_number \\
	) \\
where itaku_nissu >= 2
SQLTEXT

SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R3-E14005 "${_errmsg}"

	# エラー終了
	exit 1
fi

# JIRADB切断
db2 terminate > /dev/null

# 終了メッセージ
outlog_func R3-I14002

exit 0
