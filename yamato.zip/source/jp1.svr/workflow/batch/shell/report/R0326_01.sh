#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0326_01.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 四業務(経費振込、入金アンマッチ処理、一般集金(手動)、振込入金)
#                                  問合せ案件明細（月次）テーブル作成
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Yang Xi
#
# 作成日付       ： 2010-09-03
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-09-03 Yang Xi              新規作成
# 2 1.1.0 2010-12-7  jingwei.zhou         三業務追加
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R3-I26001

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R3-E26003 "${_errmsg}"

    # エラー終了
    exit 1
fi

#暦日２日（0:00）
bf_date_02=`db2 -x "select rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day from sysibm.sysdummy1"`
#歴日１日（23:59:59）
date_01=`db2 -x "select rp.fn_last_date(rp.fn_run_date() - 1 months) + 1 day from sysibm.sysdummy1"`
#第二営業日（23:59:59）
business_date_02=`db2 -x "select rp.fn_last_business_date(rp.fn_run_date()) from sysibm.sysdummy1"`

#インポートコマンドの戻り値が８の場合、３回処理を行う。
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
	# 振込入金手動消込問合せ案件明細(月次)テーブルをクリアする
	db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_furikomi_toiawase_meisai" > ${SQLLOG_TMP}
	SQLERROR=$?
	#DBエラー（ループに戻す）　エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${JIRA_DB_NAME}"
		connectDB ${JIRA_DB_NAME}
		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		#正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

# DBエラー
if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R3-E26004 "${_errmsg}"

	# エラー終了
	exit 1
fi

	# 履歴テーブルから振込入金手動消込_問合せ案件明細(月次)テーブルへ対象データをinsertする
	db2 "insert into
	rp.tb_furikomi_toiawase_meisai (
	output_date,
	created_date,
	service_id,
	service_name,
	sequence_number,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	pre_status_id,
	pre_status,
	event_id,
	event,
	has_question,
	issue_create_date
	)
	select
        current timestamp,
        created_date,
        service_id,
        service_name,
        sequence_number,
        branch_office_code,
        region_code,
        region_name,
        delivery_center_code,
        delivery_center_name,
        (select status_id from rp.tb_issue_history a where a.sequence_number = b.sequence_number and a.create_type = '3' and a.status_id <> 'E01' order by a.created_date desc fetch first 1 rows only),
        (select status from rp.tb_issue_history a where a.sequence_number = b.sequence_number and a.create_type = '3' and a.status_id <> 'E01' order by a.created_date desc fetch first 1 rows only),
        event_id,
        event,
        (select 'Y' from rp.tb_issue_history a where a.sequence_number = b.sequence_number and a.create_type = '3' and a.status_id = 'C01' fetch first 1 rows only),
        (select max(created_date) from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number)
  from
        rp.tb_issue_history b
        where (service_id = '4.4.1' or service_id = '3.1.2' or service_id = '3.1.4' or service_id = '4.2.2')
       	and status_id = 'E01'
        and create_type = '3'
        and created_date between timestamp('${bf_date_02}') and timestamp('${business_date_02}')
        and complete_flag = 'Y'
        and sequence_number in (
                	select sequence_number
                	from rp.tb_issue_history 
                	where create_type='1' 
                	and created_date between timestamp('${bf_date_02}') and timestamp('${date_01}') 
                	and complete_flag = 'Y'
                	)" > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E26005 "${_errmsg}"

		# エラー終了
		exit 1
	fi
	
# JIRADB切断
db2 terminate > /dev/null

# 終了メッセージ
outlog_func R3-I26002

exit 0
