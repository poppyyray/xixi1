#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0304_01.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 発生日別件数一覧テーブル作成
# 特記事項       ： 
# パラメータ     ： 1:変動料金（主管コード別）（月次）
#                ： 2:証憑マッチング基準（月次）
#                ： 3:案件登録基準（月次）
#                ： 4:変動料金（主管コード、店所別）（月次）
#                ： 5:証憑マッチング基準（日次）
#                ： 6:案件登録基準（日次）
#                ： 7:変動料金（主管コード別）（日次）
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2 1.1.0 2009-12-22 K.Murase                importリトライ追加
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R3-I04001 $1

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" -a "$1" != "3" -a "$1" != "4" -a "$1" != "5" -a "$1" != "6" -a "$1" != "7" ]
then
	outlog_func R3-E04006
	exit 1
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R3-E04003 "${_errmsg}"

    # エラー終了
    exit 1
fi

# 引数1
if [ $1 = '1' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 発生日別件数一覧テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_hasseibi_betsu_kensu_ichiran" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
			
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから発生日別件数一覧テーブルへ対象データをinsertする
	db2 -tvf ${SQL_DIR}/report/R0304_01.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数2
elif [ $1 = '2' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 発生日別件数一覧テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_hasseibi_betsu_kensu_ichiran" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
			
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから発生日別件数一覧テーブルへ対象データをinsertする
	db2 -tvf ${SQL_DIR}/report/R0304_02.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数3
elif [ $1 = '3' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 発生日別件数一覧テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_hasseibi_betsu_kensu_ichiran" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから発生日別件数一覧テーブルへ対象データをinsertする
	db2 -tvf ${SQL_DIR}/report/R0304_03.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数4
elif [ $1 = '4' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 発生日別件数一覧テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_hasseibi_betsu_kensu_ichiran" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
			
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから発生日別件数一覧テーブルへ対象データをinsertする
	db2 -tvf ${SQL_DIR}/report/R0304_04.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数5
elif [ $1 = '5' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 発生日別件数一覧テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_hasseibi_betsu_kensu_ichiran" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
			
			else
				#正常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから発生日別件数一覧テーブルへ対象データをinsertする
	db2 -tvf ${SQL_DIR}/report/R0304_05.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数6
elif [ $1 = '6' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 発生日別件数一覧テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_hasseibi_betsu_kensu_ichiran" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
			
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから発生日別件数一覧テーブルへ対象データをinsertする
	db2 -tvf ${SQL_DIR}/report/R0304_06.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数7
elif [ $1 = '7' ]
then
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		# 発生日別件数一覧テーブルをクリアする
		db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_hasseibi_betsu_kensu_ichiran" > ${SQLLOG_TMP}
		SQLERROR=$?
		#DBエラー（ループに戻す）　エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"
			connectDB ${JIRA_DB_NAME}
			
			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
			
		else
			#正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04004 "${_errmsg}"

		# エラー終了
		exit 1
	fi

	# 履歴テーブルから発生日別件数一覧テーブルへ対象データをinsertする
	db2 -tvf ${SQL_DIR}/report/R0304_07.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R3-E04005 "${_errmsg}"

		# エラー終了
		exit 1
	fi
fi

# JIRADB切断
db2 terminate > /dev/null

# 終了メッセージ
outlog_func R3-I04002

exit 0
