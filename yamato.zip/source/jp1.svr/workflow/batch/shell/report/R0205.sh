#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0205.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 処理日付更新シェル
# 特記事項       ： 
# パラメータ     ： 無し
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func R2-I05001

# ログファイル設定
createlogfile ${0}
log_main_name=`basename ${0} | sed "s/.sh//g"`
export log_name=${log_main_name}

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R2-E05003 "${_errmsg}"

    # エラー終了
    exit 1
fi

_run_date=`date +%Y%m%d`

db2 "update rp.tb_run_date set run_date = '${_run_date}'" > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R2-E05004 "${_errmsg}"

    # エラー終了
    exit 1
fi

outlog_func R2-I05002

exit 0
