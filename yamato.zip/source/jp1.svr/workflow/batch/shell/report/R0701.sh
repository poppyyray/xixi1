#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0701.sh
# 業 務 名       ： ASCA
# 処理概要       ： レポーティング 業務別件数一覧CSV作成
# 特記事項       ： 
# パラメータ     ： 1:日次-入金アンマッチ以外
#                ： 2:日次-入金アンマッチ
#                ： 3:月次
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： JingWei Zhou 
#
# 作成日付       ： 2010-7-27
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-7-27 JingWei Zhou              新規作成
# 2 1.1.0 2014-7-11 Liu Jian                  RHEL6.3 CLIの互換性対応
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#------------------
# 共通設定呼び出し
#------------------
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# -----------------
# 共通関数呼び出し
# -----------------
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

#----------------
# 開始メッセージ
#----------------
outlog_func AS-I00001 $1

#--------------
# 引数チェック
#--------------

if [ "$1" != "1" -a "$1" != "2" -a "$1" != "3" ]
then
	outlog_func AS-E00003
	exit 1
fi

#--------------
# JIRADBに接続
#--------------
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func AS-E00004 "${_errmsg}"
	
	# 一時ファイル削除
	rm -f ${SQLLOG_TMP}
	
    # エラー終了
    exit 1
fi

#----------------
# 日付を取得
#----------------
create_date1=`date +%Y%m%d`
create_date2=`date +%Y-%m-%d`
#--------------------------------
# CSVファイル名に処理日付をセット
#--------------------------------
R0701_01_REPORT_FILENAME=`echo ${R0701_01_REPORT_FILENAME} | sed -e s/rundate/${create_date1}/`
R0701_02_REPORT_FILENAME=`echo ${R0701_02_REPORT_FILENAME} | sed -e s/rundate/${create_date1}/`
R0701_03_REPORT_FILENAME=`echo ${R0701_03_REPORT_FILENAME} | sed -e s/rundate/${create_date1}/`
#-------------
# 引数1：日次(入金アンマッチ以外)
#-------------
if [ $1 = '1' ]
then
	#-------------------
	# 業務別件数CSV出力
	#-------------------
	db2 "export to ${OUT_REPORT_TMPDIR}/${R0701_01_REPORT_FILENAME} of del 
	SELECT SUBSTR(CHAR(CREATED_DATE),1,10), SUBSTR(CHAR(SEQUENCE_NUMBER),1,11), service_name, COUNT(*) 
		FROM  rp.tb_issue_history 
	WHERE create_type = '1' 
		AND created_date BETWEEN TIMESTAMP('${create_date2}' || '-00.00.00.000000') AND TIMESTAMP('${create_date2}' || '-23.59.59.000000') 
		AND SUBSTR(CHAR(SEQUENCE_NUMBER),1,2) IN ('CE', 'CT', 'GC', 'GE', 'BT') 
	GROUP BY SUBSTR(CHAR(CREATED_DATE),1,10), SUBSTR(CHAR(SEQUENCE_NUMBER),1,11), service_name 
	ORDER BY SUBSTR(CHAR(SEQUENCE_NUMBER),1,11)" > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AS-E00005 "${_errmsg}"

		# エラー終了
		exit 1
	fi
	# "を削除する
	sed -i "s/\"//g" ${OUT_REPORT_TMPDIR}/${R0701_01_REPORT_FILENAME}
	#------------------------------
	# CSVファイルのMD5ファイル生成
	#------------------------------
	cd ${OUT_REPORT_TMPDIR}
	CSVFILE=${R0701_01_REPORT_FILENAME}
	md5sum -t ${CSVFILE} > `basename ${CSVFILE%.*}`.md5 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00006 ""
		
		# エラー終了
		exit 1
	fi
	#----------------------
	# パスワード付きで圧縮
	#----------------------
	#zip  -Pjq ${ZIP_FILE_PASSWORD} `basename ${CSVFILE%.*}`.zip `basename ${CSVFILE%.*}`.* 2>${DETAIL_LOG_TMP}
	zip -P ${ZIP_FILE_PASSWORD} -jq `basename ${CSVFILE%.*}`.zip `basename ${CSVFILE%.*}`.* 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00007 ""
		
		# エラー終了
		exit 1
	fi
	#-------------------------------------
	# ZIPファイルを指定ディレクトリに移動
	#-------------------------------------
	mv -f `basename ${CSVFILE%.*}`.zip ${ASCA_DIR}/ 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00008 "`basename ${CSVFILE%.*}`.zip"
		
		# エラー終了
		exit 1
	fi
	
#-------------
# 引数2：日次(入金アンマッチ)
#-------------
# OUT_REPORT_TMPDIR=/shared/reporting/tmp
elif [ $1 = '2' ]
then
	#-------------------
	# 業務別件数CSV出力
	#-------------------
	db2 "export to ${OUT_REPORT_TMPDIR}/${R0701_02_REPORT_FILENAME} of del 
	SELECT SUBSTR(CHAR(CREATED_DATE),1,10), SUBSTR(CHAR(SEQUENCE_NUMBER),1,11), service_name, COUNT(*) 
		FROM  rp.tb_issue_history 
	WHERE create_type = '1' 
		AND created_date BETWEEN TIMESTAMP('${create_date2}' || '-00.00.00.000000') AND TIMESTAMP('${create_date2}' || '-23.59.59.000000') 
		AND SUBSTR(CHAR(SEQUENCE_NUMBER),1,2) = 'UD' 
	GROUP BY SUBSTR(CHAR(CREATED_DATE),1,10), SUBSTR(CHAR(SEQUENCE_NUMBER),1,11), service_name 
	ORDER BY SUBSTR(CHAR(SEQUENCE_NUMBER),1,11)" > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AS-E00009 "${_errmsg}"

		# エラー終了
		exit 1
	fi
	# "を削除する
	sed -i "s/\"//g" ${OUT_REPORT_TMPDIR}/${R0701_02_REPORT_FILENAME}
	#------------------------------
	# CSVファイルのMD5ファイル生成
	#------------------------------
	cd ${OUT_REPORT_TMPDIR}
	CSVFILE=${R0701_02_REPORT_FILENAME}
	md5sum -t ${CSVFILE} > `basename ${CSVFILE%.*}`.md5 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00010 ""
		
		# エラー終了
		exit 1
	fi
	#----------------------
	# パスワード付きで圧縮
	#----------------------
	#zip  -Pjq ${ZIP_FILE_PASSWORD} `basename ${CSVFILE%.*}`.zip `basename ${CSVFILE%.*}`.* 2>${DETAIL_LOG_TMP}
	zip  -P ${ZIP_FILE_PASSWORD} -jq `basename ${CSVFILE%.*}`.zip `basename ${CSVFILE%.*}`.* 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00011 ""
		
		# エラー終了
		exit 1
	fi
	#-------------------------------------
	# ZIPファイルを指定ディレクトリに移動
	#-------------------------------------
	mv -f `basename ${CSVFILE%.*}`.zip ${ASCA_DIR}/ 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00012 "`basename ${CSVFILE%.*}`.zip"
		
		# エラー終了
		exit 1
	fi
	
#-------------
# 引数3：月次
#-------------
elif [ $1 = '3' ]
then
	db2 "export to ${OUT_REPORT_TMPDIR}/${R0701_03_REPORT_FILENAME} of del 
	SELECT SUBSTR(CHAR(created_date),1,10), SUBSTR(CHAR(SEQUENCE_NUMBER),1,11), service_name, COUNT(*) 
		FROM  rp.tb_issue_history 
	WHERE create_type = '1' 
		AND  created_date BETWEEN rp.fn_first_date(rp.fn_run_date()) AND rp.fn_last_date(rp.fn_run_date()) 
	GROUP BY SUBSTR(CHAR(created_date),1,10), SUBSTR(CHAR(SEQUENCE_NUMBER),1,11), service_name 
	ORDER BY SUBSTR(CHAR(created_date),1,10), SUBSTR(CHAR(SEQUENCE_NUMBER),1,11)" > ${SQLLOG_TMP} 
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AS-E00013 "${_errmsg}"

		# エラー終了
		exit 1
	fi
	# totalの一行
	db2 "export to ${OUT_REPORT_TMPDIR}/${R0701_03_REPORT_FILENAME}.tmp of del 
	SELECT 'TOTAL', service_name, COUNT(*) 
		FROM  rp.tb_issue_history 
	WHERE create_type = '1' 
		AND  created_date BETWEEN rp.fn_first_date(rp.fn_run_date()) AND rp.fn_last_date(rp.fn_run_date()) 
	GROUP BY service_name 
	ORDER BY service_name" > ${SQLLOG_TMP} 
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AS-E00017 "${_errmsg}"

		# エラー終了
		exit 1
	fi
	#-----------------
	# Total行をマージ
	#-----------------
	cat ${OUT_REPORT_TMPDIR}/${R0701_03_REPORT_FILENAME}.tmp >> ${OUT_REPORT_TMPDIR}/${R0701_03_REPORT_FILENAME} 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00018 ""
		
		# エラー終了
		exit 1
	fi
	rm -f ${OUT_REPORT_TMPDIR}/${R0701_03_REPORT_FILENAME}.tmp 2>${DETAIL_LOG_TMP}
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
	# "を削除する
	sed -i "s/\"//g" ${OUT_REPORT_TMPDIR}/${R0701_03_REPORT_FILENAME}
	#------------------------------
	# CSVファイルのMD5ファイル生成
	#------------------------------
	cd ${OUT_REPORT_TMPDIR}
	CSVFILE=${R0701_03_REPORT_FILENAME}
	md5sum -t ${CSVFILE} > `basename ${CSVFILE%.*}`.md5 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00014 ""
		
		# エラー終了
		exit 1
	fi
	#----------------------
	# パスワード付きで圧縮
	#----------------------
	#zip  -Pjq ${ZIP_FILE_PASSWORD} `basename ${CSVFILE%.*}`.zip `basename ${CSVFILE%.*}`.* 2>${DETAIL_LOG_TMP}
	zip  -P ${ZIP_FILE_PASSWORD} -jq `basename ${CSVFILE%.*}`.zip `basename ${CSVFILE%.*}`.* 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00015 ""
		
		# エラー終了
		exit 1
	fi
	#-------------------------------------
	# ZIPファイルを指定ディレクトリに移動
	#-------------------------------------
	mv -f `basename ${CSVFILE%.*}`.zip ${ASCA_DIR}/ 2>${DETAIL_LOG_TMP}
	if [ $? != 0 ]
	then
		# エラーログ出力
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func AS-E00016 "`basename ${CSVFILE%.*}`.zip"
		
		# エラー終了
		exit 1
	fi
fi

#------------
# JIRADB切断
#------------
db2 terminate > /dev/null

#----------------
# 終了メッセージ
#----------------
outlog_func AS-I00002 $1

exit 0