#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0302_01.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング ステータス別件数一覧(日次)テーブル作成
# 特記事項       ： 
# パラメータ     ： 無し
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2 1.1.0 2009-12-21 M.Saiki                 importリトライ追加
# 3 1.1.1 2009-12-21 K.Murase                importリトライ追加
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R3-I02001

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R3-E02003 "${_errmsg}"

    # エラー終了
    exit 1
fi

#インポートコマンドの戻り値が８の場合、３回処理を行う。
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
	# ステータス別件数一覧(日次)テーブルをクリアする
	db2 "import from /dev/null of del messages ${TMP_DIR}/`basename ${0}`_TableClear.log replace into rp.tb_status_betsu_kensu_ichiran" > ${SQLLOG_TMP}
	SQLERROR=$?
	#DBエラー（ループに戻す）　エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${JIRA_DB_NAME}"
		connectDB ${JIRA_DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8

	else
		#正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done
# DBエラー
if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R3-E02004 "${_errmsg}"

	# エラー終了
	exit 1
fi

# 履歴テーブルからステータス別件数一覧(日次)テーブルへ対象データをinsertする
rundate=`db2 -x "select substr(char(rp.fn_run_date()),1,10) from sysibm.sysdummy1"`

# echo $rundate

firstdate=`db2 -x "select rp.fn_daily_report_start_date(rp.fn_run_date()) from sysibm.sysdummy1"`

# echo $firstdate

hh=$1  # hour

#db2 -tvf ${SQL_DIR}/report/R0302_${1}.sql > ${SQLLOG_TMP}

db2 -x +p INSERT INTO \\ <<SQLTEXT
rp.tb_status_betsu_kensu_ichiran( \\
  sd_work_date, \\
  branch_office_code, \\
  region_code, \\
  region_name, \\
  service_id, \\
  service_name, \\
  output_date, \\
  status_id, \\
  status, \\
  has_form, \\
  second_flag, \\
  count \\
) \\
select \\
  sagyoubi, \\
  branch_office_code, \\
  region_code, \\
  region_name, \\
  service_id, \\
  service_name, \\
  CURRENT TIMESTAMP, \\
  status_id, \\
  status, \\
  has_form, \\
  second_flag, \\
  COUNT(*) count  \\
from  \\
  (SELECT \\
    substr(sagyoubi,1,6) sagyoubi, \\
    branch_office_code, \\
    region_code, \\
    region_name, \\
    service_id, \\
    service_name, \\
    status_id, \\
    status, \\
    has_form, \\
    (select distinct 'Y' second_flag \\
     from RP.tb_issue_history h1 \\
     where  \\
       a1.sequence_number = h1.sequence_number and \\
       h1.created_date < TIMESTAMP('${rundate}-${hh}.00.00.000000') and \\
       ((h1.owner_role_id = 'C' AND h1.status_id in ('A02','A03','A04','A05','A08')) or \\
        (h1.owner_role_id = 'D' AND h1.status_id in ('A02','A03'))) \\
    ) second_flag \\
  FROM \\
    (SELECT  \\
      sequence_number, \\
      max(created_date) created_date \\
    FROM RP.tb_issue_history h2  \\
    WHERE \\
      h2.complete_flag = 'Y' and \\
      h2.created_date between TIMESTAMP('${firstdate}') AND TIMESTAMP( '${rundate}-${hh}.00.00.000000') \\
    group by sequence_number \\
    ) a1, \\
    RP.tb_issue_history h3 \\
  where \\
    a1.sequence_number = h3.sequence_number and \\
    a1.created_date = h3.created_date \\
) x1 \\
GROUP BY \\
  sagyoubi, \\
  branch_office_code, \\
  region_code, \\
  region_name, \\
  service_id, \\
  service_name, \\
  status_id, \\
  status, \\
  has_form, \\
  second_flag
SQLTEXT
#          created_date BETWEEN TIMESTAMP('${firstdate}') AND TIMESTAMP( '${rundate}-${hh}.00.00.000000') \\
#    WHERE created_date < TIMESTAMP('${rundate}-${hh}.00.00.000000') and \\

SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func R3-E02005 "${_errmsg}"

	# エラー終了
	exit 1
fi

# JIRADB切断
db2 terminate > /dev/null

# 終了メッセージ
outlog_func R3-I02002

exit 0
