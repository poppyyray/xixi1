#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0104.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 履歴レコード情報付加
# 特記事項       ： 
# パラメータ     ： 1:新規作成レコードに対して処理を行う。
#                ： 2:証憑データ取り込みで作成された履歴レコードに対して処理を行う。
#                ： 3:更新処理にて作成された履歴レコードに対して処理を行う。(5分に一回実行)
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始メッセージ
outlog_func R1-I01001 $1

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" -a "$1" != "3" ]
then
	outlog_func R1-E01003
	exit 1
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func R1-E01004 "${_errmsg}"

    # エラー終了
    exit 1
fi

# 引数1:新規作成レコードに対して処理を行う。
if [ $1 = '1' ]
then

	db2 -tvf ${SQL_DIR}/report/R0104_01.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R1-E01005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数2:証憑データ取り込みで作成された履歴レコードに対して処理を行う。
elif [ $1 = '2' ]
then

	# 履歴テーブルから発生日別件数一覧テーブルへ対象データをinsertする
	db2 -tvf ${SQL_DIR}/report/R0104_02.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R1-E01005 "${_errmsg}"

		# エラー終了
		exit 1
	fi

# 引数3:更新処理にて作成された履歴レコードに対して処理を行う。(5分に一回実行)
elif [ $1 = '3' ]
then

	db2 -tvf ${SQL_DIR}/report/R0104_03.sql > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func R1-E01005 "${_errmsg}"

		# エラー終了
		exit 1
	fi
fi

# JIRADB切断
db2 terminate > /dev/null

# 終了メッセージ
outlog_func R1-I01002

exit 0
