#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： R0301.sh
# 業 務 名       ： なし
# 処理概要       ： レポーティング 未処理件数一覧(随時)テーブル作成
# 特記事項       ： 
# パラメータ     ： $1:ファイル名
#                ： $2:支社コード
#                ： $3:主管コード
#                ： $4:業務ID
#                ： $5:ステータスID
#                ： $6:帳票有無
# リターンコード ： 0             正常終了
#                   1             処理異常
#                   2             出力結果0件
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami 
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func R3-I01007 "$1" "$2" "$3" "$4" "$5" "$6" "$7"

# 引数チェック
if [ -z "$1" ]
then
	echo "$1"
	outlog_func R3-E01006
	exit 1
fi

R0301_SQL=""

# SQL作成処理
if [ ! -z "$2" ]
then
	R0301_SQL=${R0301_SQL}" AND branch_office_code = $2"
fi

if [ ! -z "$3" ]
then
	R0301_SQL=${R0301_SQL}" AND region_code in ($3)"
fi
if [ ! -z "$4" ]
then
	R0301_SQL=${R0301_SQL}" AND service_id in ($4)"
fi

if [ ! -z "$5" ]
then
	R0301_SQL=${R0301_SQL}" AND status_id like $5"
fi

if [ ! -z "$6" ]
then
	R0301_SQL=${R0301_SQL}" AND has_form = $6"
fi

# SQLファイル名作成
R0301_SQL_FILENAME=R0301_`date +%Y%m%d%H%M%S`.sql

# SQLファイル作成
sed "s/-- INSERT CONDITION/${R0301_SQL}/g" < ${SQL_DIR}/report/R0301_01.sql > ${REPORT_SQL_LOG}/${R0301_SQL_FILENAME}

# SQLファイル名を環境変数に登録
export R0301_SQL_FILENAME=${R0301_SQL_FILENAME}

# ログファイル設定
createlogfile ${0}
log_main_name=`basename ${0} | sed "s/.sh//g"`

# テーブル作成シェルを実行
su -c "export log_name=${log_main_name};export R0301_SQL_FILENAME=${R0301_SQL_FILENAME};sh ${SHELL_DIR}/report/R0301_01.sh $7" - ${DB_USER}
RETURN_CODE=$?
if [ ${RETURN_CODE} != '0' ]
then
	outlog_func R3-E01008
	exit 1
fi

# レポート出力シェルを呼ぶ
su -c "export log_name=${log_main_name};${SHELL_DIR}/report/R0301_02.sh $1 $7" - ${DB_USER}
RETURN_CODE=$?
if [ ${RETURN_CODE} = '2' ]
then
    outlog_func R3-I01009
    exit 2
elif [ ${RETURN_CODE} != '0' ]
then

    outlog_func R3-E01010
	exit 1
fi

outlog_func R3-I01011

exit 0
