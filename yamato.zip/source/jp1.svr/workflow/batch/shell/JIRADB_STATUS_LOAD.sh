#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： JIRADB_STATUS_LOAD.sh
# 業 務 名       ： GWDBアーカイブ処理
# 処理概要       ： 更新JIRADBから取得した、未処理案件の通番・ステータスID・PNAME
#					をGWDBのテーブルMISHORI_ISSUEへ挿入する
# 特記事項       ：
# パラメータ     ： なし
# ログファイル   ： GWDB_ARCHIVE_DATE.log
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： GWDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： ----
#
# 作成日付       ： ----
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 ----/--/-- ----                   新規作成
# 2 1.1.1 2010/01/18 k.toki                 LOADコマンドをIMPORTコマンドに変更
# 3 1.1.2 2010/02/21 a.takagi               GWDBアーカイブ機能不全対応
# 4 1.1.3 2010/03/08 A.Takagi				GWDBアーカイブ機能不全対応
# 5 1.1.4 2010/03/16 A.Takagi				GWDBアーカイブ機能不全対応
#											変数SQLERROR出力処理追加
# 6 1.1.5 2010/03/17 A.Takagi               GWDBアーカイブ機能不全対応
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
if [ ! -f ${env_file_list} ]
then
	echo "Cannot read common env file. ( ${env_file_list} )."
	exit 1
else
	. ${env_file_list}
fi

# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
if [ ! -f ${conf_file_list} ]
then
	echo "Cannot read common conf file. ( ${conf_file_list}} )."
	exit 1
else
	. ${conf_file_list}
fi

# ----
# 業務別環境変数設定
# ----
# 出力ログ名設定
export log_name=${GWDB_ARCHIVE_DATE_LOG}


##本シェル使用変数は、batch_common.confを参照してください。

# ----
# 関数  JIRADB_STATUS_LOAD
# ----
function JIRADB_STATUS_LOAD
{

	#変数WDATEに現在の日付を挿入する
	WDATE=`date +%Y-%m-%d`

	#変数DATEに現在の日付を挿入する
	DATE=`date +%Y%m%d`


	#変数FILE_NAMEにロード元のファイル名を挿入する
	FILE_NAME=`ls -1 -tr ${CSV_OUT_DIR}/${JIRA_STATUS_EXPORT}_${DATE}*.ixf | tail -1`


	#変数FILE_NAMEに値が格納されているか確認する
	if [ -z ${FILE_NAME} ]
	then
		outlog_func AC-E04005
		return 1
	fi

	#変数FILE_NAMEに格納されているファイルをテーブルMISHORI_ISSUEへimportする
	db2 "import from ${FILE_NAME} of ixf MESSAGES ${ARCHIVE_FILE_IMPORT_MSG} replace into MISHORI_ISSUE" > ${SQLLOG_TMP} 2>&1

	# 変数SQLERROR にSQLの戻り値を格納する
    SQLERROR=$?

    # 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
    echo -e "日付:`date` || shell名:JIRADB_STATUS_LOAD.sh || 行番号:`expr ${LINENO} - 4` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# 変数SQLERROR の戻り値が"0"または"1"以外の場合、以下の処理を実施する
	if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func AC-E04007 "${_errmsg}" "${SQLERROR}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        return 1
    fi

	#変数_load_cntにIMPORT件数を挿入する
    _load_cnt=`tail -2 ${SQLLOG_TMP} | head -1 | grep -oE "[[:digit:]]{1,}"`

	#成功メッセージをログファイルに出力する
    outlog_func AC-I04006 '"'"${_load_cnt}"'"'

	#変数EXPORT_CNTに、JIRADB_STATUS_EXPORT.shにて出力されたEXPORT件数を格納する
	EXPORT_CNT=`grep ${WDATE} /workflow/batch/logs/${log_name}.log | grep JIRADB_STATUS_EXPORT | grep AC-I03005 | tail -1 | cut -d '"' -f2`


	#件数が一致しない場合エラーメッセージを出力する
	if [ "${_load_cnt}" != "${EXPORT_CNT}" ]
	then
		# エラーログ出力
		outlog_func AC-E04009 "${EXPORT_CNT}" "${_load_cnt}"

		#戻り値"1"を返し、メイン処理へ戻る
		return 1
	fi

	#成功メッセージをログファイルに出力する
	outlog_func AC-I04008

	#変数FILE_NAME に格納されているファイルを削除する
	rm -f ${FILE_NAME}

	return 0

}

###############################################################################
# main処理開始
###############################################################################
### 開始メッセージ
outlog_func AC-I04001

# GWDB接続
connectDB "${DB_NAME}"
if [ $? != '0' ]
then
    outlog_func AC-E04003 "connectDB"
    exit 1
fi

# 関数JIRADB_STATUS_LOAD開始
JIRADB_STATUS_LOAD
if [ $? != '0' ]
then
    outlog_func AC-E04004 "JIRADB_STATUS_LOAD"
    exit 1
fi

# GWDBへの接続を切断する
db2 terminate > /dev/null

## 終了メッセージ
outlog_func AC-I04002

## 戻り値0を返し終了
exit 0

