#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： GWDB_EXPORT.sh
# 業 務 名       ： GWDB旧データ退避
# 処理概要       ： GWDBから旧データを抽出
# 特記事項       ： テーブルリストファイルに記載されているテーブル
# パラメータ     ： なし
# ログファイル   ： GWDB_ARCHIVE_DATE.log
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB        ： GWDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： A.Takagi
#
# 作成日付       ： 2009-11-10
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-11 A.Takagi              新規作成
# 2 1.0.1 2010-02-09 A.Takagi              機能不全対応
# 3 1.0.2 2010-02-21 A.Takagi              機能不全対応
# 4 1.0.3 2010-03-08 A.Takagi              機能不全対応
# 5 1.0.4 2010-03-16 A.Takagi              機能不全対応
#                                          変数SQLERROR出力処理追加
# 6 1.0.5 2010-03-18 A.Takagi              機能不全対応
#                                          テーブル名不備の場合、異常終了する処理を追加
# 7 1.0.6 2010-03-19 A.Takagi              機能不全対応
#                                          削除条件の変更
#                                          削除パターン３・４追加
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 引数の確認
# ----
PARM_CNT=$#
if [ ${PARM_CNT} -ne 2 ]
then
	echo "Argument has not been set correctly"
	exit 1
fi

# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
if [ ! -f ${env_file_list} ]
then
	echo "Cannot read common env file. ( ${env_file_list} )."
	exit 1
else
	. ${env_file_list}
fi

# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
if [ ! -f ${conf_file_list} ]
then
	echo "Cannot read common conf file. ( ${conf_file_list}} )."
	exit 1
else
	. ${conf_file_list}
fi


###############################################################################
# GWDB旧データ抽出１（アーカイブ処理使用）
# 概要：案件が終了したデータ抽出
# 引数１：テーブル名
# 引数２：削除パターン
###############################################################################
function GWDB_EXPORT
{

	#アーカイブ対象テーブル
	TABLE=$1

	#アーカイブパターン
	PATTERN=$2

	#現在日付を取得
	NDATE=`date "+%Y%m%d%H%M%S"`


	#削除対象テーブルから削除条件に一致したデータをEXPORTする
	#変数PATTERNの値を確認する

	#変数PATTERNの値が"1"の場合、以下の処理を実施
	if [ "${PATTERN}" = '1' ]
	then
		#案件終了かつ更新日時が保持期間を過ぎたデータを抽出
		db2 "export to ${CSV_BACKUP_DIR}/${TABLE}_${NDATE}.ixf of ixf MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
		select * from ${TABLE} where  date(kousinnichiji) <= (values current date ${GWDB_DAY} days) and
		PKEY_CD not in (select pkey from MISHORI_ISSUE)" > ${SQLLOG_TMP} 2>&1

		# 変数SQLERROR にSQLの戻り値を格納する
		SQLERROR=$?

		# 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
		echo -e "日付:`date` || shell名:GWDB_EXPORT.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

		# 変数SQLERRORの値が"0"または"1"以外の場合、以下の処理を実施する
		if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func AC-E05005 "${TABLE}" "${_errmsg}" "${SQLERROR}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}
			# エラー終了
			return 1
		fi
	#変数PATTERNの値が"2"の場合、以下の処理を実施
	elif [ "${PATTERN}" = '2' ]
	then

		#更新日付が20日以上前のデータを抽出する
		db2 "export to ${CSV_BACKUP_DIR}/${TABLE}_${NDATE}.ixf of ixf MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
		select * from ${TABLE} where date(KOUSINNICHIJI) <= (values current date ${DAY_SHOHYO_DATA} days)" > ${SQLLOG_TMP} 2>&1

		SQLERROR=$?
		echo -e "日付:`date` || shell名:GWDB_EXPORT.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

		# 変数SQLERRORの値が"0"または"1"以外の場合、以下の処理を実施する
		if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func AC-E05006 "${TABLE}" "${_errmsg}" "${SQLERROR}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}
			# エラー終了
			return 1
		fi
	#変数PATTERNの値が"3"の場合、以下の処理を実施
	elif [ "${PATTERN}" = '3' ]
	then
		#案件終了かつ作成日時が保持期間を過ぎたデータを抽出
		db2 "export to ${CSV_BACKUP_DIR}/${TABLE}_${NDATE}.ixf of ixf MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
		select * from ${TABLE} where  date(sakuseinichiji) <= (values current date ${GWDB_DAY} days) and
		PKEY_CD not in (select pkey from MISHORI_ISSUE)" > ${SQLLOG_TMP} 2>&1

		# 変数SQLERROR にSQLの戻り値を格納する
		SQLERROR=$?

		# 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
		echo -e "日付:`date` || shell名:GWDB_EXPORT.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

		# 変数SQLERRORの値が"0"または"1"以外の場合、以下の処理を実施する
		if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func AC-E05010 "${TABLE}" "${_errmsg}" "${SQLERROR}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}
			# エラー終了
			return 1
		fi
	#変数PATTERNの値が"4"の場合、以下の処理を実施
	elif [ "${PATTERN}" = '4' ]
	then
		#作成日付が20日以上前のデータを抽出する
		db2 "export to ${CSV_BACKUP_DIR}/${TABLE}_${NDATE}.ixf of ixf MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
		select * from ${TABLE} where date(sakuseinichiji) <= (values current date ${DAY_SHOUNINZUMI_DATA} days)" > ${SQLLOG_TMP} 2>&1

		# 変数SQLERROR にSQLの戻り値を格納する
		SQLERROR=$?

		# 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
		echo -e "日付:`date` || shell名:GWDB_EXPORT.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

		# 変数SQLERRORの値が"0"または"1"以外の場合、以下の処理を実施する
		if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func AC-E05011 "${TABLE}" "${_errmsg}" "${SQLERROR}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}
			# エラー終了
			return 1
		fi
	else
		#エラーログ出力
		outlog_func AC-E05009

		# エラー終了
		return 1
	fi

	#変数EXPORT_CNT にEXPORTした件数を格納する
	EXPORT_CNT=`tail -2 ${SQLLOG_TMP} | head -1 | grep -oE "[[:digit:]]{1,}"`

	#変数EXPORT_CNTの値をログファイルに出力する
	outlog_func AC-I05007 "${TABLE}" '"'"${EXPORT_CNT}"'"'

	#成功メッセージをログファイルに出力する
	outlog_func AC-I05008 "${TABLE}"

	return 0

}


# ----
# 業務別環境変数設定
# ----
# 出力ログ名設定
export log_name=${GWDB_ARCHIVE_DATE_LOG}

##本シェル使用変数は、batch_common.confを参照してください。
##本シェル使用関数は、BATCH_COMMON_FUNC.shを参照してください。

###############################################################################
# main処理開始
###############################################################################

#引数(テーブル名・削除パターン)を変数に保存する
DELETE_TABLE=$1
DELETE_PATTERN=$2

### 開始メッセージ
outlog_func AC-I05001 "${DELETE_TABLE}"

# GWDB接続
connectDB ${DB_NAME}
if [ $? != '0' ]
then
    outlog_func AC-E05003 "connectDB"
    exit 1
fi

# GWDBから旧データを抽出
# 変数${DELETE_PATARN}に従い、
# 変数${DELETE_TABLE}内のテーブルに対し、削除データを抽出する
GWDB_EXPORT ${DELETE_TABLE} ${DELETE_PATTERN}
if [ $? != '0' ]
then
    outlog_func AC-E05004 "GWDB_EXPORT"
    exit 1
fi

# GWDBへの接続を切断する
db2 terminate > /dev/null

## 終了メッセージ
outlog_func AC-I05002 "${DELETE_TABLE}"

#戻り値0を返す
exit 0
