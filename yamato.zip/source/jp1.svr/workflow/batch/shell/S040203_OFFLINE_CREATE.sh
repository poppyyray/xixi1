#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S040203_OFFLINE_CREATE.sh
# 業 務 名       ： OFFLINE_CREATE機能（一般集金エラー処理）
# 処理概要       ： GWDBから取得したデータファイルを基に、
#                   JIRADBへの取り込み用CSVファイルを作成し、
#                   DB2のLOADを用いてJIRADBへデータを反映する
# 特記事項       ： JIRAがオンライン稼働中でない場合に起動する
# パラメータ     ： なし
# ログファイル   ： S040203_OFFLINE_CREATE.log
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： GWDB,JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Y.Otsuka
#
# 作成日付       ： 2009-06-05
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-06-05 S.Tsuruha              新規作成
# 2 1.0.1 2010-01-09 Y.Nagahashi            importエラー出力対応
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
    if [[ -r ${x} ]]
    then
        . ${x}
    else
        echo "Cannot read common env file. ( ${x} )."
        exit 1
    fi
done
# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh /workflow/batch/shell/BATCH_LOAD_COMMON_FUNC_TMP.sh"
for y in ${conf_file_list}
do
        if [[ -r ${y} ]]
        then
            . ${y}
        else
            echo "Cannot read common conf file. ( ${y} )."
            exit 1
        fi
done

#echo ${LOG_DIR}/${logfile}.log

# ---- 
# 業務別環境変数設定
# ----
table_name=${TABLE_S040203}                # GWDBの業務別テーブル名
SQL=${SQL_DIR}/S040203_CSV_LOAD.sql        # GWサーバ側DBのCSV抽出SQLファイル
serviceID=10032                            # 業務ID
gyomu_id2=GE                               # 業務ID(2桁)
transferSlipNumber=50000
duedate_null=1999-12-31                    # 作業日に値が存在しない場合仮の値を代入
_wf_project_name=GeneralCollectionErrorWorkFlow  # OS_WFENTRYのNAME値

# ----
# LOAD機能共通環境変数読み込み
# ----
. /workflow/batch/ini/batch_load_common.conf

###############################################################################
# CSV作成関数
###############################################################################
add=0
function create_load_csv
{
        # CSVファイルを作成
        while read tsuuban gyoumuID tenshoCODE kojinbangou sagyoubi chouhyouID ryousyuushobangou syukanCODE aeraCODE errorriyuu denpyoubangou nyuukinnengappii kihyoubusho kokyaku bunrui headerNO seiribusho seikyuuNO seikyuukingaku  nyuukinkingaku seikyuuzangaku tensho_meishou
        do
        # 各種日付の設定
        created=`date +%Y-%m-%d-%H.%M.%S`
        updated=`date +%Y-%m-%d-%H.%M.%S`
        startdate=`date +%Y-%m-%d-%H.%M.%S`

        Year=`echo ${sagyoubi} | cut -b1-4`

        Month=`echo ${sagyoubi} | cut -b5-6`
        Day=`echo ${sagyoubi} | cut -b7-8`
        duedate=`echo "${Year}-${Month}-${Day}-00.00.00.000000"`

        # 作業日の値が「0000-00-00」の場合は仮の値を代入
        if [ ${Year}-${Month}-${Day} = 0000-00-00 ]
        then            
            duedate=`echo "${duedate_null}-00.00.00.000000"`
        fi

                # 各種日付のミリ秒値設定
                let add=${add}+1
                if [ ${add} -ge 1000000 ]
                then
                        add=1
                fi
                if [ ${add} -lt 10 ]
                then
                        created_updatedid="00000"${add}
                elif [ ${add} -ge 10 -a ${add} -lt 100 ]
                then
                        created_updatedid="0000"${add}
                elif [ ${add} -ge 100 -a ${add} -lt 1000 ]
                then
                        created_updatedid="000"${add}
                elif [ ${add} -ge 1000 -a ${add} -lt 10000 ]
                then
                        created_updatedid="00"${add}
                elif [ ${add} -ge 10000 -a ${add} -lt 100000 ]
                then
                        created_updatedid="0"${add}
                else
                        created_updatedid=${add}
                fi
# 入金年月日(nyuukinnengappii)
        if [ -z "${nyuukinnengappii}" ]
        then
            issueddate=
        else
            Year2=`echo ${nyuukinnengappii} | cut -b1-4`
            Month2=`echo ${nyuukinnengappii} | cut -b5-6`
            Day2=`echo ${nyuukinnengappii} | cut -b7-8`
            bankedDate=`echo "${Year2}-${Month2}-${Day2}-00.00.00.000000"`
            bankedDate=\"${bankedDate}\"
        fi

        # 主管コード設定
          if [ -z ${syukanCODE} ]
          then
                 outlog_func CM-W05264 "主管コード" "通番「${tsuuban}」 主管コード「${syukanCODE}」"
                 continue
          else
                 component=`cat ${component_id_file} | grep "${syukanCODE}" | awk '{print $1}' | head -1`
                     if [ -z ${component} ]       
                     then
                            outlog_func CM-W05273 "主管コード" "通番「${tsuuban}」 主管コード「${syukanCODE}」"
                            continue   
                     fi
          fi


        # 帳票ID設定
          if [ -z ${chouhyouID} ]
          then
                 outlog_func CM-W05265 "帳票ID" "通番「${tsuuban}」 帳票ID「${chouhyouID}」"
                 continue
          else
                 formid=`cat ${projectversion_id_file} | grep "${chouhyouID}" | awk '{print $1}' | head -1`
                     if [ -z ${formid} ]       
                     then
                            outlog_func CM-W05274 "帳票ID" "通番「${tsuuban}」 帳票ID「${chouhyouID}」"
                            continue   
                     fi
          fi
        # エリアコード(GWDBから取得した値が無い場合"999999":aeraCODE)
        if [ -z ${aeraCODE} ]
        then
            aeraCODE="999999"
        fi
        # 入金振替伝票番号(Null固定)
        bankTransferSlipNumber="0000"
        # csv参照データファイル名(値の設定は不要（FILEATTACHMENTテーブルへのレコード挿入を行わない）)
        # 領収書番号(GWDBから取得した値をそのまま使用:ryousyuushobangou)
        # 店所名称(GWDBから取得した値をそのまま使用:tensho_meishou)
        # エラー理由(GWDBから取得した値をそのまま使用:errorriyuu
        # 伝票番号(GWDBから取得した値をそのまま使用:denpyoubangou)
        # 入金年月日(GWDBから取得した値をそのまま使用:nyuukinnengappii)
        # 起票部所(GWDBから取得した値をそのまま使用:kihyoubusho)
        # 顧客コード(GWDBから取得した値をそのまま使用:kokyaku)
        # 分類コード(GWDBから取得した値をそのまま使用:bunrui)
        # ヘッダNOヘッダNO(GWDBから取得した値をそのまま使用:headerNO)
        # 請求NO(GWDBから取得した値をそのまま使用:seikyuuNO)
        # 請求金額(GWDBから取得した値をそのまま使用:seikyuukingaku)
        # 入金金額(GWDBから取得した値をそのまま使用:nyuukinkingaku)
        # 請求残高(GWDBから取得した値をそのまま使用:seikyuuzangaku)

                # JIRAISSUE.ID採番
                let _jiraissueid_max_jiraid=${_jiraissueid_max_jiraid}+1
                if [ $? != 0 ]
                then
                        outlog_func CM-E05087
                        return 1
                fi
                # JIRAISSUE.PKEY採番
                let _pkey_max_jiraid=${_pkey_max_jiraid}+1
                if [ $? != 0 ]
                then
                        outlog_func CM-E05092
                        return 1
                fi
                # PKEY値設定
                _tmp_pkey_max=`printf "%0000006d" ${_pkey_max_jiraid}`
                _pkey_cd="${gyomu_id2}-${_TODAY}${_tmp_pkey_max}"
                # JIRAISSUE.WORKFLOW_ID採番
                let _workflowid_max_jiraid=${_workflowid_max_jiraid}+1
                if [ $? != 0 ]
                then
                        outlog_func CM-E05097
                        return 1
                fi
                # OS_CURRENTSTEP.ID採番
                let _os_currentstepid_max_jiraid=${_os_currentstepid_max_jiraid}+1
                if [ $? != 0 ]
                then
                        outlog_func CM-E05240
                        return 1
                fi
                # CUSTOMFIELDVALUE.ID採番
                let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                if [ $? != 0 ]
                then
                        outlog_func CM-E05218
                        return 1
                fi
                # JIRAACTION.ID採番
                let _jiraaction_id_max_jiraid=${_jiraaction_id_max_jiraid}+1
                if [ $? != 0 ]
                then
                        outlog_func CM-E05243
                        return 1
                fi

                ###############################################################################
                # JIRAISSUE用CSV作成
                ###############################################################################
                        echo "${_jiraissueid_max_jiraid},\"${_pkey_cd}\",${serviceID},\"${reporter}\",\"${assignee_initial}${syukanCODE}\",\"${issuetype}\",\"${kojinbangou}\",\"${tenshoCODE}\",${bankTransferSlipNumber},\"${priority}\",\"${resolution}\",\"${issuestatus}\",\"${created}.${created_updatedid}\",\"${updated}.${created_updatedid}\",\"${duedate}\",${JIRAISSUE_VOTES},,,,${_workflowid_max_jiraid},,," >> ${jiraissue_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05102
                                return 1
                        fi
                ###############################################################################
                # OS_WFENTRY用CSV作成
                ###############################################################################
                        echo "${_workflowid_max_jiraid},\"${_wf_project_name}\",,${OS_WFENTRY_STATE}" >> ${os_wfentry_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05107
                                return 1
                        fi
                ###############################################################################
                # OS_CURRENTSTEP用CSV作成
                ###############################################################################
                        echo "${_os_currentstepid_max_jiraid},${_workflowid_max_jiraid},${OS_CURRENTSTEP_STEP_ID},${OS_CURRENTSTEP_ACTION_ID},\"\",\"${startdate}.${created_updatedid}\",,,\"${OS_CURRENTSTEP_STATUS}\"," >> ${os_currentstep_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05112
                                return 1
                        fi
                ###############################################################################
                # NODEASSOCIATION用CSV作成
                ###############################################################################
                        # 主管コード(regionCode)フィールド作成・値設定
                        echo "${_jiraissueid_max_jiraid},\"${NODEASSOCIATION_SOURCE_NODE_ENTITY}\",${component},\"${NODEASSOCIATION_SINK_NODE_ENTITY_regionCode}\",\"${NODEASSOCIATION_ASSOCIATION_TYPE_regionCode}\"," >> ${nodeassociation_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05123 "主管コード(regionCode)"
                                return 1
                        fi
                        # 振替伝票番号(transferSlipNumber)フィールド作成・値設定
                        echo "${_jiraissueid_max_jiraid},\"${NODEASSOCIATION_SOURCE_NODE_ENTITY}\",${transferSlipNumber},\"${NODEASSOCIATION_SINK_NODE_ENTITY_transferSlipNumber}\",\"${NODEASSOCIATION_ASSOCIATION_TYPE_transferSlipNumber}\"," >> ${nodeassociation_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05124 "振替伝票番号(transferSlipNumber)"
                                return 1
                        fi

                        # 帳票ID(formid)フィールド作成・値設定
                        echo "${_jiraissueid_max_jiraid},\"${NODEASSOCIATION_SOURCE_NODE_ENTITY}\",${formid},\"${NODEASSOCIATION_SINK_NODE_ENTITY_transferSlipNumber}\",\"${NODEASSOCIATION_ASSOCIATION_TYPE_formId}\"," >> ${nodeassociation_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05125 "帳票ID(formid)"
                                return 1
                        fi
                ###############################################################################
                # CUSTOMFIELD用CSV作成
                ###############################################################################
                        # 対象帳票連番(selectedForm)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_selectedForm},,,,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05158 "対象帳票連番(selectedForm)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05219
                                return 1
                        fi
                        # 領収書番号(receiptNumber)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_receiptNumber},,\"${ryousyuushobangou}\",,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05159 "領収書番号(receiptNumber)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05220
                                return 1
                        fi
                        # 店所名称(deliveryCenterName)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_deliveryCenterName},,\"${tensho_meishou}\",,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05160 "店所名称(deliveryCenterName)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05221
                                return 1
                        fi
                        # エラー理由(errorCause)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_errorCause},,\"${errorriyuu}\",,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05161 "エラー理由(errorCause)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05222
                                return 1
                        fi
                        # 伝票番号(slipNumber)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_slipNumber},,\"${denpyoubangou}\",,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05162 "伝票番号(slipNumber)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05223
                                return 1
                        fi
                        # 入金年月日(bankedDate)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_bankedDate},,,,,${bankedDate}," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05163 "入金年月日(bankedDate)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05224
                                return 1
                        fi
                        # 起票部所(issuedDivision)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_issuedDivision},,\"${kihyoubusho}\",,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05164 "起票部所(issuedDivision)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05225
                                return 1
                        fi
                        # 顧客コード(customerCode)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_customerCode},,\"${kokyaku}\",,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05165 "顧客コード(customerCode)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05226
                                return 1
                        fi
                        # 分類コード(classificationCode)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_classificationCode},,\"${bunrui}\",,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05166 "分類コード(classificationCode)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05227
                                return 1
                        fi
                        # ヘッダNO(headerNumber)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_headerNumber},,\"${headerNO}\",,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05167 "ヘッダNO(headerNumber)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05228
                                return 1
                        fi
                        # 整理部所(chargedDivision)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_chargedDivision},,\"${seiribusho}\",,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05168 "整理部所(chargedDivision)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05229
                                return 1
                        fi
                        # 請求NO(billingNumber)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_billingNumber},,\"${seikyuuNO}\",,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05169 "請求NO(billingNumber)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05230
                                return 1
                        fi
                        # 請求金額(claimedAmount)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_claimedAmount},,,${seikyuukingaku},,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05170 "請求金額(claimedAmount)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05231
                                return 1
                        fi
                        # 入金金額(bankedAmount)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_bankedAmount},,,${nyuukinkingaku},,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05171 "入金金額(bankedAmount)"
                                return 1
                        fi
                        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+1
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05232
                                return 1
                        fi
                        # 請求残高(claimedBalance)フィールド作成・値設定
                        echo "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid},${CUSTOMFIELD_ID_claimedBalance},,,${seikyuuzangaku},,,," >> ${customfield_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05172 "請求残高(claimedBalance)"
                                return 1
                        fi
                ###############################################################################
                # JIRAACTION用CSV作成
                ###############################################################################
                        # エリアコード(areaCode)フィールド作成・値設定
                        echo "${_jiraaction_id_max_jiraid},${_jiraissueid_max_jiraid},,\"${JIRAACTION_ACTIONTYPE_Comment}\",,,\"${aeraCODE}\",\"${created}.${created_updatedid}\",,\"${updated}.${created_updatedid}\"," >> ${jiraaction_file}
                        if [ $? != 0 ]
                        then
                                outlog_func CM-E05246 "エリアコード(areaCode)"
                                return 1
                        fi
                                ###############################################################################
                                # GWサーバpkey_cd,JIRAhaneizumiアップデート用CSV作成
                                ###############################################################################
                                        echo "${tsuuban} ${_pkey_cd} ${JIRAhaneizumi}" >> ${update_pkey_cd_file}
                                        if [ $? != 0 ]
                                        then
                                                outlog_func CM-E05235
                                                return 1
                                        fi

done < ${ichijifile3}
return 0
}


###############################################################################
# main処理開始
###############################################################################
# 出力ログ名設定
export log_name=${S040203_MAIN_FLOW_LOG}

### 開始メッセージ
outlog_func CM-I05251

### メイン処理 ###

# tmp/csv削除
tmp_csv_delete

# jiradb接続
connectDB "${JIRA_DB_NAME}"
if [ $? != 0 ]
then
    exit 1
fi

# jiradb情報抽出
load_export_jiraissueid_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_pkey_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_workflowid_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_os_currentstepid_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_customfield_valueid_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_jiraaction_id_max_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_component_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_projectversion_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_schemeissuesecuritylevels_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_sequence_value_item_Issueid_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_sequence_value_item_osworkflowentryid_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_sequence_value_item_oscurrentstepid_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_sequence_value_item_customfieldvalueid_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_sequence_value_item_actionid_jiraid
if [ $? != 0 ]
then
    exit 1
fi

load_export_project_pcounter_jiraid
if [ $? != 0 ]
then
    exit 1
fi

# JIRA通番初期値確認
default_check

# jiradb切断
db2 terminate > /dev/null

# gwdb接続
connectDB "${DB_NAME}"
if [ $? != 0 ]
then
    exit 1
fi

# gwdb情報抽出
csv_export
if [ $? != 0 ]
then
    exit 1
fi

# gwdb情報csv化
csv_format
if [ $? != 0 ]
then
    exit 1
fi

# gwdb情報csvからjiradb格納可能csv
IFS_org=${IFS}
IFS=,
create_load_csv
if [ $? != 0 ]
then
    IFS=${IFS_org}
    exit 1
fi
IFS=${IFS_org}

# gwdb切断
db2 terminate > /dev/null


##### No Use Delete 2010/02/25 >>>
##### JIRA/GW、DBバックアップ
#####jiradb_backup
#####if [ $? != 0 ]
#####then
#####    exit 1
#####fi

##### 2009/07/31 GWDBバックアップ・リストア処理削除 start
#####gwdb_backup
#####if [ $? != 0 ]
#####then
#####    exit 1
#####fi
##### 2009/07/31 GWDBバックアップ・リストア処理削除 end
##### No Use Delete 2010/02/25 <<<

# jiradb接続
connectDB "${JIRA_DB_NAME}"
if [ $? != 0 ]
then
    exit 1
fi

# csvロード
loading_csv
if [ $? != 0 ]
then
    exit 1
fi

# csvロード2(JIRAACTIONテーブル)
loading_csv_2
if [ $? != 0 ]
then
    exit 1
fi

# sequenceIDアップデート
jira_update
if [ $? != 0 ]
then
    exit 1
fi

# sequenceIDアップデート(JIRAACTION用)
jira_update_2
if [ $? != 0 ]
then
    exit 1
fi

# jiradb切断
db2 terminate > /dev/null

# gwdb接続
connectDB "${DB_NAME}"
if [ $? != 0 ]
then
    exit 1
fi

# gwdb(pkey,JIRA反映済カラム)アップデート
GWDB_update
if [ $? != 0 ]
then
    exit 1
fi

# gwdb切断
db2 terminate > /dev/null

# tmp/csv削除
tmp_csv_delete

## 終了メッセージ
outlog_func CM-I05256
