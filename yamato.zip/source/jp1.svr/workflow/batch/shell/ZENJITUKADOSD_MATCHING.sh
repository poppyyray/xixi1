#!/bin/sh

#環境設定を行う
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func SD-I06006

# 一時ファイル変数
export _sqltmp=${TMP_DIR}/ZenjituKadoSD_tsuuban.tmp
export _idlisttmp=${TMP_DIR}/ZenjituKadoSD_idlist.tmp

#マッチング件数ログ表示用変数
matchingCount=0;

db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func SD-E06001 "${_errmsg}"

	# 一時ファイル等の削除
	rm -f ${SQLLOG_TMP}

	# エラー終了
	return 1
fi
echo "" >> ${SQLLOG_TMP}

### 前日稼働SD情報マッチング処理 ###############################################
_ZenjituKadoSD_sql=${SQL_DIR}/ZenjituKadoSD_MATCHING.sql

# 前日稼働SD情報マッチングSQL実行
db2 -tvf ${_ZenjituKadoSD_sql} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func SD-E06002 "${_errmsg}"

	# 一時ファイル等の削除
	rm -f ${SQLLOG_TMP}

	# エラー終了
	return 1
fi
echo "" >> ${SQLLOG_TMP}

# SQL結果ファイル存在チェック
if [ ! -f ${_sqltmp} ]
then
	outlog_func SD-E06003
	exit 1
fi

# csvファイルを整形
sed -e s/,/" "/g ${_sqltmp} | sed -e s/\"/""/g > ${_idlisttmp}

# マッチング条件に該当した通番と証憑IDの件数分ループを行う
while read tsuuban_tmp shohyo_id_tmp
do
	# 該当テーブルにマッチングした証憑IDを更新する
	db2 "update ${TABLE_ZenjituKadoSD} set match_shohyo_id = '${shohyo_id_tmp}' where tsuuban = '${tsuuban_tmp}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力    
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func SD-I06004 ${matchingCount}
		outlog_func SD-E06005 ${tsuuban_tmp1} "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	#マッチング件数＋１
	matchingCount=`expr ${matchingCount} + 1`

done < ${_idlisttmp}

#マッチング件数をログに出力
outlog_func SD-I06008 ${matchingCount}

db2 terminate > /dev/null

# 一時ファイルを削除
rm -f ${_sqltmp}
rm -f ${_idlisttmp}

outlog_func SD-I06007

exit 0
