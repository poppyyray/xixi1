#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： GROUPID_CHANGE.sh
# 業 務 名       ： なし
# 処理概要       ： 
# 特記事項       ：
# パラメータ     ： 無し
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-11-12
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2 1.0.1 2010-06-28 Yang Xi                 ユーザ削除不可の対応（案件#43）
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${S030104_MAIN_FLOW_LOG}

outlog_func UG-I01001

# JIRADB接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func UG-E01003 "${_errmsg}"

        # 一時ファイル等の削除
        rm -f  ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

#処理対象データを記録
today=`date "+%d"`
db2 -tvf ${SQL_DIR}/groupid_change_log.sql  > ${LOG_DIR}/groupid_change_log_${today}.log
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${LOG_DIR}/groupid_change_log_${today}.log`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${LOG_DIR}/groupid_change_log_${today}.log`
        outlog_func UG-E01005 "${_errmsg}"

        # エラー終了
        exit 1
fi

# 入金データアンマッチグループID戻しSQL
db2 -tvf ${SQL_DIR}/groupid_change.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func UG-E01004 "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

# JIRADBを切断
db2 terminate > /dev/null

outlog_func UG-I01002
