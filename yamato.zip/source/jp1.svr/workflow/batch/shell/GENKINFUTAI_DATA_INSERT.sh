#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： GENKINFUTAI_DATA_INSERT.sh
# 業 務 名       ： IF取り込み（現金附帯計上データ）
# 処理概要       ： 現金附帯計上データのIF取り込み
# 特記事項       ： 
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： GWDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： K.Mori
#
# 作成日付       ： 2009-07-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-16 K.Mori                新規作成
# 2 1.1.0 2016-11-02 yuanrui               社員番号6桁->8桁対応
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################


##########################################################################
# 現金附帯計上データCSV作成関数 
##########################################################################
function genkinfutaikeijyou_data {

    #カウント変数初期化
    _GenkinFutai_cnt=0

    while read line
    do
        # 件数をカウント
        _GenkinFutai_cnt=`expr ${_GenkinFutai_cnt} + 1`

        # 1行目のファイル名が正しいかチェック 
        if [ ${_GenkinFutai_cnt} == 1 ];then
            line=`echo ${line} | sed -e "s/\r//"`
            line=`echo ${line} | sed -e "s/ //"`
            if [ ${line} != ${FILE_GenkinFutai} ];then
                outlog_func GF-E02003 ${1}
                return 1
            fi
        # 2行目の件数が正しいかチェック
        elif [ ${_GenkinFutai_cnt} == 2 ];then
            line=`echo ${line} | sed -e "s/\r//"`
            line=`echo ${line} | sed -e "s/ //"`
            _line_cnt=`wc -l ${1} | cut -d " " -f 1`

            # 1縲鰀3行目はカウントしない
            _line_cnt=`expr ${_line_cnt} - 3`
              # 2行目を数値として扱いたいためexprで０を加算
            line=`expr ${line} + 0`

            # ファイル2行目のファイル件数と実際のファイルの件数を比較
            if [ ${line} != ${_line_cnt} ];then
                outlog_func GF-E02004 ${1}
                return 1
            fi
        # 3行目はブランク行のためなにもしない
        elif [ ${_GenkinFutai_cnt} == 3 ];then
            continue
        # 4行目以降は業務データのcsvファイルを作成
        else

             #主管コード
            _syukan_cd=`echo "$line"|cut -b1-6`

             #エリアコード
            _eria_cd=`echo "$line"|cut -b7-12`

             #店所コード
            _shop_cd=`echo "$line"|cut -b13-18`

             #作業日
            _work_day=`echo "$line"|cut -b19-26`

             #集計日
            _syukei_day=`echo "$line"|cut -b27-34`

			 #個人番号
            _sd_number=`echo "$line"|cut -b35-42`

             #引越付帯
            _hikkoshifutai=`echo "$line"|cut -b43-54`


            _outline=""
            _outline="${_outline}${_syukan_cd}",
            _outline="${_outline}${_eria_cd}",
            _outline="${_outline}${_shop_cd}",
            _outline="${_outline}${_work_day}",
            _outline="${_outline}${_syukei_day}",
            _outline="${_outline}${_sd_number}",
            _outline="${_outline}${_hikkoshifutai}"

            echo ${_outline} >> ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv

        fi

    done < ${1}

    return 0
}

#################################################################
# main処理
#################################################################
#環境設定を行う
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ];then
    echo "[現金附帯計上データIF取り込み] バッチ環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${GENKINFUTAI_MAIN_FLOW_LOG}

outlog_func GF-I02001

# 一時ファイル
_tmp="${TMP_DIR}/GENKINFUTAI_DATA_INSERT.tmp"
_tmp_devnull="${TMP_DIR}/GENKINFUTAI_DATA_INSERT_devnull.tmp"

# DB登録用シェル名
_shname="GENKINFUTAI_DATA_INSERT.sh"

# CSV格納先ディレクトリ確認
if [ ! -d ${CSV_BACKUP_DIR} ];then
    outlog_func GF-E02009 ${CSV_BACKUP_DIR}
    exit 1
fi

# 現金附帯計上データPPファイル存在確認
#if [ ! -f ${PP_FILE_PATH}/${FILE_GenkinFutai} ];then

    # PPバックアップファイル名にOKが無いものを取得（正常終了しなかったPPファイル）
    _FILE_GenkinFutai_BAK=`ls ${PPFILE_BACKUP_DIR}| grep ${FILE_GenkinFutai} | grep -v OK | head -1`

    # PPバックアップファイルの末尾が全てOK
    if [ -z ${_FILE_GenkinFutai_BAK} ];then

        # 現金附帯計上データPPファイルが存在しない
        outlog_func GF-W02005 ${FILE_GenkinFutai}

        # 処理対象ファイルが存在しないので終了
        exit 0

    # PPバックアップファイルの末尾がOKでないものがある
    else

        # ディレクトリパスを付与
        _FILE_GenkinFutai_BAK="${PPFILE_BACKUP_DIR}/${_FILE_GenkinFutai_BAK}"

        # 現金附帯計上データCSV作成関数呼び出し
        genkinfutaikeijyou_data ${_FILE_GenkinFutai_BAK}
        # エラー判定
        if [ $? != "0" ];then

            outlog_func GF-E02006
           
            # CSV削除
            rm -f ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv
           exit 1
        fi  

    fi
#else

    # 現金附帯計上データPPファイルのバックアップを作成
#    _FILE_GenkinFutai_BAK=${PPFILE_BACKUP_DIR}/${FILE_GenkinFutai}.`date +%Y%m%d%H%M`
#    mv -f ${PP_FILE_PATH}/${FILE_GenkinFutai} ${_FILE_GenkinFutai_BAK}

    # 現金附帯計上データCSV作成関数呼び出し
#    genkinfutaikeijyou_data ${_FILE_GenkinFutai_BAK}

    # エラー判定
#    if [ $? != "0" ];then

#        outlog_func GF-E02010

        # CSV削除
#        rm -f ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv

#        exit 1
#    fi
#fi

# DB接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力    
    _errmsg=`cat ${SQLLOG_TMP}`
    outlog_func GF-E02007 "${_errmsg}"
    
    # 一時ファイル等の削除
    rm -f  ${SQLLOG_TMP}

    # CSV削除
    rm -f ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv

    # エラー終了
    exit 1
fi
echo "" >> ${SQLLOG_TMP}

# CSVファイルが存在すればDBにインサートを行う
if [ -f ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv ];then

    # レポーティング用現金附帯計上テーブルのデータを削除する
    db2 "import from /dev/null of del messages ${_tmp_devnull} REPLACE into ${TABLE_GenkinFutai}" > ${SQLLOG_TMP}
    SQLERROR=$?
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    # DBエラー
    if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4 -o ${SQLERROR} -eq 8 ]
    then
        # エラーログ出力    
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func GF-E02011 "${_errmsg}"
        
        # 一時ファイル等の削除
        rm -f  ${SQLLOG_TMP}

        # CSV削除
        rm -f ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv

        # エラー終了
        exit 1
    fi

    # 現金附帯計上データCSVインポート
    db2 "import from ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv of del messages ${_tmp} INSERT into ${TABLE_GenkinFutai}" "(SYUKANCODE,AREACODE,TENSHOCODE,SAGYOUBI,SYUUKEIBI,KOJINBANGOU,HIKKOSIFUTAI)" > ${SQLLOG_TMP}
    SQLERROR=$?
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    # DBエラー
    if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]  
    then
        # エラーログ出力    
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func GF-E02008 "${_errmsg}"
        
        # 一時ファイル等の削除
        rm -f  ${SQLLOG_TMP}

        # CSV削除
        rm -f ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv

        # エラー終了
        exit 1
    fi
    echo "" >> ${SQLLOG_TMP}

    # 正常終了したPPファイルの末尾にOKをつける
    mv -f ${_FILE_GenkinFutai_BAK} ${_FILE_GenkinFutai_BAK}.OK
fi

# DB切断
db2 terminate > /dev/null

# 作成したCSVファイルを環境変数で設定された場所に移動
#mv -f ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv  ${CSV_BACKUP_DIR}/${FILE_GenkinFutai}.`date +%Y%m%d%H%M`.csv

# 一時ファイルを削除
rm -f ${_tmp}

# CSV削除
rm -f ${CSV_OUT_DIR}/${FILE_GenkinFutai}.csv

outlog_func GF-I02002

exit 0
