#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ASIGN.sh
# 業 務 名       ： なし
# 処理概要       ： 設定ファイルより指定されたテーブル名のデータ項目「ASIGNGROUPID」の更新を行う
# 特記事項       ： 入出金材料、経費振替、入金アンマッチ、一般集金（手動消込）、
#                   一般集金（エラー対応）、振込入金のIFデータがGWDBに取り込まれていること
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： GWDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Tsuruha
#
# 作成日付       ： 2009-05-25
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-05-25 S.Tsuruha              新規作成
# 2 1.0.1 2010-04-22 H.Someya               コメント修正
# 3 2.0.0 2013-02-21 Liu.H                  障害対応: 入金アンマッチ取込障害
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
#env_file_list="???"
#for x in ${env_file_list}
#do
#    if [[ -r ${x} ]]
#    then
#        . ${x}
#    else
#        echo "Cannot read common env file. ( ${x} )."
#        return 1
#    fi
#done

#########################################################################
# アサイン登録処理関数
#########################################################################
function asigngroupid_sampling
{
     if [ ! -e ${LISTFILE} ]                                       #テーブルの一覧が記載されたリストファイルが存在しない場合、エラー終了
     then
     	outlog_func CM-E03005 ${LISTFILE}]
        return 1
     fi
    db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CM-E03004 "${_errmsg}"

		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

    while read table_name                                          #LISTFILEに定義したテーブル分、以下の処理を実行
    do

	# Add start by Liu.H
	LOOP_CNT=3
	ASSIGN_RST=1

	for(( ; ${LOOP_CNT} > 0 ; LOOP_CNT=`expr ${LOOP_CNT} - 1` ))
	do
	# Add end by Liu.H

		db2 -tvf ${SQL}${table_name}.sql > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then

			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func CM-E03006 "${_errmsg}"

			# Add start by Liu.H
			# 接続断
			db2 terminate > /dev/null
			# 30秒間待ち、再接続、importコマンド実行
			sleep 30
			# Add end by Liu.H

			# 一時ファイル等の削除
			rm -f  ${SQLLOG_TMP}

			# Delete start by Liu.H
			# エラー終了
			#return 1
			# Delete end by Liu.H

			# Add start by Liu.H
			# 再接続
			connectDB ${DB_NAME}

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				LOOP_CNT=0
			fi
		else
			ASSIGN_RST=0
			# ループ終了
			LOOP_CNT=0
			# And end by Liu.H
		fi
		echo "" >> ${SQLLOG_TMP}

	# Add start by Liu.H
	done

	# エラー終了
	if [ ${ASSIGN_RST} != '0' ]
	then
		return 1
	fi
	# Add end by Liu.H

    done < ${LISTFILE}

    #GWDB切断
	db2 terminate > /dev/null
}

#########################################################################
# main処理
#########################################################################

#########################################################################
# 環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 個別環境設定
#########################################################################
LISTFILE=${CONF_DIR}/asign_table_list      #テーブル名リスト(暫定)
SQL=${SQL_DIR}/asign_sql/               #アサイン予定ID一時外出し用SQL(暫定)

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func CM-I03001

# アサイン登録関数呼び出し
asigngroupid_sampling

if [ $? != '0' ]                                                      #関数「asigngroupid_sampling」の実行結果の正否を判定
then
	outlog_func CM-E03003
    exit 1
else
	outlog_func CM-I03002
    exit 0
fi
