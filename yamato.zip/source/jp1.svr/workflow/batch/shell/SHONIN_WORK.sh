#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： SYOUNIN_WORK.sh
# 業 務 名       ： 入出金材料確認以外の全業務
# 処理概要       ： JIRAのAPIを使用してJIRAのcostomFieldの項目と
#                ： ステータスを複数件更新する
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： JIRADB,GWDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-06-05
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2009-06-05 S.Sakagami                新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################
# 共通環境変数設定
##########################################################
#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${SHONINZUMI_MAIN_FLOW_LOG}

# 
SHONIN_SQL_DIR=${SQL_DIR}/shouninzumi

outlog_func SZ-I07001

#中間CSVファイルがあれば削除する
if [ -f ${CSV_OUT_DIR}/shonin_taishou.csv ]
then
	rm -f ${CSV_OUT_DIR}/shonin_taishou.csv
fi

if [ -f ${CSV_OUT_DIR}/shounin_work_after.csv ]
then
        rm -f ${CSV_OUT_DIR}/shounin_work_after.csv
fi

# JIRADB接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07003 "${_errmsg}"

        # 一時ファイル等の削除
        rm -f  ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 -tvf ${SHONIN_SQL_DIR}/shounin1.sql > ${SQLLOG_TMP}
SQLERROR=$?
#echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07005 "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

# JIRADBを切断
db2 terminate > /dev/null

# GWDB接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07004 "${_errmsg}"

        # 一時ファイル等の削除
        rm -f  ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 -tvf ${SHONIN_SQL_DIR}/shounin2.sql > ${SQLLOG_TMP}
SQLERROR=$?
#echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマン>ド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07005 "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 -tvf ${SHONIN_SQL_DIR}/shounin3.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマン>ド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07005 "${SHONIN_SQL_DIR}/shounin3.sql" "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 -tvf ${SHONIN_SQL_DIR}/shounin4.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマン>ド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07005 "${SHONIN_SQL_DIR}/shounin4.sql" "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 -tvf ${SHONIN_SQL_DIR}/shounin5.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマン>ド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07005 "${SHONIN_SQL_DIR}/shounin5.sql" "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 -tvf ${SHONIN_SQL_DIR}/shounin6.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマン>ド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07005 "${SHONIN_SQL_DIR}/shounin6.sql" "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 -tvf ${SHONIN_SQL_DIR}/shounin7.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマン>ド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07005 "${SHONIN_SQL_DIR}/shounin7.sql" "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 -tvf ${SHONIN_SQL_DIR}/shounin8.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマン>ド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07005 "${SHONIN_SQL_DIR}/shounin8.sql" "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 terminate 

# JIRADB接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド
結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07003 "${_errmsg}"

        # 一時ファイル等の削除
        rm -f  ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 -tvf ${SHONIN_SQL_DIR}/shounin9.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマン>ド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func SZ-E07005 "${SHONIN_SQL_DIR}/shounin9.sql" "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 terminate

outlog_func SZ-I07002

exit 0
