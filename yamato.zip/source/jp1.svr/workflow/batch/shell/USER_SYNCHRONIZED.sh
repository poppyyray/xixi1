#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： USER_SYNCHRONIZED.sh
# 業 務 名       ： なし
# 処理概要       ： 更新JIRA参照JIRAのユーザー同期Batch
# 特記事項       ： 起動トリガー：JP1
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： JIRADB,JIRARDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Y.Sekiguchi
#
# 作成日付       ： 2010-02-09
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.1 2010-02-09 Y.Sekiguchi              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
#
###########################################################

###########################################################
# 共通環境変数設定
###########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
USER_SYNCRO_EXEC_DATE=`date +%Y%m%d%H%M%S`
EXPORT_FILE_USERBASE=/user_syncro/export_userbase_"${USER_SYNCRO_EXEC_DATE}".ixf
EXPORT_FILE_PROPERTYENTRY=/user_syncro/export_propertyentry_"${USER_SYNCRO_EXEC_DATE}".ixf
EXPORT_FILE_MEMBERSHIPBASE=/user_syncro/export_membershipbase_"${USER_SYNCRO_EXEC_DATE}".ixf
EXPORT_FILE_PROJECTROLEACTOR=/user_syncro/export_projectroleactor_"${USER_SYNCRO_EXEC_DATE}".ixf
EXPORT_FILE_SEQUENCEVALUEITEM=/user_syncro/export_sequence_value_item_"${USER_SYNCRO_EXEC_DATE}".ixf
EXPORT_FILE_PROPERTYSTRING=/user_syncro/export_propertystring_"${USER_SYNCRO_EXEC_DATE}".ixf
LOB_FILE_PROPERTYSTRING=lobfile_propertystring_"${USER_SYNCRO_EXEC_DATE}"
SEQUENCE_VALUE_ITEM_CNT_FILENAME=_sequence_value_item_cnt.txt
PROJECTROLEACTOR_CNT_FILENAME=_projectroleactor_cnt.txt
PROPERTYSTRING_CNT_FILENAME=_propertystring_cnt.txt
USERBASE_CNT_FILENAME=_userbase_cnt.txt
PROPERTYENTRY_CNT_FILENAME=_propertyentry_cnt.txt
MEMBERSHIPBASE_CNT_FILENAME=_membershipbase_cnt.txt

if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません"
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# ディレクトリ移動
# ----
cd ${SHELL_DIR}
###############################################################################
# 件数取得
#
# 関数名：　インポート後の件数取得
#
# 機能：　引数で渡されたTableの件数を取得する(条件なし)
#
# 引数1：　table名（"${SCHEMA_NAME}に続くtable名）
# 引数2：　ファイル名
# 引数3：　エラー発生時のメッセージID
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#
###############################################################################
function make_table_count
{
	#件数取得
	db2 "select count(*) from ${SCHEMA_NAME}${1}" > ${TMP_DIR}${2}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func ${3} "${_errmsg}"
		return 1
	fi
	return 0
}
###############################################################################
# 件数取得
#
# 関数名：　インポート後の件数取得
#
# 機能：　引数で渡されたTableの件数を取得する(条件なし)
#
# 引数1：　table名（"${SCHEMA_NAME}に続くtable名）
# 引数2：　ファイル名
# 引数3：　エラー発生時のメッセージID
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#
###############################################################################
function make_table_count_for_sequence_value_item
{
	#件数取得
	db2 "select count(*) from ${SCHEMA_NAME}${1} where seq_name in ('OSUser', 'OSMembership', 'OSPropertyEntry','ProjectRoleActor')" > ${TMP_DIR}${2}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func ${3} "${_errmsg}"
		return 1
	fi
	return 0
}
###############################################################################
# 件数取得
#
# 関数名：　エクスポート後の件数取得
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function make_exported_cnt
{
	#userbase件数取得
	_tabelename=userbase
	_filename=/user_syncro/export"${USERBASE_CNT_FILENAME}"
	_msgid=UM-E07213
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	#membershipbase件数取得
	_tabelename=membershipbase
	_filename=/user_syncro/export"${MEMBERSHIPBASE_CNT_FILENAME}"
	_msgid=UM-E07214
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	#propertyentry件数取得
	_tabelename=propertyentry
	_filename=/user_syncro/export"${PROPERTYENTRY_CNT_FILENAME}"
	_msgid=UM-E07215
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	#propertystring件数取得
	_tabelename=propertystring
	_filename=/user_syncro/export"${PROPERTYSTRING_CNT_FILENAME}"
	_msgid=UM-E07216
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	#projectroleactor件数取得
	_tabelename=projectroleactor
	_filename=/user_syncro/export"${PROJECTROLEACTOR_CNT_FILENAME}"
	_msgid=UM-E07217
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	#sequence_value_item件数取得
	_tabelename=sequence_value_item
	_filename=/user_syncro/export"${SEQUENCE_VALUE_ITEM_CNT_FILENAME}"
	_msgid=UM-E07218
	make_table_count_for_sequence_value_item ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	return 0
}
###############################################################################
# 件数取得
#
# 関数名：　インポート後の件数取得
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function make_importeded_cnt
{
	#userbase件数取得
	_tabelename=userbase
	_filename=/user_syncro/import"${USERBASE_CNT_FILENAME}"
	_msgid=UM-E07219
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	#membershipbase件数取得
	_tabelename=membershipbase
	_filename=/user_syncro/import"${MEMBERSHIPBASE_CNT_FILENAME}"
	_msgid=UM-E07220
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	#propertyentry件数取得
	_tabelename=propertyentry
	_filename=/user_syncro/import"${PROPERTYENTRY_CNT_FILENAME}"
	_msgid=UM-E07221
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	#propertystring件数取得
	_tabelename=propertystring
	_filename=/user_syncro/import"${PROPERTYSTRING_CNT_FILENAME}"
	_msgid=UM-E07222
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	#projectroleactor件数取得
	_tabelename=projectroleactor
	_filename=/user_syncro/import"${PROJECTROLEACTOR_CNT_FILENAME}"
	_msgid=UM-E07223
	make_table_count ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
			return 1
	fi
	#sequence_value_item件数取得
	_tabelename=sequence_value_item
	_filename=/user_syncro/import"${SEQUENCE_VALUE_ITEM_CNT_FILENAME}"
	_msgid=UM-E07224
	make_table_count_for_sequence_value_item ${_tabelename} ${_filename} ${_msgid}
	if [ $? != '0' ]
	then
		return 1
	fi
	return 0
}
###############################################################################
# userbaseのエクスポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function export_userbase
{
	#エクスポート
	db2 "export to ${TMP_DIR}${EXPORT_FILE_USERBASE} of ixf select * from ${SCHEMA_NAME}userbase" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E07201 "${_errmsg}"

		# エラー終了
		return 1
	fi
    return 0
}
###############################################################################
# membershipbaseのエクスポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function export_membershipbase
{
	#エクスポート
	db2 "export to ${TMP_DIR}${EXPORT_FILE_MEMBERSHIPBASE} of ixf select * from ${SCHEMA_NAME}membershipbase" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E07202 "${_errmsg}"

		# エラー終了
		return 1
	fi
    return 0
}
###############################################################################
# propertyentryのエクスポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function export_propertyentry
{
	db2 "export to ${TMP_DIR}${EXPORT_FILE_PROPERTYENTRY} of ixf select * from ${SCHEMA_NAME}propertyentry" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E07203 "${_errmsg}"

		# エラー終了
		return 1
	fi
    return 0
}
###############################################################################
# propertystringのエクスポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function export_propertystring
{
	db2 "export to ${TMP_DIR}${EXPORT_FILE_PROPERTYSTRING} of ixf select * from ${SCHEMA_NAME}propertystring" > ${SQLLOG_TMP}
	#20100219 lobファイル対応削除 Sekiguchi START
	#db2 "export to ${TMP_DIR}${EXPORT_FILE_PROPERTYSTRING} of ixf LOBS TO ${TMP_DIR}/user_syncro/ LOBFILE ${LOB_FILE_PROPERTYSTRING} MODIFIED BY LOBSINFILE select * from ${SCHEMA_NAME}propertystring" > ${SQLLOG_TMP}
	#20100219 lobファイル対応削除 Sekiguchi END

	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E07204 "${_errmsg}"

		# エラー終了
		return 1
	fi
    return 0
}
###############################################################################
# projectroleactorのエクスポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function export_projectroleactor
{
	db2 "export to ${TMP_DIR}${EXPORT_FILE_PROJECTROLEACTOR} of ixf select * from ${SCHEMA_NAME}projectroleactor" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E07205 "${_errmsg}"

		# エラー終了
		return 1
	fi
    return 0
}
###############################################################################
# sequence_value_itemのエクスポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function export_sequence_value_item
{
	db2 "export to ${TMP_DIR}${EXPORT_FILE_SEQUENCEVALUEITEM} of ixf select * from ${SCHEMA_NAME}sequence_value_item where seq_name in ('OSUser', 'OSMembership', 'OSPropertyEntry','ProjectRoleActor')" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E07206 "${_errmsg}"

		# エラー終了
		return 1
	fi
	return 0
}
###############################################################################
# userbaseのインポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function import_userbase
{
	db2 "import from ${TMP_DIR}${EXPORT_FILE_USERBASE} of ixf commitcount 1000 replace into ${SCHEMA_NAME}userbase" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー (Warningとして扱い、処理は終了させない)
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
		    # エラーログ出力
		    _errmsg=`cat ${SQLLOG_TMP}`
			outlog_func UM-E07207 "${_errmsg}"
			return 1
		fi
	return 0
}
###############################################################################
# membershipbaseのインポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function import_membershipbase
{
	db2 "import from ${TMP_DIR}${EXPORT_FILE_MEMBERSHIPBASE} of ixf commitcount 1000 replace into ${SCHEMA_NAME}membershipbase" > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー (Warningとして扱い、処理は終了させない)
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
	        # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
			outlog_func UM-E07208 "${_errmsg}"
			return 1
		fi
	return 0
}
###############################################################################
# propertyentryのインポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function import_propertyentry
{
	db2 "import from ${TMP_DIR}${EXPORT_FILE_PROPERTYENTRY} of ixf commitcount 1000 replace into ${SCHEMA_NAME}propertyentry" > ${SQLLOG_TMP}

        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー (Warningとして扱い、処理は終了させない)
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
	        # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
			outlog_func UM-E07209 "${_errmsg}"
			return 1
        fi
	return 0
}
###############################################################################
# propertystringのインポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function import_propertystring
{
	db2 "import from ${TMP_DIR}${EXPORT_FILE_PROPERTYSTRING} of ixf commitcount 1000 replace into ${SCHEMA_NAME}propertystring" > ${SQLLOG_TMP}
	#20100219 lobファイル対応削除 Sekiguchi START
	#db2 "import from ${TMP_DIR}${EXPORT_FILE_PROPERTYSTRING} of ixf LOBS FROM ${TMP_DIR}/user_syncro/ MODIFIED BY LOBSINFILE commitcount 1000 replace into ${SCHEMA_NAME}propertystring" > ${SQLLOG_TMP}
	#20100219 lobファイル対応削除 Sekiguchi END
       SQLERROR=$?
       echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー (Warningとして扱い、処理は終了させない)
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
	        # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
			outlog_func UM-E07210 "${_errmsg}"
			return 1
        fi
	return 0
}
###############################################################################
# projectroleactorのインポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function import_projectroleactor
{
	db2 "import from ${TMP_DIR}${EXPORT_FILE_PROJECTROLEACTOR} of ixf commitcount 1000 replace into ${SCHEMA_NAME}projectroleactor" > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー (Warningとして扱い、処理は終了させない)
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
	        # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
			outlog_func UM-E07211 "${_errmsg}"
			return 1
       fi
	return 0
}
###############################################################################
# sequence_value_itemのインポート
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function import_sequence_value_item
{
	db2 "import from ${TMP_DIR}${EXPORT_FILE_SEQUENCEVALUEITEM} of ixf commitcount 1000 insert_update into ${SCHEMA_NAME}sequence_value_item" > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー (Warningとして扱い、処理は終了させない)
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
	        # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
			outlog_func UM-E07212 "${_errmsg}"
			return 1
        fi
	return 0
}
###############################################################################
# 過去のexportファイルの削除
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
function remove_export_file
{
	find ${TMP_DIR}/user_syncro/*.ixf -mtime +${USERSYNCRO_EXPORT_DELETE_DATE} -exec rm {} \;
	_ret=$?
	if [ $_ret != '0' ]
	then
		# エラー終了
		return 1
	fi

#20100219 lobファイル対応削除 Sekiguchi START
#	find ${TMP_DIR}/user_syncro/*.lob -mtime +${USERSYNCRO_EXPORT_DELETE_DATE} -exec rm {} \;
#	_ret=$?
#	if [ $_ret != '0' ]
#	then
#		# エラー終了
#		return 1
#	fi
#20100219 lobファイル対応削除 Sekiguchi END

	return 0
}
###############################################################################
# main処理
# 処理概要
# 1.更新系JIRADBのユーザー関連テーブルのexport
# 2.更新系JIRADBのユーザー関連テーブルの件数取得t
# 3.1で取得したデータを参照系系JIRADBのユーザー関連テーブルへimport
# 4.3の結果件数を取得
# 5.2と4の結果に相違がないことを確認する
#
# 下記のシーケンスで処理を行う
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################

#出力ログ名設定
export log_name=${USER_MAIN_FLOW_LOG}
#main処理開始
outlog_func UM-I07001

#更新系JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
#DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func UM-E07101 "${_errmsg}"

	# エラー終了
	exit 1
fi

#userbaseのエクスポート
export_userbase
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07102
    exit 1
fi
#membershipbaseのエクスポート
export_membershipbase
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07103
    exit 1
fi
#propertyentryのエクスポート
export_propertyentry
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07104
    exit 1
fi
#propertystringのエクスポート
export_propertystring
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07105
    exit 1
fi
#projectroleactorのエクスポート
export_projectroleactor
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07106
    exit 1
fi
#sequence_value_itemのエクスポート
export_sequence_value_item
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07107
    exit 1
fi
#更新系件数取得
make_exported_cnt
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07122
    exit 1
fi
# 更新系JIRADBから切断
db2 terminate > /dev/null

# 参照系JIRADBに接続
db2 connect to ${RF_JIRA_DB} > ${SQLLOG_TMP}
#TODO test用
#db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}

SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func UM-E07108 "${_errmsg}"
	# エラー終了
	exit 1
fi
#userbaseのimport
import_userbase
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07109
    exit 1
fi
#membershipbaseのimport
import_membershipbase
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07110
    exit 1
fi
#propertyentryのimport
import_propertyentry
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07111
    exit 1
fi
#propertystringのimport
import_propertystring
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07112
    exit 1
fi
#projectroleactorのimport
import_projectroleactor
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07113
    exit 1
fi
#import_sequence_value_itemのimport
import_sequence_value_item
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07114
    exit 1
fi
#参照系件数取得
make_importeded_cnt
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07123
    exit 1
fi
# DB切断
db2 terminate > /dev/null
# userbase件数確認
diff ${TMP_DIR}/user_syncro/export"${USERBASE_CNT_FILENAME}" ${TMP_DIR}/user_syncro/import"${USERBASE_CNT_FILENAME}" > ${DETAIL_LOG_TMP}
_ret=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
if [ $_ret != '0' ]
then
    outlog_func UM-E07115
    exit 1
fi
# membershipbase件数確認
diff ${TMP_DIR}/user_syncro/export"${MEMBERSHIPBASE_CNT_FILENAME}" ${TMP_DIR}/user_syncro/import"${MEMBERSHIPBASE_CNT_FILENAME}" > ${DETAIL_LOG_TMP}
_ret=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
if [ $_ret != '0' ]
then
    outlog_func UM-E07116
    exit 1
fi
# propertyentry件数確認
diff ${TMP_DIR}/user_syncro/export"${PROPERTYENTRY_CNT_FILENAME}" ${TMP_DIR}/user_syncro/import"${PROPERTYENTRY_CNT_FILENAME}" > ${DETAIL_LOG_TMP}
_ret=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
if [ $_ret != '0' ]
then
    outlog_func UM-E07117
    exit 1
fi
# propertystring件数確認
diff ${TMP_DIR}/user_syncro/export"${PROPERTYSTRING_CNT_FILENAME}" ${TMP_DIR}/user_syncro/import"${PROPERTYSTRING_CNT_FILENAME}" > ${DETAIL_LOG_TMP}
_ret=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
if [ $_ret != '0' ]
then
    outlog_func UM-E07118
    exit 1
fi
# projectroleactor件数確認
diff ${TMP_DIR}/user_syncro/export"${PROJECTROLEACTOR_CNT_FILENAME}" ${TMP_DIR}/user_syncro/import"${PROJECTROLEACTOR_CNT_FILENAME}" > ${DETAIL_LOG_TMP}
_ret=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
if [ $_ret != '0' ]
then
    outlog_func UM-E07119
    exit 1
fi
# sequence_value_item件数確認
diff ${TMP_DIR}/user_syncro/export"${SEQUENCE_VALUE_ITEM_CNT_FILENAME}" ${TMP_DIR}/user_syncro/import"${SEQUENCE_VALUE_ITEM_CNT_FILENAME}" > ${DETAIL_LOG_TMP}
_ret=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
if [ $_ret != '0' ]
then
    outlog_func UM-E07120
    exit 1
fi


# ファイルメンテナンス
remove_export_file
_ret=$?
if [ $_ret != '0' ]
then
    outlog_func UM-E07121
    exit 1
fi

# main処理終了
outlog_func UM-I07002

exit 0

