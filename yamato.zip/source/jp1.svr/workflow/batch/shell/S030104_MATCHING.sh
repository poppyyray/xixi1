#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S030104_MATCHING.sh
# 業 務 名       ： マッチング（入金データアンマッチリスト処理）
# 処理概要       ： 入金データアンマッチテーブルと証憑テーブルの紐付けを行う。
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： GWDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ：A.Takagi
#
# 作成日付       ：2009-07-15
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-15 A.Takagi	  既存修正  エラーハンドルを追加
# 2 1.0.1 2010-04-22 H.Someya               コメント修正
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#環境設定を行う
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# 一時ファイル変数
export _sqltmp=${TMP_DIR}/S030104_tsuuban.tmp
export _idlisttmp=${TMP_DIR}/S030104_idlist.tmp

#マッチング件数ログ表示用変数
matchingCount=0;

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${SHOHYO_MAIN_FLOW_LOG}

outlog_func UD-I06001

db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func UD-E06003 "${_errmsg}"

	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# エラー終了
	exit 1
fi
echo "" >> ${SQLLOG_TMP}

### 経費振替マッチング処理 ###############################################
_s030104_sql=${SQL_DIR}/S030104_MATCHING.sql

# 経費振替マッチングSQL実行
db2 -tvf ${_s030104_sql}  > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func UD-E06004 "${_errmsg}"

	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# エラー終了
	exit 1
fi
echo "" >> ${SQLLOG_TMP}

# SQL結果ファイル存在チェック
if [ ! -f ${_sqltmp} ]
then
	outlog_func UD-E06005
	return 1
fi

# csvファイルを整形
sed -e s/,/" "/g ${_sqltmp} | sed -e s/\"/""/g > ${_idlisttmp}

# マッチング条件に該当した通番と証憑IDの件数分ループを行う
while read tsuuban_tmp shohyo_id_tmp
do
	# 該当テーブルにマッチングした証憑IDを更新する
	db2 "update ${TABLE_S030104} set MATCHINGshouhyouID = '${shohyo_id_tmp}' where tsuuban = '${tsuuban_tmp}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-I06006 ${matchingCount}
		outlog_func UD-E06007 ${tsuuban_tmp} "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		exit 1
	fi
	echo "" >> ${SQLLOG_TMP}

	#マッチング件数＋１
	matchingCount=`expr ${matchingCount} + 1`

done < ${_idlisttmp}

#マッチング件数をログに出力
outlog_func UD-I06008 ${matchingCount}

db2 terminate > /dev/null

# 一時ファイルを削除
rm -f ${_sqltmp}
rm -f ${_idlisttmp}

outlog_func UD-I06002

exit 0
