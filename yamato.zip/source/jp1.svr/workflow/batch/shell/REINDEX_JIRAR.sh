#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： REINDEX_JIRAR.sh
# 業 務 名       ： なし
# 処理概要       ： 参照JIRA Re-Indexシェル
# 特記事項       ：
# パラメータ     ： 
# リターンコード ： 0             正常
#                   1             エラー
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： LiuJian
#
# 作成日付       ： 2014-09-18
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2014-09-18 LiuJian                新規作成
# 2 
# 3 
# 4 
# 5       
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

################################
# MAIN
################################

rc=0

##########################################
# RE-INDEX
##########################################
cd ${SHELL_DIR}

# 出力ログ名設定
export log_name=${ARCHIVE_DATE_LOG}

# 開始メッセージ
outlog_func RE-I01001

# 変数設定
JIRAR_PORT=${JIRAR_CIP}:8080
CURRENT_PATH=`pwd`
LOGIN_PATH=${TMP_DIR}/login_jsp

if [ ! -d ${LOGIN_PATH} ]
then
	mkdir -p ${LOGIN_PATH}
fi

cd ${LOGIN_PATH}

## 不要なファイルを削除
rm -rf ./${JIRAR_PORT}
rm -f ./re_index_cookies.txt
rm -f ./http_res_file_reindex.txt
rm -f ./login.jsp*

#JIRAへログイン
wget -o ${ROOT_FILE} --save-cookies re_index_cookies.txt --keep-session-cookies --post-data "os_username=${JIRAr_USER}&os_password=${JIRAr_PASSWORD}&os_cookie=true" --output-file=http_res_file_reindex.txt ${JIRAr_LOGIN_URL}
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${ROOT_FILE}`" >>${DETAIL_LOG}

#re-index実行
wget -o ${ROOT_FILE} --load-cookies re_index_cookies.txt --post-data 'Re-Index=Re-Index' --timeout=${WGET_TIMEOUT} -p "${REINDEX_URL}"
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${ROOT_FILE}`" >>${DETAIL_LOG}

ls ${LOGIN_PATH}/${REINDEX_RESULT_FILE}
rc=$?

if [ $rc -eq 0 ]; then
    proc_time_msec=`ls ${REINDEX_RESULT_FILE} | sed 's/.\+=\([0-9]\+\)/\1/'`
    # reindex異常場合(proc_time_msec = 0)
    if [ $proc_time_msec = 0 ]; then
      rc=1
    fi
fi

if [ $rc -eq 0 ]; then
    rc=1

    # ./直下に作成されるcookies.txtファイルが存在するか確認
    _find_cookiesfile=`find . -name re_index_cookies.txt`
    if [ ! -z "${_find_cookiesfile}" ]; then

        #re_index_cookies.txtファイルの内容をチェック
        cookies_code=`cat ${_find_cookiesfile} | grep "seraph.os.cookie"`
        if [ ! -z "${cookies_code}" ]; then

            wget_log_file=`find . -name http_res_file_reindex.txt`
            #HTTPレスポンスを記述したファイルが存在するか確認
            if [ ! -z "${wget_log_file}" ]; then

                #HTTPリターンコードが200(正常)か確認
                http_res_code=`cat ${wget_log_file} | grep "200 OK"`
                if [ ! -z "${http_res_code}" ]; then
                    rc=0
                fi
            fi
        fi
    fi
fi


if [ $rc = 0 ]; then
    # Succeeded to re-index
    outlog_func RE-I01003 ${proc_time_msec}
else
  # Failed to re-index
    outlog_func RE-E01004
fi

cd ${CURRENT_PATH}

# 終了メッセージ
outlog_func RE-I01002

exit $rc
