#!/bin/bash
################### モジュール説明 ############################################
# モジュール名   ： RECOMPOTIN.sh
# システム名     ： テーブル再構成
# 業 務 名       ： 共通
# 機 能 名　　 　： テーブル再構成
# 言語           ： bash
# ＯＳ           ： Linux (Red hat)
# 処理概要       ： 指定テーブルを再構成／統計情報の再作成を行う。
# 特記事項       ： 再構成対象テーブル設定ファイルが存在すること。
# パラメータ     ： なし
# ログファイル   ： 
# リターンコード ： 正常終了(0)
#                  処理異常(1)
# 対象DB         ： なし
#
################### モジュール説明 #############################################
#
################### 改定履歴       #############################################
# 作成者         ： T.Harita
# 作成日付       ： 2009-07-14
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
# 1初版     2009-07-14  T.harita                新規作成
# 2
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
################### 改定履歴       #############################################

################################################################################
# MAIN関数
################################################################################
function main
{
    # 対象情報取得
    lineno=0
    while read line;do
        array[${lineno}]=${line}
        lineno=$(expr ${lineno} + 1)
    done < ${_tablelist}
    # ProcStartLog
    if [ ${lineno} != '0' ]
    then
        outlog_func CM-I11004 ${lineno}
    else
        outlog_func CM-E11005
        return 1
    fi
    # テーブル再構成
    for i in "${array[@]}";do
        rtncd=0
        # 対象情報エレメント分割
        echo ${i} | sed -e 's/,/ /g' | while read dbname schemaname tablename
        do
            # DB接続
            db2 connect to ${dbname} > ${SQLLOG_TMP}
            SQLERROR=$?
            echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
            # コマンド判定
            if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
            then
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func CM-E11006 "${_errmsg}"
                return 1
            fi
            echo "" >> ${SQLLOG_TMP}
            # テーブル再構成
            db2 "reorg table ${schemaname}.${tablename}" > ${SQLLOG_TMP}
            SQLERROR=$?
            echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
            # コマンド判定
            if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
            then
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func CM-E11007 "${_errmsg}"
                return 1
            fi
            echo "" >> ${SQLLOG_TMP}
            # テーブル統計情報再作成
            db2 "runstats on table ${schemaname}.${tablename} with DISTRIBUTION" > ${SQLLOG_TMP}
            SQLERROR=$?
            echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
            # コマンド判定
            if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
            then
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func CM-E11008 "${_errmsg}"
                return 1
            fi
            echo "" >> ${SQLLOG_TMP}
            # DB切断
            db2 terminate > /dev/null
            outlog_func CM-I11010 ${dbname} ${schemaname} ${tablename}
        done
        if [ $? != 0 ]
        then
            outlog_func CM-E11009
            return 1
        fi
    done
    return 0
}
################################################################################
# 環境設定を行う
################################################################################
# モジュール名取得
shname=`basename ${0}`
# ログ名設定
logname=`echo ${shname} | sed "s/.sh//g"`".log"
# 環境設定ファイルを読み込む
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

################################################################################
# 個別環境設定を行う
################################################################################
# 処理対象データ設定ファイルを読み込む
export _tablelist=${CONF_DIR}/tablelist.conf
# SQLログ用一時ファイル作成
touch ${SQLLOG_TMP}
chmod 777 ${SQLLOG_TMP}
################################################################################
# MAIN処理
################################################################################
outlog_func CM-I11001
# 関数呼び出し
main
if [ $? != '0' ]
then
    outlog_func CM-E11003
    exit 1
else
    outlog_func CM-I11002
    rm -f ${SQLLOG_TMP}
    exit 0
fi
