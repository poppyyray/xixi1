#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： SHUTDOWN_JIRA.sh
# 業 務 名       ： なし
# 処理概要       ： JIRA停止バッチ
# 特記事項       ： 起動トリガー：JP1
# パラメータ     ： U(更新JIRA)/R(参照JIRA)
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ：
#
# 作成日付       ：
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.1 2014-09-18 LiuJian                新規作成
# 2       
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
#
###########################################################

#####################################
# TSA起動／停止待ち時間
TIMEOUT=900
#####################################

#########################################################################
#環境設定を行う
#########################################################################
_exec_sh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_sh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_sh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# パラメータより更新JIRA/参照JIRA確定
case ${1} in
	"U")	SERVER_TYPE="UPDATE_JIRA"
			PROG_NAME="SHUTDOWN_JIRAU"
			#　ACTIVEサーバをチェックする
			#二つJIRAのBackLanIPがいずれかアクセスできる場合、停止する
			ACTIVE_CHECK "$JIRAU1_IP $JIRAU2_IP"
			rc=$?
			if [ $rc -eq 0 ]; then
				JIRA_HOST=$ACTIVE_CHECK_SERVER
			else
				outlog_func SM-E01012 "${SERVER_TYPE}"
				exit 1
			fi
			;;
	"R")	SERVER_TYPE="REFERENCE_JIRA"
			PROG_NAME="SHUTDOWN_JIRAR"
			#　ACTIVEサーバをチェックする
			#二つJIRAのBackLanIPがいずれかアクセスできる場合、停止する
			ACTIVE_CHECK "$JIRAR1_IP $JIRAR2_IP"
			rc=$?
			if [ $rc -eq 0 ]; then
				JIRA_HOST=$ACTIVE_CHECK_SERVER
			else
				outlog_func SM-E01012 "${SERVER_TYPE}"
				exit 1
			fi
			;;
	*)	exit 1 ;;
esac
KEYWORD_SERVER="RG_JIRA"

# function: wait until the JIRA resource group is offline
# return code: 0 - success, 255 - timeout
waitUntilJIRARGStop() {
  local rc=0
  local timeout=$TIMEOUT
  while true
  do
    REMOTE_EXEC_SH ${JIRA_HOST} "lssam -nocolor -g ${KEYWORD_SERVER}"
    res=`cat ${REMOTE_EXEC_FILE} | head -1 | grep "^Offline.*IBM"`
    if [ "${res}""x" != """x" ]; then
      # success
      break
    elif [ "$timeout" -gt 0 ]; then
      sleep 10
      timeout=$(($timeout - 10))
    else
      # timeout
      rc=255
      break
    fi
  done

  return $rc
}

# function: shutdown JIRA server
# return code: 0 - success, 1 - fail
shutdownJIRA() {
  outlog_func SM-I01006 "${SERVER_TYPE}"
  local rc=0

  # Send jirau-rg or jirar-rg stop request
  REMOTE_EXEC_SH ${JIRA_HOST} "chrg -o offline ${KEYWORD_SERVER}"
  rc=$?
  if [ $rc -eq 0 ]; then
    outlog_func SM-I01007 "${SERVER_TYPE}" "${JIRA_HOST}"
  else
	outlog_func SM-E01008 "${SERVER_TYPE}" "${JIRA_HOST}" "${rc}"
  fi

  # Wait until jirau or jirar stops
  waitUntilJIRARGStop
  rc=$?
  if [ $rc -eq 0 ]; then
    outlog_func SM-I01009 "${SERVER_TYPE}"
    rc=0
  else
    outlog_func SM-E01010 "${SERVER_TYPE}"    
    rc=1
  fi

  return $rc
}

echo "################################################################"
echo `basename $0`
date
echo "################################################################"

shutdownJIRA
