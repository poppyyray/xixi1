#!/bin/bash
################### モジュール説明 #############################################
# モジュール名   ： S030104_ONLINE_CREATE.sh
# 業 務 名       ： ワークアイテム更新（ONLINE_CREATE）
# 処理概要       ： 業務データをデータベースより取得取り込み、
#                  wgetでJIRAの対象項目に反映する。
# 特記事項       ： なし
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB       ： GWDB,JIRADB
#
################### モジュール説明 #############################################
#
################### 改定履歴       #############################################
# 作成者         ： S.Tsuruha
# 作成日付       ： 2009-06-24
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
# 1.0.0     2009-06-24  S.Tsuruha              新規作成
# 2
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
################### 改定履歴       ########################

###############################################################################
# main処理開始
###############################################################################
# 共通環境変数読み込み
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
    if [[ -r ${x} ]]
    then
        . ${x}
    else
        echo "Cannot read common env file. ( ${x} )."
        exit 1
    fi
done

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${S030104_MAIN_FLOW_LOG}

# 開始ログ出力
outlog_func UD-I04001

# JIRAPKEY 初期化
java -classpath "${JAVA_CLASSPATH}" com.ibm.jirax.batch.SetUpSequenceNumberBatch ${JIRA_UI_PID_S030104} > ${DETAIL_LOG_TMP} 2>&1
RC=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
case ${RC} in
        0)      outlog_func UD-I04027 ${JIRA_UI_PID_S030104} ${RC};;
        10)     outlog_func UD-I04028 ${JIRA_UI_PID_S030104} ${RC};;
        *)      outlog_func UD-E04026 ${JIRA_UI_PID_S030104} ${RC}
                exit 1;;
esac

# JIRA ワークアイテム追加
java -classpath "${JAVA_CLASSPATH}" com.ibm.jirax.batch.CreateIssuesBatch ${JIRA_UI_PID_S030104} > ${DETAIL_LOG_TMP} 2>&1
RC=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
case ${RC} in
        0)      outlog_func UD-I04029 ${JIRA_UI_PID_S030104} ${RC};;
        10)     outlog_func UD-I04030 ${JIRA_UI_PID_S030104} ${RC};;
        *)      outlog_func UD-E04031 ${JIRA_UI_PID_S030104} ${RC}
                exit 1;;
esac

# 終了ログ出力
outlog_func UD-I04002

exit 0
