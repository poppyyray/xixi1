#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S040202_MATCHING.sh
# 業 務 名       ： マッチング（一般集金（手動消込）リスト処理）
# 処理概要       ： 一般集金（手動消込）テーブルと証憑テーブルの紐付けを行う。
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ：
#
# 作成日付       ：
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.1 2010-04-22 H.Someya               コメント修正
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
# マッチング処理関数
#########################################################################
function matching
{
	#マッチング件数ログ表示用変数
	matchingCount=0;

	# DB接続
	db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func GC-E06004 "${_errmsg}"

		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	### 一般集金（手動消込：領収書番号有り）マッチング処理 ###############################################
	_S040202_ID0007_sql=${SQL_DIR}/S040202_ID0007_MATCHING.sql

	# 一般集金（手動消込：領収書番号有り）マッチングSQL実行
	db2 -tvf ${_S040202_ID0007_sql} > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# SQL実行エラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func GC-E06007 "${_errmsg}"

		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# SQL結果ファイル存在チェック
	if [ ! -f ${_sqltmp1} ]
	then
		outlog_func GC-E06005
		return 1
	fi

	# csvファイルを整形
	sed -e s/,/" "/g ${_sqltmp1} | sed -e s/\"/""/g > ${_idlisttmp1}

	# マッチング条件に該当した通番と証憑IDの件数分ループを行う
	while read tsuuban_tmp1 shohyo_id_tmp1
	do
		# 該当テーブルにマッチングした証憑IDを更新する
		db2 "update ${TABLE_S040202} set MATCHINGshouhyouID = '${shohyo_id_tmp1}' where tsuuban = '${tsuuban_tmp1}'"  > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func GC-I06011 ${matchingCount}
			outlog_func GC-E06008 ${tsuuban_tmp} "${_errmsg}"

			# 一時ファイル等の削除
			rm -f  ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi
		echo "" >> ${SQLLOG_TMP}

		#マッチング件数＋１
		matchingCount=`expr ${matchingCount} + 1`

	done < ${_idlisttmp1}

	#マッチング件数をログに出力
	outlog_func GC-I06015 ${matchingCount}

	### 一般集金（手動消込：領収書番号無し）マッチング処理 ###############################################

	#マッチング件数初期化
	matchingCount=0;

	_S040202_ID0008_sql=${SQL_DIR}/S040202_ID0008_MATCHING.sql

	# 一般集金（手動消込：領収書番号無し）マッチングSQL実行
	db2 -tvf ${_S040202_ID0008_sql}   > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func GC-E06009 ${tsuuban_tmp} "${_errmsg}"

		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}


	# SQL結果ファイル存在チェック
	if [ ! -f ${_sqltmp2} ]
	then
		outlog_func GC-E06006
		return 1
	fi

	# csvファイルを整形
	sed -e s/,/" "/g ${_sqltmp2} | sed -e s/\"/""/g > ${_idlisttmp2}

	# マッチング条件に該当した通番と証憑IDの件数分ループを行う
	while read tsuuban_tmp2 shohyo_id_tmp2               #tmp2ファイルの行数分、以下の処理を実行
	do
		# 該当テーブルにマッチングした証憑IDを更新する
		db2 "update ${TABLE_S040202} set MATCHINGshouhyouID = '${shohyo_id_tmp2}' where tsuuban = '${tsuuban_tmp2}'"   > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func GC-I06012 ${matchingCount}
			outlog_func GC-E06010 ${tsuuban_tmp} "${_errmsg}"

			# 一時ファイル等の削除
			rm -f  ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi
		echo "" >> ${SQLLOG_TMP}

		#マッチング件数＋１
		matchingCount=`expr ${matchingCount} + 1`

	done < ${_idlisttmp2}

	#マッチング件数をログに出力
	outlog_func GC-I06014 ${matchingCount}

	db2 terminate > /dev/null

	return 0
}

#########################################################################
# main処理
#########################################################################

#########################################################################
# 環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 個別環境設定
#########################################################################
# 一時ファイル変数
export _sqltmp1=${TMP_DIR}/S040202_tsuuban1.tmp
export _idlisttmp1=${TMP_DIR}/S040202_idlist1.tmp
export _sqltmp2=${TMP_DIR}/S040202_tsuuban2.tmp
export _idlisttmp2=${TMP_DIR}/S040202_idlist2.tmp

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${SHOHYO_MAIN_FLOW_LOG}

# ログ出力
outlog_func GC-I06001

# マッチング処理関数呼び出し
matching

if [ $? != '0' ]                                                      #関数「matching」の実行結果の正否を判定
then
	# 一時ファイル削除
	rm -f ${_sqltmp1}
	rm -f ${_idlisttmp1}
	rm -f ${_sqltmp2}
	rm -f ${_idlisttmp2}

	# ログ出力
	outlog_func GC-E06003
    exit 1
else

	# 一時ファイル削除
	rm -f ${_sqltmp1}
	rm -f ${_idlisttmp1}
	rm -f ${_sqltmp2}
	rm -f ${_idlisttmp2}

	# ログ出力
	outlog_func GC-I06002
    exit 0
fi
