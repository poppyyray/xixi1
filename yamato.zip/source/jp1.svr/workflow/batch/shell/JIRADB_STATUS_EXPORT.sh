#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： JIRADB_STATUS_EXPORT.sh
# 業 務 名       ： GWDBアーカイブ処理
# 処理概要       ： 更新JIRADBから案件が未処理("E01"以外)
#                   の通番・ステータスID・PNAMEを取得する
# 特記事項       ： 起動トリガー：JP1にて起動。
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： 更新JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： A.Takagi
#
# 作成日付       ： 2009-12-25
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-12-25 A.Takagi                新規作成
# 2 1.0.1 2009-02-19 Y.Otsuka
# 3 1.0.2 2010-03-08 A.Takagi				機能不全対応
# 4 1.0.3 2010-03-16 A.Takagi				機能不全対応
#											変数SQLERROR出力処理追加
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################## 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
if [ ! -f ${env_file_list} ]
then
	echo "Cannot read common env file. ( ${env_file_list} )."
	exit 1
else
	. ${env_file_list}
fi


# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
if [ ! -f ${conf_file_list} ]
then
	echo "Cannot read common conf file. ( ${conf_file_list}} )."
	exit 1
else
	. ${conf_file_list}
fi


# ----
# 業務別環境変数設定
# ----
# 出力ログ名設定
export log_name=${GWDB_ARCHIVE_DATE_LOG}


##本シェル使用変数は、batch_common.confを参照してください。

# ----
# 関数  JIRADB_STATUS_EXPORT
# ----
function JIRADB_STATUS_EXPORT
{
	# 変数NDATE に現在の日付時分秒を挿入する
	NDATE=`date "+%Y%m%d%H%M%S"`

    # テーブルJIRA_ISSUEのカラムISSUESTATUSの値が"E01(案件終了)"以外のデータをixf形式にて出力する。
    db2 "export to ${CSV_OUT_DIR}/${JIRA_STATUS_EXPORT}_${NDATE}.ixf of ixf
	MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
	select ji.pkey,ji.issuestatus,is.pname
	from jiraschema.jiraissue ji,jiraschema.issuestatus is where ji.issuestatus = is.id
	and ji.issuestatus <> '${STATUS_COMPLETION}'" > ${SQLLOG_TMP} 2>&1

    # 変数SQLERROR にSQLの戻り値を格納する
    SQLERROR=$?

    # 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
    echo -e "日付:`date` || shell名:JIRADB_STATUS_EXPORT.sh || 行番号:`expr ${LINENO} - 4` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# 変数SQLERRORの値が"0"または"1"以外の場合、以下の処理を実施する
    if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func AC-E03006 "${_errmsg}" "${SQLERROR}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        return 1
    fi

	# 変数_export_cntにEXPORT件数を格納する
	_export_cnt=`tail -2 ${SQLLOG_TMP} | head -1 | grep -oE "[[:digit:]]{1,}"`

	# エクスポート処理、成功メッセージを出力する。
    outlog_func AC-I03005 '"'"${_export_cnt}"'"'

    return 0
}

###############################################################################
# main処理開始
###############################################################################
### 開始メッセージ
outlog_func AC-I03001

# 更新JIRADB接続
connectDB "${JIRA_DB_NAME}"
if [ $? != '0' ]
then
    outlog_func AC-E03003 "connectDB"
    exit 1
fi

# 関数JIRADB_STATUS_EXPORT開始
JIRADB_STATUS_EXPORT
if [ $? != '0' ]
then
    outlog_func AC-E03004 "JIRADB_STATUS_EXPORT"
    exit 1
fi

# 更新JIRADBへの接続を切断する
db2 terminate > /dev/null

## 終了メッセージ
outlog_func AC-I03002

## 戻り値0を返し終了
exit 0
