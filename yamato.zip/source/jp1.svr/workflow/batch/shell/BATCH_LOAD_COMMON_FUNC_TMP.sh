#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： BATCH_LOAD_COMMON_FUNC.sh
# 概要           ： LOAD機能（???_CSV_LOAD.sh）共通関数群
# 前提条件       ： BATCH_COMMON_FUNC.shが読み込まれていること
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： K.Tooi
#
# 作成日付       ： 2009-07-17
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-17 K.Tooi                 新規作成
# 2 1.0.0 2009-07-28 K.Tooi                 「PKEY」への設定値変更対応
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################


###############################################################################
# JIRAISSUE.ID MAX値取得用関数
#
# 関数名：　load_export_jiraissueid_max_jiraid
#
# 機能：　JIRADBのJIRAISSUEテーブルから項目「ID」のMAX値を取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_jiraissueid_max_jiraid
{
        # 変数初期化
        _jiraissueid_max_jiraid=""
        tmp_jiraissueidmax=""
        # JIRAISSUE.ID MAX値をエクスポート
        db2 "export to ${jiraissue_id_max_file} of del select max(id) from ${SCHEMA_NAME}jiraissue" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
            outlog_func CM-E05003 "${_errmsg}"

            # エラー終了
            return 1
        fi

        # JIRAISSUE.ID MAX値があるか判定
        tmp_jiraissueidmax=`cat ${jiraissue_id_max_file}`
        if [ ! -z "${tmp_jiraissueidmax}" ]
        then
        # JIRAISSUE.ID MAX値がある場合
                # 行頭の+を削除
                sed -i "s/+//g" ${jiraissue_id_max_file}
                # 先頭の0を削除
                sed -i "s/^0*//g" ${jiraissue_id_max_file}
                # .を削除
                sed -i "s/\.//g" ${jiraissue_id_max_file}
                # JIRAISSUE.ID MAX値格納
                _jiraissueid_max_jiraid=`cat ${jiraissue_id_max_file}`
                if [ -z "${_jiraissueid_max_jiraid}" ]
                then
                        outlog_func CM-E05004
                        return 1
                else
                        return 0
                fi
        else

                _jiraissueid_max_jiraid=""
                return 0
        fi
}

###############################################################################
# JIRAISSUE.PKEY MAX値取得用関数
#
# 関数名：　load_export_pkey_max_jiraid
#
# 機能：　JIRADBのJIRAISSUEテーブルから項目「PKEY」のMAX値を取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_pkey_max_jiraid
{
        # 変数初期化
        _pkey_max_jiraid=""
        tmp_pkey_max=""
        # JIRAISSUE.PKEY MAX値をエクスポート
        db2 "export to ${jiraissue_pkey_max_file} of del select max(int(substr(pkey,12,18))) from ${SCHEMA_NAME}jiraissue where pkey like '${gyomu_id2}-${_TODAY}%'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
            outlog_func CM-E05065 "${_errmsg}"

            # エラー終了
            return 1
        fi

        # JIRAISSUE.PKEY MAX値があるか判定
        tmp_pkey_max=`cat ${jiraissue_pkey_max_file}`
        if [ ! -z "${tmp_pkey_max}" ]
        then
        # JIRAISSUE.PKEY MAX値がある場合
                # "を削除
                sed -i "s/\"//g" ${jiraissue_pkey_max_file}
                # JIRAISSUE.PKEY MAX値格納
                _pkey_max_jiraid=`cat ${jiraissue_pkey_max_file}`

                if [ -z "${_pkey_max_jiraid}" ]
                then
                        outlog_func CM-E05066
                        return 1
                else
                        return 0
                fi
        else
                _pkey_max_jiraid=""
                return 0
        fi
}

###############################################################################
# JIRAISSUE.WORKFLOW_ID MAX値取得用関数
#
# 関数名：　load_export_workflowid_max_jiraid
#
# 機能：　JIRADBのJIRAISSUEテーブルから項目「WORKFLOW_ID」のMAX値を取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_workflowid_max_jiraid
{
        # 変数初期化
        _workflowid_max_jiraid=""
        tmp_workflowid_max=""
        # JIRAISSUE.WORKFLOW_ID MAX値をエクスポート
        db2 "export to ${jiraissue_workflowid_max_file} of del select max(workflow_id) from ${SCHEMA_NAME}jiraissue" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
        # JIRAISSUE.PKEY MAX値がある場合
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
            outlog_func CM-E05067 "${_errmsg}"

            # エラー終了
            return 1
        fi

        # WORKFLOW_IDのMAX値があるか判定
        tmp_workflowid_max=`cat ${jiraissue_workflowid_max_file}`
        if [ ! -z "${tmp_workflowid_max}" ]
        then
                # 行頭の+を削除
                sed -i "s/+//g" ${jiraissue_workflowid_max_file}
                # 先頭の0を削除
                sed -i "s/^0*//g" ${jiraissue_workflowid_max_file}
                # .を削除
                sed -i "s/\.//g" ${jiraissue_workflowid_max_file}
                # JIRAISSUE.WORKFLOW_ID MAX値格納
                _workflowid_max_jiraid=`cat ${jiraissue_workflowid_max_file}`

                if [ -z "${_workflowid_max_jiraid}" ]
                then
                        outlog_func CM-E05005
                        return 1
                else
                        return 0
                fi
        else
                _workflowid_max_jiraid=""
                return 0
        fi
}

###############################################################################
# OS_CURRENTSTEP.ID MAX値取得関数
#
# 関数名：　load_export_os_currentstepid_max_jiraid
#
# 機能：　JIRADBのOS_CURRENTSTEPテーブルから項目「ID」のMAX値を取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_os_currentstepid_max_jiraid
{
        # 変数初期化
        _os_currentstepid_max_jiraid=""
        tmp_os_currentstepid_max=""
        # OS_CURRENTSTEP.ID MAX値をエクスポート
        db2 "export to ${os_currentstep_id_max_file} of del select max(id) from ${SCHEMA_NAME}os_currentstep" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
            outlog_func CM-E05006 "${_errmsg}"

            # エラー終了
            return 1
        fi
        # OS_CURRENTSTEP.ID MAX値があるか判定
        tmp_os_currentstepid_max=`cat ${os_currentstep_id_max_file}`
        if [ ! -z "${tmp_os_currentstepid_max}" ]
        then
        # OS_CURRENTSTEP.ID MAX値がある場合
                # 行頭の+を削除
                sed -i "s/+//g" ${os_currentstep_id_max_file}
                # 先頭の0を削除
                sed -i "s/^0*//g" ${os_currentstep_id_max_file}
                # .を削除
                sed -i "s/\.//g" ${os_currentstep_id_max_file}
                # OS_CURRENTSTEP.ID MAX値格納
                _os_currentstepid_max_jiraid=`cat ${os_currentstep_id_max_file}`

                if [ -z ${_os_currentstepid_max_jiraid} ]
                then
                        outlog_func CM-E05007
                        return 1
                else
                        return 0
                fi
        else
                _os_currentstepid_max_jiraid=""
                return 0
        fi
}

###############################################################################
# CUSTOMFIELDVALUE.ID MAX値取得関数
#
# 関数名：　load_export_customfield_valueid_max_jiraid
#
# 機能：　CUSTOMFIELDVALUEテーブルから項目「ID」のMAX値を取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_customfield_valueid_max_jiraid
{
        # 変数初期化
        _customfield_valueid_max_jiraid=""
        tmp_customfield_valueid_max=""
        # CUSTOMFIELDVALUE.ID MAX値をエクスポート
        db2 "export to ${customfieldvalue_id_max_file} of del select max(ID) from ${SCHEMA_NAME}customfieldvalue" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
            outlog_func CM-E05008 "${_errmsg}"

            # エラー終了
            return 1
        fi

        # CUSTOMFIELDVALUE.ID MAX値があるか判定
        tmp_customfield_valueid_max=`cat ${customfieldvalue_id_max_file}`
        if [ ! -z ${tmp_customfield_valueid_max} ]
        then
        # CUSTOMFIELDVALUE.ID MAX値がある場合
                # 行頭の+を削除
                sed -i "s/+//g" ${customfieldvalue_id_max_file}
                # 先頭の0を削除
                sed -i "s/^0*//g" ${customfieldvalue_id_max_file}
                # .を削除
                sed -i "s/\.//g" ${customfieldvalue_id_max_file}
                # CUSTOMFIELDVALUE.ID MAX値格納
                _customfield_valueid_max_jiraid=`cat ${customfieldvalue_id_max_file}`

                if [ -z "${_customfield_valueid_max_jiraid}" ]
                then
                        outlog_func CM-E05009
                        return 1
                else
                        return 0
                fi
        else
               _customfield_valueid_max_jiraid="" 
                return 0
        fi
}

###############################################################################
# JIRAACTION.ID MAX値取得関数
#
# 関数名：　load_export_jiraaction_id_max_jiraid
#
# 機能：　JIRAACTIONテーブルから項目「ID」のMAX値を取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_jiraaction_id_max_jiraid
{
        # 変数初期化
        _jiraaction_id_max_jiraid=""
        tmp_jiraaction_id_max=""
        # JIRAACTION.ID MAX値をエクスポート
        db2 "export to ${jiraaction_id_max_file} of del select max(ID) from ${SCHEMA_NAME}jiraaction" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
            outlog_func CM-E05074 "${_errmsg}"

            # エラー終了
            return 1
        fi

        # JIRAACTION.ID MAX値があるか判定
        tmp_jiraaction_id_max=`cat ${jiraaction_id_max_file}`
        if [ ! -z ${tmp_jiraaction_id_max} ]
        then
        # JIRAACTION.ID MAX値がある場合
                # 行頭の+を削除
                sed -i "s/+//g" ${jiraaction_id_max_file}
                # 先頭の0を削除
                sed -i "s/^0*//g" ${jiraaction_id_max_file}
                # .を削除
                sed -i "s/\.//g" ${jiraaction_id_max_file}
                # JIRAACTION.ID MAX値格納
                _jiraaction_id_max_jiraid=`cat ${jiraaction_id_max_file}`

                if [ -z "${_jiraaction_id_max_jiraid}" ]
                then
                        outlog_func CM-E05075
                        return 1
                else
                        return 0
                fi
        else
                _jiraaction_id_max_jiraid="" 
                return 0
        fi
}

###############################################################################
# JIRADBのCOMPONENTテーブルID取得関数
#
# 関数名：　load_export_component_jiraid
#
# 機能：　JIRADBのCOMPONENTテーブルから対象業務の「ID」「CNAME」のリストファイルを作成する(主管コード用)
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_component_jiraid
{
	# COMPONENTテーブルから「ID」「CNAME」のリストをエクスポート
	db2 "export to ${component_id_file} of del select id,cname from ${SCHEMA_NAME}component where PROJECT = ${serviceID}" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CM-E05059 "${_errmsg}"

		# エラー終了
		return 1
	fi
	
	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${component_id_file} ]
	then
		outlog_func CM-E05060
		return 1
	fi
	
	# 行頭の+を削除
	sed -i "s/+//g" ${component_id_file}
	
	# .を削除
	sed -i "s/\.//g" ${component_id_file}
	
	# "を削除
	sed -i "s/\"//g" ${component_id_file}
	
	# ,をスペースに変換
	sed -i "s/,/ /g" ${component_id_file}
	
	# 先頭の0を削除
	sed -i "s/^0*//g" ${component_id_file}
	
	return 0
}

###############################################################################
# JIRADBのSCHEMEISSUESECURITYLEVELSテーブルID取得関数
#
# 関数名：　load_export_schemeissuesecuritylevels_jiraid
#
# 機能：　JIRADBのSCHEMEISSUESECURITYLEVELSテーブルから対象業務の「ID」「NAME」のリストファイルを作成する(店所コード用)
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_schemeissuesecuritylevels_jiraid
{
	# SCHEMEISSUESECURITYLEVELSテーブルから「ID」「NAME」のリストをエクスポート
	db2 "export to ${schemeissuesecuritylevels_id_file} of del select id,name from ${SCHEMA_NAME}schemeissuesecuritylevels" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CM-E05061 "${_errmsg}"

		# エラー終了
		return 1
	fi
	
	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${schemeissuesecuritylevels_id_file} ]
	then
		outlog_func CM-E05062
		return 1
	fi
	
	# 行頭の+を削除
	sed -i "s/+//g" ${schemeissuesecuritylevels_id_file}
	
	# .を削除
	sed -i "s/\.//g" ${schemeissuesecuritylevels_id_file}
	
	# "を削除
	sed -i "s/\"//g" ${schemeissuesecuritylevels_id_file}
	
	# ,をスペースに変換
	sed -i "s/,/ /g" ${schemeissuesecuritylevels_id_file}
	
	# 先頭の0を削除
	sed -i "s/^0*//g" ${schemeissuesecuritylevels_id_file}

	return 0
}

###############################################################################
# JIRADBのPROJECTVERSIONテーブルID取得関数
#
# 関数名：　load_export_projectversion_jiraid
#
# 機能：　JIRADBのPROJECTVERSIONテーブルから対象業務の「ID」「VNAME」のリストファイルを作成する(帳票ID用)
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_projectversion_jiraid
{
	# PROJECTVERSIONテーブルから「ID」「VNAME」のリストをエクスポート
    db2 "export to ${projectversion_id_file} of del select id,vname from ${SCHEMA_NAME}projectversion where project = ${serviceID}" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CM-E05063 "${_errmsg}"

		# エラー終了
		return 1
	fi

	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${projectversion_id_file} ]
	then
		outlog_func CM-E05064
		return 1
	fi

        # 行頭の+を削除
        sed -i "s/+//g" ${projectversion_id_file}

        # .を削除
        sed -i "s/\.//g" ${projectversion_id_file}

        # "を削除
        sed -i "s/\"//g" ${projectversion_id_file}

        # ,をスペースに変換
        sed -i "s/,/ /g" ${projectversion_id_file}

        # 先頭の0を削除
        sed -i "s/^0*//g" ${projectversion_id_file}

        return 0
}

###############################################################################
# SEQUENCE_VALUE_ITEM.SEQ_ID(JIRAIssueテーブル用)取得関数
#
# 関数名：　load_export_sequence_value_item_Issueid_jiraid
#
# 機能：　JIRADBのsequence_value_itemテーブルからIssueのSEQ_IDを取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_sequence_value_item_Issueid_jiraid
{
        # 変数初期化
        _sequence_value_item_Issueid_jiraid=""
        # SEQUENCE_VALUE_ITEM.SEQ_ID(Issue)をエクスポート
        db2 "export to ${sequence_value_item_seqid_Issue_file} of del select SEQ_ID from ${SCHEMA_NAME}sequence_value_item where SEQ_NAME = 'Issue'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                # DBエラー
                if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
                then
                        # エラーログ出力
                        _errmsg=`cat ${SQLLOG_TMP}`
                        outlog_func CM-E05014 "${_errmsg}"

                        # エラー終了
                        return 1
                fi
        # 行頭の+を削除
        sed -i "s/+//g" ${sequence_value_item_seqid_Issue_file}
        # 先頭の0を削除
        sed -i "s/^0*//g" ${sequence_value_item_seqid_Issue_file}
        # .を削除
        sed -i "s/\.//g" ${sequence_value_item_seqid_Issue_file}
        # SEQUENCE_VALUE_ITEM.SEQ_ID(Issue)値格納
        _sequence_value_item_Issueid_jiraid=`cat ${sequence_value_item_seqid_Issue_file}`
        if [ -z "${_sequence_value_item_Issueid_jiraid}" ]
        then
                outlog_func CM-E05015
                return 1
        else
                return 0
        fi
}

###############################################################################
# SEQUENCE_VALUE_ITEM.SEQ_ID(OSWorkflowEntryテーブル用)取得関数
#
# 関数名：　load_export_sequence_value_item_osworkflowentryid_jiraid
#
# 機能：　JIRADBのsequence_value_itemテーブルからOSWorkflowEntryのSEQ_IDを取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_sequence_value_item_osworkflowentryid_jiraid
{
        # 変数初期化
        _sequence_value_item_osworkflowentryid_jiraid=""
        # SEQUENCE_VALUE_ITEM.SEQ_ID(OSWorkflowEntry)をエクスポート
        db2 "export to ${sequence_value_item_seqid_OSWorkflowEntry_file} of del select SEQ_ID from ${SCHEMA_NAME}sequence_value_item where SEQ_NAME = 'OSWorkflowEntry'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                # DBエラー
                if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
                then
                        # エラーログ出力
                        _errmsg=`cat ${SQLLOG_TMP}`
                        outlog_func CM-E05012 "${_errmsg}"

                        # エラー終了
                        return 1
                fi
        # 行頭の+を削除
        sed -i "s/+//g" ${sequence_value_item_seqid_OSWorkflowEntry_file}
        # 先頭の0を削除
        sed -i "s/^0*//g" ${sequence_value_item_seqid_OSWorkflowEntry_file}
        # .を削除
        sed -i "s/\.//g" ${sequence_value_item_seqid_OSWorkflowEntry_file}
        # SEQUENCE_VALUE_ITEM.SEQ_ID(OSWorkflowEntry)値格納
        _sequence_value_item_osworkflowentryid_jiraid=`cat ${sequence_value_item_seqid_OSWorkflowEntry_file}`
        if [ -z "${_sequence_value_item_osworkflowentryid_jiraid}" ]
        then
                outlog_func CM-E05013
                return 1
        else
                return 0
        fi
}

###############################################################################
# SEQUENCE_VALUE_ITEM.SEQ_ID(OSCurrentStepテーブル用)取得関数
#
# 関数名：　load_export_sequence_value_item_oscurrentstepid_jiraid
#
# 機能：　JIRADBのsequence_value_itemテーブルからOSCurrentStepのSEQ_IDを取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_sequence_value_item_oscurrentstepid_jiraid
{
        # 変数初期化
        _sequence_value_item_oscurrentstepid_jiraid=""
        # SEQUENCE_VALUE_ITEM.ID(OSCurrentStep)をエクスポート
        db2 "export to ${sequence_value_item_seqid_OSCurrentStep_file} of del select SEQ_ID from ${SCHEMA_NAME}sequence_value_item where SEQ_NAME = 'OSCurrentStep'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                # DBエラー
                if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
                then
                        # エラーログ出力
                        _errmsg=`cat ${SQLLOG_TMP}`
                        outlog_func CM-E05010 "${_errmsg}"

                        # エラー終了
                        return 1
                fi
        # 行頭の+を削除
        sed -i "s/+//g" ${sequence_value_item_seqid_OSCurrentStep_file}
        # 先頭の0を削除
        sed -i "s/^0*//g" ${sequence_value_item_seqid_OSCurrentStep_file}
        # .を削除
        sed -i "s/\.//g" ${sequence_value_item_seqid_OSCurrentStep_file}
        # SEQUENCE_VALUE_ITEM.SEQ_ID(OSCurrentStep)値格納
        _sequence_value_item_oscurrentstepid_jiraid=`cat ${sequence_value_item_seqid_OSCurrentStep_file}`
        if [ -z "${_sequence_value_item_oscurrentstepid_jiraid}" ]
        then
                outlog_func CM-E05011
                return 1
        else
                return 0
        fi
}

###############################################################################
# SEQUENCE_VALUE_ITEM.SEQ_ID(CustomFieldValueテーブル用)取得関数
#
# 関数名：　load_export_sequence_value_item_customfieldvalueid_jiraid
#
# 機能：　JIRADBのsequence_value_itemテーブルからCustomFieldValueのSEQ_IDを取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_sequence_value_item_customfieldvalueid_jiraid
{
        # 変数初期化
        _sequence_value_item_customfieldvalueid_jiraid=""
        # SEQUENCE_VALUE_ITEM.SEQ_ID(CustomFieldValue)をエクスポート
        db2 "export to ${sequence_value_item_seqid_CustomFieldValue_file} of del select SEQ_ID from ${SCHEMA_NAME}sequence_value_item where SEQ_NAME = 'CustomFieldValue'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                # DBエラー
                if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
                then
                        # エラーログ出力
                        _errmsg=`cat ${SQLLOG_TMP}`
                        outlog_func CM-E05016 "${_errmsg}"

                        # エラー終了
                        return 1
                fi
        # 行頭の+を削除
        sed -i "s/+//g" ${sequence_value_item_seqid_CustomFieldValue_file}
        # 先頭の0を削除
        sed -i "s/^0*//g" ${sequence_value_item_seqid_CustomFieldValue_file}
        # .を削除
        sed -i "s/\.//g" ${sequence_value_item_seqid_CustomFieldValue_file}
        # SEQUENCE_VALUE_ITEM.SEQ_ID(CustomFieldValue)値格納
        _sequence_value_item_customfieldvalueid_jiraid=`cat ${sequence_value_item_seqid_CustomFieldValue_file}`
        if [ -z "${_sequence_value_item_customfieldvalueid_jiraid}" ]
        then
                outlog_func CM-E05017
                return 1
        else
                return 0
        fi
}

###############################################################################
# SEQUENCE_VALUE_ITEM.SEQ_ID(JIRAActionテーブル用)取得関数
#
# 関数名：　load_export_sequence_value_item_actionid_jiraid
#
# 機能：　JIRADBのsequence_value_itemテーブルからActionのSEQ_IDを取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_sequence_value_item_actionid_jiraid
{
        # 変数初期化
        _sequence_value_item_actionid_jiraid=""
        # SEQUENCE_VALUE_ITEM.ID(Action)をエクスポート
        db2 "export to ${sequence_value_item_seqid_Action_file} of del select SEQ_ID from ${SCHEMA_NAME}sequence_value_item where SEQ_NAME = 'Action'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                # DBエラー
                if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
                then
                        # エラーログ出力
                        _errmsg=`cat ${SQLLOG_TMP}`
                        outlog_func CM-E05072 "${_errmsg}"

                        # エラー終了
                        return 1
                fi
        # 行頭の+を削除
        sed -i "s/+//g" ${sequence_value_item_seqid_Action_file}
        # 先頭の0を削除
        sed -i "s/^0*//g" ${sequence_value_item_seqid_Action_file}
        # .を削除
        sed -i "s/\.//g" ${sequence_value_item_seqid_Action_file}
        # SEQUENCE_VALUE_ITEM.SEQ_ID(Action)値格納
        _sequence_value_item_actionid_jiraid=`cat ${sequence_value_item_seqid_Action_file}`
        if [ -z "${_sequence_value_item_actionid_jiraid}" ]
        then
                outlog_func CM-E05073
                return 1
        else
                return 0
        fi
}

###############################################################################
# PROJECT.PCOUNTER取得関数
#
# 関数名：　load_export_project_pcounter_jiraid
#
# 機能：　JIRADBのPROJECTテーブルから対象業務のPCOUNTERの値を取得する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function load_export_project_pcounter_jiraid
{
        # 変数初期化
        _project_pcounter=""
        # PROJECT.PCOUNTERをエクスポート
        db2 "export to ${project_pcounter_file} of del select PCOUNTER from ${SCHEMA_NAME}project where ID = ${serviceID}" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
            outlog_func CM-E05018 "${_errmsg}"

            # エラー終了
            return 1
        fi
        # 行頭の+を削除
        sed -i "s/+//g" ${project_pcounter_file}
        # 先頭の0を削除
        sed -i "s/^0*//g" ${project_pcounter_file}
        # .を削除
        sed -i "s/\.//g" ${project_pcounter_file}
        # PROJECT.PCOUNTER値格納
        _project_pcounter=`cat ${project_pcounter_file}`

        if [ -z "${_project_pcounter}" ]
        then
                outlog_func CM-E05019
                return 1
        else
                return 0
        fi
}

###############################################################################
# JIRADB側通番初期値確認関数
#
# 関数名：　default_check
#
# 機能：　JIRADBの各項目の通番初期値を確認し、空の場合に補完を行う
#
# 引数：　なし
#
# 戻り値：　0:正常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#
###############################################################################
function default_check
{

        if [ -z "${_pkey_max_jiraid}" ]
        then
                _pkey_max_jiraid=0
        fi

        if [ -z "${_jiraissueid_max_jiraid}" ]
        then
                _jiraissueid_max_jiraid=${_sequence_value_item_Issueid_jiraid}
        fi

        if [ -z "${_workflowid_max_jiraid}" ]
        then
                _workflowid_max_jiraid=${_sequence_value_item_osworkflowentryid_jiraid}
        fi

                _os_currentstepid_max_jiraid=${_sequence_value_item_oscurrentstepid_jiraid}

        if [ -z "${_customfield_valueid_max_jiraid}" ]
        then
                _customfield_valueid_max_jiraid=${_sequence_value_item_customfieldvalueid_jiraid}
        fi

        if [ -z "${_jiraaction_id_max_jiraid}" ]
        then
                _jiraaction_id_max_jiraid=${_sequence_value_item_actionid_jiraid}
        fi
        return 0
}

###############################################################################
# GWサーバ側DBのCSV抽出関数
#
# 関数名：　csv_export
#
# 機能：　GWDBから各業務のCSVデータファイルをEXPORTし、文字コードの変換を行う
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             GWDBに接続していること
#
###############################################################################
function csv_export
{
        # 各テーブル用に準備したDDLを実行
        db2 -tvf "${SQL}" > ${SQLLOG_TMP};
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
            outlog_func CM-E05020 "${_errmsg}"
            return 1
        fi

        # SQLの結果を格納したテンポラリファイルが存在しない場合、エラー終了
        if [ ! -e ${ichijifile1} ]
        then
            outlog_func CM-E05021
            return 1
        fi

        # 文字コード変換
        #nkf --ic=CP932 --oc=UTF-8 ${ichijifile1} > ${ichijifile2}
        cat ${ichijifile1} > ${ichijifile2}
        if [ $? != 0 ]
        then
            outlog_func CM-E05022
            return 1
        fi

    return 0
}

###############################################################################
# CSV整形関数
#
# 関数名：　csv_format
#
# 機能：　GWDBから取得した各業務のCSVデータファイルを整形し、レコード件数を設定する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#
###############################################################################
function csv_format
{
        # csvファイルを整形
        sed -e s/\"/""/g ${ichijifile2} > ${ichijifile3}

        # 整形した結果を格納したtmpファイルが存在しない場合、エラー終了
        if [ ! -e ${ichijifile3} ]
        then
                outlog_func CM-E05068
                return 1
        fi
        # データ行数を計測
        GW_CVS_wcl=`wc -l ${ichijifile3} | awk '{print $1}'`
        if [ ${GW_CVS_wcl} == 0 ]
        then
                outlog_func CM-I05023
                return 0
        fi

        return 0
}

##### No Use Delete 2010/02/25 >>>
###############################################################################
# JIRADBバックアップ
#
# 関数名：　jiradb_backup
#
# 機能：　JIRADBのバックアップを行う
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
#####function jiradb_backup
#####{
##### GW側のデータが０件の場合はバックアップを実施しない
#####if [ ${GW_CVS_wcl} == 0 ]
#####then
#####        outlog_func CM-I05053
#####        return 0
#####else
#####        # DB2 force application ALLコマンド実行
#####        db2 force application ALL > /dev/null
#####
#####        # DBバックアップコマンド実行
#####        db2 "backup db ${JIRA_DB_NAME} to ${TMP_DIR}" > ${backupJIRADB_LOG}
#####        SQLERROR=$?
#####echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${backupJIRADB_LOG}`" >>${DETAIL_LOG}
#####        if [ ${SQLERROR} != 0 -o ! -e ${backupJIRADB_LOG} ]
#####        then
#####                outlog_func CM-E05054
#####                return 1
#####        fi
#####        while read backup_org
#####        do
#####        if [ -n "${backup_org}" ]
#####        then
#####                jira_backup_date=`echo ${backup_org} | cut -f11 -d " "`
#####        fi
#####        done < ${backupJIRADB_LOG}
#####        return 0
#####fi
#####}
#####
# 2009/07/31 GWDBバックアップ・リストア処理削除 start
###############################################################################
# GWDBバックアップ
#
# 関数名：　gwdb_backup
#
# 機能：　GWDBのバックアップを行う
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             GWDBに接続していること
#
###############################################################################
######function gwdb_backup
######{
####### GW側のデータが０件の場合はバックアップを実施しない
######if [ ${GW_CVS_wcl} == 0 ]
######then
######        outlog_func CM-I05055
######        return 0
######else
######        # DBバックアップコマンド実行
######        db2 "backup db ${DB_NAME} to ${TMP_DIR}" > ${backupGWDB_LOG}
######        if [ $? != 0 -o ! -e ${backupGWDB_LOG} ]
######        then
######                outlog_func CM-E05056
######                return 1
######        fi
######        while read backup_org
######        do
######        if [ -n "${backup_org}" ]
######        then
######                gw_backup_date=`echo ${backup_org} | cut -f11 -d " "`
######        fi
######        done < ${backupGWDB_LOG}
######        return 0
######fi
######}
###### 2009/07/31 GWDBバックアップ・リストア処理削除 end
##### No Use Delete 2010/02/25 <<<



###############################################################################
# LOADING_CSV関数
#
# 関数名：　loading_csv
#
# 機能：　JIRADBの下記テーブルへCSVファイルのLOADを行う
#         ・JIRAISSUE
#         ・OS_WFENTRY
#         ・OS_CURRENTSTEP
#         ・NODEASSOCIATION
#         ・CUSTOMFIELDVALUE
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function loading_csv
{
#メッセージファイル出力先フォルダのチェック
MES_FOLDER=${HOME}/mes/
if [[ ! -d ${MES_FOLDER} ]]
then
    outlog_func CM-E05035 "Message Folder Not Found"
    return 1
fi


# GW側のデータが０件の場合はロードを実施しない
if [ ${GW_CVS_wcl} == 0 ]
then
        outlog_func CM-I05034
        return 0
else
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	IMPORT_RETRY_CNT=3
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do

        # ログ＆メッセージファイル出力先設定
        SQL_COMMAND_LOG=${LOG_DIR}/`basename ${0}`01_`date +%Y%m%d%H%M%S`_SQLCOMMAND.log
        MES_FILE=${HOME}/mes/`basename ${0}`01_`date +%Y%m%d%H%M%S`_MESSAGE.mes

        # JIRAISSUE追加CSVのロード
        SQL_COMMAND='db2 "IMPORT FROM '${jiraissue_file}' OF DEL commitcount 1000 MESSAGES '${MES_FILE}' INSERT INTO '${SCHEMA_NAME}'jiraissue" > '${SQLLOG_TMP}' 2>&1'
        echo ${SQL_COMMAND} > ${SQL_COMMAND_LOG}
        eval ${SQL_COMMAND}

		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

        if [[ ! -f ${MES_FILE} ]]
        then
            outlog_func CM-E05035 "Message file Not Found"
            return 1
        fi


		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > ${SQLLOG_TMP} 2>&1
			echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"

			connectDB "${JIRA_DB_NAME}"

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

        if [ ${SQLERROR} != 0 ]
        then
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
            outlog_func CM-E05035 "${_errmsg}"
            echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

            return 1
        fi

        # LOAD完了メッセージ出力
        _load_cnt=`tail -2 ${SQLLOG_TMP} | head -1 | awk -F"=" '{print $2}'`
        outlog_func CM-I05072 "${_load_cnt}"

	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	IMPORT_RETRY_CNT=3
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
        # ログ＆メッセージファイル出力先設定
        SQL_COMMAND_LOG=${LOG_DIR}/`basename ${0}`02_`date +%Y%m%d%H%M%S`_SQLCOMMAND.log
        MES_FILE=${HOME}/mes/`basename ${0}`02_`date +%Y%m%d%H%M%S`_MESSAGE.mes

        # OS_WFENTRY追加CSVのロード
        SQL_COMMAND='db2 "IMPORT FROM '${os_wfentry_file}' OF DEL commitcount 1000 MESSAGES '${MES_FILE}' INSERT INTO '${SCHEMA_NAME}'OS_WFENTRY" > '${SQLLOG_TMP}' 2>&1'
        echo ${SQL_COMMAND} > ${SQL_COMMAND_LOG}
        eval ${SQL_COMMAND}

        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

        if [[ ! -f ${MES_FILE} ]]
        then
            outlog_func CM-E05036 "Message file Not Found"
            return 1
        fi

		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > ${SQLLOG_TMP} 2>&1
			echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"

			connectDB "${JIRA_DB_NAME}"

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

    if [ ${SQLERROR} != 0 ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func CM-E05036 "${_errmsg}"
        echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

        return 1
    fi


	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	IMPORT_RETRY_CNT=3
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
        # ログ＆メッセージファイル出力先設定
        SQL_COMMAND_LOG=${LOG_DIR}/`basename ${0}`03_`date +%Y%m%d%H%M%S`_SQLCOMMAND.log
        MES_FILE=${HOME}/mes/`basename ${0}`03_`date +%Y%m%d%H%M%S`_MESSAGE.mes

        # OS_CURRENTSTEP追加CSVのロード
        SQL_COMMAND='db2 "IMPORT FROM '${os_currentstep_file}' OF DEL commitcount 1000 MESSAGES '${MES_FILE}' INSERT INTO '${SCHEMA_NAME}'OS_CURRENTSTEP" > '${SQLLOG_TMP}' 2>&1'
        echo ${SQL_COMMAND} > ${SQL_COMMAND_LOG}
        eval ${SQL_COMMAND}

        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

        if [[ ! -f ${MES_FILE} ]]
        then
            outlog_func CM-E05037 "Message file Not Found"
            return 1
        fi

		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > ${SQLLOG_TMP} 2>&1
			echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"

			connectDB "${JIRA_DB_NAME}"

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

    if [ ${SQLERROR} != 0 ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func CM-E05037 "${_errmsg}"
        echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        return 1
    fi


	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	IMPORT_RETRY_CNT=3
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
        # ログ＆メッセージファイル出力先設定
        SQL_COMMAND_LOG=${LOG_DIR}/`basename ${0}`04_`date +%Y%m%d%H%M%S`_SQLCOMMAND.log
        MES_FILE=${HOME}/mes/`basename ${0}`04_`date +%Y%m%d%H%M%S`_MESSAGE.mes

        # NODEASSOCIATION追加CSVのロード
        SQL_COMMAND='db2 "IMPORT FROM '${nodeassociation_file}' OF DEL commitcount 1000 MESSAGES '${MES_FILE}' INSERT INTO '${SCHEMA_NAME}'nodeassociation" > '${SQLLOG_TMP}' 2>&1'
        echo ${SQL_COMMAND} > ${SQL_COMMAND_LOG}
        eval ${SQL_COMMAND}
        
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

        if [[ ! -f ${MES_FILE} ]]
        then
            outlog_func CM-E05038 "Message file Not Found"
            return 1
        fi

		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > ${SQLLOG_TMP} 2>&1
			echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"

			connectDB "${JIRA_DB_NAME}"

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

    if [ ${SQLERROR} != 0 ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func CM-E05038 "${_errmsg}"
        echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        return 1
    fi

	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	IMPORT_RETRY_CNT=3
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
        # ログ＆メッセージファイル出力先設定
        SQL_COMMAND_LOG=${LOG_DIR}/`basename ${0}`05_`date +%Y%m%d%H%M%S`_SQLCOMMAND.log
        MES_FILE=${HOME}/mes/`basename ${0}`05_`date +%Y%m%d%H%M%S`_MESSAGE.mes

        # CUSTOMFIELD追加CSVのロード
        SQL_COMMAND='db2 "IMPORT FROM '${customfield_file}' OF DEL commitcount 1000 MESSAGES '${MES_FILE}' INSERT INTO '${SCHEMA_NAME}'customfieldvalue" > '${SQLLOG_TMP}' 2>&1'
        echo ${SQL_COMMAND} > ${SQL_COMMAND_LOG}
        eval ${SQL_COMMAND}
        
        
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

        if [[ ! -f ${MES_FILE} ]]
        then
            outlog_func CM-E05039 "Message file Not Found"
            return 1
        fi

		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > ${SQLLOG_TMP} 2>&1
			echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"

			connectDB "${JIRA_DB_NAME}"

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

    if [ ${SQLERROR} != 0 ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func CM-E05039 "${_errmsg}"
        echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        return 1
    fi

    return 0
fi
}

###############################################################################
# LOADING_CSV_2関数
#
# 関数名：　loading_csv_2
#
# 機能：　JIRADBの下記テーブルへCSVファイルのLOADを行う
#         ・JIRAACTION
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function loading_csv_2
{

# GW側のデータが０件の場合はロードを実施しない
if [ ${GW_CVS_wcl} == 0 ]
then
        outlog_func CM-I05076
        return 0
else
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	IMPORT_RETRY_CNT=3
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
        # ログ＆メッセージファイル出力先設定
        SQL_COMMAND_LOG=${LOG_DIR}/`basename ${0}`06_`date +%Y%m%d%H%M%S`_SQLCOMMAND.log
        MES_FILE=${HOME}/mes/`basename ${0}`06_`date +%Y%m%d%H%M%S`_MESSAGE.mes

        # JIRAACTION追加CSVのロード
        SQL_COMMAND='db2 "IMPORT FROM '${jiraaction_file}' OF DEL commitcount 1000 MESSAGES '${MES_FILE}' INSERT INTO '${SCHEMA_NAME}'jiraaction" > '${SQLLOG_TMP}' 2>&1'
        echo ${SQL_COMMAND} > ${SQL_COMMAND_LOG}
        eval ${SQL_COMMAND}
        
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

        if [[ ! -f ${MES_FILE} ]]
        then
            outlog_func CM-E05077 "Message file Not Found"
            return 1
        fi

		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > ${SQLLOG_TMP} 2>&1
			echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${JIRA_DB_NAME}"

			connectDB "${JIRA_DB_NAME}"

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

    if [ ${SQLERROR} != 0 ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func CM-E05077 "${_errmsg}"
        echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        return 1
    fi

    return 0

fi
}


##############################################################################
# JIRADB更新
#
# 関数名：　jira_update
#
# 機能：　JIRADBの下記テーブルの更新を行う
#         ・SEQUENCE_VALUE_ITEMテーブルのSEQ_ID(ISSUE用/OS_WFENTRY用/OS_CURRENTSTEP用/CUSTOMFIELDVALUE用)
#         ・PROJECTテーブルのPCOUNTER
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function jira_update
{
# GW側のデータが０件の場合はアップデートを実施しない
if [ ${GW_CVS_wcl} == 0 ]
then
        outlog_func CM-I05040
        return 0
else
        # ISSUEのSEQ_ID格納
        let _jiraissueid_max_jiraid=${_jiraissueid_max_jiraid}+0
                # ISSUEのSEQ_IDが格納されているか判定
                if [ $? != 0 ]
                then
                    # エラーログ出力
                    outlog_func CM-E05043
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        # OS_WFENTRYのSEQ_ID格納
        let _workflowid_max_jiraid=${_workflowid_max_jiraid}+0
                # OS_WFENTRYのSEQ_IDが格納されているか判定
                if [ $? != 0 ]
                then
                    # エラーログ出力
                    outlog_func CM-E05042
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        # OS_CURRENTSTEPのSEQ_ID格納
        let _os_currentstepid_max_jiraid=${_os_currentstepid_max_jiraid}+0
                # OS_CURRENTSTEPのSEQ_IDが格納されているか判定
                if [ $? != 0 ]
                then
                    # エラーログ出力
                    outlog_func CM-E05041
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        # CUSTOMFIELDVALUEのSEQ_ID格納
        let _customfield_valueid_max_jiraid=${_customfield_valueid_max_jiraid}+0
                # CUSTOMFIELDVALUEのSEQ_IDが格納されているか判定
                if [ $? != 0 ]
                then
                    # エラーログ出力
                    outlog_func CM-E05044
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        # PCOUNTER格納
        let _project_pcounter=${_project_pcounter}+${GW_CVS_wcl}
                # PCOUNTERが格納されているか判定
                if [ $? != 0 ]
                then
                    # エラーログ出力
                    outlog_func CM-E05045
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi

        # SEQUENCE_VALUE_ITEMテーブル(ISSUEのSEQ_ID)アップデート
        db2 "update ${SCHEMA_NAME}SEQUENCE_VALUE_ITEM set SEQ_ID = (${_jiraissueid_max_jiraid} / 10 + 1) *10 where SEQ_NAME = 'Issue'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                if [ ${SQLERROR} != 0 ]
                then
                    # エラーログ出力
                    _errmsg=`cat ${SQLLOG_TMP}`
                    outlog_func CM-E05048 "${_errmsg}"
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        # SEQUENCE_VALUE_ITEMテーブル(OS_WFENTRYのSEQ_ID)アップデート
        db2 "update ${SCHEMA_NAME}SEQUENCE_VALUE_ITEM set SEQ_ID = (${_workflowid_max_jiraid} / 10 + 1) *10 where SEQ_NAME = 'OSWorkflowEntry'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                if [ ${SQLERROR} != 0 ]
                then
                    # エラーログ出力
                    _errmsg=`cat ${SQLLOG_TMP}`
                    outlog_func CM-E05047 "${_errmsg}"
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        # SEQUENCE_VALUE_ITEMテーブル(OS_CURRENTSTEPのSEQ_ID)アップデート
        db2 "update ${SCHEMA_NAME}SEQUENCE_VALUE_ITEM set SEQ_ID = (${_os_currentstepid_max_jiraid} / 10 + 1) *10 where SEQ_NAME = 'OSCurrentStep'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                if [ ${SQLERROR} != 0 ]
                then
                    # エラーログ出力
                    _errmsg=`cat ${SQLLOG_TMP}`
                    outlog_func CM-E05046 "${_errmsg}"
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        # SEQUENCE_VALUE_ITEMテーブル(CUSTOMFIELDVALUEのSEQ_ID)アップデート
        db2 "update ${SCHEMA_NAME}SEQUENCE_VALUE_ITEM set SEQ_ID = (${_customfield_valueid_max_jiraid} / 10 + 1) *10 where SEQ_NAME = 'CustomFieldValue'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                if [ ${SQLERROR} != 0 ]
                then
                    # エラーログ出力
                    _errmsg=`cat ${SQLLOG_TMP}`
                    outlog_func CM-E05049 "${_errmsg}"
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        # PROJECTテーブル(PCOUNTER)アップデート
        db2 "update ${SCHEMA_NAME}PROJECT set PCOUNTER = ${_project_pcounter} where ID = ${serviceID}" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                if [ ${SQLERROR} != 0 ]
                then
                    # エラーログ出力
                    _errmsg=`cat ${SQLLOG_TMP}`
                    outlog_func CM-E05050 "${_errmsg}"
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        return 0
fi
}

###############################################################################
# JIRADB更新２（JIRAACTION用）
#
# 関数名：　jira_update_2
#
# 機能：　JIRADBの下記テーブルの更新を行う
#         ・SEQUENCE_VALUE_ITEMテーブルのSEQ_ID(Action用)
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             JIRADBに接続していること
#
###############################################################################
function jira_update_2
{
# GW側のデータが０件の場合はアップデートを実施しない
if [ ${GW_CVS_wcl} == 0 ]
then
        outlog_func CM-I05081
        return 0
else
        # JIRAACTIONのSEQ_ID格納
        let _jiraaction_id_max_jiraid=${_jiraaction_id_max_jiraid}+10
                # OS_CURRENTSTEPのSEQ_IDが格納されているか判定
                if [ $? != 0 ]
                then
                    # エラーログ出力
                    outlog_func CM-E05079
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi

        # SEQUENCE_VALUE_ITEMテーブル(JIRAACTIONのSEQ_ID)アップデート
        db2 "update ${SCHEMA_NAME}SEQUENCE_VALUE_ITEM set SEQ_ID = ${_jiraaction_id_max_jiraid} where SEQ_NAME = 'Action'" > ${SQLLOG_TMP}
        SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                if [ ${SQLERROR} != 0 ]
                then
                    # エラーログ出力
                    _errmsg=`cat ${SQLLOG_TMP}`
                    outlog_func CM-E05080 "${_errmsg}"
					echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                    return 1
                fi
        return 0
fi
}

###############################################################################
# GWDB更新
#
# 関数名：　GWDB_update
#
# 機能：　GWDBの下記テーブルの更新を行う
#         ・各業務テーブルのpkey_cd/JIRAhaneizumi
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#             GWDBに接続していること
#
###############################################################################
function GWDB_update
{
# GW側のデータが０件の場合はアップデートを実施しない
if [ ${GW_CVS_wcl} == 0 ]
then
        outlog_func CM-I05051
        return 0
else
        while read tsuuban pkey_cd JIRAhaneizumi
        do
                db2 "update ${table_name} set pkey_cd = '${pkey_cd}',JIRAhaneizumi = '${JIRAhaneizumi}' where tsuuban = '${tsuuban}'" > ${SQLLOG_TMP}
                SQLERROR=$?
				echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                if [ ${SQLERROR} != 0 ]
                then
                    # エラーログ出力
                    _errmsg=`cat ${SQLLOG_TMP}`
                    outlog_func CM-E05052 "${_errmsg}"
                    return 1
                fi
        done < ${update_pkey_cd_file}
        return 0
fi
}

###############################################################################
# tmp/csv/DBbackupファイル削除
#
# 関数名：　tmp_csv_delete
#
# 機能：　LOAD機能で作成される一時ファイルの削除を行う
#
# 引数：　なし
#
# 戻り値：　0:正常
#
# 前提条件：　なし
#
###############################################################################
function tmp_csv_delete
{
rm -f ${jiraissue_file}
rm -f ${os_wfentry_file}
rm -f ${os_currentstep_file}
rm -f ${nodeassociation_file}
rm -f ${customfield_file}
rm -f ${jiraaction_file}
rm -f ${update_pkey_cd_file}
rm -f ${ichijifile1}
rm -f ${ichijifile2}
rm -f ${ichijifile3}
rm -f ${jiraissue_id_max_file}
rm -f ${jiraissue_pkey_max_file}
rm -f ${jiraissue_workflowid_max_file}
rm -f ${os_currentstep_id_max_file}
rm -f ${jiraaction_id_max_file}
rm -f ${customfieldvalue_id_max_file}
rm -f ${sequence_value_item_seqid_Issue_file}
rm -f ${sequence_value_item_seqid_OSWorkflowEntry_file}
rm -f ${sequence_value_item_seqid_OSCurrentStep_file}
rm -f ${sequence_value_item_seqid_CustomFieldValue_file}
rm -f ${sequence_value_item_seqid_Action_file}
rm -f ${component_id_file}
rm -f ${schemeissuesecuritylevels_id_file}
rm -f ${projectversion_id_file}
rm -f ${backupJIRADB_LOG}
rm -f ${backupGWDB_LOG}
rm -f ${DB_BACKUP_FILE}
rm -f ${project_pcounter_file}
rm -f ${SQLLOG_TMP}
return 0
}
