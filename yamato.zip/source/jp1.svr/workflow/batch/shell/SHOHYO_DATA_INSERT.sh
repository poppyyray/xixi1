#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： SHOHYO_DATA_INSERT.sh
# 業 務 名       ： 証憑データ登録
# 処理概要       ： 証憑データをGWに登録
# 特記事項       ： 起動トリガー：JP1により起動
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-07-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-16 T.Sakagami             新規作成
# 2 1.1.0 2009-09-14 Y.Otsuka               処理改訂
# 3 1.2.0 2009-12-21 M.Saiki                importリトライ追加
# 4 1.2.1 2010-01-09 Y.Nagahashi            importエラー出力対応
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#共通関数呼び出し
_exec_ksh=/workflow/batch/ini/batch_common.conf

if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ログファイル設定
createlogfile ${0}
log_main_name=`basename ${0} | sed "s/.sh//g"`

#########################################################################

# ---- 
# 業務別環境変数設定
# ----

export _FILE_Shohyo_BAK=`ls /workflow/batch/scan_bak | grep -v "OK" | head -n 1`

# DB登録用シェル名
_shname="SHOHYO_DATA_INSERT.sh"

# 一時ファイル
_tmp="${TMP_DIR}/SHOHYO_DATA_INSERT_`date +%Y%m%d%H%M`.tmp"

##########################################################################
# 証憑データCSV作成関数 
##########################################################################
function shohyo_data {

    # Perlに渡すためにexportする。
    export CSV_OUT_DIR
    export FILE_Shohyo
    export HANBAIHYO_ID
    export RYOSHUUSHO_ID
    export SHIJISHO_ID_1
    export SHIJISHO_ID_2
    export SHIJISHO_ID_3
    export _shname

    # 証憑データの主キーがdateコマンドを使用しているため重複したいよう1秒待つ
    sleep 1

    /workflow/batch/perl/SHOHYO_DATA_INSERT.pl ${1}

    return 0

}

##########################################################################
# MAIN関数01
##########################################################################
function MAIN_01 {

	# SCANBKに移動したファイルの中から、更新日時が一番古いかつOKが無いものを取得
	#（正常終了しなかったスキャンファイル）
	if [ -z "${_FILE_Shohyo_BAK}" ]
	then
		# 証憑データファイルが存在しない
		outlog_func SH-I02003 ${FILE_Shohyo}
		# 処理対象ファイルが存在しないので終了
		return 0
	# バックアップファイルの末尾がOKではない場合
	else
		# ディレクトリパスを付与
		_FILE_Shohyo_BAK="${SCANFILE_BACKUP_DIR}/${_FILE_Shohyo_BAK}"

		# 証憑データファイルCSV作成関数呼び出し
		shohyo_data "${_FILE_Shohyo_BAK}"
		STATUS=$?
		# エラー判定
		if [ ${STATUS} != "0" ]
		then
			outlog_func SH-E02004
			# CSV削除
			rm -f ${CSV_OUT_DIR}/${FILE_Shohyo}.csv

			# SCANデータの退避
			SCAN_FILE=`echo ${_FILE_Shohyo_BAK} | cut -f5 -d'/'`
			cp -f ${SCANFILE_BACKUP_DIR}/${SCAN_FILE} ${ERROR_DIR}/${SCAN_FILE}
			outlog_func SH-E02011 "${SCAN_FILE}"

    		return 1
		fi
	fi
	return 0
}

##########################################################################
# MAIN関数02
##########################################################################
function MAIN_02 {


	# 証憑データCSVファイルが存在すればDBにインサートを行う
	if [ -f ${CSV_OUT_DIR}/${FILE_Shohyo}.csv ]
	then
		#インポートコマンドの戻り値が８の場合、３回処理を行う。
		for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
		do

			#ログ＆メッセージファイル出力先設定
			SQL_COMMAND_LOG=${LOG_DIR}/`basename ${0}`_`date +%Y%m%d%H%M%S`_SQLCOMMAND.log
			MES_FILE=${HOME}/mes/`basename ${0}`_`date +%Y%m%d%H%M%S`_MESSAGE.mes
		
			# 証憑データCSVインポート
			SQL_COMMAND='db2 "import from '${CSV_OUT_DIR}/${FILE_Shohyo}.csv' of del commitcount 1000 messages '${MES_FILE}' INSERT into '${TABLE_Shohyo}'" > '${SQLLOG_TMP}' 2>&1'
			echo ${SQL_COMMAND} > ${SQL_COMMAND_LOG}
			eval ${SQL_COMMAND}
			
			
			SQLERROR=$?
			echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		
			# DBエラー（ループに戻す） エラーコード８のみ
			if [ ${SQLERROR} -eq 8 ]
			then
				# 接続断
				db2 terminate > ${SQLLOG_TMP} 2>&1
				echo -e "日付:`date` || shell名:BATCH_LOAD_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

				
				# 5秒間待ち、再接続、importコマンド実行
				sleep 5
				outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
				outlog_func IM-I01002 "${DB_NAME}"

				connectDB "${DB_NAME}"

				if [ $? != '0' ]
				then
					# 異常の場合、次の処理を行う。
					IMPORT_RETRY_CNT=0
				fi
				SQLERROR=8
			else
				# 正常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
		done
			
		# DBエラー
		if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力	
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func SH-E02006 "${SQLERROR}" "${_errmsg}"
			
			# 一時ファイル等の削除
			#rm -f  ${SQLLOG_TMP}

			# CSV削除
			rm -f ${CSV_OUT_DIR}/${FILE_Shohyo}.csv

			# SCANデータの退避
			SCAN_FILE=`echo ${_FILE_Shohyo_BAK} | cut -f5 -d'/'`
			cp -f ${SCANFILE_BACKUP_DIR}/${SCAN_FILE} ${ERROR_DIR}/${SCAN_FILE}
			outlog_func SH-E02011 "${SCAN_FILE}"

			# エラー終了
			return 1
		fi
		echo "" >> ${SQLLOG_TMP}

		# 正常終了したスキャンデータファイルの末尾にOKをつける
		mv ${_FILE_Shohyo_BAK} ${_FILE_Shohyo_BAK}.OK
	fi
	return 0
}

##################################################################

#################################################################
# main処理
#################################################################

# MAIN処理

#出力ログ名設定
export log_name=${SHOHYO_MAIN_FLOW_LOG}

# 処理開始
outlog_func SH-I02001

# 証憑データファイルからCSVファイルを作成する
MAIN_01
if [ $? != 0 ]
then
	outlog_func SH-E02008 "MAIN_01"
	exit 1
fi

# GWDBに接続
connectDB "${DB_NAME}"
if [ $? != '0'  ]
then
	outlog_func SH-E02009 "connectDB"

	# 証憑データCSVファイルが存在する場合、SCANデータの退避
	if [ -f ${CSV_OUT_DIR}/${FILE_Shohyo}.csv ]
	then
		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_Shohyo}.csv

		# SCANデータの退避
		SCAN_FILE=`echo ${_FILE_Shohyo_BAK} | cut -f5 -d'/'`
		cp -f ${SCANFILE_BACKUP_DIR}/${SCAN_FILE} ${ERROR_DIR}/${SCAN_FILE}
		outlog_func SH-E02011 "${SCAN_FILE}"
	fi

	exit 1
fi

# 証憑データCSVファイルが存在すればDBにインサートを行う
MAIN_02
if [ $? != 0 ]
then
    outlog_func SH-E02010 "MAIN_02"
    exit 1
fi

# DB切断
db2 terminate > /dev/null

# 作成したCSVファイルを削除
rm -f ${CSV_OUT_DIR}/${FILE_Shohyo}.csv


# 一時ファイル削除
#rm -f ${_tmp}

# 処理終了
outlog_func SH-I02002

exit 0
