#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： USER_INPUT.sh
# 業 務 名       ： なし
# 処理概要       ： JIRAへのユーザ登録・更新
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Tsuruha 
#
# 作成日付       ： 2009-07-26
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-26 S.Tsuruha              新規作成
# 2 1.0.1 2010-04-19 S.Tsuruha              チームリーダ権限ユーザの権限変更不具合対応
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません" 
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# ディレクトリ移動
# ----
cd ${SHELL_DIR}

# ----
# 関数「tmpファイル削除」
# ----
function tmp_csv_delete
{
rm -f ${CSV_OUT_DIR}/user_insert.csv
rm -f ${CSV_OUT_DIR}/user_update_kanji_simei.csv
rm -f ${CSV_OUT_DIR}/user_update_shukan_code.csv
rm -f ${CSV_OUT_DIR}/user_update_ninmei_level.csv
rm -f ${TMP_DIR}/export_user_data_jira_new.csv
rm -f ${TMP_DIR}/export_syukanCODE_jiraid.csv
rm -f ${TMP_DIR}/export_project_jiraid_user.csv
rm -f ${TMP_DIR}/export_project_jiraid_sort.csv
rm -f ${TMP_DIR}/add_user_logindata.txt
rm -f ${SHELL_DIR}/login.jsp*
rm -fr ${SHELL_DIR}/${IP_ADDRESS_JIRAU}
rm -f ${SHELL_DIR}/cookies.txt
rm -f ${TMP_DIR}/add_usergroup_data.txt
rm -f ${TMP_DIR}/update_user_logindata.txt
rm -f ${TMP_DIR}/add_user_shukan_code_data.txt
rm -f ${TMP_DIR}/update_shukan_code_data.txt
rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/UserBrowser.jspa*
rm -f ${SQLLOG_TMP}
rm -f ${CSV_OUT_DIR}/user_update_shukan_code_copy.csv
rm -f ${DETAIL_LOG_TMP}
rm -f ${CSV_OUT_DIR}/user_update_password.csv
rm -f ${CSV_OUT_DIR}/team_leader_user_insert.csv
return 0
}

# ----
# 関数「社員マスタ情報移入」
# ----
function shain_master_import
{
if [ -z "${USERIN01BK}" ]
then
	return 0
fi

#db2 "import from ${PPFILE_BACKUP_DIR}/${USERIN01BK} of asc method L (1 8,9 9,10 29,30 49,50 53,54 55,56 61,62 67,68 73,74 81,82 89,90 97,98 105) commitcount 1000 insert into shain_master" > ${SQLLOG_TMP}

#インポートコマンドの戻り値が８の場合、３回処理を行う。
IMPORT_RETRY_CNT=3
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
	db2 "import from ${PPFILE_BACKUP_DIR}/${USERIN01BK} of asc method L (1 8,9 9,10 29,30 49,50 53,54 55,56 61,62 67,68 73,74 81,82 89,90 97,98 105) commitcount 1000 insert into shain_master" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${DB_NAME}"

		connectDB ${DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02003 "${_errmsg}"

		# エラー終了
		return 1
	fi
	# 正常終了したPPファイルの末尾にOKをつける
    mv -f ${PPFILE_BACKUP_DIR}/${USERIN01BK} ${PPFILE_BACKUP_DIR}/${USERIN01BK}.OK
	return 0
}

# ----
# 関数「社員所属マスタ情報移入」
# ----
function shain_shozoku_master_import
{
if [ -z "${USERIN02BK}" ]
then
	return 0
fi

#db2 "import from ${PPFILE_BACKUP_DIR}/${USERIN02BK}  of asc method L (1 8,9 9,10 15,16 18,19 20) commitcount 1000 insert into shain_shozoku_master" > ${SQLLOG_TMP}

#インポートコマンドの戻り値が８の場合、３回処理を行う。
IMPORT_RETRY_CNT=3
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
    db2 "import from ${PPFILE_BACKUP_DIR}/${USERIN02BK}  of asc method L (1 8,9 9,10 15,16 18,19 20) commitcount 1000 insert into shain_shozoku_master" > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${DB_NAME}"

		connectDB ${DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02004 "${_errmsg}"

                # エラー終了
                return 1
        fi
        # 正常終了したPPファイルの末尾にOKをつける
        mv -f ${PPFILE_BACKUP_DIR}/${USERIN02BK} ${PPFILE_BACKUP_DIR}/${USERIN02BK}.OK
        return 0
}

# ----
# 関数「任命レベル情報移入」
# ----
function shain_ninmei_level_import
{
if [ -z "${USERIN03BK}" ]
then
	return 0
fi

#db2 "import from ${PPFILE_BACKUP_DIR}/${USERIN03BK} of asc method L (1 8,9 9,10 14,15 16,17 17) commitcount 1000 insert into shain_ninmei_level" > ${SQLLOG_TMP}

#インポートコマンドの戻り値が８の場合、３回処理を行う。
IMPORT_RETRY_CNT=3
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
    db2 "import from ${PPFILE_BACKUP_DIR}/${USERIN03BK} of asc method L (1 8,9 9,10 14,15 16,17 17) commitcount 1000 insert into shain_ninmei_level" > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${DB_NAME}"

		connectDB ${DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02005 "${_errmsg}"

                # エラー終了
                return 1
        fi
        # 正常終了したPPファイルの末尾にOKをつける
        mv -f ${PPFILE_BACKUP_DIR}/${USERIN03BK} ${PPFILE_BACKUP_DIR}/${USERIN03BK}.OK
        return 0
}

# ----
# 関数「3テーブル結合移入」
# ----
function insert_user_master
{
db2 -tvf ${SQL_DIR}/insert_user_master.sql > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02006 "${_errmsg}"

                # エラー終了
                return 1
        fi
        return 0
}
# ----
# 関数「任命レベル複数チェック」
# ----
function insert_user_data_jira_new
{
db2 -tvf ${SQL_DIR}/insert_user_data_jira_new.sql > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02007 "${_errmsg}"

                # エラー終了
                return 1
        fi
        return 0
}

# ----
# 関数「差分チェック_ユーザ追加」
# ----
function make_csv_insert
{
db2 -tvf ${SQL_DIR}/make_csv_insert.sql > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02062 "${_errmsg}"

                # エラー終了
                return 1
  	  fi  

	# 行頭の+を削除
	sed -i "s/+//g" ${CSV_OUT_DIR}/user_insert.csv
	# .を削除
#	sed -i "s/\.//g" ${CSV_OUT_DIR}/user_insert.csv

	# "を削除
	sed -i "s/\"//g" ${CSV_OUT_DIR}/user_insert.csv

	# スペースを削除
	sed -i "s/ //g" ${CSV_OUT_DIR}/user_insert.csv
      
	return 0
}

# ----
# 関数「差分チェック_チームリーダ任命レベル追加」
# ----
function make_csv_team_leader_user
{
db2 -tvf ${SQL_DIR}/make_csv_team_leader_user.sql > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02081 "${_errmsg}"

                # エラー終了
                return 1
        fi
	# 行頭の+を削除
	sed -i "s/+//g" ${CSV_OUT_DIR}/team_leader_user_insert.csv
	# .を削除
#	sed -i "s/\.//g" ${CSV_OUT_DIR}/team_leader_user_insert.csv

	# "を削除
	sed -i "s/\"//g" ${CSV_OUT_DIR}/team_leader_user_insert.csv

	# スペースを削除
	sed -i "s/ //g" ${CSV_OUT_DIR}/team_leader_user_insert.csv
      
	return 0
}

# ----
# 関数「差分チェック_氏名変更」
# ----
function make_csv_update_kanji_simei
{
db2 -tvf ${SQL_DIR}/make_csv_update_kanji_simei.sql > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02034 "${_errmsg}"

                # エラー終了
                return 1
        fi
	# 行頭の+を削除
	sed -i "s/+//g" ${CSV_OUT_DIR}/user_update_kanji_simei.csv
	# .を削除
	sed -i "s/\.//g" ${CSV_OUT_DIR}/user_update_kanji_simei.csv
	# "を削除
	sed -i "s/\"//g" ${CSV_OUT_DIR}/user_update_kanji_simei.csv

	# スペースを削除
	sed -i "s/ //g" ${CSV_OUT_DIR}/user_update_kanji_simei.csv

       return 0
}

# ----
# 関数「差分チェック_主管コード変更」
# ----
function make_csv_update_shukan_code
{
db2 -tvf ${SQL_DIR}/make_csv_update_shukan_code.sql > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02035 "${_errmsg}"

                # エラー終了
                return 1
        fi
	# 行頭の+を削除
	sed -i "s/+//g" ${CSV_OUT_DIR}/user_update_shukan_code.csv
	# .を削除
	sed -i "s/\.//g" ${CSV_OUT_DIR}/user_update_shukan_code.csv
	# "を削除
	sed -i "s/\"//g" ${CSV_OUT_DIR}/user_update_shukan_code.csv
	# スペースを削除
	sed -i "s/ //g" ${CSV_OUT_DIR}/user_update_shukan_code.csv
        
	return 0
}

# ----
# 関数「差分チェック_任命レベル変更」
# ----
function make_csv_update_ninmei_level
{
db2 -tvf ${SQL_DIR}/make_csv_update_ninmei_level.sql > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02036 "${_errmsg}"

                # エラー終了
                return 1
        fi
	# 行頭の+を削除
	sed -i "s/+//g" ${CSV_OUT_DIR}/user_update_ninmei_level.csv
	# .を削除
	sed -i "s/\.//g" ${CSV_OUT_DIR}/user_update_ninmei_level.csv
	# "を削除
	sed -i "s/\"//g" ${CSV_OUT_DIR}/user_update_ninmei_level.csv
	# スペースを削除
	sed -i "s/ //g" ${CSV_OUT_DIR}/user_update_ninmei_level.csv
      
	return 0
}

# ----
# 関数「ユーザーデータJIRA反映分（前回分）テーブル移入」
# ----
function update_user_data_jira_old_update
{

# ユーザーデータJIRA反映分（今回分）テーブル情報をCSV形式で抽出
db2 "export to ${TMP_DIR}/export_user_data_jira_new.csv of del select * from user_data_jira_new" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー (Warningとして扱い、処理は終了させない)
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02008 "${_errmsg}"
		return 1
	fi

# ユーザーデータJIRA反映分（前回分）テーブル情報を削除(削除対象レコード以外)
db2 "delete from user_data_jira_old where ronrisakujo is null and kojinbangou in (select kojinbangou from user_data_jira_new)" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー (Warningとして扱い、処理は終了させない)
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02080 "${_errmsg}"
		return 1
	fi

# ユーザーデータJIRA反映分（今回分）テーブル情報をユーザーデータJIRA反映分（前回分）テーブルへ移入
#db2 "import from ${TMP_DIR}/export_user_data_jira_new.csv of del insert into user_data_jira_old" > ${SQLLOG_TMP}

#インポートコマンドの戻り値が８の場合、３回処理を行う。
IMPORT_RETRY_CNT=3
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
    db2 "import from ${TMP_DIR}/export_user_data_jira_new.csv of del insert into user_data_jira_old" > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${DB_NAME}"

		connectDB ${DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

        # DBエラー (Warningとして扱い、処理は終了させない)
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02009 "${_errmsg}"
		return 1
        fi
        
        return 0
}


# ----
# 関数「ユーザテーブルメンテナンス」
# ----
function maintenance_table
{
# ユーザーマスタテーブルクリアー
#db2 "import from /dev/null of del replace into user_master" > ${SQLLOG_TMP}

#インポートコマンドの戻り値が８の場合、３回処理を行う。
IMPORT_RETRY_CNT=3
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
    db2 "import from /dev/null of del replace into user_master" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${DB_NAME}"

		connectDB ${DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

	# DBエラー (Warningとして扱い、処理は終了させない)
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02010 "${_errmsg}"
		return 1
	fi


# システム任命レベル情報テーブルクリアー
#db2 "import from /dev/null of del replace into shain_ninmei_level" > ${SQLLOG_TMP}

#インポートコマンドの戻り値が８の場合、３回処理を行う。
IMPORT_RETRY_CNT=3
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
    db2 "import from /dev/null of del replace into shain_ninmei_level" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${DB_NAME}"

		connectDB ${DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

	# DBエラー　(Warningとして扱い、処理は終了させない)
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02011 "${_errmsg}"
		return 1
	fi


# 社員所属マスタテーブルクリアー
#db2 "import from /dev/null of del replace into shain_shozoku_master" > ${SQLLOG_TMP}

#インポートコマンドの戻り値が８の場合、３回処理を行う。
IMPORT_RETRY_CNT=3
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
    db2 "import from /dev/null of del replace into shain_shozoku_master" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${DB_NAME}"

		connectDB ${DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

	# DBエラー (Warningとして扱い、処理は終了させない)
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02012 "${_errmsg}"
		return 1
	fi


# 社員マスタテーブルクリアー
#db2 "import from /dev/null of del replace into shain_master" > ${SQLLOG_TMP}

#インポートコマンドの戻り値が８の場合、３回処理を行う。
IMPORT_RETRY_CNT=3
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
    db2 "import from /dev/null of del replace into shain_master" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${DB_NAME}"

		connectDB ${DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

	# DBエラー (Warningとして扱い、処理は終了させない)
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02013 "${_errmsg}"
		return 1
	fi


# ユーザーデータJIRA反映分（今回分）テーブルクリアー
#db2 "import from /dev/null of del replace into user_data_jira_new" > ${SQLLOG_TMP}

#インポートコマンドの戻り値が８の場合、３回処理を行う。
IMPORT_RETRY_CNT=3
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
    db2 "import from /dev/null of del replace into user_data_jira_new" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー（ループに戻す） エラーコード８のみ
	if [ ${SQLERROR} -eq 8 ]
	then
		# 接続断
		db2 terminate > /dev/null
		# 5秒間待ち、再接続、importコマンド実行
		sleep 5
		outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
		outlog_func IM-I01002 "${DB_NAME}"

		connectDB ${DB_NAME}

		if [ $? != '0' ]
		then
			# 異常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
		SQLERROR=8
	else
		# 正常の場合、次の処理を行う。
		IMPORT_RETRY_CNT=0
	fi
done

	# DBエラー (Warningとして扱い、処理は終了させない)
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02014 "${_errmsg}"
		return 1
	fi

return 0
}

# ----
# 関数「JIRAログイン」
# ----
function login_jira
{
	# wgetコマンドでJIRAへログインを行う
	wget -o ${DETAIL_LOG_TMP} --save-cookies cookies.txt --keep-session-cookies --header='Proxy-Connection: keep-alive' --post-data "os_username=${A_USER5_ID}&os_password=${A_USER5_PWD}&os_cookie=true" ${JIRA_IP}login.jsp
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}

	#ループ変数初期化
	_logincount=0
	while [ ${_logincount} -le 10 ]
	do
		# ./直下に作成されるlogin.jsp*ファイルが存在するか確認
		_find_Loginfile=`find ${SHELL_DIR} -name login.jsp | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}

		if [ -z "${_find_Loginfile}" ]
		then

			if [ ${_logincount} == 10 ]
			then
				outlog_func UM-E02015
				return 1
			fi
				_logincount=`expr ${_logincount} + 1`
				sleep 1
		else

			# login.jsp*のファイルを削除
			rm -f ${_find_Loginfile}
			break
		fi
	done

	return 0
}

# ----
# 関数「ユーザ追加_ログイン情報」
# ----
function add_user_logindata
{
	# ユーザ追加情報を読み込む
	while read kojinbangou ninmei_level kanji_simei shukan_code password password_unencode
	do
		fullname=`echo "${kanji_simei}"`
		echo "username=${kojinbangou}&password=${password}&confirm=${password}&fullname=${fullname}&email=nothing@en&Create=Create" > ${TMP_DIR}/add_user_logindata.txt
		if [ ! -s ${TMP_DIR}/add_user_logindata.txt ]
		then
			outlog_func UM-E02016
			return 1
		fi
		wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/add_user_logindata.txt" -p "${JIRA_IP}secure/admin/user/AddUser.jspa"
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func UM-I02087 ${kojinbangou} ${kanji_simei} ${password_unencode}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile1=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name AddUser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile2=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name ViewUser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile3=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile1}" -a -z "${_find_CEfile2}" -a -z "${_find_CEfile3}" ]
		then
			outlog_func UM-E02025
			return 1
		fi
		outlog_func UM-I02096 ${kojinbangou} ${kanji_simei} ${password_unencode}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*

	done < ${CSV_OUT_DIR}/user_insert.csv
	return 0
}

# ----
# 関数「ユーザ追加_グループ情報」
# ----
function add_user_groupdata
{

	# ユーザ追加情報を読み込む
	while read kojinbangou groups kanji_simei shukan_code password
	do
# ユーザ追加グループ情報作成
#		echo "join=Join+%3E%3E&groupsToJoin=${groups}&ToJoin=jira-developers&name=${kojinbangou}&returnuUrl=UserBrowser.jspa" > ${TMP_DIR}/add_usergroup_data.txt
		echo "join=Join+%3E%3E&groupsToJoin=${groups}&groupsToJoin=jira-developers&name=${kojinbangou}&returnuUrl=UserBrowser.jspa" > ${TMP_DIR}/add_usergroup_data.txt
		if [ ! -s ${TMP_DIR}/add_usergroup_data.txt ]
		then
			outlog_func UM-E02017
			return 1
		fi
		wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/add_usergroup_data.txt" -p "${JIRA_IP}secure/admin/user/EditUserGroups.jspa"
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func UM-I02088 ${kojinbangou} ${groups}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile1=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name EditUserGroups* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile2=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name ViewUserGroups* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile3=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile1}" -a -z "${_find_CEfile2}" -a -z "${_find_CEfile3}" ]
		then
			outlog_func UM-E02068
			return 1
		fi
		outlog_func UM-I02097 ${kojinbangou} ${groups}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*
		
	done < ${CSV_OUT_DIR}/user_insert.csv

	return 0
}

# ----
# 関数「ユーザ追加_主管コード情報」
# ----
function add_user_shukan_code_data
{

	# ユーザ追加情報を読み込む
	while read kojinbangou groups kanji_simei shukan_code password
	do
	if [ "${groups}" = "F" ]
	then
		continue
	fi
		param_kojin_id=${kojinbangou}
		param_syukan_id=${shukan_code}
		request_string=
		first_read_flag=0

		# ユーザ追加_主管コード情報ファイルの初期化
		rm -f ${TMP_DIR}/add_user_shukan_code_data.txt
		if [ -e ${TMP_DIR}/add_user_shukan_code_data.txt ]
		then
			outlog_func UM-E02018
			return 1
		fi

		# プロジェクト一覧のファイルを読み込む
		while read project_code project_name 
		do
			# 初期読み込み以外は"&"をつける
			if [ ${first_read_flag} -eq 1 ]
			then
				request_string="&"
				printf ${request_string} >> ${TMP_DIR}/add_user_shukan_code_data.txt
			fi
			request_string="project_shown=${project_code}"
			printf ${request_string} >> ${TMP_DIR}/add_user_shukan_code_data.txt
			first_read_flag=1

			# 全主管一覧のファイルを読み込む
			while read syukan_id syukan_value
			do
				# 読み込んだ主管コードとパラメータの主管コードが一致した場合
				if [ ${syukan_value} == ${param_syukan_id} ]
				then
					request_string="&${project_code}_${syukan_id}=on"
					printf ${request_string} >> ${TMP_DIR}/add_user_shukan_code_data.txt
				fi
				request_string="&${project_code}_${syukan_id}_orig=false"
				printf ${request_string} >> ${TMP_DIR}/add_user_shukan_code_data.txt
			done < ${TMP_DIR}/export_syukanCODE_jiraid.csv
		done < ${TMP_DIR}/export_project_jiraid_sort.csv

		printf "&Save=Save" >> ${TMP_DIR}/add_user_shukan_code_data.txt
		printf "&name=${param_kojin_id}" >> ${TMP_DIR}/add_user_shukan_code_data.txt
		printf "&projects_to_add=" >> ${TMP_DIR}/add_user_shukan_code_data.txt

		if [ ! -s ${TMP_DIR}/add_user_shukan_code_data.txt ]
		then
			outlog_func UM-E02019
			return 1
		fi

		wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/add_user_shukan_code_data.txt" -p "${JIRA_IP}secure/admin/user/EditUserProjectRoles.jspa"
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func UM-I02089 ${kojinbangou} ${shukan_code}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile1=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name EditUserProjectRoles* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile2=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name ViewUserProjectRoles* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile3=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile1}" -a -z "${_find_CEfile2}" -a -z "${_find_CEfile3}" ]
		then
			outlog_func UM-E02069
			return 1
		fi
		outlog_func UM-I02098 ${kojinbangou} ${shukan_code}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*
		
	done < ${CSV_OUT_DIR}/user_insert.csv

	return 0

}

# ----
# 関数「チームリーダユーザ追加_主管コード情報」
# ----
function add_team_leader_user_shukan_code_data
{

	# チームリーダユーザ追加情報を読み込む
	while read kojinbangou
	do
		param_kojin_id=${kojinbangou}
		request_string=
		first_read_flag=0

		# ユーザ追加_主管コード情報ファイルの初期化
		rm -f ${TMP_DIR}/add_user_shukan_code_data.txt
		if [ -e ${TMP_DIR}/add_user_shukan_code_data.txt ]
		then
			outlog_func UM-E02082
			return 1
		fi

		# プロジェクト一覧のファイルを読み込む
		while read project_code project_name 
		do
			# 初期読み込み以外は"&"をつける
			if [ ${first_read_flag} -eq 1 ]
			then
				request_string="&"
				printf ${request_string} >> ${TMP_DIR}/add_user_shukan_code_data.txt
			fi
			request_string="project_shown=${project_code}"
			printf ${request_string} >> ${TMP_DIR}/add_user_shukan_code_data.txt
			first_read_flag=1

			# 全主管一覧のファイルを読み込む
			while read syukan_id syukan_value
			do
					request_string="&${project_code}_${syukan_id}=on"
					printf ${request_string} >> ${TMP_DIR}/add_user_shukan_code_data.txt
				request_string="&${project_code}_${syukan_id}_orig=false"
				printf ${request_string} >> ${TMP_DIR}/add_user_shukan_code_data.txt
			done < ${TMP_DIR}/export_syukanCODE_jiraid.csv
		done < ${TMP_DIR}/export_project_jiraid_sort.csv

		printf "&Save=Save" >> ${TMP_DIR}/add_user_shukan_code_data.txt
		printf "&name=${param_kojin_id}" >> ${TMP_DIR}/add_user_shukan_code_data.txt
		printf "&projects_to_add=" >> ${TMP_DIR}/add_user_shukan_code_data.txt

		if [ ! -s ${TMP_DIR}/add_user_shukan_code_data.txt ]
		then
			outlog_func UM-E02083
			return 1
		fi

		wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/add_user_shukan_code_data.txt" -p "${JIRA_IP}secure/admin/user/EditUserProjectRoles.jspa"
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func UM-I02090 ${kojinbangou}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile1=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name EditUserProjectRoles* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile2=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name ViewUserProjectRoles* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile3=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile1}" -a -z "${_find_CEfile2}" -a -z "${_find_CEfile3}" ]
		then
			outlog_func UM-E02084
			return 1
		fi
		outlog_func UM-I02099 ${kojinbangou}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*
		
	done < ${CSV_OUT_DIR}/team_leader_user_insert.csv

	return 0

}

# ----
# 関数「ユーザ変更_ログイン情報」
# ----
function update_user_logindata
{
	while read kojinbangou kanji_simei_new kanji_simei_old
	do
		fullname=`echo "${kanji_simei_new}"`
		echo "fullName=${fullname}&email=nothing@en&editName=${kojinbangou}&Update=Update&returnUrl=UserBrowser.jspa" > ${TMP_DIR}/update_user_logindata.txt
		if [ ! -s ${TMP_DIR}/update_user_logindata.txt ]
		then
			outlog_func UM-E02020
			return 1
		fi
		wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/update_user_logindata.txt" -p "${JIRA_IP}secure/admin/user/EditUser.jspa"
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func UM-I02091 ${kojinbangou} ${kanji_simei_old} ${kanji_simei_new}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile1=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name EditUser* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile2=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name ViewUser* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile3=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile1}" -a -z "${_find_CEfile2}" -a -z "${_find_CEfile3}" ]
		then
			outlog_func UM-E02070
			return 1
		fi
		outlog_func UM-I02100 ${kojinbangou} ${kanji_simei_old} ${kanji_simei_new}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*
		
	done < ${CSV_OUT_DIR}/user_update_kanji_simei.csv
	return 0
}

# ----
# 関数「ユーザ変更_グループ情報」
# ----
function update_user_groupdata
{
	while read kojinbangou groups_new groups_old
	do
	# ユーザ変更グループ情報(削除用)作成
		echo "leave=%3C%3C+Leave&groupsToLeave=${groups_old}&name=${kojinbangou}&returnUrl=UserBrowser.jspa" > ${TMP_DIR}/leave_usergroup_data.txt
		if [ ! -s ${TMP_DIR}/leave_usergroup_data.txt ]
		then
			outlog_func UM-E02022
			return 1
		fi
	# ユーザ変更グループ情報(作成用)作成
		#echo "join=Join+%3E%3E&groupsToJoin=${groups_new}&name=${kojinbangou}&returnUrl=UserBrowser.jspa" > ${TMP_DIR}/update_usergroup_data.txt
		echo "join=Join+%3E%3E&groupsToJoin=${groups_new}&groupsToJoin=jira-developers&name=${kojinbangou}&returnUrl=UserBrowser.jspa" > ${TMP_DIR}/update_usergroup_data.txt
		if [ ! -s ${TMP_DIR}/update_usergroup_data.txt ]
		then
			outlog_func UM-E02023
			return 1
		fi

		wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/leave_usergroup_data.txt" -p "${JIRA_IP}secure/admin/user/EditUserGroups.jspa"
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func UM-I02092 ${kojinbangou} ${groups_old}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile}" ]
		then
			outlog_func UM-E02071
			return 1
		fi
		outlog_func UM-I02101 ${kojinbangou} ${groups_old}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*

		wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/update_usergroup_data.txt" -p "${JIRA_IP}secure/admin/user/EditUserGroups.jspa"
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func UM-I02093 ${kojinbangou} ${groups_new}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile}" ]
		then
			outlog_func UM-E02072
			return 1
		fi
		outlog_func UM-I02102 ${kojinbangou} ${groups_new}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*

	done < ${CSV_OUT_DIR}/user_update_ninmei_level.csv

	return 0

}

# ----
# 関数「ユーザ変更_主管コード情報」
# ----
function update_user_syukanCODEdata
{

	# 初期読み込みフラグ
	export first_read_flag=0

	# 変更前主管ID
	before_syukan_id=''

	while read kojinbangou shukan_code_new shukan_code_old groups_new groups_old
	do
    		param_kojin_id=${kojinbangou}
    		param_syukan_id=${shukan_code_new}
		request_string=
		first_read_flag=0

		# ユーザ変更_主管コード情報ファイルの初期化
		rm -f ${TMP_DIR}/update_shukan_code_data.txt
		if [ -e ${TMP_DIR}/update_shukan_code_data.txt ]
		then
			outlog_func UM-E02108
			return 1
		fi

		if [ "${groups_new}" = "F" ]
		then
			local_message1=(UM-I02110 ${kojinbangou} ${shukan_code_old} ${shukan_code_new})
			local_message2=UM-E02111
			local_message3=(UM-I02112 ${kojinbangou} ${shukan_code_old} ${shukan_code_new})
		elif [ "${groups_old}" = "F" ]
		then
			local_message1=(UM-I02113 ${kojinbangou} ${shukan_code_old} ${shukan_code_new})
			local_message2=UM-E02114
			local_message3=(UM-I02115 ${kojinbangou} ${shukan_code_old} ${shukan_code_new})
		else
			local_message1=(UM-I02094 ${kojinbangou} ${shukan_code_old} ${shukan_code_new})
			local_message2=UM-E02073
			local_message3=(UM-I02103 ${kojinbangou} ${shukan_code_old} ${shukan_code_new})

			while read diff_kojin_id diff_tmp1 diff_before_syukan_id diff_tmp2 diff_tmp3
		do
				if [ "${param_kojin_id}" = "${diff_kojin_id}" ]
		then
			before_syukan_id=${diff_before_syukan_id}
			break
		fi
		done < ${CSV_OUT_DIR}/user_update_shukan_code_copy.csv
		fi

	# プロジェクト一覧のファイルを読み込む
	while read project_code project_name
	do
		# 初期読み込み以外は"&"をつける
			if [ ${first_read_flag} -eq 1 ]
		then
			request_string="&"
			printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
		fi
		request_string="project_shown=${project_code}"
		printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
		first_read_flag=1

		# 全主管一覧のファイルを読み込む
		while read syukan_id syukan_value
		do
				if [ "${groups_new}" = "F" ]
				then
					request_string="&${project_code}_${syukan_id}=on"
					printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
					request_string="&${project_code}_${syukan_id}_orig=false"
					printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
				elif [ "${groups_old}" = "F" ]
				then
					# 読み込んだ主管コードとパラメータの主管コードが一致した場合
					if [ "${syukan_value}" = "${param_syukan_id}" ]
					then
						request_string="&${project_code}_${syukan_id}=on"
						printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
					fi
					request_string="&${project_code}_${syukan_id}_orig=true"
					printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
				else
			# 読み込んだ主管IDとパラメータの主管IDが一致した場合
					if [ "${syukan_value}" = "${param_syukan_id}" ]
			then
				request_string="&${project_code}_${syukan_id}=on"
				printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
			fi
			request_string="&${project_code}_${syukan_id}_orig="
			printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
				# 変更前の主管コードと一致した場合
					if [ "${before_syukan_id}" = "${syukan_value}" ]
			then
				request_string="true"
				printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
			else
				request_string="false"
				printf ${request_string} >> ${TMP_DIR}/update_shukan_code_data.txt
			fi
				fi
		done < ${TMP_DIR}/export_syukanCODE_jiraid.csv
	done < ${TMP_DIR}/export_project_jiraid_sort.csv

	printf "&Save=Save" >> ${TMP_DIR}/update_shukan_code_data.txt
	printf "&name=${param_kojin_id}" >> ${TMP_DIR}/update_shukan_code_data.txt
	printf "&projects_to_add=" >> ${TMP_DIR}/update_shukan_code_data.txt
	
		if [ ! -s ${TMP_DIR}/update_shukan_code_data.txt ]
		then
			outlog_func UM-E02109
			return 1
		fi
	wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/update_shukan_code_data.txt" -p "${JIRA_IP}secure/admin/user/EditUserProjectRoles.jspa"
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}

		outlog_func ${local_message1[@]}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile1=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name EditUserProjectRoles* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile2=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name ViewUserProjectRoles* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile3=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile1}" -a -z "${_find_CEfile2}" -a -z "${_find_CEfile3}" ]
		then
			outlog_func ${local_message2}
			return 1
		fi
		outlog_func ${local_message3[@]}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*

	done < ${CSV_OUT_DIR}/user_update_shukan_code.csv

	return 0

}


# ----
# 関数「主管コード通番取得」
# ----
function export_syukanCODE_jiraid
{	# 主管コードとIDファイルをエクスポート
	db2 "export to ${TMP_DIR}/export_syukanCODE_jiraid.csv of del select id,name from ${SCHEMA_NAME}projectrole" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02039 "${_errmsg}"

		# エラー終了
		return 1
	fi

	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${TMP_DIR}/export_syukanCODE_jiraid.csv ]
	then
		outlog_func UM-E02040
		return 1
	fi
	# 行頭の+を削除
	sed -i "s/+//g" ${TMP_DIR}/export_syukanCODE_jiraid.csv
	# .を削除
	sed -i "s/\.//g" ${TMP_DIR}/export_syukanCODE_jiraid.csv
	# "を削除
	sed -i "s/\"//g" ${TMP_DIR}/export_syukanCODE_jiraid.csv
	# 先頭の0を削除
	sed -i "s/^0*//g" ${TMP_DIR}/export_syukanCODE_jiraid.csv


	return 0
}

# ----
# 関数「プロジェクトID,プロジェクト名取得」
# ----
function export_project_jiraid_user
{

	# プロジェクトIDとプロジェクト名をエクスポート
	db2 "export to ${TMP_DIR}/export_project_jiraid_user.csv of del select id,pname from ${SCHEMA_NAME}project" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UM-E02026 "${_errmsg}"

		# エラー終了
		return 1
	fi

	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${TMP_DIR}/export_project_jiraid_user.csv ]
	then
		outlog_func UM-E02027
		return 1
	fi
	# 行頭の+を削除
	sed -i "s/+//g" ${TMP_DIR}/export_project_jiraid_user.csv
	# .を削除
	sed -i "s/\.//g" ${TMP_DIR}/export_project_jiraid_user.csv
	# "を削除
	sed -i "s/\"//g" ${TMP_DIR}/export_project_jiraid_user.csv
	# 先頭の0を削除
	sed -i "s/^0*//g" ${TMP_DIR}/export_project_jiraid_user.csv
	# スペースを削除
	sed -i "s/ //g" ${TMP_DIR}/export_project_jiraid_user.csv

	return 0
}

# ----
# 関数「論理削除フラグ更新」
# ----
function update_user_data_jira_old_delete
{
db2 -tvf ${SQL_DIR}/update_user_data_jira_old_delete.sql > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02105 "${_errmsg}"

                # エラー終了
                return 1
        fi
return 0
}

# ----
# 関数「ユーザ変更_パスワード情報」
# ----
function update_user_password
{
	while read kojinbangou password password_new password_old
	do
		echo "password=${password}&confirm=${password}&name=${kojinbangou}&Update=Update" > ${TMP_DIR}/update_user_password.txt
		if [ ! -s ${TMP_DIR}/update_user_password.txt ]
		then
			outlog_func UM-E02076
			return 1
		fi
		wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/update_user_password.txt" -p "${JIRA_IP}secure/admin/user/SetPassword.jspa"
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		outlog_func UM-I02095 ${kojinbangou} ${password_old} ${password_new}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile1=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name SetPassword* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile2=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa* | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile1}" -a -z "${_find_CEfile2}" ]
		then
			outlog_func UM-E02077
			return 1
		fi
		outlog_func UM-I02104 ${kojinbangou} ${password_old} ${password_new}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*
		
	done < ${CSV_OUT_DIR}/user_update_password.csv
	return 0
}

# ----
# 関数「差分チェック_パスワード変更」
# ----
function make_csv_update_password
{
db2 -tvf ${SQL_DIR}/make_csv_update_password.sql > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E02078 "${_errmsg}"

                # エラー終了
                return 1
        fi
	# 行頭の+を削除
	sed -i "s/+//g" ${CSV_OUT_DIR}/user_update_password.csv
	# .を削除
#	sed -i "s/\.//g" ${CSV_OUT_DIR}/user_update_password.csv
	# "を削除
	sed -i "s/\"//g" ${CSV_OUT_DIR}/user_update_password.csv
	# スペースを削除
	sed -i "s/ //g" ${CSV_OUT_DIR}/user_update_password.csv

       return 0
}


#####################################################################
# 出力ログ名設定
export log_name=${USER_MAIN_FLOW_LOG}

# main処理開始
outlog_func UM-I02001

# tmpファイル削除
tmp_csv_delete

# PPバックアップファイル名にOKが無いものを取得（正常終了しなかったPPファイル）
USERIN01BK=`ls ${PPFILE_BACKUP_DIR}| grep ${IF_syain_master} | grep -v OK | head -1`
USERIN02BK=`ls ${PPFILE_BACKUP_DIR}| grep ${IF_shain_shozoku_master} | grep -v OK | head -1`
USERIN03BK=`ls ${PPFILE_BACKUP_DIR}| grep ${IF_ninmei_level} | grep -v OK | head -1`

# PPバックアップファイルの末尾が全てOK
if [ -z "${USERIN01BK}" -a -z "${USERIN02BK}" -a -z "${USERIN03BK}" ];then

    # PPファイルが存在しない
    outlog_func UM-E02075 

    # 処理対象ファイルが存在しないので終了
    exit 0

fi
outlog_func UM-I02074 "${PPFILE_BACKUP_DIR}/${USERIN01BK}" "${PPFILE_BACKUP_DIR}/${USERIN02BK}" "${PPFILE_BACKUP_DIR}/${USERIN03BK}"

# GW側DBに接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func UM-E02041 "${_errmsg}"

	# エラー終了
	exit 1
fi

# テーブルメンテナンス
maintenance_table
if [ $? != '0' ]
then
    outlog_func UM-E02063
    exit 1
fi


# 社員マスタ情報移入
shain_master_import
if [ $? != '0' ]
then
    outlog_func UM-E02042
    exit 1
fi

# 社員所属マスタ情報移入
shain_shozoku_master_import
if [ $? != '0' ]
then
    outlog_func UM-E02043
    exit 1
fi
# 任命レベル情報移入
shain_ninmei_level_import
if [ $? != '0' ]
then
    outlog_func UM-E02044
    exit 1
fi

# 3テーブル結合移入
insert_user_master
if [ $? != '0' ]
then
    outlog_func UM-E02045
    exit 1
fi

# 任命レベル複数チェック
insert_user_data_jira_new
if [ $? != '0' ]
then
    outlog_func UM-E02046
    exit 1
fi

# 差分チェック_ユーザ追加
make_csv_insert
if [ $? != '0' ]
then
    outlog_func UM-E02047
    exit 1
fi

# ユーザ追加用ファイルの文字コード変換
nkf -w --overwrite ${CSV_OUT_DIR}/user_insert.csv
if [ $? != '0' ]
then
    outlog_func UM-E02048
    exit 1
fi

# 差分チェック_チームリーダ主管コード追加
make_csv_team_leader_user
if [ $? != '0' ]
then
    outlog_func UM-E02106
    exit 1
fi

# ユーザ追加用ファイルの文字コード変換
nkf -w --overwrite ${CSV_OUT_DIR}/user_insert.csv
if [ $? != '0' ]
then
    outlog_func UM-E02048
    exit 1
fi

# 差分チェック_氏名変更
make_csv_update_kanji_simei
if [ $? != '0' ]
then
    outlog_func UM-E02049
    exit 1
fi

# ユーザ氏名変更用ファイルの文字コード変換
nkf -w --overwrite ${CSV_OUT_DIR}/user_update_kanji_simei.csv
if [ $? != '0' ]
then
    outlog_func UM-E02050
    exit 1
fi

# 差分チェック_主管コード変更
make_csv_update_shukan_code
if [ $? != '0' ]
then
    outlog_func UM-E02051
    exit 1
fi

# ユーザ主管コード変更用ファイルの文字コード変換
nkf -w --overwrite ${CSV_OUT_DIR}/user_update_shukan_code.csv
if [ $? != '0' ]
then
    outlog_func UM-E02052
    exit 1
fi

# ユーザ変更_主管コード用コピーファイル作成
cp -pf ${CSV_OUT_DIR}/user_update_shukan_code.csv ${CSV_OUT_DIR}/user_update_shukan_code_copy.csv
if [ ! -e ${CSV_OUT_DIR}/user_update_shukan_code_copy.csv ]
then
	outlog_func UM-E02053
	exit 1
fi

# 差分チェック_任命レベル変更
make_csv_update_ninmei_level
if [ $? != '0' ]
then
    outlog_func UM-E02054
    exit 1
fi

# ユーザ任命レベル変更用ファイルの文字コード変換
nkf -w --overwrite ${CSV_OUT_DIR}/user_update_ninmei_level.csv
if [ $? != '0' ]
then
    outlog_func UM-E02055
    exit 1
fi

# 差分チェック_パスワード変更
make_csv_update_password
if [ $? != '0' ]
then
    outlog_func UM-E02079
    exit 1
fi

# ユーザ任命レベル変更用ファイルの文字コード変換
nkf -w --overwrite ${CSV_OUT_DIR}/user_update_password.csv
if [ $? != '0' ]
then
    outlog_func UM-E02080
    exit 1
fi

# GW側DBを切断
db2 terminate > /dev/null

# JIRA側DBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func UM-E02030 "${_errmsg}"

	# エラー終了
	exit 1
fi


# 主管コード通番取得
export_syukanCODE_jiraid
if [ $? != '0' ]
then
    outlog_func UM-E02031
    exit 1
fi

# プロジェクト対応JIRA側ID取得
export_project_jiraid_user
if [ $? != '0' ]
then
    outlog_func UM-E02056
    exit 1
fi

# ,をスペースに変更
sed -i "s/,/ /g" ${TMP_DIR}/export_project_jiraid_user.csv

# アルファベット順に業務名リスト並べ替え
sort -k2 ${TMP_DIR}/export_project_jiraid_user.csv > ${TMP_DIR}/export_project_jiraid_sort.csv
if [ $? != '0' ]
then
    outlog_func UM-E02057
    exit 1
fi
# スペースを,に変更
	sed -i "s/ /,/g" ${TMP_DIR}/export_project_jiraid_sort.csv

# JIRAログイン
login_jira
if [ $? != '0' ]
then
	outlog_func UM-E02085
    exit 1
fi

# ファイル読み込み時のセパレートを設定
IFS_org=${IFS}
IFS=,

# ユーザ追加_ログイン情報
add_user_logindata
if [ $? != '0' ]
then
    outlog_func UM-E02032
    IFS=${IFS_org}
    exit 1
fi

# ユーザ追加_グループ情報
add_user_groupdata
if [ $? != '0' ]
then
    outlog_func UM-E02058
    IFS=${IFS_org}
    exit 1
fi
# ユーザ追加_主管コード情報
add_user_shukan_code_data
if [ $? != '0' ]
then
    outlog_func UM-E02059
    IFS=${IFS_org}
    exit 1
fi

# チームリーダユーザ追加_主管コード情報
add_team_leader_user_shukan_code_data
if [ $? != '0' ]
then
    outlog_func UM-E02107
    IFS=${IFS_org}
    exit 1
fi


# ユーザ変更_ログイン情報
update_user_logindata
if [ $? != '0' ]
then
    outlog_func UM-E02033
    IFS=${IFS_org}
    exit 1
fi
# ユーザ変更_グループ情報
update_user_groupdata
if [ $? != '0' ]
then
    outlog_func UM-E02060
    IFS=${IFS_org}
    exit 1
fi
# ユーザ変更_主管コード情報
update_user_syukanCODEdata
if [ $? != '0' ]
then
    outlog_func UM-E02061
    IFS=${IFS_org}
    exit 1
fi

# ユーザ変更_パスワード情報
update_user_password
if [ $? != '0' ]
then
    outlog_func UM-E02081
    IFS=${IFS_org}
    exit 1
fi

# JIRA側DBを切断
db2 terminate > /dev/null

# GW側DBに接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func UM-E02086 "${_errmsg}"

	# エラー終了
	exit 1
fi

# ユーザーデータJIRA反映分（前回分）テーブル移入
update_user_data_jira_old_update
if [ $? != '0' ]
then
    outlog_func UM-E02064
    exit 1
fi

# 処理終了
    outlog_func UM-I02002
    IFS=${IFS_org}
exit 0

