#!/bin/bash
################### モジュール説明 ############################################
# モジュール名   ： S030102_ONLINE_CREATE.sh
# システム名     ： ワークアイテム更新（ONLINE_CREATE）
# 業 務 名       ： 経費振込み
# 機 能 名　　 　： ONLINE_CREATE
# 言語           ： bash
# ＯＳ           ： Linux (Red hat)
# 処理概要       ： 業務データをデータベースより取得取り込み、
#                  wgetでJIRAの対象項目に反映する。
# 特記事項       ： なし
# パラメータ     ： なし
# ログファイル   ： 
# リターンコード ： 正常終了(0)
#                  処理異常(1)
# 対象DB         ： なし
#
################### モジュール説明 #############################################
#
################### 改定履歴       #############################################
# 作成者         ： S.Tsuruha
# 作成日付       ： 2009-06-05
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
# 1初版     2009-06-05  S.Tsuruha               新規作成
# 2
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
################### 改定履歴       #############################################

###############################################################################
# main処理開始
###############################################################################
# 共通環境変数読み込み
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
    if [[ -r ${x} ]]
    then
        . ${x}
    else
        echo "Cannot read common env file. ( ${x} )."
        exit 1
    fi
done


# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# IF業務ID取得
shname=`basename ${0}`
basename=`echo ${shname} | sed "s/_CSV_IMPORT.sh//g"`

# 出力ログ名設定
export log_name=${S030102_MAIN_FLOW_LOG}

# 開始ログ出力
outlog_func CT-I04001

# JIRAPKEY 初期化
java -classpath "${JAVA_CLASSPATH}" com.ibm.jirax.batch.SetUpSequenceNumberBatch ${JIRA_UI_PID_S030102} > ${DETAIL_LOG_TMP} 2>&1
RC=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
case ${RC} in
        0)      outlog_func CT-I04025 ${JIRA_UI_PID_S030102} ${RC};;
        10)     outlog_func CT-I04026 ${JIRA_UI_PID_S030102} ${RC};;
        *)      outlog_func CT-E04024 ${JIRA_UI_PID_S030102} ${RC}
                exit 1;;
esac

# JIRA ワークアイテム追加
java -classpath "${JAVA_CLASSPATH}" com.ibm.jirax.batch.CreateIssuesBatch ${JIRA_UI_PID_S030102} > ${DETAIL_LOG_TMP} 2>&1
RC=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
case ${RC} in
        0)      outlog_func CT-I04027 ${JIRA_UI_PID_S030102} ${RC};;
        10)     outlog_func CT-I04028 ${JIRA_UI_PID_S030102} ${RC};;
        *)      outlog_func CT-E04029 ${JIRA_UI_PID_S030102} ${RC}
                exit 1;;
esac

# 終了ログ出力
outlog_func CT-I04002

exit 0
