#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S030101_MATCHING.sh
# 業 務 名       ： マッチング（入金データアンマッチリスト処理）
# 処理概要       ： 入金データアンマッチテーブルと証憑テーブルの紐付けを行う。
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： GWDB
#
################### モジュール説明 ########################
################### 改定履歴       ########################
# 作成者         ： K.Yamaguchi
#
# 作成日付       ： 2009-07-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#  1.0.0  2009-07-08 K.Yamaguchi            新規作成
#  1.1.0  2014-03017 T.Xiaodong             メンバー割処理追加
# 
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
# 入出金材料確認関数
#########################################################################
function s030101_matching
{

	#マッチング件数ログ表示用変数
	matchingCount=0;

	db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CE-E06004 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}
	
	### 入出金材料確認（販売票）マッチング処理 ###############################################
	_s030101_hanbai_sql=${SQL_DIR}/S030101_ID0004_MATCHING.sql

	# 入出金材料確認（販売票）マッチングSQL実行
	db2 -tvf ${_s030101_hanbai_sql} > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CE-E06005 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}
	
	# SQL結果ファイル存在チェック
	if [ ! -f ${_sqltmp1} ]
	then
	    outlog_func CE-E06006
		return 1
	fi

	# csvファイルを整形
	sed -e s/,/" "/g ${_sqltmp1} | sed -e s/\"/""/g > ${_idlisttmp1}

	if [ ! -e ${_idlisttmp1} ]   #整形した結果を格納した_idlisttmp1ファイルが存在しない場合、エラー終了
	then
	     return 1
	fi

	#echo ${_s030101_hanbai_sql}
	
	# マッチング条件に該当した通番と証憑IDの件数分ループを行う
	while read tsuuban_tmp1 shohyo_id_tmp1
	do
		# 該当テーブルにマッチングした証憑IDを更新する
	    db2 "update ${TABLE_S030101} set MATCHINGshouhyouID = '${shohyo_id_tmp1}' where tsuuban = '${tsuuban_tmp1}'"   > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力	
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func CE-I06007 ${matchingCount}
			outlog_func CE-E06008 ${tsuuban_tmp1} "${_errmsg}"
			
			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi
		echo "" >> ${SQLLOG_TMP}
		
		#マッチング件数＋１
		matchingCount=`expr ${matchingCount} + 1`

	done < ${_idlisttmp1}

	#マッチング件数をログに出力
	outlog_func CE-I06013 ${matchingCount}
	
	### 入出金材料確認（支払い証明）マッチング処理 ############################################
	
	#マッチング件数初期化
	matchingCount=0;
	
	_s030101_shiharai_sql=${SQL_DIR}/S030101_ID0005_MATCHING.sql

	# 入出金材料確認（支払い証明）マッチング処理SQL実行
	db2 -tvf ${_s030101_shiharai_sql} > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CE-E06009 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}
	
	# SQL結果ファイル存在チェック
	if [ ! -f ${_sqltmp2} ]
	then
	    outlog_func CE-E06010
		return 1
	fi

	# csvファイルを整形
	sed -e s/,/" "/g ${_sqltmp2} | sed -e s/\"/""/g > ${_idlisttmp2}

	if [ ! -e ${_idlisttmp2} ]   #整形した結果を格納した_idlisttmp2ファイルが存在しない場合、エラー終了
	then
	     return 1
	fi

	#echo ${_s030101_shiharai_sql}

	# マッチング条件に該当した通番と証憑IDの件数分ループを行う
	while read tsuuban_tmp2 shohyo_id_tmp2               #tmp2ファイルの行数分、以下の処理を実行
	do
		# 該当テーブルにマッチングした証憑IDを更新する
	    db2 "update ${TABLE_S030101} set MATCHINGshouhyouID = '${shohyo_id_tmp2}' where tsuuban = '${tsuuban_tmp2}'"   > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力	
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func CE-I06011 ${matchingCount}
			outlog_func CE-E06012 ${tsuuban_tmp2} "${_errmsg}"
			
			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi
		echo "" >> ${SQLLOG_TMP}

		#マッチング件数＋１
		matchingCount=`expr ${matchingCount} + 1`

	done < ${_idlisttmp2}

	#マッチング件数をログに出力
	outlog_func CE-I06014 ${matchingCount}
	

	### 入出金材料確認（メンバー割）マッチング処理 ############################################
	
	#マッチング件数初期化
	matchingCount=0;
	
	_s030101_KM_sql=${SQL_DIR}/S030101_ID0023_MATCHING.sql

	# 入出金材料確認（メンバー割）マッチング処理SQL実行
	db2 -tvf ${_s030101_KM_sql} > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CE-E06015 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}
	
	# SQL結果ファイル存在チェック
	if [ ! -f ${_sqltmp3} ]
	then
	    outlog_func CE-E06016
		return 1
	fi

	# csvファイルを整形
	sed -e s/,/" "/g ${_sqltmp3} | sed -e s/\"/""/g > ${_idlisttmp3}

	if [ ! -e ${_idlisttmp3} ]   #整形した結果を格納した_idlisttmp3ファイルが存在しない場合、エラー終了
	then
	     return 1
	fi

	# マッチング条件に該当した通番と証憑IDの件数分ループを行う
	while read tsuuban_tmp3 shohyo_id_tmp3               #tmp3ファイルの行数分、以下の処理を実行
	do
		# 該当テーブルにマッチングした証憑IDを更新する
	    db2 "update ${TABLE_S030101} set MATCHINGshouhyouID = '${shohyo_id_tmp3}' where tsuuban = '${tsuuban_tmp3}'"   > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力	
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func CE-I06017 ${matchingCount}
			outlog_func CE-E06018 ${tsuuban_tmp3} "${_errmsg}"
			
			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi
		echo "" >> ${SQLLOG_TMP}

		#マッチング件数＋１
		matchingCount=`expr ${matchingCount} + 1`

	done < ${_idlisttmp3}

	#マッチング件数をログに出力
	outlog_func CE-I06019 ${matchingCount}


	db2 terminate > /dev/null
	
	return 0
}

#########################################################################
# main処理
#########################################################################

#########################################################################
# 環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 個別環境設定
#########################################################################
# 一時ファイル変数
export _sqltmp1=${TMP_DIR}/S030101_tsuuban1.tmp
export _idlisttmp1=${TMP_DIR}/S030101_idlist1.tmp
export _sqltmp2=${TMP_DIR}/S030101_tsuuban2.tmp
export _idlisttmp2=${TMP_DIR}/S030101_idlist2.tmp
export _sqltmp3=${TMP_DIR}/S030101_tsuuban3.tmp
export _idlisttmp3=${TMP_DIR}/S030101_idlist3.tmp

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${SHOHYO_MAIN_FLOW_LOG}

outlog_func CE-I06001

##入出金材料確認関数呼出
s030101_matching

if [ $? != '0' ]   #関数「s030101_matching」の実行結果の正否を判定
then
	outlog_func CE-E06003
	exit 1
else
	# 一時ファイル削除
	rm -f ${_sqltmp1}
	rm -f ${_idlisttmp1}
	rm -f ${_sqltmp2}
	rm -f ${_idlisttmp2}
	rm -f ${_sqltmp3}
	rm -f ${_idlisttmp3}
	outlog_func CE-I06002
	exit 0
fi
