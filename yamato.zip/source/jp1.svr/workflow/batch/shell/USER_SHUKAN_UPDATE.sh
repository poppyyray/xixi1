#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： USER_SHUKAN_UPDATE.sh
# 業 務 名       ： 兼務主管更新
# 処理概要       ：JiraUIで兼務主管の追加処理
# 特記事項       ：
# パラメータ     ： なし
#				
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： GWDB
#					JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： YYK
#
# 作成日付       ： 2017-04-15
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2017-04-15 YYK                新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません" >>${DETAIL_LOG}
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません" >>${DETAIL_LOG}
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# 関数「兼務主管コードCSV作成」
# ----
function make_csv_update_shukan_code
{
    #GWDBへ接続する
    connectDB ${DB_NAME}

    #-----------------------------------------------------
    local SQL=`cat ${MULTI_SHUKAN_SQL}`
    #-----------------------------------------------------

    db2 "export to ${SHUKAN_CSV} of del ${SQL}" > ${SQLLOG_TMP}
    SQLERROR=$?
    # DBエラー
    if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func UM-E08010 "${_errmsg}"

        # エラー終了
        exit 1
    fi

    #GWDBから切断する
    db2 terminate > /dev/null
    return 0
}


# ----
# 関数「postファイル作成」
# ----
function create_shukan_postfile
{
    local userId=$1
    local shukan=($2)
	local flg
    rm -f ${POST_FILE}
    echo $userId,${shukan[*]} >>${DETAIL_LOG}
    echo ${shukan[*]} >>${DETAIL_LOG}
    # ファイル読み込み時のセパレートを設定
    IFS_org=${IFS}
    IFS=,

    while read projectId projectName
    do
        echo -n "project_shown=${projectId}&" >> ${POST_FILE}
        while read syukan_id syukan_value
        do
			flg=0
            for shukanCdTmp_target in ${shukan[*]}
            do
                if [ ${shukanCdTmp_target} = ${syukan_value} ];then
					flg=1
                fi
            done
			if [ ${flg} -eq 1 ];then
				echo -n "${projectId}_${syukan_id}=on&" >> ${POST_FILE}
				echo -n "${projectId}_${syukan_id}_orig=false&" >> ${POST_FILE}
			else
				echo -n "${projectId}_${syukan_id}_orig=true&" >> ${POST_FILE}
			fi
        done < ${SHUKAN_JIRAID_FILE}
    done < ${PROJECT_JIRAID_FILE}
    echo -n "Save=Save&name=${userId}&projects_to_add=" >> ${POST_FILE}
    IFS=${IFS_org}
    return 0
}

# ----
# 関数「JIRA主管コードCSV作成」
# ----
function make_csv_jira_shukan_code
{
    #GWDBへ接続する
    connectDB ${JIRA_DB_NAME}

    #-----------------------------------------------------
    local SQL=`cat ${JIRA_SHUKAN_SQL}`
    #-----------------------------------------------------

    db2 "export to ${SHUKAN_JIRA_CSV} of del ${SQL}" > ${SQLLOG_TMP}
    SQLERROR=$?
    # DBエラー
    if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func UM-E08010 "${_errmsg}"

        # エラー終了
        exit 1
    fi

    #GWDBから切断する
    db2 terminate > /dev/null
    return 0
}


# ----
# 関数「主管コード設定」
# ----
function set_shukan
{
    local userId=$1
    local shukan=($2)

    rm -f ${POST_FILE}
    rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/*
    echo $userId,${shukan[*]} >>${DETAIL_LOG}
    # ファイル読み込み時のセパレートを設定
    create_shukan_postfile $userId "${shukan[*]}"
    #echo -n "Save=Save&name=${userId}&projects_to_add=" >> ${POST_FILE}
    cd ${SHELL_DIR}
    
    #JIRA URL呼び出す
    wget -o ${DETAIL_LOG_TMP} --load-cookies ${COOKIE_FILE} --header="Content-Type: application/x-www-form-urlencoded" --post-file="${POST_FILE}" -p "${JIRA_IP}secure/admin/user/EditUserProjectRoles.jspa"

    cd ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/
    local role_path=`find . -type f -name "ViewUserProjectRoles*" -o -name "EditUserProjectRoles*" -o -name "UserBrowser.jspa*"`
    
    if [ -z $role_path ];then
        outlog_func UM-W08007 ${userId} "${shukan[*]}"
        timeYMD=`date '+%Y%m%d'`
        cp ${SHUKAN_CSV} ${SHUKAN_CSV}-${timeYMD}.ERR
    fi

    return 0
}


###############################################################################
# main処理開始
###############################################################################
echo "処理開始" >>${DETAIL_LOG}
# 出力ログ名設定
export log_name=${USER_MAIN_FLOW_LOG}

# 開始メッセージ
outlog_func UM-I08001

timeYMD=`date '+%Y%m%d'`

# project file
PROJECT_JIRAID_FILE=${TMP_DIR}/export_project_jiraid_sort.csv
SHUKAN_JIRAID_FILE=${TMP_DIR}/export_syukanCODE_jiraid.csv
COOKIE_FILE=cookies.txt
SQL_DIR=/workflow/batch/sql

# sql file
MULTI_SHUKAN_SQL=${SQL_DIR}/make_csv_multi_shukan.sql
JIRA_SHUKAN_SQL=${SQL_DIR}/make_csv_jira_shukan.sql

# temp file
SHUKAN_CSV_NAME=user_shukan_update.csv
SHUKAN_CSV=${CSV_OUT_DIR}/${SHUKAN_CSV_NAME}
SHUKAN_JIRA_CSV=${CSV_OUT_DIR}/user_shukan_jira.csv
SHUKAN_DIFF_USER_LIST=${TMP_DIR}/${SHUKAN_CSV_NAME}.userlist
SHUKAN_CSV_OUT=${SHUKAN_CSV}.${timeYMD}.OK
SHUKAN_OFF_POST_FILE=${TMP_DIR}/shukan_all_off.txt
POST_FILE=${TMP_DIR}/update_multi_shukan.txt

# tmpファイル削除
rm -f ${SHUKAN_CSV}
rm -f ${SHUKAN_JIRA_CSV}
rm -f ${SHUKAN_DIFF_USER_LIST}
rm -f ${SHUKAN_OFF_POST_FILE}
rm -f ${POST_FILE}

echo "業務リストファイル存在チェック" >>${DETAIL_LOG}
#業務リストファイル存在チェック
if [ ! -f ${PROJECT_JIRAID_FILE} ]
then
	outlog_func UM-E08009 "${PROJECT_JIRAID_FILE}"
	exit 1
fi

#主管リストファイル存在チャック
if [ ! -f ${SHUKAN_JIRAID_FILE} ]
then
	outlog_func UM-E08009 "${SHUKAN_JIRAID_FILE}"
	exit 1
fi

echo "兼務主管コードCSV作成" >>${DETAIL_LOG}
# 兼務主管コードCSV作成
make_csv_update_shukan_code
if [ $? != '0' ]
then
	outlog_func UM-E08004 ${MULTI_SHUKAN_SQL}
    exit 1
else
    outlog_func UM-I08003 "${SHUKAN_CSV}"
fi

echo "JIRA主管コードCSV作成" >>${DETAIL_LOG}
# JIRA主管コードCSV作成
make_csv_jira_shukan_code
if [ $? != '0' ]
then
	outlog_func UM-E08004 ${JIRA_SHUKAN_SQL}
    exit 1
else
    outlog_func UM-I08003 "${SHUKAN_JIRA_CSV}"
fi

echo "差分ファイル作成" >>${DETAIL_LOG}
#差分ファイル取得し、社員番号リストファイルを作成する
diff ${SHUKAN_CSV} ${SHUKAN_JIRA_CSV} | grep -E "<|>" | sed 's/\"//g' > ${TMP_DIR}/${SHUKAN_CSV_NAME}.diff1
sed 's/.[ ]\([0-9]\{6,\}\),[0-9]\{6,\}/\1/' ${TMP_DIR}/${SHUKAN_CSV_NAME}.diff1 > ${TMP_DIR}/${SHUKAN_CSV_NAME}.diff2
sort -u ${TMP_DIR}/${SHUKAN_CSV_NAME}.diff2 > ${SHUKAN_DIFF_USER_LIST}

rm -f ${TMP_DIR}/${SHUKAN_CSV_NAME}.diff1
rm -f ${TMP_DIR}/${SHUKAN_CSV_NAME}.diff2

# JIRAログイン
jira_login ${SHELL_DIR}
if [ $? != '0' ]
then
	outlog_func UM-E08005
    exit 1
fi

while read userId
do
    echo "${userId}" >>${DETAIL_LOG}
    #社員番号対応して主管リストを取得する
    shukanList=`cat ${SHUKAN_CSV} | grep ${userId} | sed 's/\"//g' | awk -F, '{print $2}'`
    if [ -z "${shukanList}" ]
    then
        continue
    fi

    # 主管コード設定
    set_shukan ${userId} "${shukanList[*]}"
	
	outlog_func UM-I08011 ${userId} "${shukanList[*]}"

done < ${SHUKAN_DIFF_USER_LIST}

mv ${SHUKAN_CSV} ${SHUKAN_CSV_OUT}
outlog_func UM-I08008 "${SHUKAN_CSV_OUT}"

rm -f ${COOKIE_FILE}

# 処理終了ログ出力
outlog_func UM-I08002

echo "主管追加処理終了" >> ${DETAIL_LOG}
# 終了
exit 0