#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S030102_DATA_INSERT.sh
# 業 務 名       ： フロー処理（経費振込み）
# 処理概要       ： 経費振込みデータをGWに登録
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： N.Asada 
#
# 作成日付       ： 2009-07-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-16 N.Asada                新規作成
# 2 1.0.0 2009-09-14 N.Asada                ヘッダー追加
# 3 1.2.0 2009-12-21 M.Saiki                importリトライ追加
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################################
# 経費振替CSV作成関数
##########################################################################
function keihi_hurikae {

    ${PERL_DIR}/S030102_CREATE_CSV.pl ${1} ${CSV_OUT_DIR}/${FILE_S030102}.csv ${FILE_S030102} > ${DETAIL_LOG_TMP}
    rc=$?
    while read id msg
    do
        outlog_func ${id} ${msg}
    done < ${DETAIL_LOG_TMP}
    
    if [ ${rc} != "0" ];then
        return 1
    else
        return 0
    fi
}

#################################
# main処理
#################################################################

#環境設定を行う
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [[ ! -f ${_exec_ksh} ]];then
    echo "[経費振替IF取り込み] バッチ環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${S030102_MAIN_FLOW_LOG}

outlog_func CT-I02001

# 一時ファイル
_tmp="${TMP_DIR}/S030102_DATA_INSERT.tmp"
# DB登録用シェル名
_shname="S030102_DATA_INSERT.sh"

# 経費振替PPファイル存在確認
#if [[ ! -f ${PP_FILE_PATH}/${FILE_S030102} ]];then

   # PPバックアップファイル名にOKが無いものを取得（正常終了しなかったPPファイル）
   _FILE_S030102_BAK=`ls ${PPFILE_BACKUP_DIR} | grep ${FILE_S030102} | grep -v OK | head -1`

    # PPバックアップファイルの末尾が全てOK
    if [[ -z ${_FILE_S030102_BAK} ]];then

	# 経費振替PPファイルが存在しない
    	outlog_func CT-W02005 ${FILE_S030102}

        # 処理対象ファイルが存在しないので終了
        exit 0

    # PPバックアップファイルの末尾がOKでないものがある
    else

	# ディレクトリパスを付与
	_FILE_S030102_BAK="${PPFILE_BACKUP_DIR}/${_FILE_S030102_BAK}"

        # 経費振替CSV作成関数呼び出し
        keihi_hurikae ${_FILE_S030102_BAK}
        # エラー判定
        if [[ $? != "0" ]];then

            outlog_func CT-E02006

            # CSV削除
            rm -f ${CSV_OUT_DIR}/${FILE_S030102}.csv

            exit 1
        fi  

    fi
#else

    # 経費振替PPファイルのバックアップを作成
#    _FILE_S030102_BAK=${PPFILE_BACKUP_DIR}/${FILE_S030102}.`date +%Y%m%d%H%M`
#    mv ${PP_FILE_PATH}/${FILE_S030102} ${_FILE_S030102_BAK}

    # 経費振替CSV作成関数呼び出し
#    keihi_hurikae "${_FILE_S030102_BAK}"
    # エラー判定
#    if [[ $? != "0" ]];then

#        outlog_func CT-E02009

		# CSV削除
#		rm -f ${CSV_OUT_DIR}/${FILE_S030102}.csv

#        exit 1
#    fi
#fi

# DB接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func CT-E02007 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# CSV削除
	rm -f ${CSV_OUT_DIR}/${FILE_S030102}.csv

	# エラー終了
	exit 1
fi
echo "" >> ${SQLLOG_TMP}

# CSVファイルが存在すればDBにインサートを行う
if [[ -f ${CSV_OUT_DIR}/${FILE_S030102}.csv ]];then
	# 経費振替CSVインポート
nkf --ic=CP932 --oc=UTF-8 ${CSV_OUT_DIR}/${FILE_S030102}.csv > ${CSV_OUT_DIR}/${FILE_S030102}.csv.utf8

	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do	
		db2 import from ${CSV_OUT_DIR}/${FILE_S030102}.csv.utf8 of del messages ${_tmp} INSERT_UPDATE into ${TABLE_S030102} > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	
		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${DB_NAME}"

			connectDB ${DB_NAME}

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done
			
	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CT-E02008 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}

		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_S030102}.csv
		rm -f ${CSV_OUT_DIR}/${FILE_S030102}.csv.utf8

		# エラー終了
		exit 1
	fi
	echo "" >> ${SQLLOG_TMP}
	# 正常終了したPPファイルの末尾にOKをつける
	mv ${_FILE_S030102_BAK} ${_FILE_S030102_BAK}.OK
fi

# DB切断
db2 terminate > ${_tmp}

# 作成したCSVファイルを削除
rm -f ${CSV_OUT_DIR}/${FILE_S030102}.csv
rm -f ${CSV_OUT_DIR}/${FILE_S030102}.csv.utf8
rm -f ${_tmp}

outlog_func CT-I02002
exit 0
