#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： CHOUHYOU_FLAG.sh
# 業 務 名       ： なし
# 処理概要       ： 証憑データJIRA反映
# 特記事項       ： 起動トリガー：JP1
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Tsuruha
#
# 作成日付       ： 2009-06-01
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-06-01 S.Tsuruha              新規作成
# 2 1.0.1 2010-04-22 H.Someya               コメント修正
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
    if [[ -r ${x} ]]
    then
        . ${x}
    else
        echo "Cannot read common env file. ( ${x} )."
        exit 1
    fi
done

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 開始ログ出力
outlog_func SH-I08001

# JIRA帳票有無フラグ更新、GW帳票有無反映フラグ更新
java -classpath "${JAVA_CLASSPATH}" com.ibm.jirax.batch.UpdateHasFormsAllBatch >> ${LOG_DIR}/SHOHYO_MAIN_FLOW.log 2>&1
RC=$?
case ${RC} in
        0)      outlog_func SH-I08010 "" ${RC};;
        10)     outlog_func SH-I08011 "" ${RC};;
        *)      outlog_func SH-E08012 "" ${RC}
                exit 1;;
esac

# 終了ログ出力
outlog_func SH-I08002

exit 0
