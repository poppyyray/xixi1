#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： WORK_ITEM_UPDATE_UNMATCH.sh
# 業 務 名       ： ワークアイテム更新（入金アンマッチ承認完了）
# 処理概要       ： GWとWFのDBより承認済かつ残高が０でないデータを抽出し
#                   該当するデータのステータスを「委託先担当処理待ち」に更新する。
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： GWDB,JIRADB
#
################### モジュール説明 ########################
################### 改定履歴       ########################
# 作成者         ： K.Yamaguchi
#
# 作成日付       ： 2009-07-15
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#  1.0.0  2009-07-15 K.Yamaguchi            新規作成
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
# GWのDBへ接続する
#########################################################################
function gwdb_connect
{
	# GWDB接続
	db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-E13004 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}
	return 0
}

#########################################################################
# WFのDBへ接続する
#########################################################################
function jiradb_connect
{
	# WF側DBへ接続
	db2 connect to ${JIRA_DB_NAME}  > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-E13005 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}
	return 0
}
#########################################################################
# DBへの接続を破棄する。
#########################################################################
function db_disconnect
{
	db2 terminate > /dev/null

}

#########################################################################
# pkeyよりjiraのデータを一件取得。
# 引数: PKEY_CD
# 戻り値: 0:正常
# 		1:異常
#		2:データ０件
#########################################################################
function jira_select
{
	# PKEY_CDと一致＆残高０以外のデータを取得
	db2 "export to ${_wfSelTmp} of del lobs to ${TMP_DIR} lobfile ${LOB_FILE} select pkey,actionbody FROM ${SCHEMA_NAME}JIRAISSUE JIS,${SCHEMA_NAME}JIRAACTION JAC where pkey = '${1}' AND JAC.issueid=JIS.id order by JAC.updated asc fetch first 1 rows only" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-E13006 ${1} "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# SQL結果ファイル存在チェック
	if [ ! -f ${_wfSelTmp} ]
	then
		outlog_func UD-E13007 ${_wfSelTmp}
		return 1
	fi
	# SQL結果サイズチェック( 0バイトは対象0件 )
	if [ ! -s ${_wfSelTmp} ]
	then
		return 2
	fi
		
	return 0
}

#########################################################################
# pkeyデータからjiraのデータを更新。
# 戻り値: 0:正常
# 		1:異常
#########################################################################
function jira_update
{	
	jira_pkey=${1}
	jira_zandaka=${2}

	# ステップIDを更新する(OS_CURRENTSTEP)
	db2 +c "update ${SCHEMA_NAME}OS_CURRENTSTEP set step_id=${UPDATE_STEP_ID} where ${SCHEMA_NAME}OS_CURRENTSTEP.entry_id=(select workflow_id from ${SCHEMA_NAME}JIRAISSUE where pkey='${jira_pkey}')" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-E13008 ${jira_pkey} "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		db2 rollback > /dev/null
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# ステータスを更新する(JIRAISSUE)
	db2 +c "update ${SCHEMA_NAME}JIRAISSUE set issuestatus='${UPDATE_ISSUE_STATUS}' where pkey='${jira_pkey}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-E13009 ${jira_pkey} "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		db2 rollback > /dev/null
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# JIRAの消込残高更新(CUSTOMFIELDVALUE)
    db2 +c "update ${SCHEMA_NAME}CUSTOMFIELDVALUE CFV set CFV.numbervalue = ${jira_zandaka} where CFV.issue = (select ID from ${SCHEMA_NAME}JIRAISSUE where pkey='${jira_pkey}') and CFV.customfield = (select id from ${SCHEMA_NAME}CUSTOMFIELD where cfname = '${KESHIKOMI_CFNAME}')" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-E13010 ${jira_pkey} ${jira_zandaka} "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		db2 rollback > /dev/null
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}
	
	db2 commit > /dev/null
	return 0
}
#########################################################################
# JIRAの更新が完了したデータの承認済みカラムをNullに更新する
# 引数: PKEY_CD
# 戻り値: 0:正常
# 		1:異常
#########################################################################
function gw_update
{
	pkey_cd=${1}

	# PKEY_CDのデータを更新する
    db2 "update ${TABLE_S030104} set SHOUNINZUMI = null where PKEY_CD = '${pkey_cd}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-E13011 ${pkey_cd} "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	return 0
}
#########################################################################
# 入金データアンマッチ承認完了
#########################################################################
function unmatch
{
	## GWDBに接続する		
	gwdb_connect
	if [ $? != '0' ]
	then
		#DB接続でエラー発生
		outlog_func UD-E13015
		return 1
	fi
	
	### GW（入金データアンマッチTBL）より承認済データ取得 ###############################################
	# 承認済みデータ取得SQL実行
	db2 -tvf ${GW_SQL_FILE} > ${SQLLOG_TMP};
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-E13012 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}
	
	## GWDBを切断する	
	db_disconnect ${DB_NAME}

	# SQL結果ファイル存在チェック
	if [ ! -f ${_gwSelTmp} ]
	then
		outlog_func UD-E13013
		return 1
	fi
	# SQL結果サイズチェック( 0バイトはマッチング0件 )
	if [ ! -s ${_gwSelTmp} ]
	then
		#入金データアンマッチTBL検索SQLの結果が0件の場合
		#バッチ処理対象０件となるので正常終了としてバッチを終わらせる。
		outlog_func UD-I13014
		return 0
	fi

	# csvファイルを整形
	sed -e s/\"//g ${_gwSelTmp} > ${_gwSelList}

	if [ ! -e ${_gwSelList} ]   #整形した結果を格納した_gwSelListファイルが存在しない場合、エラー終了
	then
		outlog_func UD-E13017
	    return 1
	fi

	### JIRAより承認済データの取得及び更新 ###############################################

	## WFDBに接続する	
	jiradb_connect
	if [ $? != '0' ]
	then
		#DB接続でエラー発生
		return 1
	fi

	#GW更新用に残高が０でないPKEYのリストファイルを作成する。(空のファイルで初期化)
	cat /dev/null > ${_gwUpdateList_zandakaNotZero}
		
	##承認済みのデータ件数分ループする。
	while read pkey_cd
	do
		## WFDBからデータを１件取得
		jira_select ${pkey_cd}
		
		result_tmp=${?}

		if [ ${result_tmp} == '1' ]
		then
			#処理異常
			return 1
		elif [ ${result_tmp} == '2' ]
		then
			#検索結果０件
			continue
		fi
		
		#exportされたCLOBデータの残高を読み込む
		zandaka=`cat ${_lobFileName}`
		
		#lobファイル削除
		rm -f ${_lobFileName}
		
		if [ ${zandaka} == '0' ]
		then
			#残高０の場合は処理しない（更新対象外）
			continue
		fi

		#JIRAのステータスを委託先担当処理待ち、消込金額を残高で更新する
		jira_update	${pkey_cd} ${zandaka}
		if [ $? == '1' ]
		then
			#処理異常
			return 1
		fi
		
		#GW更新用に残高が０でないPKEYをリストファイルに追加する。
		echo ${pkey_cd} >> ${_gwUpdateList_zandakaNotZero}
		
	done < ${_gwSelList}

	## WFDBを切断する	
	db_disconnect ${JIRA_DB_NAME}


	### GWの承認済データをNULLに更新 ###############################################

	## GWDBに接続する
	gwdb_connect
	if [ $? != '0' ]
	then
		#DB接続でエラー発生
		outlog_func UD-E13016
		return 1
	fi
	
	##承認済みのデータ件数分ループする。
	while read pkey_cd
	do
		#GW（入金データアンマッチTBL）の承認済データを更新
		gw_update ${pkey_cd}
		if [ $? != '0' ]
		then
			#DB接続でエラー発生
			return 1
		fi
	done < ${_gwUpdateList_zandakaNotZero}
	
	## GWDBを切断する	
	db_disconnect ${DB_NAME}
	
	return 0
}

###############################################################################
# main処理開始
###############################################################################
# ----
# 共通環境変数読み込み
# ----
#環境設定を行う
_batch_cnf=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_batch_cnf} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_batch_cnf}

# ---- 
# 個別環境設定
# ----
# 委託先担当処理待ち更新後のステータスやSTEPID 
export UPDATE_ISSUE_STATUS="10006"
export UPDATE_STEP_ID="6"

#SQLファイル
export GW_SQL_FILE=${SQL_DIR}/WORK_ITEM_UPDATE_UNMATCH_GW_SEL.sql

#消込金額のCFNAME値
export KESHIKOMI_CFNAME="reconcileAmount"

# 一時ファイル変数
export _gwSelTmp=${TMP_DIR}/WORK_ITEM_UPDATE_UNMATCH_SEL01.tmp
export _wfSelTmp=${TMP_DIR}/WORK_ITEM_UPDATE_UNMATCH_SEL02.tmp
export _wfSelSedTmp=${TMP_DIR}/WORK_ITEM_UPDATE_UNMATCH_Sed.tmp
export _gwSelList=${TMP_DIR}/WORK_ITEM_UPDATE_UNMATCH_LIST01.tmp
export _gwUpdateList_zandakaNotZero=${TMP_DIR}/WORK_ITEM_UPDATE_UNMATCH_LIST02.tmp
#LOBファイル名
export LOB_FILE="WORK_ITEM_UPDATE_UNMATCH_LOB"
export _lobFileName=${TMP_DIR}/${LOB_FILE}.001.lob

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${SHONINZUMI_MAIN_FLOW_LOG}

#処理開始メッセージ
outlog_func UD-I13001

db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
db2 "export to ${CSV_OUT_DIR}/unmatch.csv of del select pkey,integer(substr(char(actionbody),1,1)) from jiraschema.jiraaction ja,jiraschema.jiraissue ji where ji.id = ja.issueid and (issueid,ja.updated) in (select issueid,min(updated) from jiraschema.jiraaction where issueid in (select id from jiraschema.jiraissue where pkey like 'UD%' and issuestatus='10039') group by issueid) with ur"
db2 "import from ${CSV_OUT_DIR}/unmatch.csv of del replace into NYUUKINDATAUNMATCH_WORK"
db2 "select 1 from NYUUKINDATAUNMATCH_WORK where zandaka <> 0"
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 1 ]
then
        outlog_func UD-I13002
        exit 0
fi
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func UD-E13012 "${_errmsg}"

        # 一時ファイル等の削除
        rm -f ${SQLLOG_TMP}

        # エラー終了
        exit 1
fi

db2 terminate

##入金データアンマッチ承認完了関数呼出
unmatch
if [ $? != '0' ]   #関数「unmatch」の実行結果の正否を判定
then
	outlog_func UD-E13003
	exit 1
else
	# 一時ファイル削除
	rm -f ${_gwSelTmp}
	rm -f ${_wfSelTmp}
	rm -f ${_wfSelSedTmp}
	rm -f ${_gwSelList}
	rm -f ${_gwUpdateList_zandakaNotZero}
	rm -f ${_lobFileName}
	#処理完了メッセージ
	outlog_func UD-I13002
	exit 0
fi
