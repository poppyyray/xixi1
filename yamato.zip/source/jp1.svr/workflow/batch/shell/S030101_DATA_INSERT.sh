#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S030101_DATE_INSERT.sh
# 業 務 名       ： 入出金材料確認データ登録
# 処理概要       ： 入出金材料確認データをGWに登録
# 特記事項       ： 起動トリガー：JP1により機動
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-07-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-16 T.Sakagami             新規作成
# 2 1.1.0 2009-09-14 Y.Otsuka               処理改訂
# 3 1.2.0 2009-12-21 M.Saiki                importリトライ追加
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################################
# 入出金材料確認CSV作成関数 
##########################################################################
function zairyou_kakunin {

    ${PERL_DIR}/S030101_CREATE_CSV.pl ${1} ${CSV_OUT_DIR}/${FILE_S030101}.csv ${FILE_S030101} > ${DETAIL_LOG_TMP}
    rc=$?
    while read id msg
    do
        outlog_func ${id} ${msg}
    done < ${DETAIL_LOG_TMP}

    if [ ${rc} != "0" ];then
        return 1
    else
        return 0
    fi
}

#################################################################
# main処理
#################################################################
#環境設定を行う
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ];then
    echo "[入出金材料確認IF取り込み] バッチ環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 一時ファイル
_tmp="${TMP_DIR}/S030101_DATA_INSERT.tmp"
# DB登録用シェル名
_shname="S030101_DATA_INSERT.sh"

# 出力ログ名設定
export log_name=${S030101_MAIN_FLOW_LOG}

outlog_func CE-I02001

# 入出金材料確認PPファイル存在確認
#if [ ! -f ${PP_FILE_PATH}/${FILE_S030101} ];then

   # PPバックアップファイル名にOKが無いものを取得（正常終了しなかったPPファイル）
   _FILE_S030101_BAK=`ls ${PPFILE_BACKUP_DIR}| grep ${FILE_S030101} | grep -v OK | head -1`

    # PPバックアップファイルの末尾が全てOK
    if [ -z ${_FILE_S030101_BAK} ];then

	# 入出金材料確認PPファイルが存在しない
    	outlog_func CE-W02005 ${FILE_S030101}

        # 処理対象ファイルが存在しないので終了
        exit 0

    # PPバックアップファイルの末尾がOKでないものがある
    else

	# ディレクトリパスを付与
	_FILE_S030101_BAK="${PPFILE_BACKUP_DIR}/${_FILE_S030101_BAK}"

        # 入出金材料確認CSV作成関数呼び出し
        zairyou_kakunin ${_FILE_S030101_BAK}
        # エラー判定
        if [ $? != "0" ];then

			outlog_func CE-E02006
           
			# CSV削除
			rm -f ${CSV_OUT_DIR}/${FILE_S030101}.csv
           exit 1
        fi  

    fi
#else

    # 入出金材料確認PPファイルのバックアップを作成
#    _FILE_S030101_BAK=${PPFILE_BACKUP_DIR}/${FILE_S030101}.`date +%Y%m%d%H%M`
#    mv ${PP_FILE_PATH}/${FILE_S030101} ${_FILE_S030101_BAK}

    # 入出金材料確認CSV作成関数呼び出し
#    zairyou_kakunin ${_FILE_S030101_BAK}

    # エラー判定
#    if [ $? != "0" ];then

#		outlog_func CE-E02017

		# CSV削除
#		rm -f ${CSV_OUT_DIR}/${FILE_S030101}.csv

#        exit 1
#    fi
#fi

# DB接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func CE-E02007 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# CSV削除
	rm -f ${CSV_OUT_DIR}/${FILE_S030101}.csv

	# エラー終了
	exit 1
fi
echo "" >> ${SQLLOG_TMP}

# CSVファイルが存在すればDBにインサートを行う
if [ -f ${CSV_OUT_DIR}/${FILE_S030101}.csv ];then
	# 入出金材料確認CSVインポート
	nkf --ic=CP932 --oc=UTF-8 ${CSV_OUT_DIR}/${FILE_S030101}.csv > ${CSV_OUT_DIR}/${FILE_S030101}.csv.utf8
	#db2 import from ${CSV_OUT_DIR}/${FILE_S030101}.csv of del messages ${_tmp} INSERT_UPDATE into ${TABLE_S030101} > ${SQLLOG_TMP}
	
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do	
		db2 import from ${CSV_OUT_DIR}/${FILE_S030101}.csv.utf8 of del messages ${_tmp} INSERT_UPDATE into ${TABLE_S030101} > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	
		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${DB_NAME}"

			connectDB ${DB_NAME}

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CE-E02008 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}

		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_S030101}.csv
		rm -f ${CSV_OUT_DIR}/${FILE_S030101}.csv.utf8

		# エラー終了
		exit 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# 正常終了したPPファイルの末尾にOKをつける
	mv ${_FILE_S030101_BAK} ${_FILE_S030101_BAK}.OK
fi

# DB切断
db2 terminate > /dev/null

# 作成したCSVファイルを削除
rm -f ${CSV_OUT_DIR}/${FILE_S030101}.csv
rm -f ${CSV_OUT_DIR}/${FILE_S030101}.csv.utf8
rm -f ${_tmp}

outlog_func CE-I02002

exit 0
