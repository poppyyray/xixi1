#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S030104_DATA_INSERT.sh
# 業 務 名       ： IF取り込み（入金データアンマッチリスト処理）
# 処理概要       ： I/Fファイルを取り込み、ファイルの種類に応じたテーブルに
#               　　データを追加する。
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし　    
# ログファイル   ： ?
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： GWDB
#
#################### 改定履歴       ########################
# 作成者         ： K.Yamaguchi
#
# 作成日付       ： 2009-07-15
#
# =V.R.M= == DATE == = 担当者  =   =準拠文書= ==== 内容 =======
#  1.0.0  2009-07-15 K.Yamaguchi             新規作成
#  1.0.1  2009-07-15 A.Takagi               エラーハンドルを追加
#  1.0.2  2009-07-17 K.Tooi        
#  1.0.3  2009-07-22 A.takagi              1.金額にかかわる項目の処理を修正
#						(変数が空のとき、変数="0"とした。)
#					       2.作成したCSVファイルをcsv_bak/フォルダに
#						移動させる処理を削除。
#  1.1.0  2009-12-21 M.Saiki                importリトライ追加
# =V.R.M= == DATE == = 担当者  =   =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################


##########################################################################
# 入金データアンマッチCSV作成関数
##########################################################################
function nyukindata_unmatch {

    ${PERL_DIR}/S030104_CREATE_CSV.pl ${1} ${CSV_OUT_DIR}/${FILE_S030104}.csv ${FILE_S030104} > ${DETAIL_LOG_TMP}
    rc=$?
    while read id msg
    do
        outlog_func ${id} ${msg}
    done < ${DETAIL_LOG_TMP}
    	
   	if [ ${rc} != "0" ];then
        return 1
    else
        return 0
    fi
}

function main {

# DB登録用シェル名
_shname="S030104_DATA_INSERT.sh"
# 一時ファイル
_tmp="${TMP_DIR}/S030104_DATA_INSERT.tmp"

# 入金データアンマッチPPファイル存在確認
#if [[ ! -f ${PP_FILE_PATH}/${FILE_S030104} ]];then

    # PPバックアップファイル名にOKが無いものを取得（正常終了しなかったPPファイル）
   _FILE_S030104_BAK=`ls ${PPFILE_BACKUP_DIR}| grep ${FILE_S030104} | grep -v OK | head -1`

    # PPバックアップファイルの末尾が全てOK
    if [[ -z ${_FILE_S030104_BAK} ]];then

	# 入金データアンマッチPPファイルが存在しない
	outlog_func UD-W02005 ${FILE_S030104}

	#処理対象ファイルが存在しないので終了
	return 0

    # PPバックアップファイルの末尾がOKでないものがある
    else

	# ディレクトリパスを付与
	_FILE_S030104_BAK="${PPFILE_BACKUP_DIR}/${_FILE_S030104_BAK}"

        # 入金データアンマッチCSV作成関数呼び出し
        nyukindata_unmatch ${_FILE_S030104_BAK}

        # エラー判定
        if [[ $? != "0" ]];then

            outlog_func UD-E02006 

		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_S030104}.csv
           return 1
        fi  

    fi
#else

    # 入金データアンマッチPPファイルのバックアップを作成
#    _FILE_S030104_BAK=${PPFILE_BACKUP_DIR}/${FILE_S030104}.`date +%Y%m%d%H%M`
#    mv -f ${PP_FILE_PATH}/${FILE_S030104} ${_FILE_S030104_BAK}

    # 入金データアンマッチCSV作成関数呼び出し
#    nyukindata_unmatch "${_FILE_S030104_BAK}"

    # エラー判定
#    if [[ $? != "0" ]];then
# 	  outlog_func UD-E02009 
	# CSV削除
#	rm -f ${CSV_OUT_DIR}/${FILE_S030104}.csv

#        return 1
#    fi
#fi

# DB接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func UD-E02007 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}
	
	# CSV削除
	rm -f ${CSV_OUT_DIR}/${FILE_S030104}.csv

	# エラー終了
	return 1
fi
echo "" >> ${SQLLOG_TMP}

# CSVファイルが存在すればDBにインサートを行う
if [[ -f ${CSV_OUT_DIR}/${FILE_S030104}.csv ]];then
	# 入金データアンマッチリスト処理CSVインポート
nkf --ic=CP932 --oc=UTF-8 ${CSV_OUT_DIR}/${FILE_S030104}.csv > ${CSV_OUT_DIR}/${FILE_S030104}.csv.utf8

	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		db2 import from ${CSV_OUT_DIR}/${FILE_S030104}.csv.utf8 of del messages ${_tmp} INSERT_UPDATE into ${TABLE_S030104} > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${DB_NAME}"

			connectDB ${DB_NAME}

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done
		
	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func UD-E02008 "${_errmsg}"
	
		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}
		
		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_S030104}.csv
		rm -f ${CSV_OUT_DIR}/${FILE_S030104}.csv.utf8

		# エラー終了
		return 1
	fi

	# 正常終了したPPファイルの末尾にOKをつける
	mv -f ${_FILE_S030104_BAK} ${_FILE_S030104_BAK}.OK
fi

# DB切断
db2 terminate > /dev/null

}

#################################################################
# main処理
#################################################################

#環境設定を行う
_exec_ksh="/workflow/batch/ini/batch_common.conf"
env_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"

# ----
# 共通環境変数読み込み
# ----
if [[ ! -f ${_exec_ksh} ]];then
    echo "バッチ環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数読み込み
# ----
if [[ ! -f ${env_file_list} ]];then
    echo "バッチ環境共通関数ファイルが存在しません"
    exit 1
fi
. ${env_file_list}

# 出力ログ名設定
export log_name=${S030104_MAIN_FLOW_LOG}

outlog_func UD-I02001

main

if [ $? != '0' ]   #関数「main」の実行結果の正否を判定
then
	#outlog_func UD-I02002
	#CSV削除
	rm -f ${CSV_OUT_DIR}/${FILE_S030104}.csv

	exit 1
else
	#CSV削除
	rm -f ${CSV_OUT_DIR}/${FILE_S030104}.csv
	rm -f ${CSV_OUT_DIR}/${FILE_S030104}.csv.utf8
	rm -f ${_tmp}
	# 一時ファイルの削除
	rm -f ${SQLLOG_TMP}
	outlog_func UD-I02002
	
	exit 0
fi

exit 0
