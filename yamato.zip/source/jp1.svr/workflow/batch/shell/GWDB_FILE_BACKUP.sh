#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： GWDB_FILE_BACKUP.sh
# 業 務 名       ： GWDB旧データ退避
# 処理概要       ： GWDBのテーブルからエクスポートし、
#					作成されたIXFファイルをtar.gz形式でまとめて
#					保存を行う
# 特記事項       ： テーブルリストファイルに記載されているテーブル
# パラメータ     ： なし
# ログファイル   ： GWDB_ARCHIVE_DATE.log
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB        ： GWDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： A.Takagi
#
# 作成日付       ： 2009-11-10
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-11 A.Takagi              新規作成
# 2 1.0.1 2010-02-09 A.Takagi              機能不全対応
# 3 1.0.2 2010-02-21 A.Takagi              機能不全対応
# 4 1.0.3 2010-03-09 A.Takagi              機能不全対応
# 5 1.0.4 2010-03-16 A.Takagi              機能不全対応
#										   TMPファイル削除処理追加
# 6 1.0.5 2010-03-17 A.Takagi              機能不全対応
#                                          テーブルリストファイル存在確認処理追加
# 7 1.0.6 2010-03-19 A.Takagi              tarコマンドの結果を/dev/null へ出すように追加
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
if [ ! -f ${env_file_list} ]
then
	echo "Cannot read common env file. ( ${env_file_list} )."
	exit 1
else
	. ${env_file_list}
fi

# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
if [ ! -f ${conf_file_list} ]
then
	echo "Cannot read common conf file. ( ${conf_file_list}} )."
	exit 1
else
	. ${conf_file_list}
fi

###############################################################################
# GWDB旧データ退避（アーカイブ処理使用）
# 概要：退避されたデータの保存
# 引数１：テーブルリスト
###############################################################################
function GWDB_FILE_COMPRESSION
{

	#引数（テーブルリストファイル名）を変数に代入
	TABLE_LIST=$1

	#テーブルリストファイルが存在するか確認
	if [ ! -f ${TABLE_LIST} ]
	then
			outlog_func AC-E07010 "${TABLE_LIST}"
			return 1
	fi

	#作業日付/モジュール実施日付(詳細)を変数に代入
	#変数WDATEに現在の日付を格納する
	WDATE=`date +%Y%m%d`

	#変数NDATEに現在の日付時分秒を格納する
	NDATE=`date "+%Y%m%d%H%M%S"`

	#テーブルリストファイルを一行ずつ読み、
	#テーブルの数だけループ処理を行う
	while read GWDB_TABLE
	do
		#退避するファイルを検索し、結果をTMPファイルに保存する
		ls -1 ${CSV_OUT_DIR}/${GWDB_TABLE}_${WDATE}*.ixf > ${GWDB_FILE_BACKUP}_${GWDB_TABLE}.tmp 2>&1

		CMD_RESULT=$?

		while read GWDB_FILE
		do
			if [ ${CMD_RESULT} != '0' ]
			then
				#エラーメッセージ
				outlog_func AC-E07009 "${GWDB_TABLE}"

				return 1
			fi

			tar rvf ${BACKUP_DIR}/gwdb_back${NDATE}.tar ${GWDB_FILE} > /dev/null 2>&1
			CMD_ERROR=$?

			if [ ${CMD_ERROR} != '0' ]
			then
				#エラーメッセージ出力
				outlog_func AC-E07005 "${GWDB_FILE}"

				return 1
			fi

			#成功メッセージ出力
			outlog_func AC-I07004 "${GWDB_FILE}"

		done < ${GWDB_FILE_BACKUP}_${GWDB_TABLE}.tmp

	done < ${TABLE_LIST}

	#tarファイルをtar.gz形式に圧縮する
	gzip ${BACKUP_DIR}/gwdb_back${NDATE}.tar
	CMD_ERROR=$?

	if [ ${CMD_ERROR} != '0' ]
	then
		#エラーメッセージ出力
		outlog_func AC-E07006

		return 1
	fi

	#作成したバックアップファイルが存在するか確認する
	if [ ! -e ${BACKUP_DIR}/gwdb_back${NDATE}.tar.gz ]
	then
		#エラーメッセージ出力
		outlog_func AC-E07007

		return 1
	fi

	#テーブルリストファイルを一行ずつ読み、
	#テーブルの数だけループ処理を行う
	#退避するファイルを検索し、結果をTMPファイルに保存する
	while read GWDB_TABLE
	do
		while read GWDB_FILE
		do
			#IXFファイル削除
			rm -f ${GWDB_FILE}

			#メッセージ出力
			outlog_func AC-I07008 "${GWDB_FILE}"

		done < ${GWDB_FILE_BACKUP}_${GWDB_TABLE}.tmp

		#TMPファイル削除
		rm -f ${GWDB_FILE_BACKUP}_${GWDB_TABLE}.tmp

	done < ${TABLE_LIST}

	return 0
}
# ----
# 業務別環境変数設定
# ----
# 出力ログ名設定
export log_name=${GWDB_ARCHIVE_DATE_LOG}

##本シェル使用変数は、batch_common.confを参照してください。
##本シェル使用関数は、BATCH_COMMON_FUNC.shを参照してください。

###############################################################################
# main処理開始
###############################################################################

### 開始メッセージ
outlog_func AC-I07001

#関数GWDB_FILE_COMPRESSION 開始
GWDB_FILE_COMPRESSION ${GWDB_ARCHIVE_TABLE_LIST}
if [ $? != '0' ]
then
    outlog_func AC-E07003 "GWDB_FILE_COMPRESSION"
    exit 1
fi


## 終了メッセージ
outlog_func AC-I07002

#戻り値0を返す
exit 0
