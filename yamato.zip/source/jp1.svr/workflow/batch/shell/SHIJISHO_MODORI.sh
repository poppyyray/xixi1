#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： SHIJISHO_MODORI.sh
# 業 務 名       ： なし
# 処理概要       ： 証憑マッチングデータ反映（指示書回収）
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし
# リターンコード ： 0             正常
#                   1             異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-12-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2009-12-08 T.Sakagami                新規作成
# 2 1.0.1 2010-04-22 H.Someya               コメント修正
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_sh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_sh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_sh}

#########################################################################
# 共通関数呼び出し
#########################################################################
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${SHOHYO_MAIN_FLOW_LOG}

outlog_func SH-I09001

# キューテーブル監視
java -classpath "${JAVA_CLASSPATH}" com.ibm.jirax.batch.WithdrawDirectiveBatch > ${TMP_DIR}/SHIJISHO_JAVA.log 2>&1
RC=$?
if [ ${RC} != '0' ]
then
	errmsg=`cat ${TMP_DIR}/SHIJISHO_JAVA.log`
	outlog_func SH-E09003 ${RC} "${errmsg}"
	exit 1
fi

# 終了ログ出力
outlog_func SH-I09002

exit 0
