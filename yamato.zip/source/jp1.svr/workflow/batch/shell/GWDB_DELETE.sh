#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： GWDB_DELETE.sh
# 業 務 名       ： GWDB旧データ退避
# 処理概要       ： GWDBから旧データを削除
# 特記事項       ：
# パラメータ     ： なし
# ログファイル   ： GWDB_ARCHIVE_DATE.log
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB        ： GWDB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： A.Takagi
#
# 作成日付       ： 2009-09-11
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-11 A.Takagi              新規作成
# 2 1.0.1 2010-02-21 A.Takagi              アーカイブ機能不全対応
# 3 1.0.2 2010-03-09 A.Takagi              アーカイブ機能不全対応
# 4 1.0.3 2010-03-16 A.Takagi              機能不全対応
#                                          変数SQLERROR出力処理追加
# 5 1.0.4 2010-03-19 A.Takagi              null文字対応追加
#                                          削除パターン３・４追加
#                                          変数EXPORT_CNTの変数宣言を変更
#6 1.0.5 2015-03-20 Tang                   削除コミット処理の修正
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 引数の確認
# ----
PARM_CNT=$#
if [ ${PARM_CNT} -ne 2 ]
then
	echo "Argument has not been set correctly"
	exit 1
fi

# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
if [ ! -f ${env_file_list} ]
then
	echo "Cannot read common env file. ( ${env_file_list} )."
	exit 1
else
	. ${env_file_list}
fi
# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
if [ ! -f ${conf_file_list} ]
then
	echo "Cannot read common conf file. ( ${conf_file_list}} )."
	exit 1
else
	. ${conf_file_list}
fi

###############################################################################
# GWDB旧データ削除１（アーカイブ処理使用）
# 概要：案件終了したデータを削除する。
#       「証憑データ」・「承認済みデータ」は更新日時が20日以上前のものを削除する。
# 引数１：削除対象のテーブル名
# 引数２：削除条件を判別する数値("1"または"2")
###############################################################################
function GWDB_DELETE
{

	#テーブル名・削除パターンを変数に格納
	TABLE=$1
	PATTERN=$2

	#変数WDATEに現在の日付を格納する
	WDATE=`date +%Y-%m-%d`

	#削除データが存在するか確認する
	#変数EXPORT_CNTにGWDB_EXPORT.sh　にてEXPORTした件数を格納する
	EXPORT_CNT=`grep ${WDATE} ${LOG_DIR}/${log_name}.log | grep GWDB_EXPORT | grep AC-I05007 | grep ${TABLE} | tail -1 | cut -d '"' -f2`

	if [ "${EXPORT_CNT}" = "0" ]
	then
		outlog_func AC-I06005 "${TABLE}"

		#戻り値"0"を返し、メイン処理へ戻る
		return 0
	elif [ -z "${EXPORT_CNT}" ]
	then
		outlog_func AC-E06018 "${TABLE}"

		#戻り値"0"を返し、メイン処理へ戻る
		return 1
	fi

	#削除前のテーブル総件数を取得する
	db2 "select count(*) from ${TABLE}" > ${SQLLOG_TMP} 2>&1

	# 変数SQLERROR にSQLの戻り値を格納する
	SQLERROR=$?

	# 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
	echo -e "日付:`date` || shell名:GWDB_DELETE.sh || 行番号:`expr ${LINENO} - 4` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# 変数SQLERRORの値が"0"または"1"以外の場合、以下の処理を実施する
	if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E06007 "${TABLE}" "${_errmsg}" "${SQLERROR}"

		#一時ファイル削除
		rm -f ${SQLLOG_TMP}

		return 1
	fi

	#件数を変数BF_CNTに代入する
	BF_CNT=`head -4 ${SQLLOG_TMP} | tail -1 | grep -oE "[[:digit:]]{1,}"`

	#変数BF_CNT をログファイルに出力する
	outlog_func AC-I06006 "${TABLE}" "${BF_CNT}"

	#変数SQLSTATUS に"0" を格納する
	SQLSTATUS=0

	#削除対象テーブルから削除条件に一致したデータをDELETEする
	#変数PATTERNの値を確認する
	#変数PATTERNの値が"1"の場合、以下の処理を実施
	if [ "${PATTERN}" = '1' ]
	then
		while [ ${SQLSTATUS} -eq 0 ]
		do

			#削除SQLの実施
			db2 +c "delete from (
			select * from ${TABLE} where date(kousinnichiji) <= (values current date ${GWDB_DAY} days) and
			PKEY_CD not in (select pkey from MISHORI_ISSUE) fetch first ${AD_DELETE_COUNT} rows only)" > ${SQLLOG_TMP} 2>&1

			# 変数SQLSTATUS にSQLの戻り値を格納する
			SQLSTATUS=$?

			# 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
			echo -e "日付:`date` || shell名:GWDB_DELETE.sh || 行番号:`expr ${LINENO} - 4` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 変数SQLSTATUSの値が"0"または"1"以外の場合、以下の処理を実施する
			if [ ${SQLSTATUS} != '0' -a ${SQLSTATUS} != '1' ]
			then
				# エラーログ出力
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func AC-E06008 "${TABLE}" "${_errmsg}" "${SQLSTATUS}"

				#一時ファイル削除
				rm -f ${SQLLOG_TMP}

				return 1
			fi
			
			db2 commit > /dev/null
			
			if [ ${SQLSTATUS} -eq 1 ]
			then
				break
			fi
		done
	#変数PATTERNの値が"2"の場合、以下の処理を実施
	elif [ "${PATTERN}" = '2' ]
	then
		while [ ${SQLSTATUS} -eq 0 ]
		do
			#削除SQLの実施
			db2 +c "delete from (
			select * from ${TABLE} where date(KOUSINNICHIJI) <= (values current date ${DAY_SHOHYO_DATA} days)
			fetch first ${AD_DELETE_COUNT} rows only)" > ${SQLLOG_TMP} 2>&1

			# 変数SQLSTATUS にSQLの戻り値を格納する
			SQLSTATUS=$?

			# 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
			echo -e "日付:`date` || shell名:GWDB_DELETE.sh || 行番号:`expr ${LINENO} - 4` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 変数SQLSTATUSの値が"0"または"1"以外の場合、以下の処理を実施する
			if [ ${SQLSTATUS} != '0' -a ${SQLSTATUS} != '1' ]
			then
				# エラーログ出力
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func AC-E06009 "${TABLE}" "${_errmsg}" "${SQLSTATUS}"
				#一時ファイル削除
				rm -f ${SQLLOG_TMP}
				return 1
			fi

			db2 commit > /dev/null

			if [ ${SQLSTATUS} -eq 1 ]
			then
				break
			fi
		done
	#変数PATTERNの値が"3"の場合、以下の処理を実施
	elif [ "${PATTERN}" = '3' ]
	then
			while [ ${SQLSTATUS} -eq 0 ]
		do

			#削除SQLの実施
			db2 +c "delete from (
			select * from ${TABLE} where date(sakuseinichiji) <= (values current date ${GWDB_DAY} days) and
			PKEY_CD not in (select pkey from MISHORI_ISSUE) fetch first ${AD_DELETE_COUNT} rows only)" > ${SQLLOG_TMP} 2>&1

			# 変数SQLSTATUS にSQLの戻り値を格納する
			SQLSTATUS=$?

			# 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
			echo -e "日付:`date` || shell名:GWDB_DELETE.sh || 行番号:`expr ${LINENO} - 4` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 変数SQLSTATUSの値が"0"または"1"以外の場合、以下の処理を実施する
			if [ ${SQLSTATUS} != '0' -a ${SQLSTATUS} != '1' ]
			then
				# エラーログ出力
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func AC-E06016 "${TABLE}" "${_errmsg}" "${SQLSTATUS}"

				#一時ファイル削除
				rm -f ${SQLLOG_TMP}

				return 1
			fi

			db2 commit > /dev/null
			
			if [ ${SQLSTATUS} -eq 1 ]
			then
				break
			fi
		done
	#変数PATTERNの値が"4"の場合、以下の処理を実施
	elif [ "${PATTERN}" = '4' ]
	then
		while [ ${SQLSTATUS} -eq 0 ]
		do
			#削除SQLの実施
			db2 +c "delete from (
			select * from ${TABLE} where date(sakuseinichiji) <= (values current date ${DAY_SHOUNINZUMI_DATA} days)
			fetch first ${AD_DELETE_COUNT} rows only)" > ${SQLLOG_TMP} 2>&1

			# 変数SQLSTATUS にSQLの戻り値を格納する
			SQLSTATUS=$?

			# 変数SQLLOG_TMPの内容を変数DETAIL_LOGに格納する。
			echo -e "日付:`date` || shell名:GWDB_DELETE.sh || 行番号:`expr ${LINENO} - 4` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

			# 変数SQLSTATUSの値が"0"または"1"以外の場合、以下の処理を実施する
			if [ ${SQLSTATUS} != '0' -a ${SQLSTATUS} != '1' ]
			then
				# エラーログ出力
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func AC-E06017 "${TABLE}" "${_errmsg}" "${SQLSTATUS}"

				#一時ファイル削除
				rm -f ${SQLLOG_TMP}

				return 1
			fi

			db2 commit > /dev/null

			if [ ${SQLSTATUS} -eq 1 ]
			then
				break
			fi
		done
	else
		#エラーログ出力
		outlog_func AC-E06015

		#エラー終了
		return 1
	fi

	#削除後のテーブル総件数を取得する
	db2 "select count(*) from ${TABLE}" > ${SQLLOG_TMP} 2>&1

	SQLERROR=$?
	echo -e "日付:`date` || shell名:GWDB_DELETE.sh || 行番号:`expr ${LINENO} - 4` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

	# 変数SQLERRORの値が"0"以外の場合、以下の処理を実施する
	if [ ${SQLERROR} != '0' ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E06011 "${TABLE}" "${_errmsg}" "${SQLERROR}"

		#一時ファイル削除
		rm -f ${SQLLOG_TMP}

		return 1
	fi

	#件数を変数AF_CNTに代入する
	AF_CNT=`head -4 ${SQLLOG_TMP} | tail -1 | grep -oE "[[:digit:]]{1,}"`

	#変数AF_CNT をログファイルに出力する
	outlog_func AC-I06010 "${TABLE}" "${AF_CNT}"

	#削除件数が正しいか確認する
	DELETE_CNT=`expr ${BF_CNT} - ${AF_CNT}`

	#等しくない場合エラーメッセージを出力する
	if [ "${EXPORT_CNT}" != "${DELETE_CNT}" ]
	then

		outlog_func AC-E06013 "${TABLE}" "${EXPORT_CNT}" "${DELETE_CNT}"

		return 1
	fi

	outlog_func AC-I06012 "${TABLE}"
	outlog_func AC-I06014 "${TABLE}"

	return 0
}


# ----
# 業務別環境変数設定
# ----
# 出力ログ名設定
export log_name=${GWDB_ARCHIVE_DATE_LOG}

##本シェル使用変数は、batch_common.confを参照してください。
##本シェル使用関数は、BATCH_COMMON_FUNC.shを参照してください。

###############################################################################
# main処理開始
###############################################################################

#引数(テーブル名・削除パターン)を変数に保存する
DELETE_TABLE=$1
DELETE_PATTERN=$2

### 開始メッセージ
outlog_func AC-I06001 "${DELETE_TABLE}"

# GWDB接続
connectDB ${DB_NAME}
if [ $? != '0' ]
then
    outlog_func AC-E06003 "connectDB"
    exit 1
fi

# GWDBから旧データを削除1
# 変数${DAY}に出力対象日数を指定
# 変数{DLETE_COUNT}に削除件数を指定
# 案件終了し、保管期間を超過したデータ削除
GWDB_DELETE "${DELETE_TABLE}" "${DELETE_PATTERN}"
if [ $? != '0' ]
then
    outlog_func AC-E06004 "GWDB_DELETE"
    exit 1
fi

## 終了メッセージ
outlog_func AC-I06002 "${DELETE_TABLE}"

#戻り値0を返す
exit 0
