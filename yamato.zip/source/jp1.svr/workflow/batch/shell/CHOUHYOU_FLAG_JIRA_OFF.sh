#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： CHOUHYOU_FLAG_JIRA_OFF.sh
# 業 務 名       ： 証憑データ
# 処理概要       ： 帳票の有無を決めるフラグを変更する
#				    JIRA未起動の場合のJIRADBを直接変更するためのシェル
# 特記事項       ： 起動トリガー：SHOHYO_SUB_FLOW.shから呼び出し
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： N.Asada 
#
# 作成日付       ： 2009-07-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-16 N.Asada                新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ---- 
# 関数「帳票有入力予定通番の抽出」
# ----
function chouhyou_exist
{
	db2 connect to ${GW_DB} > ${SQLLOG_TMP}
	SQLERROR=$?
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func SH-E08004 "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	while read table_name1	# LISTFILEに定義したテーブル分、以下の処理を実行
	do
		# 各テーブル用に準備したDDLを実行(マッチング証憑ID未記入行をexport)
		db2 -tvf ${SQL}${table_name1} > ${SQLLOG_TMP}
		SQLERROR=$?
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func SH-E08005 "${table_name1}" "${_errmsg}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi

		if [ ! -e ${tmp1}${table_name1} ]	# DDLの結果を格納したテンポラリファイルが存在しない場合、エラー終了
		then
			# エラーログ出力
			outlog_func SH-I08006 "${table_name1}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi
	done < ${LISTFILE}
	
	db2 terminate > /dev/null

	return 0
}
# ---- 
# 関数「帳票有入力」
# ----
function chouhyou_input
{
	while read table_name1
	do
		sed s/,/" "/g ${tmp1}${table_name1} | sed -e s/\"/""/g  >${tmp2}${table_name1}	  # 下記のループ分に読み込み可能な形に整形
		if [ ! -e ${tmp2}${table_name1} ]								 # 整形した結果を格納したテンポラリファイルが存在しない場合、エラー終了
		then
			return 1
		fi

		while read gyoumuID_tmp pkey_cd_tmp					 # テンポラリファイルの行数分、以下の処理を実行
		do


			# 帳票を有りに変更
			db2 "update ${SCHEMA_NAME}JIRAISSUE set REPORTER = 'form' where PKEY = '${pkey_cd_tmp}'" > ${SQLLOG_TMP}
			SQLERROR=$?
			# DBエラー
			if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
			then
				# エラーログ出力	
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func SH-E08007 "${pkey_cd_tmp}" "${gyoumuID_tmp}" "${_errmsg}"

				# 一時ファイル等の削除
				rm -f ${SQLLOG_TMP}

				# エラー終了
				return 1
			fi
			outlog_func SH-I08008 "${pkey_cd_tmp}" "${gyoumuID_tmp}"

			# 帳票を有りに変更
			db2 "update ${table_name1} set chohyo_umu_haneizumi = 'Y' where pkey_cd = '${pkey_cd_tmp}'" > ${SQLLOG_TMP}
			SQLERROR=$?
			# DBエラー
			if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
			then
				# エラーログ出力	
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func SH-E08009 "${table_name1}" "${_errmsg}"

				# 一時ファイル等の削除
				rm -f ${SQLLOG_TMP}

				# エラー終了
				return 1
			fi
			
		done < ${tmp2}${table_name1}

	done < ${LISTFILE}

	return 0
}
# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
	if [[ -r ${x} ]]
	then
		. ${x}
	else
		echo "Cannot read common env file. ( ${x} )."
		exit 1
	fi
done
# ---- 
# 個別環境設定
# ----
LISTFILE=${CONF_DIR}/table_list		# テーブル名リスト(暫定)
SQL=${SQL_DIR}/chouhyou_sql/		# 「帳票有」入力表一時外だし用SQL(暫定)
GW_DB=${DB_NAME}
table_name1=						# LISTFILEから指定した１テーブル名
tmp1=${TMP_DIR}/ichijifile1.		# 一時ファイル(暫定)
tmp2=${TMP_DIR}/ichijifile2.		# 一時ファイル(暫定)
tmp3=${TMP_DIR}/ichijifile3.		# 一時ファイル(暫定)
sqltmp1=${TMP_DIR}/sqltmp1			# SQL一時格納ファイル

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func SH-I08001

# ---- 
# 処理開始
# ----
chouhyou_exist
if [ $? != '0' ]
then
	outlog_func SH-E08003
	exit 1
fi

# JIRA側DBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func SH-E08004 "${_errmsg}"

	# 一時ファイル等の削除
	rm -f ${SQLLOG_TMP}

	# エラー終了
	return 1
fi

chouhyou_input
if [ $? != '0' ]
then
	outlog_func SH-E08003
	exit 1
fi

# JIRA側DBから切断
db2 terminate > /dev/null

# ---- 
# 終了処理
# ----
outlog_func SH-I08002

exit 0
