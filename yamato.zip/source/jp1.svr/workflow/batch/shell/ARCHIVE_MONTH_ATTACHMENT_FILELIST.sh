#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ARCHIVE_MONTH_ATTACHMENT_FILELIST.sh
# 業 務 名       ： なし
# 処理概要       ： アーカイブ対象リストを作成する(月次)
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0             正常
#                   1             エラー
# 対象DB         ： 参照JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Tsuruha
#
# 作成日付       ： 2009-06-01
#
# = V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 初版   2009-06-01 S.Tsuruha                新規作成
# 2 1.0.1  2010-11-22 jingwei.zhou             エラー処理追加
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func AC-I10044

# attachmentファイルリストが存在する場合削除する
if [ -f ${CSV_OUT_DIR}/attachment_month_file_list.csv ]
then
        rm -f ${CSV_OUT_DIR}/attachment_month_file_list.csv
fi

#参照JIRAに接続
db2 connect to ${RF_JIRA_DB} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func AC-E10045 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f ${SQLLOG_TMP}

	# エラー終了
	exit 1
fi
echo "" >> ${SQLLOG_TMP}

db2 -x "export to ${CSV_OUT_DIR}/attachment_month_file_list.csv of del modified by nochardel 
select pr.pkey,ji.pkey
from 
	jiraschema.fileattachment fa 
LEFT OUTER JOIN
	jiraschema.jiraissue ji ON
	fa.issueid = ji.id
LEFT OUTER JOIN
	jiraschema.project pr ON
	pr.id = ji.project
where fa.issueid in 
(select id from 
jiraschema.jiraissue 
where 
date(updated) <= (values current date ${MONTHLY} days) and 
issuestatus = '${STATUS_COMPLETION}')" 
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func AC-E10046 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f ${SQLLOG_TMP}

	# エラー終了
	exit 1
fi
echo "" >> ${SQLLOG_TMP}

db2 terminate

outlog_func AC-I10047

exit 0