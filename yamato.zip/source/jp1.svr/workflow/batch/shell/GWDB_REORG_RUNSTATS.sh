#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： GWDB_REORG_RUNSTATS.sh
# 業 務 名       ： GWDB_REORG_RUNSTATS
# 処理概要       ： GWDBを_REORG_RUNSTATS
# 特記事項       ： 事業所マスタ、ユーザーマスタ以外の
#                   テーブルが対象
# パラメータ     ： なし
# ログファイル   ： House_Keep.log
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB        ： GWDB 
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： A.Takagi
#
# 作成日付       ： 2009-09-11
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-11 A.Takagi              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
        if [[ -r ${x} ]]
        then
            . ${x}
        else
            echo "Cannot read common env file. ( ${x} )."
            exit 1
        fi
done
# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
for y in ${conf_file_list}
do
        if [[ -r ${y} ]]
        then
            . ${y}
        else
            echo "Cannot read common conf file. ( ${y} )."
            exit 1
        fi
done

# ---- 
# 業務別環境変数設定
# ----

##本シェル使用変数は、batch_common.confを参照してください。
##本シェル使用関数は、BATCH_COMMON_FUNC.shを参照してください。

###############################################################################
# main処理開始
###############################################################################
# 出力ログ名設定
export log_name=${GWDB_ARCHIVE_DATE_LOG}

### 開始メッセージ
outlog_func AC-I10036

### メイン処理 ###

# GWDBに対し、REORG/RUNSTATS
# 変数${GWDB_TABLELIST}に対象テーブルリストファイルを指定
REORG_RUNSTATS ${GWDB_TABLELIST_REORG_RUSTATS}
if [ $? != 0 ]
then
    outlog_func AC-E10033 "REORG_RUNSTATS"
    exit 1
fi

## 終了メッセージ
outlog_func AC-I10037
