#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： USER_DELETE.sh
# 業 務 名       ： なし
# 処理概要       ： JIRAに登録されたユーザの削除
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Tsuruha 
#
# 作成日付       ： 2009-07-26
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-26 S.Tsuruha              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません" 
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${USER_MAIN_FLOW_LOG}

# ディレクトリ移動
cd ${SHELL_DIR}

# ----
# 関数「論理削除チェック」
# ----
function update_user_data_jira_old
{
db2 -tvf ${SQL_DIR}/update_user_data_jira_old_delete.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E04076 "${_errmsg}"

                # エラー終了
                return 1
        fi
        return 0
}

# ----
# 関数「差分チェック_ユーザ削除」
# ----
function make_csv_delete
{
db2 -tvf ${SQL_DIR}/make_csv_delete.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        # DBエラー
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
                # エラーログ出力        
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func UM-E04077 "${_errmsg}"

                # エラー終了
                return 1
        fi
	# 行頭の+を削除
	sed -i "s/+//g" ${CSV_OUT_DIR}/user_delete.csv
	# .を削除
	sed -i "s/\.//g" ${CSV_OUT_DIR}/user_delete.csv
	# "を削除
	sed -i "s/\"//g" ${CSV_OUT_DIR}/user_delete.csv
	# スペースを削除
	sed -i "s/ //g" ${CSV_OUT_DIR}/user_delete.csv
      
	return 0
}

# ----
# 関数「ユーザ削除_ログイン情報」
# ----
function delete_user_logindata
{
	# ファイル読み込み時のセパレートを設定
	IFS_org=${IFS}
	IFS=,

	# ユーザ削除情報を読み込む
	while read kojinbangou ninmei_level kanji_simei shukan_code password system_code
	do
		fullname=`echo "${kanji_simei}"`
		echo "name=${kojinbangou}&confirm=true&Delete=Delete&returnUrl=UserBrowser.jspa" > ${TMP_DIR}/delete_user_logindata.txt
		if [ ! -s ${TMP_DIR}/delete_user_logindata.txt ]
		then
			outlog_func UM-E04078
			IFS=${IFS_org}
			return 1
		fi
		wget -o ${DETAIL_LOG_TMP} --load-cookies cookies.txt --header="Content-Type: application/x-www-form-urlencoded" --post-file="${TMP_DIR}/delete_user_logindata.txt" -p "${JIRA_IP}secure/admin/user/DeleteUser.jspa"
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		# ./直下に作成されるwgetの結果ファイルが存在するか確認
		_find_CEfile1=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name DeleteUser.jspa | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		_find_CEfile2=`find ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user -name UserBrowser.jspa | tee ${DETAIL_LOG_TMP}`
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${DETAIL_LOG}
		if [ -z "${_find_CEfile1}" -a -z "${_find_CEfile2}" ]
		then
			outlog_func UM-E04088 ${kojinbangou} ${ninmei_level} ${kanji_simei} ${shukan_code} ${system_code}
			IFS=${IFS_org}
			return 1
		fi
		outlog_func UM-I04089 ${kojinbangou} ${ninmei_level} ${kanji_simei} ${shukan_code} ${system_code}
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/DeleteUser.jspa*
		rm -f ${SHELL_DIR}/${JIRA_IP_DIR}/secure/admin/user/UserBrowser.jspa*

	done < ${CSV_OUT_DIR}/user_delete.csv
	IFS=${IFS_org}
	return 0
}


# ----
# 関数「削除済み_ユーザデータ削除」
# ----
function delete_gwdb_user
{
db2 -tvf ${SQL_DIR}/delete_gwdb_user.sql > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
        # エラーログ出力        
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func UM-E04080 "${_errmsg}"

        # エラー終了
        return 1
fi
return 0
}

###############################################################################
# main処理開始
###############################################################################

# 開始ログ出力
outlog_func UM-I04081


# GWDB接続
connectDB ${DB_NAME}
if [ $? != '0' ]
then
    outlog_func UM-E04086
    exit 1
fi

# JIRAログイン
jira_login ${SHELL_DIR}
if [ $? != '0' ]
then
	outlog_func UM-E04087
    exit 1
fi
# ----
# 関数「論理削除チェック」
# ----
update_user_data_jira_old
if [ $? != '0' ]
then
    outlog_func UM-E04086
    exit 1
fi

# ----
# 関数「差分チェック_ユーザ削除」
# ----
make_csv_delete
if [ $? != '0' ]
then
    outlog_func UM-E04082
    exit 1
fi

# ----
# 関数「ユーザ削除_ログイン情報」
# ----
delete_user_logindata
if [ $? != '0' ]
then
    outlog_func UM-E04083
    exit 1
fi

# ----
# 関数「削除済み_ユーザデータ削除」
# ----
delete_gwdb_user
if [ $? != '0' ]
then
    outlog_func UM-E04084
    exit 1
fi

# 終了ログ出力
outlog_func UM-I04085

exit 0
