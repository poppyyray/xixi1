#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ARCHIVE_MONTH_ATTACHMENT.sh
# 業 務 名       ： なし
# 処理概要       ： FILEATTACHMENTアーカイブシェル(月次)
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0             正常
#                   1             エラー
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： S.Tsuruha
#
# 作成日付       ： 2009-06-01
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2009-06-01 S.Tsuruha                新規作成
# 2       2014-06-25 LiuJian                  IP集約管理
# 3       2014-07-28 LiuJian                  更新と参照JIRA Attachment同期と退避 (JP1関連)
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

outlog_func AC-I10048

# 参照JIRAへ削除対象listを送る
REMOTE_COPY ${CSV_OUT_DIR}/attachment_month_file_list.csv ${JIRAR_CIP}:${TMP_DIR}
if [ $? != '0' ]
then
	exit 1
fi

#参照JIRAでのATTACHMENT_ARCHIVE.shを実行する
REMOTE_EXEC_SH ${JIRAR_CIP} ${SHELL_DIR}/ATTACHMENT_ARCHIVE.sh 
if [ $? != '0' ]
then
    exit 1
fi

outlog_func AC-I10053
