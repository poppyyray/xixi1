#!/bin/sh

echo "証憑ファイル到着 : " `date` >> /tmp/scanfile_move.log
mv /shared/gateway/hulft/scan/Shohyo /20091003/scan/Shohyo.`date +%Y%m%d%H%M`
echo "証憑ファイルバックアップ : " `date` >> /tmp/scanfile_move.log
