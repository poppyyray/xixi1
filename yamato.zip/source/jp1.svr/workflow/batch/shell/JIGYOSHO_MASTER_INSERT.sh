#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： JIGYOSHO_MASTER_INSERT.sh
# 業 務 名       ： フロー処理（事業所マスター）
# 処理概要       ： 事業所データをGWに登録
# 特記事項       ： 起動トリガー：JP1より機動
# パラメータ     ： なし 
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-07-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 ======= 
# 1 1.0.0 2009-07-16 T.Sakagami                新規作成
# 2 1.1.0 2009-09-14 Y.Otsuka                  ヘッダー追加
# 3 1.2.0 2009-12-21 M.Saiki                   importリトライ追加
# 4 1.2.1 2009-12-21 K.Murase                  importリトライ追加
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 ======= 
#
################### 改定履歴       ########################

# シェル名
_shname="JIGYOSHO_MASTER_INSERT.sh"
_tmp="/workflow/batch/tmp/import.tmp"


# 事業所マスターCSV作成関数 ###################################################
function jigyosho_master {

    #カウント変数初期化
    _Jigyosho_cnt=0

    while read line
    do
        # 件数をカウント
        _Jigyosho_cnt=`expr ${_Jigyosho_cnt} + 1`

        # 1行目のファイル名が正しいかチェック 
       if [ ${_Jigyosho_cnt} == 1 ]
		then
           line=`echo ${line} | sed -e "s/\r//"`
           line=`echo ${line} | sed -e "s/ //"` 
           if [ ${line} != ${FILE_Jigyosho} ]
	
		then
                outlog_func JM-E02003 ${1}
                exit 1
            fi
        # 2行目の件数が正しいかチェック
       elif [ ${_Jigyosho_cnt} == 2 ]
		then
           line=`echo ${line} | sed -e "s/\r//"`
           line=`echo ${line} | sed -e "s/ //"`
            _line_cnt=`wc -l ${1} | cut -d " " -f 1`

            # 1縲鰀3行目はカウントしない
            _line_cnt=`expr ${_line_cnt} - 3`
              # 2行目を数値として扱いたいためexprで０を加算
            line=`expr ${line} + 0`

            # ファイル2行目のファイル件数と実際のファイルの件数を比較
           if [ ${line} != ${_line_cnt} ]
			then
                outlog_func JM-E02004 ${1}
                exit 1
            fi
             # 件数が0件の場合は処理終了
            if [ ${line} -eq 0 ]
            then
                touch  ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc
                return 0
            fi
        # 3行目はブランク行のためなにもしない
       elif [ ${_Jigyosho_cnt} == 3 ]
		then
            continue
        # 4行目以降は業務データのcsvファイルを作成
        else

             #店所コード
            _tensho_cd=`echo "$line"|cut -b1-6`

             #主管コード
            _syukan_cd=`echo "$line"|cut -b7-12`
            _syukan_cd=`echo ${_syukan_cd} | sed -e 's/ //g'`

             #支社コード
            _shisya_cd=`echo "$line"|cut -b13-18`
            _shisya_cd=`echo ${_shisya_cd} | sed -e 's/ //g'`

             #店所名称
             _tensho_meishou=`echo "$line"|cut -b19-58`
           #_tensho_meishou=`echo ${_tensho_meishou} |  sed -e "s/^0*//"`

             #店所略称
            _tensho_ryakushou=`echo "$line"|cut -b59-68`
           #_tensho_ryakushou=`echo ${_tensho_ryakushou} |  sed -e "s/^0*//"`

			#タイムスタンプ
			_time_stmp=`date +%Y-%m-%d-%H.%M.%S`.000000

	    _outline=""
            _outline="${_outline}${_tensho_cd}",
            _outline="${_outline}${_syukan_cd}",
            _outline="${_outline}${_shisya_cd}",
            _outline="${_outline}${_tensho_meishou}",
            _outline="${_outline}${_tensho_ryakushou}",,
            _outline="${_outline}${_shname}",
            _outline="${_outline}${_time_stmp}",,,

            echo ${_outline} >> ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc

        fi

    done < ${1}

    return 0
}


#################################################################
# main処理
#################################################################
#環境設定を行う
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${JIGYOSHO_MAIN_FLOW_LOG}

outlog_func JM-I02001

# 事業所マスターデータファイル存在確認
#if [ ! -f ${MASTER_FILE_PATH}/${FILE_Jigyosho} ]
#then

	# バックアップファイル名にOKが無いものを取得（正常終了しなかったスキャンファイル）
   _FILE_Jigyosho_BAK=`ls ${PPFILE_BACKUP_DIR}| grep ${FILE_Jigyosho} | grep -v OK | head -1`
	echo $_FILE_Jigyosho_BAK
    # バックアップファイルの末尾が全てOK
    if [ -z ${_FILE_Jigyosho_BAK} ]
	then

		# 事業所マスターデータファイルが存在しない
    	outlog_func JM-W02005 ${FILE_Jigyosho}

		# 対象ファイルがないため終了
		exit 0

    # バックアップファイルの末尾がOKでないものがある
    else
	# ディレクトリパスを付与
	_FILE_Jigyosho_BAK_PATH="${PPFILE_BACKUP_DIR}/${_FILE_Jigyosho_BAK}"
	# 文字化けを防ぐためUTFに変換
	nkf -e ${_FILE_Jigyosho_BAK_PATH} > "${CSV_OUT_DIR}/${_FILE_Jigyosho_BAK}"

        # 事業所マスターデータファイルCSV作成関数呼び出し
        jigyosho_master "${CSV_OUT_DIR}/${_FILE_Jigyosho_BAK}"
        # エラー判定
       if [ $? != "0" ]
		then

           outlog_func JM-E02006
           
			# CSV削除
			rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc
           exit 1
        fi  
	rm -f "${CSV_OUT_DIR}/${_FILE_Jigyosho_BAK}"
    fi
#else

    # 事業所マスターデータファイルのバックアップを作成
#    _FILE_Jigyosho_BAK=${PPFILE_BACKUP_DIR}/${FILE_Jigyosho}.`date +%Y%m%d%H%M`
    # 文字化けを防ぐためEUCにコード変換して退避
#    nkf -e ${MASTER_FILE_PATH}/${FILE_Jigyosho} > ${_FILE_Jigyosho_BAK}
    # エラー判定
#    if [ $? != "0" ]
#	then

#        outlog_func JM-E02009

#        exit 1
#    fi
    # バックアップ成功時に送られてきたファイルを削除
#    rm -f ${MASTER_FILE_PATH}/${FILE_Jigyosho}

    # 事業所マスターデータファイルCSV作成関数呼び出し
#    jigyosho_master "${_FILE_Jigyosho_BAK}"

    # エラー判定
#    if [ $? != "0" ]
#	then

#        outlog_func JM-E02011

		# CSV削除
#		rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc

#        exit 1
#    fi
#fi

# DB接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func JM-E02007 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# CSV削除
	rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc

	# エラー終了
	exit 1
fi
echo "" > ${SQLLOG_TMP}

# 事業所マスター情報CSVファイルが存在すればDBにインサートを行う
if [ -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc ]
then
	# SJISにコード変換
	nkf -s ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc > ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv
    # エラー判定
    if [ $? != "0" ]
	then

        outlog_func JM-E02010

    	# 一時ファイル等の削除
    	rm -f  ${SQLLOG_TMP}

		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv
		rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc

        exit 1
    fi

	# 事業所マスター情報CSVインポート
	nkf --ic=CP932 --oc=UTF-8 ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv > ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.utf8
	#db2 import from ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv of del messages ${_tmp} INSERT_UPDATE into ${TABLE_jigyosho_master} > ${SQLLOG_TMP}

	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		db2 import from ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.utf8 of del messages ${_tmp} INSERT_UPDATE into ${TABLE_jigyosho_master} > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
			
		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${DB_NAME}"

			connectDB ${DB_NAME}

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done

	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ] 
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func JM-E02008 "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}

		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv
		rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc
		rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.utf8

		# エラー終了
		exit 1
	fi
	echo "" > ${SQLLOG_TMP}

	# 正常終了したスキャンデータファイルの末尾にOKをつける
	mv ${_FILE_Jigyosho_BAK_PATH} ${_FILE_Jigyosho_BAK_PATH}.OK
fi

# DB切断
db2 terminate > /dev/null

# 作成したCSVファイルを削除
rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv
rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.euc
rm -f ${CSV_OUT_DIR}/${FILE_Jigyosho}.csv.utf8

# 一時ファイルを削除
rm -f ${_tmp}

outlog_func JM-I02002

exit 0
