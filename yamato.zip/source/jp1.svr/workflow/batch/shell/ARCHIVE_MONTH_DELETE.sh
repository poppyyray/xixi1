#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ARCHIVE_MONTH_DELETE.sh
# 業 務 名       ： JIRADB旧データ退避
# 処理概要       ： 参照JIRAからバックアップデータを出力する
# 特記事項       ： JIRAがオンライン稼働中でない場合に起動する
# パラメータ     ： なし
# ログファイル   ： Archive.log
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： 参照JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Y.Otsuka
#
# 作成日付       ： 2009-XX-XX
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-08-27 Y.Otsuka              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
env_file_list="/workflow/batch/ini/batch_common.conf"
for x in ${env_file_list}
do
        if [[ -r ${x} ]]
        then
            . ${x}
        else
            echo "Cannot read common env file. ( ${x} )."
            exit 1
        fi
done
# ----
# 共通関数読み込み
# ----
conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
for y in ${conf_file_list}
do
        if [[ -r ${y} ]]
        then
            . ${y}
        else
            echo "Cannot read common conf file. ( ${y} )."
            exit 1
        fi
done

# ---- 
# 業務別環境変数設定
# ----

##本シェル使用変数は、batch_common.confを参照してください。
##本シェル使用関数は、BATCH_COMMON_FUNC.shを参照してください。

###############################################################################
# main処理開始
###############################################################################
# 出力ログ名設定
export log_name=${ARCHIVE_MONTH_LOG}

### 開始メッセージ
outlog_func AC-I10025


# 参照JIRADB接続
connectDB "${RF_JIRA_DB}"
if [ $? != 0 ]
then
    outlog_func AC-E10004 "connectDB"
    exit 1
fi

# 参照JIRAから出力したデータを削除
# 変数${DAY}に出力対象日数を指定(関数JIRA_EXPORT_CSVにて指定した出力対象日数と同上)
# 変数{DLETE_COUNT}に削除件数を指定
JIRADB_DELETE ${MONTHLY} ${AD_RF_DELETE_COUNT}
if [ $? != 0 ]
then
    outlog_func AC-E10004 "JIRADB_DELETE"
    exit 1
fi

db2 terminate > /dev/null

## 終了メッセージ
outlog_func AC-I10026
