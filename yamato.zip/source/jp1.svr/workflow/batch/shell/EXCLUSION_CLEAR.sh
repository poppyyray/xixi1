#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： EXCLUSION_CLEAR.sh
# 業 務 名       ： なし
# 処理概要       ： 排他情報テーブルクリアBatch
# 特記事項       ： 起動トリガー：JP1
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： H.Someya
#
# 作成日付       ： 2010-03-15
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.1 2010-03-15 H.Someya               新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
#
###########################################################

###########################################################
# 共通環境変数設定
###########################################################
_exec_ksh=/workflow/batch/ini/batch_common.conf

# 環境設定ファイルの存在チェック
if [ ! -f ${_exec_ksh} ]; then
	echo "環境設定ファイルが存在しません"
	exit 1
fi

# 環境設定ファイル読み込み
. ${_exec_ksh}

# 共通関数ファイルの存在チェック
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]; then
	echo "共通関数ファイルが存在しません"
	exit 1
fi

# 共通関数ファイル読み込み
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

###############################################################################
# 機能：　詳細ログ出力
# 処理概要：
# 　詳細ログを出力する
#
# 引数1：　実行コマンド
# 引数2：　コマンド結果
#
# 戻り値：　0:正常
#
# 前提条件：パラメータが必ず2つあること
#           環境設定ファイル読み込み済みであること
#
###############################################################################
function fnc_outdetaillog
{
	echo -e "日付:`date` || shell名:`basename ${0}` \n コマンド:${1}\n コマンド結果:\n${2}" >>${DETAIL_LOG}

	return ${RC_NOR}
}

###############################################################################
# 機能：　排他情報テーブルクリア
# 処理概要：
# 　排他情報テーブルの『ユーザID』、『トークン』、『有効期限』のクリア、『更新日時』の更新を実施する
# 　また、クリア・更新処理件数と排他情報テーブルの件数が一致していることを検証する
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：環境設定ファイル読み込み済みであること
#
###############################################################################
function fnc_clear_exclusion
{
	# 排他情報テーブル件数取得
	_sqlcmd="SELECT COUNT(*) FROM WF1.EXCLUSION WHERE USERID IS NOT NULL"
	db2 -x ${_sqlcmd} > ${SQLLOG_TMP} 2>&1
	SQLERROR=$?
	fnc_outdetaillog "db2 -x ${_sqlcmd}" "`cat ${SQLLOG_TMP}`"

	# DBエラーチェック
	if [ ${SQLERROR} != 0 -a ${SQLERROR} != 1 ]; then
		# エラーログ出力
		outlog_func EC-E01002

		# エラー終了
		return ${RC_ERR}
	fi

	COUNT=`cat ${SQLLOG_TMP}`

	# 排他情報テーブル更新
	_sqlcmd="UPDATE WF1.EXCLUSION set USERID = NULL,TOKEN = NULL,EXPIRATIONDATE = NULL, UPDATED = CURRENT_TIMESTAMP WHERE USERID IS NOT NULL"
	db2 -a ${_sqlcmd} > ${SQLLOG_TMP} 2>&1
	SQLERROR=$?
	fnc_outdetaillog "db2 -a ${_sqlcmd}" "`cat ${SQLLOG_TMP}`"

	# DBエラーチェック
	if [ ${SQLERROR} != 0 -a ${SQLERROR} != 1 ]; then
		# エラーログ出力
		outlog_func EC-E01004

		# エラー終了
		return ${RC_ERR}
	fi

	# 更新処理件数取得
	PROC_COUNT=`cat ${SQLLOG_TMP} | grep sqlerrd| awk -F")" '{ print $NF }'`

	# 更新処理件数検証
	if [ ${COUNT} -eq ${PROC_COUNT} ]; then
		# 件数ログ出力
		outlog_func EC-I01003 "${COUNT}" "${PROC_COUNT}"
	else
		# エラーログ出力
		outlog_func EC-E01005 "${COUNT}" "${PROC_COUNT}"
		# エラー終了
		return ${RC_ERR}
	fi

	return ${RC_NOR}
}


###############################################################################
# main処理
# 処理概要
# 1.更新系JIRADBに接続
# 2.排他情報テーブルクリア処理実行
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
# 出力ログ名設定
export log_name=${EXCLUSION_CLEAR_LOG}

# 処理開始ログ出力
outlog_func EC-I01001

# 更新系JIRADBに接続
connectDB ${JIRA_DB_NAME}
_ret=$?

if [ $_ret != ${RC_NOR} ]; then
	# エラーログはconnectDBにて出力済み
	exit ${RC_ERR}
fi

# 排他情報テーブルクリア
fnc_clear_exclusion
_ret=$?
if [ $_ret != ${RC_NOR} ]; then
	outlog_func EC-E01003
	exit ${RC_ERR}
fi

# 処理終了ログ出力
outlog_func EC-I01002

# 処理終了
exit ${RC_NOR}
