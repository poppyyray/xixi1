#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ARCHIVE_CSV_BACKUP.sh
# 業 務 名       ： なし
# 処理概要       ： 週次アーカイブIXF保存シェル
# 特記事項       ： 参照JIRA退避データ(IXFファイル)を圧縮する
#                   DBサーバーに圧縮ファイルを保存する
# パラメータ     ： 無し
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-09-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-09-08 T.Sakagami              新規作成
# 2 1.0.1 2010-01-19 Y.Nagahashi             月次アーカイブデータロスト対応
# 3 1.0.2 2010-05-19 S.Tsuruha               月次から週次化に伴う、
#                                            アーカイブデータのファイル名ユニーク化
# 4       2014-06-24 LiuJian                 IP集約管理
# 5       2014-08-13 LiuJian                 参照系DBデータArchive改善
# 6
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません"
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 出力ログ名設定
export log_name=${ARCHIVE_MONTH_LOG}

# アーカイブ取得日時を設定
DATE=`date +%Y%m%d%H%M%S`

# マウント先(アーカイブファイルの格納先)を定義
MOUNT_PATH=${DBR_BAK_MNT_DIR}

# main処理開始
outlog_func AC-I02001

# 参照JIRA退避データファイル名を取得
FILE_LIST=`ls ${CSV_OUT_DIR}/update_jira_arc_monthly*`
if [ -z "${FILE_LIST}" ]
then
	outlog_func AC-E02005
	exit 1
fi

# 参照JIRA退避データファイルを圧縮
tar -cvzf ${TMP_DIR}/JIRAR_ARC_${DATE}.tar.gz ${FILE_LIST[*]} >/dev/null 2>&1
RC=$?
if [[ "${RC}" != "0" ]]
then
	outlog_func AC-E02006
	exit 1
fi

# 参照JIRA退避データファイル名と圧縮ファイル名をログ出力
outlog_func AC-I02008 "${FILE_LIST[*]}" "${TMP_DIR}/JIRAR_ARC_${DATE}.tar.gz"

# マウント実施
mount ${MOUNT_PATH} >/dev/null 2>&1
RC=$?
if [[ "${RC}" != "0" ]]
then
	outlog_func AC-E02010 "${MOUNT_PATH}" "${RC}"
	exit 1
fi

# 参照JIRA退避データ圧縮ファイルをテープ退避元に移動
mv ${TMP_DIR}/JIRAR_ARC_${DATE}.tar.gz ${MOUNT_PATH}
MVRC=$?

# アンマウント実施
umount ${MOUNT_PATH} >/dev/null 2>&1
RC=$?
if [[ "${RC}" != "0" ]]
then
	outlog_func AC-E02012 "${MOUNT_PATH}" "${RC}"
	exit 1
fi

if [[ "${MVRC}" != "0" ]]
then
	outlog_func AC-E02011 "${MOUNT_PATH}" "${MVRC}"
	exit 1
fi

# 参照JIRA退避データファイル、DBサーバへコピー済みの圧縮ファイルを削除
rm -f ${FILE_LIST[*]}
RC=$?
if [[ "${RC}" != "0" ]]
then
	outlog_func AC-E02009 "${FILE_LIST[*]}"
	exit 1
fi

# 終了メッセージ出力
outlog_func AC-I02002

exit 0
