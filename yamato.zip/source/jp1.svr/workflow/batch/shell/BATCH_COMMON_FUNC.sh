#!/bin/sh
###########################################################
# 関数名:outlog_func
#
# 機能:指定されたパスにシェル名.logの名前でログを作成し出力する
#
# 引数
# $1 MSGID
#
# $2 MSG引数
#
# 戻り値
#  0:正常
#  1:異常
#
# 前提条件:ログ出力パス環境変数${LOG_DIR}にパスが指定されていること
#
###########################################################
function outlog_func
{

    # ログ名が設定されていない場合呼ばれているシェルをログ名に使用
    if [ ! "${log_name}" ]; then
            shname=`basename ${0}`
            log_name=`echo ${shname} | sed "s/.sh//g"`
    fi

	shname=`basename ${0}`

    # ログが存在しない場合作成し権限を変更
    if [ ! -f ${LOG_DIR}/${log_name}.log ]; then
            touch ${LOG_DIR}/${log_name}.log
            chmod 777 ${LOG_DIR}/${log_name}.log
    fi

	error_id=`echo ${1} | cut -b4`

	if [ ${error_id} == "E" ]
	then
	        errorlevel="ERROR"
	elif [ ${error_id} == "W" ]
	then
	        errorlevel="WARNING"
	elif [ ${error_id} == "I" ]
	then
	        errorlevel="INFO"
	elif [ ${error_id} == "F" ]
	then
	        errorlevel="FATAL"
	elif [ ${error_id} == "D" ]
	then
	        errorlevel="DEBUG"
	else
	        echo "エラー出力関数の第一引数に誤りがあります。シェル名[${0}] 第一引数[${1}]"
		return 1
	fi

	logdate=`date "+%Y-%m-%d %H:%M:%S"`

	log_id_msg=`cat ${CONF_DIR}/message.conf | grep ${1}`
	if [ -z "${log_id_msg}" ]
	then
		echo ${logdate} ${errorlevel} ${shname} "CM-W01001" "メッセージID[${1}]が存在しません。" >> ${LOG_DIR}/${log_name}.log
		return 1
	fi

	PARM_CNT=$#
	# 引数の2個目から取得するために初期値を2としている
	MSG_CNT=2
	while (( ${MSG_CNT} <= ${PARM_CNT} ))
	do
		PARM_MSG=`eval echo "\\${${MSG_CNT}}"`

		#%sを引数に変換
		log_id_msg=`echo ${log_id_msg} | sed s@%s@"${PARM_MSG}"@`

		MSG_CNT=`expr $MSG_CNT + 1`
	done

	logmsg="${logdate} ${errorlevel} ${shname} ${log_id_msg}"

	echo ${logmsg} >> ${LOG_DIR}/${log_name}.log

	return 0
}

###############################################################################
# 店所コード対応JIRA側ID取得関数
###############################################################################
function export_tensyocd_jiraid
{
	# 変数初期化
	_tensyo_jiraid=""

	# 店所コードとIDファイルをエクスポート
	db2 export to ${TMP_DIR}/export_tensyocd_jiraid.csv of del select id,name from ${SCHEMA_NAME}schemeissuesecuritylevels > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CM-E99001 "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${TMP_DIR}/export_tensyocd_jiraid.csv ]
	then
		outlog_func CM-E99002
		return 1
	fi

	# 行頭の+を削除
	sed -i "s/+//g" ${TMP_DIR}/export_tensyocd_jiraid.csv

	# .を削除
	sed -i "s/\.//g" ${TMP_DIR}/export_tensyocd_jiraid.csv

	# "を削除
	sed -i "s/\"//g" ${TMP_DIR}/export_tensyocd_jiraid.csv

	# ,をスペースに変換
	sed -i "s/,/ /g" ${TMP_DIR}/export_tensyocd_jiraid.csv

	# 先頭の0を削除
	sed -i "s/^0*//g" ${TMP_DIR}/export_tensyocd_jiraid.csv

	return 0
}

###############################################################################
# 帳票ID対応JIRA側ID取得関数
# 引数１：JIRAで定義されているプロジェクト名に対応しているID
###############################################################################
function export_tyouhyou_jiraid
{
	# 変数初期化
	_tyouhyou_jiraid=""

	# 帳票IDとIDファイルをエクスポート
	db2 "export to ${TMP_DIR}/export_tyouhyou_jiraid.csv of del select id,vname from ${SCHEMA_NAME}projectversion where project = ${1}" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CM-E99003 "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${TMP_DIR}/export_tyouhyou_jiraid.csv ]
	then
		outlog_func CM-E99004
		return 1
	fi

	# 行頭の+を削除
	sed -i "s/+//g" ${TMP_DIR}/export_tyouhyou_jiraid.csv

	# .を削除
	sed -i "s/\.//g" ${TMP_DIR}/export_tyouhyou_jiraid.csv

	# "を削除
	sed -i "s/\"//g" ${TMP_DIR}/export_tyouhyou_jiraid.csv

	# ,をスペースに変換
	sed -i "s/,/ /g" ${TMP_DIR}/export_tyouhyou_jiraid.csv

	# 先頭の0を削除
	sed -i "s/^0*//g" ${TMP_DIR}/export_tyouhyou_jiraid.csv

	return 0
}

###############################################################################
# 主管コード対応JIRA側ID取得関数
# 引数1:プロジェクトID
###############################################################################
function export_syukan_jiraid
{
	# 変数初期化
	_syukan_jiraid=""

	# 店所コードとIDファイルをエクスポート
	db2 "export to ${TMP_DIR}/export_syukan_jiraid.csv of del select id,cname from ${SCHEMA_NAME}component where PROJECT = ${1}" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CM-E99005 "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${TMP_DIR}/export_syukan_jiraid.csv ]
	then
		outlog_func CM-E99006
		return 1
	fi

	# 行頭の+を削除
	sed -i "s/+//g" ${TMP_DIR}/export_syukan_jiraid.csv

	# .を削除
	sed -i "s/\.//g" ${TMP_DIR}/export_syukan_jiraid.csv

	# "を削除
	sed -i "s/\"//g" ${TMP_DIR}/export_syukan_jiraid.csv

	# ,をスペースに変換
	sed -i "s/,/ /g" ${TMP_DIR}/export_syukan_jiraid.csv

	# 先頭の0を削除
	sed -i "s/^0*//g" ${TMP_DIR}/export_syukan_jiraid.csv

	return 0
}

###############################################################################
# グループID対応JIRA側ID取得関数
###############################################################################
function export_groupid_jiraid_jiraid
{

	# 店所コードとIDファイルをエクスポート
	db2 "export to ${TMP_DIR}/export_groupid_jiraid.csv of del select id,USERNAME from ${SCHEMA_NAME}USERBASE" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CM-E99007 "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${TMP_DIR}/export_groupid_jiraid.csv ]
	then
		outlog_func CM-E99008
		return 1
	fi

	# 行頭の+を削除
	sed -i "s/+//g" ${TMP_DIR}/export_groupid_jiraid.csv

	# .を削除
	sed -i "s/\.//g" ${TMP_DIR}/export_groupid_jiraid.csv

	# "を削除
	sed -i "s/\"//g" ${TMP_DIR}/export_groupid_jiraid.csv

	# ,をスペースに変換
	sed -i "s/,/ /g" ${TMP_DIR}/export_groupid_jiraid.csv

	# 先頭の0を削除
	sed -i "s/^0*//g" ${TMP_DIR}/export_groupid_jiraid.csv

	return 0
}

###############################################################################
# プロジェクト対応JIRA側ID取得関数
# 引数１：JIRAで定義されているプロジェクト名
###############################################################################
function export_project_jiraid_jiraid
{

	# 店所コードとIDファイルをエクスポート
	db2 "export to ${TMP_DIR}/export_project_jiraid.csv of del select id,pname from ${SCHEMA_NAME}project where pname = '${1}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func CM-E99009 "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# 検索結果のファイルが0バイトの場合
	if [ ! -s ${TMP_DIR}/export_project_jiraid.csv ]
	then
		outlog_func CM-E99010
		return 1
	fi


	# 行頭の+を削除
	sed -i "s/+//g" ${TMP_DIR}/export_project_jiraid.csv

	# .を削除
	sed -i "s/\.//g" ${TMP_DIR}/export_project_jiraid.csv

	# "を削除
	sed -i "s/\"//g" ${TMP_DIR}/export_project_jiraid.csv

	# ,をスペースに変換
	sed -i "s/,/ /g" ${TMP_DIR}/export_project_jiraid.csv

	# 先頭の0を削除
	sed -i "s/^0*//g" ${TMP_DIR}/export_project_jiraid.csv

	return 0
}

###############################################################################
# MAIN_FLOW用 排他処理制御関数
# 引数１：Sleepする秒数
###############################################################################
function haita
{
	local sleep_time=${1}

	while ( [ -f ${LOCK_FILE} ] )
	do
        	sleep ${1}
	done

	touch ${LOCK_FILE}

	return 0

}

###############################################################################
# SHOHYO_MAIN_FLOW用 排他処理制御関数
# 引数１：Sleepする秒数
###############################################################################
function haita_shohyo
{
	local sleep_time=${1}
	count=""
	pid=$$
	while ( [ -f ${LOCK_FILE_SHOHYO} ] )
	do
        	sleep ${1}
		let count=${count}+${1}
		outlog_func CM-I99011 ${count} ${pid}
	done

	touch ${LOCK_FILE_SHOHYO}

	return 0

}

###############################################################################
# MAIN_FLOW用 ログファイル作成関数
# 引数１：実行プログラム名
###############################################################################
function createlogfile
{
	# ログ名の設定
	local sh_name=`basename ${0}`
	local log_main_name=`echo ${sh_name} | sed "s/.sh//g"`

	# ログが存在しない場合作成し権限を変更
	if [ ! -f ${LOG_DIR}/${log_main_name}.log ]; then
   		touch ${LOG_DIR}/${log_main_name}.log
    	chmod 777 ${LOG_DIR}/${log_main_name}.log
	fi

	return 0
}
###############################################################################
# JIRAログイン関数
# 引数１：login.jspファイルを作成するパス.任意 （指定がなければカレントに作成）
# 引数２：作成するcookie名.任意 （指定がなければcookies.txtで作成）
# 引数３：接続先のJIRAのIPアドレスを指定する（指定がなければデフォルト値を使用)
###############################################################################
function jira_login
{
	current_path=`pwd`
	common_login_path=${1}
	common_cookie_name=${2}
	CONNECT_JIRA=${3}

	#ループカウンタ初期化
	_logincount=0

	#クッキー名の指定がなければデフォルト名
	if [ -z "${common_cookie_name}" ]
	then
	     common_cookie_name=${DEFAULT_COOKIE_NAME}
	fi

	#login.jspの出力パスの指定がなければカレントに作成
	if [ -z "${common_login_path}" ]
	then
	     common_login_path=${current_path}
	fi

	#JIRAIPの指定がなければデフォルト値(更新JIRAのIP）を使用
	if [ -z "${CONNECT_JIRA}" ]
	then
	     CONNECT_JIRA=${JIRA_IP}
	fi

	#login.jsp出力パスへ移動
	cd ${common_login_path}

	# wgetコマンドでJIRAへログインを行う
	. /workflow/auth_mgr/decrypt/ASCA_DECRYPT_MANAGER.sh USER5
	wget -o ${ROOT_FILE} --save-cookies ${common_cookie_name} --keep-session-cookies --header='Proxy-Connection: keep-alive' --post-data "os_username=${A_USER5_ID}&os_password=${A_USER5_PWD}&os_cookie=true" ${JIRA_IP}login.jsp
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${ROOT_FILE}`" >>${DETAIL_LOG}

	while [ ${_logincount} -le ${LOGIN_MAX_LOOP} ]
	do
		# 指定パスに作成されるlogin.jsp*ファイルが存在するか確認
		_find_Loginfile=`find ${common_login_path} -name "login.jsp*" | tee ${ROOT_FILE}`
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${ROOT_FILE}`" >>${DETAIL_LOG}
		if [ -z "${_find_Loginfile}" ]
		then
			if [ ${_logincount} -eq ${LOGIN_MAX_LOOP} ]
			then
				#規定回数ループした場合はログイン失敗とみなす。
				return 1
			fi
			_logincount=`expr ${_logincount} + 1`
			# ログイン確認できない場合スリープ(sec)
			sleep ${LOGIN_WAIT_TIME}
		else
			# login.jsp*のファイルを削除
			rm -f ${_find_Loginfile}
			break
		fi
	done

	#カレントパスを元に戻す
	cd ${current_path}

	return 0
}
###############################################################################
# JIRADB旧データ抽出関数（アーカイブ処理使用）
# 引数１：ステータスが案件終了のデータの抽出日数を指定する。
###############################################################################
function JIRADB_EXPORT_CSV
{
	# 抽出日数
	DAILY_MONTHLY_STATUS=$1

	# 抽出日数
	DAY_JIRA=$2

		#日次バッチで実行
	if [ ${DAILY_MONTHLY_STATUS} -eq ${DAILY_STATUS} ]
	then
		OUT_DIR=${CSV_OUT_DIR}

	else
	#月次バッチで実行

		#バックアップ保存先のディレクトリ内をクリア
		#rm -f ${ARCHIVE_BK_DIR}${UPDATE_JIRA_ARC_JIRAISSUE}
		#rm -f ${ARCHIVE_BK_DIR}${UPDATE_JIRA_ARC_OS_WFENTRY}
		#rm -f ${ARCHIVE_BK_DIR}${UPDATE_JIRA_ARC_CUSTOMFIELDVALUE}
		#rm -f ${ARCHIVE_BK_DIR}${UPDATE_JIRA_ARC_NODEASSOCIATION}
		#rm -f ${ARCHIVE_BK_DIR}${UPDATE_JIRA_ARC_CHANGEGROUP}
		#rm -f ${ARCHIVE_BK_DIR}${UPDATE_JIRA_ARC_CHANGEITEM}
		#rm -f ${ARCHIVE_BK_DIR}${UPDATE_JIRA_ARC_JIRAACTION}
		#rm -f ${ARCHIVE_BK_DIR}${UPDATE_JIRA_ARC_FILEATTACHMENT}

		OUT_DIR=${ARCHIVE_BK_DIR}

		# アーカイブ共通 更新JIRADB旧データ退避使用_更新JIRADB旧データ抽出CSVファイル名を設定
		UPDATE_JIRA_ARC_JIRAISSUE=${UPDATE_JIRA_ARC_MONTHLY_JIRAISSUE}
		UPDATE_JIRA_ARC_OS_WFENTRY=${UPDATE_JIRA_ARC_MONTHLY_OS_WFENTRY}
		UPDATE_JIRA_ARC_CUSTOMFIELDVALUE=${UPDATE_JIRA_ARC_MONTHLY_CUSTOMFIELDVALUE}
		UPDATE_JIRA_ARC_NODEASSOCIATION=${UPDATE_JIRA_ARC_MONTHLY_NODEASSOCIATION}
		UPDATE_JIRA_ARC_CHANGEGROUP=${UPDATE_JIRA_ARC_MONTHLY_CHANGEGROUP}
		UPDATE_JIRA_ARC_CHANGEITEM=${UPDATE_JIRA_ARC_MONTHLY_CHANGEITEM}
		UPDATE_JIRA_ARC_JIRAACTION=${UPDATE_JIRA_ARC_MONTHLY_JIRAACTION}
		UPDATE_JIRA_ARC_FILEATTACHMENT=${UPDATE_JIRA_ARC_MONTHLY_FILEATTACHMENT}

	fi

	# JIRAISSUEのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
	db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_JIRAISSUE} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG} select j_i.* from jiraschema.jiraissue j_i where date(j_i.updated) <= (values current date ${DAY_JIRA} days) and j_i.issuestatus = '${STATUS_COMPLETION}'"  > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10009 "JIRAISSUE" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
	outlog_func AC-I10038 "JIRAISSUE" "${_export_cnt}"

	# OS_WFENTRYのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
	db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_OS_WFENTRY} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
	select o_w.* from jiraschema.os_wfentry o_w inner join jiraschema.jiraissue j_i on j_i.workflow_id = o_w.id
	where date(j_i.updated) <= (values current date ${DAY_JIRA} days)
	and j_i.issuestatus = '${STATUS_COMPLETION}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10009 "OS_WFENTRY" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
	outlog_func AC-I10038 "OS_WFENTRY" "${_export_cnt}"


	# CUSTOMFIELDVALUEのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
	db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_CUSTOMFIELDVALUE} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
	select c_f_v.* from jiraschema.customfieldvalue c_f_v inner join jiraschema.jiraissue j_i on j_i.id = c_f_v.issue
	where date(j_i.updated) <= (values current date ${DAY_JIRA} days)
	and j_i.issuestatus = '${STATUS_COMPLETION}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10009 "CUSTOMFIELDVALUE" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
	outlog_func AC-I10038 "CUSTOMFIELDVALUE" "${_export_cnt}"

	# NODEASSOCIATIONのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
	db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_NODEASSOCIATION} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
	select n_a.* from jiraschema.nodeassociation n_a inner join jiraschema.jiraissue j_i on j_i.id = n_a.source_node_id
	where date(j_i.updated) <= (values current date ${DAY_JIRA} days)
	and j_i.issuestatus = '${STATUS_COMPLETION}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10009 "NODEASSOCIATION" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
	outlog_func AC-I10038 "NODEASSOCIATION" "${_export_cnt}"


	# CHANGEGROUPのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
	db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_CHANGEGROUP} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
	select c_g.* from jiraschema.changegroup c_g inner join jiraschema.jiraissue j_i on j_i.id = c_g.issueid
	where date(j_i.updated) <= (values current date ${DAY_JIRA} days)
	and j_i.issuestatus = '${STATUS_COMPLETION}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10009 "CHANGEGROUP" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
	outlog_func AC-I10038 "CHANGEGROUP" "${_export_cnt}"


	# CHANGEITEMのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
	db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_CHANGEITEM} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
	select c_i.* from (jiraschema.changegroup c_g inner join jiraschema.jiraissue j_i on j_i.id = c_g.issueid)
	inner join jiraschema.changeitem c_i on c_i.groupid = c_g.id
	where date(j_i.updated) <= (values current date ${DAY_JIRA} days)
	and j_i.issuestatus = '${STATUS_COMPLETION}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10009 "CHANGEITEM" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
	outlog_func AC-I10038 "CHANGEITEM" "${_export_cnt}"


	# JIRAACTIONのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
	db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_JIRAACTION} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
	select j_a.* from jiraschema.jiraaction j_a inner join jiraschema.jiraissue j_i on j_i.id = j_a.issueid
	where date(j_i.updated) <= (values current date ${DAY_JIRA} days)
	and j_i.issuestatus = '${STATUS_COMPLETION}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10009 "JIRAACTION" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
	outlog_func AC-I10038 "JIRAACTION" "${_export_cnt}"


	# FILEATTACHMENTのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
	db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_FILEATTACHMENT} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
	select f_a.* from jiraschema.fileattachment f_a inner join jiraschema.jiraissue j_i on j_i.id = f_a.issueid
	where date(j_i.updated) <= (values current date ${DAY_JIRA} days)
	and j_i.issuestatus = '${STATUS_COMPLETION}'" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10009 "FILEATTACHMENT" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
	fi

	_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
	outlog_func AC-I10038 "FILEATTACHMENT" "${_export_cnt}"

	# 日時アーカイブのみ実行
	# 更新JIRAアーカイブ時のみOS_CURRENTSTEP、OS_CURRENTSTEP_PREV、OS_HISTORYSTEP、OS_HISTORYSTEP_PREVテーブルをエクスポート
	if [ ${DAILY_MONTHLY_STATUS} -eq ${DAILY_STATUS} ]
	then
		# OS_CURRENTSTEPのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
		db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_OS_CURRENTSTEP} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
		select * from jiraschema.os_currentstep where entry_id in (select workflow_id from jiraschema.jiraissue
		where date(updated) <= (values current date ${DAY_JIRA} days)
		and issuestatus = '${STATUS_COMPLETION}')" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func AC-E10009 "OS_CURRENTSTEP" "${_errmsg}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi

		_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
		outlog_func AC-I10038 "OS_CURRENTSTEP" "${_export_cnt}"


		# OS_CURRENTSTEP_PREVのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
		db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_OS_CURRENTSTEP_PREV} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
		select * from jiraschema.os_currentstep_prev where id in (select id from jiraschema.os_historystep
		where entry_id in (select workflow_id from jiraschema.jiraissue where date(updated) <= (values current date ${DAY_JIRA} days)
		and issuestatus = '${STATUS_COMPLETION}'))" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func AC-E10009 "OS_CURRENTSTEP_PREV" "${_errmsg}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi

		_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
		outlog_func AC-I10038 "OS_CURRENTSTEP_PREV" "${_export_cnt}"


		# OS_HISTORYSTEPのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
		db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_OS_HISTORYSTEP} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
		select * from jiraschema.os_historystep where entry_id in (select workflow_id from jiraschema.jiraissue
		where date(updated) <= (values current date ${DAY_JIRA} days)
		and issuestatus = '${STATUS_COMPLETION}')" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func AC-E10009 "OS_HISTORYSTEP" "${_errmsg}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi

		_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
		outlog_func AC-I10038 "OS_HISTORYSTEP" "${_export_cnt}"


		# OS_HISTORYSTEP_PREVのステータスが案件終了かつ${DAY}日経過したデータをCSVにて出力
		db2 "export to ${OUT_DIR}${UPDATE_JIRA_ARC_OS_HISTORYSTEP_PREV} of IXF MESSAGES ${ARCHIVE_FILE_EXPORT_MSG}
		select * from jiraschema.os_historystep_prev where id in (select id from jiraschema.os_historystep
		where entry_id in (select workflow_id from jiraschema.jiraissue where date(updated) <= (values current date ${DAY_JIRA} days)
		and issuestatus = '${STATUS_COMPLETION}'))" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
			# エラーログ出力
			_errmsg=`cat ${SQLLOG_TMP}`
			outlog_func AC-E10009 "OS_HISTORYSTEP_PREV" "${_errmsg}"

			# 一時ファイル等の削除
			rm -f ${SQLLOG_TMP}

			# エラー終了
			return 1
		fi

		_export_cnt=`tail -2 ${ARCHIVE_FILE_EXPORT_MSG} | head -1 | awk -F" " '{print $8}'`
		outlog_func AC-I10038 "OS_HISTORYSTEP_PREV" "${_export_cnt}"
	fi



return 0
}

###############################################################################
# 更新JIRADB旧データ取り込み（アーカイブ処理使用）
# 参照JIRAにLOADするCSVファイルを指定
# 引数１：参照JIRAにLOADするCSVファイル
###############################################################################
function JIRADB_LOAD_CSV
{
	# 参照JIRAにLOADするCSVファイル
	JIRA_EXP_CSV_FILE=$1

	# 更新JIRADBのから出力したCSVファイルを参照JIRAにLOADする。
	while read UPDATE_JIRA_EXP_CSV
	do
		JIRA_TABLE=`echo ${UPDATE_JIRA_EXP_CSV} | cut -c 37-55 | cut -f1 -d'.'`

		db2 "LOAD client FROM ${UPDATE_JIRA_EXP_CSV} OF IXF MESSAGES ${ARCHIVE_FILE_LOAD_MSG} INSERT INTO ${SCHEMA_NAME}${JIRA_TABLE} copy no" > ${SQLLOG_TMP}


		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DB2コマンド エラーハンドリング
		if [ ${SQLERROR} != 0 ]
		then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10010 "${JIRA_TABLE}" "${_errmsg}"

		return 1
		fi

		# LOAD完了メッセージ出力
		_load_cnt=`tail -3 ${ARCHIVE_FILE_LOAD_MSG} | head -1 | awk -F" " '{print $10}'`
		outlog_func AC-I10011 "${JIRA_TABLE}" "${JIRA_TABLE}" "${_load_cnt}"
	done  < ${JIRA_EXP_CSV_FILE}

	return 0
}

###############################################################################
# JIRADB旧データ削除（アーカイブ処理使用）
# 引数１：ステータスが案件終了のデータの抽出日数を指定する。
# 引数２：commit件数を指定する。
###############################################################################
function JIRADB_DELETE
{
	# 抽出日数
	DAY=$1

	# commit件数
	DELETE_COUNT=$2

	# SQL戻り値確認（処理完了後初期化にも利用）
	SQLSTATUS=0

	# 更新JIRADBのOS_WFENTRYから参照JIRADBのOS_WFENTRYに移動したデータをCommitし削除
	while [ ${SQLSTATUS} -eq 0 ]
	do
		db2 +c  "delete from (
				SELECT
				  id
				FROM
				  jiraschema.os_wfentry o_w
				WHERE
				  o_w.id IN (
					SELECT
					  workflow_id
					FROM
					  jiraschema.jiraissue j_i
					WHERE
					  date(j_i.updated) <= (VALUES current date ${DAY} days)
					AND
					  j_i.issuestatus = '${STATUS_COMPLETION}'
				  )
				fetch first ${DELETE_COUNT} rows only
				)
				" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10012 "OS_WFENTRY" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
		fi

                if [ ${SQLERROR} -eq 1 ]
                then
			db2 commit
                	break
                fi

		db2 commit > /dev/null
	done

	#削除完了メッセージ
	outlog_func AC-I10039 "OS_WFENTRY"

	#戻り値初期化
	SQLSTATUS=0

	# 更新JIRADBのCUSTOMFIELDVALUEから参照JIRADBのCUSTOMFIELDVALUEに移動したデータをCommitし削除
	while [ ${SQLSTATUS} -eq 0 ]
	do
		db2 +c "delete from (
				SELECT
				  id
				FROM
				  jiraschema.customfieldvalue c_f_v
				WHERE
				  (c_f_v.issue) IN (
					SELECT
				      id
					FROM
				      jiraschema.jiraissue j_i
					WHERE
					  date(j_i.updated) <= (VALUES current date ${DAY} days)
					AND
					  j_i.issuestatus = '${STATUS_COMPLETION}'
					)
				fetch first ${DELETE_COUNT} rows only
				)
				" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10012 "CUSTOMFIELDVALUE" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
		fi

                if [ ${SQLERROR} -eq 1 ]
                then
			db2 commit
                        break
                fi

		db2 commit > /dev/null
	done

	#削除完了メッセージ
	outlog_func AC-I10039 "CUSTOMFIELDVALUE"

	#戻り値初期化
	SQLSTATUS=0

	# 更新JIRADBのNODEASSOCIATIONから参照JIRADBのNODEASSOCIATIONに移動したデータをCommitし削除
	while [ ${SQLSTATUS} -eq 0 ]
	do
		db2 +c "delete from (
				SELECT
				  source_node_id
				FROM
				  jiraschema.nodeassociation n_a
				WHERE
				  n_a.source_node_id IN (
					SELECT
					  id
					FROM
					  jiraschema.jiraissue j_i
					WHERE
					  date(j_i.updated) <= (VALUES current date ${DAY} days)
					AND
					  j_i.issuestatus = '${STATUS_COMPLETION}'
					  )
				AND
				  SOURCE_NODE_ENTITY = 'Issue'
				fetch first ${DELETE_COUNT} rows only
				)
				" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10012 "NODEASSOCIATION" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
		fi

                if [ ${SQLERROR} -eq 1 ]
                then
			db2 commit
                        break
                fi

		db2 commit > /dev/null
	done

	#削除完了メッセージ
	outlog_func AC-I10039 "NODEASSOCIATION"

	#戻り値初期化
	SQLSTATUS=0

	# 更新JIRADBのCHANGEITEMから参照JIRADBのCHANGEITEMに移動したデータをCommitし削除
	while [ ${SQLSTATUS} -eq 0 ]
	do
		db2 +c "delete from (
				SELECT
				  id
				FROM
				  jiraschema.changeitem c_i
				WHERE
				  c_i.groupid in (
					SELECT
					  id
					FROM
					  jiraschema.changegroup c_g
					WHERE
					  c_g.issueid in (
						SELECT
						  id
						FROM
						  jiraschema.jiraissue j_i
						WHERE
						 date(j_i.updated) <= (values current date ${DAY} days)
						AND
						  j_i.issuestatus = '${STATUS_COMPLETION}'
					  )
				  )
				fetch first ${DELETE_COUNT} rows only
				)
				" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10012 "CHANGEITEM" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
		fi

                if [ ${SQLERROR} -eq 1 ]
                then
			db2 commit
                        break
                fi

		db2 commit > /dev/null

	done

	#削除完了メッセージ
	outlog_func AC-I10039 "CHANGEITEM"

	#戻り値初期化
	SQLSTATUS=0

	# 更新JIRADBのCHANGEGROUPから参照JIRADBのCHANGEGROUPに移動したデータをCommitし削除
	while [ ${SQLSTATUS} -eq 0 ]
	do
		db2 +c "delete from (
				SELECT
				  id
				FROM
				  jiraschema.changegroup c_g
				WHERE
				  c_g.issueid IN (
					SELECT
					  id
					FROM
					  jiraschema.jiraissue j_i
					WHERE
					  date(j_i.updated) <= (VALUES current date ${DAY} days) AND
					  j_i.issuestatus = '${STATUS_COMPLETION}'
					)
				fetch first ${DELETE_COUNT} rows only
				)
				" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10012 "CHANGEGROUP" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
		fi

                if [ ${SQLERROR} -eq 1 ]
                then
			db2 commit
                        break
                fi

		db2 commit > /dev/null
	done

	#削除完了メッセージ
	outlog_func AC-I10039 "CHANGEGROUP"

	#戻り値初期化
	SQLSTATUS=0

	# 更新JIRADBのJIRAACTIONから参照JIRADBのJIRAACTIONに移動したデータをCommitし削除
	while [ ${SQLSTATUS} -eq 0 ]
	do
		db2 +c "delete from (
				SELECT
				  id
				FROM
				  jiraschema.jiraaction j_a
				WHERE
				  j_a.issueid IN (
					SELECT
					  id
					FROM
					  jiraschema.jiraissue j_i
					WHERE
					  date(j_i.updated) <= (VALUES current date ${DAY} days)
					AND
					  j_i.issuestatus = '${STATUS_COMPLETION}'
				  )
				fetch first ${DELETE_COUNT} rows only
				)
				" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10012 "JIRAACTION" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
		fi

                if [ ${SQLERROR} -eq 1 ]
                then
			db2 commit
                        break
                fi

		db2 commit > /dev/null
	done

	#削除完了メッセージ
	outlog_func AC-I10039 "JIRAACTION"

	#戻り値初期化
	SQLSTATUS=0

	# 更新JIRADBのFILEATTACHMENTから参照JIRADBのFILEATTACHMENTに移動したデータをCommitし削除
	while [ ${SQLSTATUS} -eq 0 ]
	do
		db2 +c "delete from (
				SELECT
				  id
				FROM
				  jiraschema.fileattachment f_a
				WHERE
				  f_a.issueid IN (
					SELECT
					  id
					FROM
					  jiraschema.jiraissue j_i
					WHERE
					  date(j_i.updated) <= (VALUES current date ${DAY} days)
					AND
					  j_i.issuestatus = '${STATUS_COMPLETION}'
				  )
				fetch first ${DELETE_COUNT} rows only
				)
				" > ${SQLLOG_TMP}
                SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
                # DBエラー
                if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
                then
                # エラーログ出力
                _errmsg=`cat ${SQLLOG_TMP}`
                outlog_func AC-E10012 "FILEATTACHMENT" "${_errmsg}"

                # 一時ファイル等の削除
                rm -f ${SQLLOG_TMP}

                # エラー終了
                return 1
                fi

                if [ ${SQLERROR} -eq 1 ]
                then
                	db2 commit
                        break
                fi

                db2 commit > /dev/null
        done

	#削除完了メッセージ
	outlog_func AC-I10039 "FILEATTACHMENT"

        #戻り値初期化
        SQLSTATUS=0

	# 日時バッチの場合のみ処理する
	# 更新JIRADB旧データ削除時のみOS_CURRENTSTEP、OS_CURRENTSTEP_PREV、OS_HISTORYSTEP、OS_HISTORYSTEP_PREVテーブルのデータを削除する
	# OS_CURRENTSTEP、OS_CURRENTSTEP_PREV、OS_HISTORYSTEP_PREVはOS_HISTORYSTEPを見ているので最後にdeleteする
	if [ ${MONTHLY} -ne $1 ]
	then
		# 更新JIRADBのOS_CURRENTSTEPからステータスが案件終了かつ${DAY}日経過したデータをCommitし削除
		while [ ${SQLSTATUS} -eq 0 ]
		do
			db2 +c "delete from (
					SELECT
					  id
					FROM
				  	jiraschema.os_currentstep o_c
					WHERE
				  	o_c.entry_id IN (
						SELECT
					  	workflow_id
						FROM
					  	jiraschema.jiraissue j_i
						WHERE
					  	date(j_i.updated) <= (VALUES current date ${DAY} days)
						AND
					  	j_i.issuestatus = '${STATUS_COMPLETION}'
				 	 )
					fetch first ${DELETE_COUNT} rows only
					)
					" > ${SQLLOG_TMP}
			SQLERROR=$?
			echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
			# DBエラー
			if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
			then
				# エラーログ出力
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func AC-E10012 "OS_CURRENTSTEP" "${_errmsg}"

				# 一時ファイル等の削除
				rm -f ${SQLLOG_TMP}

				# エラー終了
				return 1
			fi

			if [ ${SQLERROR} -eq 1 ]
			then
				db2 commit
				break
			fi

			db2 commit > /dev/null
		done

		#削除完了メッセージ
		outlog_func AC-I10039 "OS_CURRENTSTEP"

		#戻り値初期化
		SQLSTATUS=0

		# 更新JIRADBのOS_CURRENTSTEP_PREVからステータスが案件終了かつ${DAY}日経過したデータをCommitし削除
		while [ ${SQLSTATUS} -eq 0 ]
		do
			db2 +c "delete from (
					SELECT
				  	id
					FROM
					  jiraschema.os_currentstep_prev o_c_p
					WHERE
					  o_c_p.id IN (
						SELECT
						  id
						FROM
						  jiraschema.os_historystep o_h
						WHERE
							o_h.entry_id IN (
								SELECT
									j_i.workflow_id
								FROM
									jiraschema.jiraissue j_i
								WHERE
						  			date(j_i.updated) <= (VALUES current date ${DAY} days)
								AND
						  			j_i.issuestatus = '${STATUS_COMPLETION}'
							)
						)
					fetch first ${DELETE_COUNT} rows only
					)
					" > ${SQLLOG_TMP}
			SQLERROR=$?
			echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
			# DBエラー
			if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
			then
				# エラーログ出力
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func AC-E10012 "OS_CURRENTSTEP_PREV" "${_errmsg}"

				# 一時ファイル等の削除
				rm -f ${SQLLOG_TMP}

				# エラー終了
				return 1
			fi

			if [ ${SQLERROR} -eq 1 ]
			then
				db2 commit
				break
			fi

			db2 commit > /dev/null
		done

		#削除完了メッセージ
		outlog_func AC-I10039 "OS_CURRENTSTEP_PREV"

		#戻り値初期化
		SQLSTATUS=0

		# 更新JIRADBのOS_HISTORYSTEP_PREVからステータスが案件終了かつ${DAY}日経過したデータをCommitし削除
		while [ ${SQLSTATUS} -eq 0 ]
		do
			db2 +c "delete from (
					SELECT
					  id
					FROM
					  jiraschema.os_historystep_prev o_h_p
					WHERE
					  o_h_p.id IN (
						SELECT
						  id
						FROM
						  jiraschema.os_historystep o_h
						WHERE
							o_h.entry_id IN (
								SELECT
									j_i.workflow_id
								FROM
									jiraschema.jiraissue j_i
								WHERE
						  			date(j_i.updated) <= (VALUES current date ${DAY} days)
								AND
						  			j_i.issuestatus = '${STATUS_COMPLETION}'
							)
						)
					fetch first ${DELETE_COUNT} rows only
					)
					" > ${SQLLOG_TMP}
			SQLERROR=$?
			echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
			# DBエラー
			if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
			then
				# エラーログ出力
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func AC-E10012 "OS_HISTORYSTEP_PREV" "${_errmsg}"

				# 一時ファイル等の削除
				rm -f ${SQLLOG_TMP}

				# エラー終了
				return 1
			fi

			if [ ${SQLERROR} -eq 1 ]
			then
				db2 commit
				break
			fi

			db2 commit > /dev/null
		done

		#削除完了メッセージ
		outlog_func AC-I10039 "OS_HISTORYSTEP_PREV"

		#戻り値初期化
		SQLSTATUS=0

		# 更新JIRADBのOS_HISTORYSTEPからステータスが案件終了かつ${DAY}日経過したデータをCommitし削除
		while [ ${SQLSTATUS} -eq 0 ]
		do
			db2 +c "delete from (
					SELECT
					  id
					FROM
					  jiraschema.os_historystep o_h
					WHERE
					  o_h.entry_id IN (
						SELECT
						  workflow_id
						FROM
						  jiraschema.jiraissue j_i
						WHERE
						  date(j_i.updated) <= (VALUES current date ${DAY} days)
						AND
						  j_i.issuestatus = '${STATUS_COMPLETION}'
					  )
					fetch first ${DELETE_COUNT} rows only
					)
					" > ${SQLLOG_TMP}
			SQLERROR=$?
			echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
			# DBエラー
			if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
			then
				# エラーログ出力
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func AC-E10012 "OS_HISTORYSTEP" "${_errmsg}"

				# 一時ファイル等の削除
				rm -f ${SQLLOG_TMP}

				# エラー終了
				return 1
			fi

			if [ ${SQLERROR} -eq 1 ]
			then
				db2 commit
				break
			fi

			db2 commit > /dev/null
		done

		#削除完了メッセージ
		outlog_func AC-I10039 "OS_HISTORYSTEP"

		#戻り値初期化
		SQLSTATUS=0

	fi

	# 更新JIRADBのJIRAISSUEから参照JIRADBのJIRAISSUEに移動したデータをCommitし削除
	while [ ${SQLSTATUS} -eq 0 ]
	do
		db2 +c  "delete from (
				SELECT
				  id
				FROM
				  jiraschema.jiraissue j_i
				WHERE
				  date(j_i.updated) <= (VALUES current date ${DAY} days)
				AND
				  j_i.issuestatus = '${STATUS_COMPLETION}'
				fetch first ${DELETE_COUNT} rows only
				)
				" > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
		# DBエラー
		if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
		then
		# エラーログ出力
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func AC-E10012 "JIRAISSUE" "${_errmsg}"

		# 一時ファイル等の削除
		rm -f ${SQLLOG_TMP}

		# エラー終了
		return 1
		fi

                if [ ${SQLERROR} -eq 1 ]
                then
			db2 commit
                        break
                fi

		db2 commit > /dev/null
	done

	#削除完了メッセージ
	outlog_func AC-I10039 "JIRAISSUE"


return 0
}

################################################################################
# REORG_RUNSTATS（アーカイブ処理使用）
# 引数１：対象テーブルリストファイルを指定
################################################################################
function REORG_RUNSTATS
{

	#対象テーブルリストファイルを指定
	_tablelist=$1

	# 対象情報取得
	lineno=0
	while read line;do
		array[${lineno}]=${line}
		lineno=$(expr ${lineno} + 1)
	done < ${_tablelist}
	# ProcStartLog
	if [ ${lineno} != '0' ]
	then
		outlog_func CM-I11004 "${lineno}"
	else
		outlog_func CM-E11005
		return 1
	fi

	#認証関数を呼出す
	. /workflow/auth_mgr/decrypt/ASCA_DECRYPT_MANAGER.sh ALL

	# テーブル再構成
	for i in "${array[@]}";do
		rtncd=0
		# 対象情報エレメント分割
		echo ${i} | sed -e 's/,/ /g' | while read dbname dbuserkbn schemaname tablename
		#echo ${i} | sed -e 's/,/ /g' | while read dbname schemaname tablename

		do
			#DB区分によって、ユーザーIDとPWDを取得
			case ${dbuserkbn} in
				USER2)	dbuser=${A_USER2_ID}
			            pswd=${A_USER2_PWD}
				;;
				USER3)	dbuser=${A_USER3_ID}
			            pswd=${A_USER3_PWD}
				;;
				USER4)	dbuser=${A_USER4_ID}
			            pswd=${A_USER4_PWD}
				;;
			esac
			
			# DB接続
			db2 connect to ${dbname} user ${dbuser} using ${pswd} > ${SQLLOG_TMP}
			SQLERROR=$?
			echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
			# コマンド判定
			if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
			then
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func CM-E11006 "${_errmsg}"
				return 1
			fi
			echo "" >> ${SQLLOG_TMP}
			# テーブル再構成
			db2 "reorg table ${schemaname}.${tablename}" > ${SQLLOG_TMP}
			SQLERROR=$?
			echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
			# コマンド判定
			if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
			then
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func CM-E11007 "${_errmsg}"
				return 1
			fi
			echo "" >> ${SQLLOG_TMP}
			# テーブル統計情報再作成
			db2 "runstats on table ${schemaname}.${tablename} and indexes all" > ${SQLLOG_TMP}
			SQLERROR=$?
			echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
			# コマンド判定
			if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
			then
				_errmsg=`cat ${SQLLOG_TMP}`
				outlog_func CM-E11008 "${_errmsg}"
				return 1
			fi
			echo "" >> ${SQLLOG_TMP}
			# DB切断
			db2 terminate > /dev/null
			outlog_func CM-I11010 ${dbname} ${schemaname} ${tablename}
		done
		if [ $? != 0 ]
		then
			outlog_func CM-E11009
			return 1
		fi
	done
	return 0
}

###############################################################################
# DB接続関数
#
# 関数名：　connectDB
#
# 機能：　引数で指定したDBに接続する
#
# 引数：　DB名（"db2 connect to"に続くコマンド）
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#
###############################################################################
function connectDB
{

    # DB接続
    db2 connect to "$*" > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
	# コマンド判定
    if [ ${SQLERROR} != 0 ]
    then
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func CM-E05058 "${_errmsg}"

        return 1
    fi

    return 0
}

###############################################################################
# JIRA DELETE_CSV_FILE関数
#
# 関数名：　DELETE_EXPORT_CSV
#
# 機能：　更新用DBから抽出したCSVファイルを削除する
#
# 引数：　対象テーブルリストファイルを指定
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#
###############################################################################
function DELETE_EXPORT_CSV
{

	# 参照JIRAにLOADするCSVファイル
	JIRA_EXP_CSV_FILE=$1

	# 更新JIRADBのから出力したCSVファイルを削除する。
	while read UPDATE_JIRA_EXP_CSV
	do

		if [ -z "${UPDATE_JIRA_EXP_CSV}" ]
		then
			outlog_func CM-E99002 "${UPDATE_JIRA_EXP_CSV}"
			continue
		else
			rm -f "${UPDATE_JIRA_EXP_CSV}"
		fi

	done  < ${JIRA_EXP_CSV_FILE}

	return 0
}

################################################################################
# TRIGER_FL（アーカイブ処理使用）
# 引数１：JP1起動トリガーファイル名を指定
################################################################################
function JP1_TRIGER_FL {

	# JP1起動ファイル
	TRIGER_FL=$1

	# ERR_ID
	ERR_ID=$2

	# INF_ID
	INF_ID=$3

	# JP1起動トリガーファイル生成
	touch ${TRIGER_FL}
	STATUS=$?
	# 戻り値が0以外の場合はエラーのため、return 1を返す
	if [ ${STATUS} != '0'  ]
	then
		outlog_func ${ERR_ID} ${TRIGER_FL}
		return 1
	else
		outlog_func ${INF_ID} ${TRIGER_FL}
	fi

	return 0
}

#########################################################################
# I/Fファイル転送関数
#
# 関数名： IF_FILE_TRANSMISSION
#
# 機能： HULFTから送信されたI/Fファイルをバックアップフォルダへ転送する
#
# 戻り値：  0:正常
#           1:異常
#
# 引数１：HULFT送信先のフォルダパス、及びファイル名
#
# 引数２：バックアップフォルダパス、及びバックアップファイル名
#
#########################################################################
function IF_FILE_TRANSMISSION {
	HULFT_IF_FILE=$1
	BKUP_IF_FILE=$2

	# I/Fファイルの存在確認をし、I/Fファイルが存在する場合は
	# I/Fファイルのバックアップを作成する
	if [ -f "${HULFT_IF_FILE}" ]
	then
		# HULFT送信先のファイルパスからバックアップフォルダパスに
		# %Y%m%d%H%M形式にてMV
		mv -f ${HULFT_IF_FILE} ${BKUP_IF_FILE}
		STATUS=$?	# 戻り値
		# 戻り値が0以外の場合はエラーのため、return 1を返す
		if [ ${STATUS} != '0'  ]
		then
			outlog_func CM-E01001 ${BKUP_IF_FILE}
			return 1
		fi
		outlog_func CM-I01003 ${HULFT_IF_FILE} ${BKUP_IF_FILE}
	else
		# I/Fファイルが存在しない場合はメッセージを出力し処理終了
    	outlog_func CM-E01002 ${HULFT_IF_FILE}
    	return 0
	fi
	return 0
}

#########################################################################
# ディスク利用できるサイズチェック関数
# 関数名：CHECK_DISK_FREE_SIZE
# 機能：ディスク利用できるサイズをチェックする
# 引数１：ディレクトリ名
# 引数２：最小サイズ（M）
# 戻り値：０－正常
#		1－異常
#########################################################################
function CHECK_DISK_FREE_SIZE {

	# ディスク利用できるサイズ取得
	result=`df -m ${1}`
	RC=$?
	if [ "${RC}" != "0" ]
	then
		outlog_func CM-E99026 ${1} ${RC}
		return 1
	fi

	# ディスク利用できるサイズチェック
	available=`echo ${result} | awk '{print $(NF-2)}'`
	if [ ${available} -le ${2} ]
	then
		outlog_func CM-E99027 ${2}
		return 1
	fi
	return 0
}

#########################################################################
# rshコマンドはsshで置き換える
# 関数名：REMOTE_EXEC_SH
# 機能：リモートでシェルを実行する
# 引数１：対象IP
# 引数２：パスとシェル名
# 戻り値：０－正常
#		   1－異常
#########################################################################
function REMOTE_EXEC_SH {

	# 対象IP
	IP=$1
	
	# シェル名
	SH_NAME=$2
	
	# 臨時メッセージ出力ログ
	export REMOTE_EXEC_FILE=${TMP_DIR}/`basename ${0}`_ssh_result_`date +%Y%m%d`.txt
	
	# リモートシェル実行
	ssh ${IP} ${SH_NAME} > ${REMOTE_EXEC_FILE} 2>&1
	RC=$?
	
	# 戻り値が0以外の場合はエラー
	if [ ${RC} != '0' ]
	then
		outlog_func CM-E99028 ${IP} "${SH_NAME}" ${RC} "${REMOTE_EXEC_FILE}"
	fi
	
	return ${RC}
}

#########################################################################
# rcpコマンドはscpで置き換える
# 関数名：REMOTE_COPY
# 機能：リモートでファイルをコピーする
# 引数１：コピー元（[<IP>]:<パス><ファイル名>）
# 引数２：コピー先（[<IP>]:<パス>）
# 戻り値：０－正常
#		   1－異常
#########################################################################
function REMOTE_COPY {

	# コピー元
	SCP_FROM=$1
	
	# コピー先
	SCP_TO=$2
	
	# リモートファイルコピー
	scp -p ${SCP_FROM} ${SCP_TO}
	RC=$?
	
	# 戻り値が0以外の場合はエラー
	if [ ${RC} != '0' ]
	then
		outlog_func CM-E99029 ${SCP_FROM} ${SCP_TO} ${RC}
	fi
	
	return ${RC}
}

#########################################################################
# サーバACTIVEチェック
# 関数名：サーバACTIVEチェック
# 機能：サーバACTIVEチェック
# 引数１：サーバ配列
# 戻り値：0－正常
#	1-異常(全部ACTIVEではない)
#########################################################################
function ACTIVE_CHECK {

	# サーバ
	servers=$1
	
	RC=1
	for server in $servers
	do
		ping -c 5 $server  > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			RC=0
			export ACTIVE_CHECK_SERVER=$server
			break
		fi
	done
	
	return ${RC}
}
