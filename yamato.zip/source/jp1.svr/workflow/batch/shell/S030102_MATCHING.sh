#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S030102_MATCHING.sh
# 業 務 名       ： マッチング（経費振替リスト処理）
# 処理概要       ： 経費振替テーブルと証憑テーブルの紐付けを行う。
# 特記事項       ： 起動トリガー：定期的な時間起動。
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ：
#
# 作成日付       ：
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.1 2010-04-22 H.Someya               コメント修正
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

################################################################################
# マッチング処理関数
################################################################################
function matching
{
	#マッチング件数ログ表示用変数
	matchingCount=0;

    # DB接続
    db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
    SQLERROR=$?
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
    then
        # DB接続エラー
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func CT-E06004 "${_errmsg}"
        # 一時ファイル等の削除
        rm -f  ${SQLLOG_TMP}
        # エラー終了
        return 1
    fi
    echo "" >> ${SQLLOG_TMP}

    # 経費振替マッチング処理
    _s030102_sql=${SQL_DIR}/S030102_MATCHING.sql
    # SQL実行
    db2 -tvf ${_s030102_sql} > ${SQLLOG_TMP}
    if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
    then
        # SQLエラー
        # エラーログ出力
        _errmsg=`cat ${SQLLOG_TMP}`
        outlog_func CT-E06005 "${_errmsg}"
        # 一時ファイル等の削除
        rm -f  ${SQLLOG_TMP}
        # エラー終了
        return 1
    fi
    echo "" >> ${SQLLOG_TMP}

    # SQL結果ファイル存在チェック
    if [ ! -f ${_sqltmp} ]
    then
        outlog_func CT-E06006
        return 1
    fi

    # SQL結果ファイルを整形
    sed -e s/,/" "/g ${_sqltmp} | sed -e s/\"/""/g > ${_idlisttmp}
    if [ $? != '0' ]
    then
        # コマンドエラー
        outlog_func CT-E06008
        return 1
    fi

    # マッチング結果反映
    # マッチング条件に該当した通番と証憑IDの件数分ループを行う
    while read tsuuban_tmp shohyo_id_tmp
    do
        # 該当テーブルにマッチングした証憑IDを更新する
        db2 "update ${TABLE_S030102} set MATCHINGshouhyouID = '${shohyo_id_tmp}' where tsuuban = '${tsuuban_tmp}'" > ${SQLLOG_TMP}
        SQLERROR=$?
        echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
        if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
        then
            # SQLエラー
            # エラーログ出力
            _errmsg=`cat ${SQLLOG_TMP}`
			outlog_func CT-I06007 ${matchingCount}
            outlog_func CT-E06009 ${tsuuban_tmp} "${_errmsg}"
            # 一時ファイル等の削除
            rm -f  ${SQLLOG_TMP}
            # エラー終了
            return 1
        fi
        echo "" >> ${SQLLOG_TMP}

		#マッチング件数＋１
		matchingCount=`expr ${matchingCount} + 1`

    done < ${_idlisttmp}

	#マッチング件数をログに出力
	outlog_func CT-I06010 ${matchingCount}

    # DB切断
    db2 terminate > /dev/null

	return 0
}
################################################################################
# 環境設定を行う
################################################################################
# 環境設定ファイルを読み込む
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
    # TODO : 起動時標準出力をdev/nullに投げているが問題ないか確認
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

################################################################################
# 個別環境設定を行う
################################################################################
# 一時設定ファイルを読み込む
export _sqltmp=${TMP_DIR}/S030102_tsuuban.tmp
export _idlisttmp=${TMP_DIR}/S030102_idlist.tmp

################################################################################
# MAIN処理
################################################################################
# 出力ログ名設定
export log_name=${SHOHYO_MAIN_FLOW_LOG}

outlog_func CT-I06001
# 関数呼び出し
matching
if [ $? != '0' ]
then
     # 一時ファイルを削除
    rm -f ${_sqltmp}
    rm -f ${_idlisttmp}
    outlog_func CT-E06003
    exit 1
else
     # 一時ファイルを削除
    rm -f ${_sqltmp}
    rm -f ${_idlisttmp}
    outlog_func CT-I06002
    exit 0
fi
