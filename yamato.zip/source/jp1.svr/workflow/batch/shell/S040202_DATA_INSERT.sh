#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： S040202_DATE_INSERT.sh
# 業 務 名       ： 一般集金（手動消込）データ登録
# 処理概要       ： 一般集金（手動消込）データをGWに登録
# 特記事項       ： 起動トリガー：JP1により機動
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： T.Sakagami
#
# 作成日付       ： 2009-07-16
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-16 T.Sakagami             新規作成
# 2 1.1.0 2009-09-14 Y.Otsuka               ヘッダー追加
# 3 1.2.0 2009-12-21 M.Saiki                importリトライ追加
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

##########################################################################
# 一般集金（手動消込）CSV作成関数 
##########################################################################
function ippansyukin_syudou {

    ${PERL_DIR}/S040202_CREATE_CSV.pl ${1} ${CSV_OUT_DIR}/${FILE_S040202}.csv.euc ${FILE_S040202} > ${DETAIL_LOG_TMP}
    rc=$?
    while read id msg
    do
        outlog_func ${id} ${msg}
    done < ${DETAIL_LOG_TMP}

    if [ ${rc} != "0" ];then
        return 1
    else
        return 0
    fi
}

#################################################################
# main処理
#################################################################

#環境設定を行う
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ];then
    echo "バッチ環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# 一時ファイル
_tmp="${TMP_DIR}/S040202_DATA_INSERT.tmp"
# DB登録用シェル名
_shname="S040202_DATA_INSERT.sh"

# 出力ログ名設定
export log_name=${S040202_MAIN_FLOW_LOG}

outlog_func GC-I02001

# 一般集金（手動消込）PPファイル存在確認
#if [[ ! -f ${PP_FILE_PATH}/${FILE_S040202} ]];then

	# PPバックアップファイル名にOKが無いものを取得（正常終了しなかったPPファイル）
   _FILE_S040202_BAK=`ls ${PPFILE_BACKUP_DIR}| grep ${FILE_S040202} | grep -v OK | head -1`

    # PPバックアップファイルの末尾が全てOK
    if [[ -z ${_FILE_S040202_BAK} ]];then

	# 一般集金（手動消込）PPファイルが存在しない
    	outlog_func GC-W02005 ${FILE_S040202}

        # 処理対象ファイルが存在しないので終了
        exit 0

    # PPバックアップファイルの末尾がOKでないものがある
    else

	# ディレクトリパスを付与
	_FILE_S040202_BAK_PATH="${PPFILE_BACKUP_DIR}/${_FILE_S040202_BAK}"

	# 文字化けを防ぐためEUCにコード変換
	nkf -e ${_FILE_S040202_BAK_PATH} > ${CSV_OUT_DIR}/${_FILE_S040202_BAK}

        # 一般集金（手動消込）CSV作成関数呼び出し
        ippansyukin_syudou "${CSV_OUT_DIR}/${_FILE_S040202_BAK}"

        # エラー判定
        if [[ $? != "0" ]];then

			outlog_func GC-E02006
			# CSV削除
			rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv.euc
           exit 1
        fi
	# コード変換したファイルを削除
	rm -f "${CSV_OUT_DIR}/${_FILE_S040202_BAK}"
    fi
#else

    # 一般集金（手動消込）PPファイルのバックアップを作成
#    _FILE_S040202_BAK=${PPFILE_BACKUP_DIR}/${FILE_S040202}.`date +%Y%m%d%H%M`
    # 文字化けを防ぐためEUCにコード変換して退避
#    nkf -e ${PP_FILE_PATH}/${FILE_S040202} > ${_FILE_S040202_BAK}

    # エラー判定
#    if [ $? != "0" ]
#	then

#        outlog_func GC-E02009

#        exit 1
#    fi

    # バックアップ成功時に送られてきたファイルを削除
#    rm -f ${PP_FILE_PATH}/${FILE_S040202}

    # 一般集金（手動消込）CSV作成関数呼び出し
#    ippansyukin_syudou "${_FILE_S040202_BAK}"

    # エラー判定
#    if [[ $? != "0" ]];then
#        outlog_func GC-E02011

		# CSV削除
#		rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv.euc

#        exit 1
#    fi
#fi

# DB接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力	
	_errmsg=`cat ${SQLLOG_TMP}`
	outlog_func GC-E02007
	
	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# CSV削除
	rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv.euc

	# エラー終了
	exit 1
fi
echo "" >> ${SQLLOG_TMP}

# CSVファイルが存在すればDBにインサートを行う
if [ -f ${CSV_OUT_DIR}/${FILE_S040202}.csv.euc ];then

	# SJISにコード変換
	nkf -s ${CSV_OUT_DIR}/${FILE_S040202}.csv.euc > ${CSV_OUT_DIR}/${FILE_S040202}.csv

    # エラー判定
    if [ $? != "0" ]
	then

        outlog_func GC-E02010

    	# 一時ファイル等の削除
    	rm -f  ${SQLLOG_TMP}

		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv
		rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv.euc

        exit 1
    fi

	# 一般集金（手動消込）CSVインポート
nkf --ic=CP932 --oc=UTF-8 ${CSV_OUT_DIR}/${FILE_S040202}.csv > ${CSV_OUT_DIR}/${FILE_S040202}.csv.utf8
	
	#インポートコマンドの戻り値が８の場合、３回処理を行う。
	for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
	do
		db2 import from ${CSV_OUT_DIR}/${FILE_S040202}.csv.utf8 of del messages ${_tmp} INSERT_UPDATE into ${TABLE_S040202} > ${SQLLOG_TMP}
		SQLERROR=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

		# DBエラー（ループに戻す） エラーコード８のみ
		if [ ${SQLERROR} -eq 8 ]
		then
			# 接続断
			db2 terminate > /dev/null
			# 5秒間待ち、再接続、importコマンド実行
			sleep 5
			outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
			outlog_func IM-I01002 "${DB_NAME}"

			connectDB ${DB_NAME}

			if [ $? != '0' ]
			then
				# 異常の場合、次の処理を行う。
				IMPORT_RETRY_CNT=0
			fi
			SQLERROR=8
		else
			# 正常の場合、次の処理を行う。
			IMPORT_RETRY_CNT=0
		fi
	done
		
	# DBエラー
	if [ ${SQLERROR} -eq 2 -o ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラーログ出力	
		_errmsg=`cat ${SQLLOG_TMP}`
		outlog_func GC-E02008  "${_errmsg}"
		
		# 一時ファイル等の削除
		rm -f  ${SQLLOG_TMP}

		# CSV削除
		rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv
		rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv.euc
		rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv.utf8

		# エラー終了
		exit 1
	fi
	echo "" >> ${SQLLOG_TMP}

	# 正常終了したPPファイルの末尾にOKをつける
	mv -f ${_FILE_S040202_BAK_PATH} ${_FILE_S040202_BAK_PATH}.OK
fi

# DB切断
db2 terminate > /dev/null

# 作成したCSVファイルを削除
rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv
rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv.euc
rm -f ${CSV_OUT_DIR}/${FILE_S040202}.csv.utf8

# 一時ファイル削除
rm -f ${_tmp}

outlog_func GC-I02002

exit 0
