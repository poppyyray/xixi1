#!/bin/sh
################### モジュール説明 ############################################
# モジュール名   ： CHOHYO_UMU_HANEIZUMI_UPDATE.sh
# システム名     ： 帳票有無フラグ反映対象外更新
# 言語           ： sh
# ＯＳ           ： Linux (Red hat)
# 処理概要       ： 参照系JIRAにアーカイブされたか、案件終了しているステータスの
#                   ワークアイテムについて帳票反映済みフラグをNに更新し、
#                   帳票反映対象外にする。更新対象テーブルはGWDBの業務テーブル
# 特記事項       ： なし
# パラメータ     ： なし
# ログファイル   ： /workflow/batch/logs/CHOHYO_UMU_HANEIZUMI_UPDATE.log
# リターンコード ： 正常終了(0)
#                   処理異常(1)
# 対象DB         ： なし
#
################### モジュール説明 #############################################
#
################### 改定履歴       #############################################
# 作成者         ： S.Tsuruha
# 作成日付       ： 2010-02-26
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
# 1初版     2010-02-26  S.Tsuruha               新規作成
# 2
# =V.R.M=== == DATE == ==担当者==== =準拠文書== ==== 内容 ======================
################### 改定履歴       #############################################

###############################################################################
# main処理開始
###############################################################################
# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
        echo "環境設定ファイルが存在しません"
        exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# 個別環境変数設定
# ----
JIRA_PKEY_LIST=jirau_pkey_list.csv
SHONINZUMI_STATUS=10039
COLUMN_PKEY=pkey
TABLE_JIRAISSUE=jiraschema.jiraissue
TABLE_JIRAU_PKEY_LIST=db2inst3.jirau_pkey_list
COLUMN_ISSUESTATUS=issuestatus
TABLE_GE=IPPANSYUUKIN_ERRORTAIOU
TABLE_GC=IPPANSYUUKIN_SHUDOUKESHIKOMI
TABLE_CT=KEIHIFURIKAE
TABLE_CE=NYUUSYUKKINZAIRYOUKAKUNIN
TABLE_UD=NYUUKINDATAUNMATCH
COLUMN_CHOHYO_UMU_HANEIZUMI=CHOHYO_UMU_HANEIZUMI
CHOHYO_UMU_HANEIZUMI_SETVALUE="'N'"
COLUMN_KOUSINSYA=KOUSINSYA
KOUSINSYA_SETVALUE="'data_maintenance'"
COLUMN_KOUSINNICHIJI=KOUSINNICHIJI
KOUSINNICHIJI_SETVALUE="current timestamp"
COLUMN_JIRAHANEIZUMI=JIRAHANEIZUMI
JIRAHANEIZUMI_VALUE="'Y'"
COLUMN_PKEY_CD=pkey_cd

# ----
# 出力ログ名設定
# ----
export log_name=${CHOHYO_UMU_HANEIZUMI_UPDATE_LOG}

# ----
# main処理開始
# ----
outlog_func CH-I01001

# ----
# JIRADBへ接続
# ----
connectDB ${JIRA_DB_NAME}

# SQLエラーハンドリング
if [ $? != '0' ]
then
    outlog_func CH-E01002
    exit 1
fi

# ----
# 更新JIRADBから、ステータスがE01(案件終了)以外のワークアイテムの通番を取得する
# ----
db2 " 
EXPORT TO ${CSV_OUT_DIR}/${JIRA_PKEY_LIST} OF DEL
SELECT SUBSTR(${COLUMN_PKEY},1,17) 
FROM ${TABLE_JIRAISSUE}
WHERE ${COLUMN_ISSUESTATUS} <> '${SHONINZUMI_STATUS}'" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
if [ ${SQLERROR} != '0' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01003 "${ERRORMSG}"
    exit 1
fi

# ----
# db接続切断
# ----
db2 terminate > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
if [ ${SQLERROR} != '0' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01004 "${ERRORMSG}"
    exit 1
fi

# ----
# GWDBへ接続
# ----
connectDB ${DB_NAME}

# SQLエラーハンドリング
if [ $? != '0' ]
then
    outlog_func CH-E01005
    exit 1
fi

# ----
# 作業用テーブルへのデータインポート処理
# ----

#インポートコマンドの戻り値が８の場合、３回処理を行う。
for(( ; ${IMPORT_RETRY_CNT} > 0 ; IMPORT_RETRY_CNT=`expr ${IMPORT_RETRY_CNT} - 1` ))
do
    db2 "
    IMPORT FROM  ${CSV_OUT_DIR}/${JIRA_PKEY_LIST} OF DEL 
    REPLACE INTO ${TABLE_JIRAU_PKEY_LIST}" > ${SQLLOG_TMP} 2>&1
    
    # SQL実行後の戻り値を変数SQLERRORに格納
    SQLERROR=$?
    
    # SQL実行後のメッセージ内容を、処理詳細ログに出力する
    echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}
    
    # DBエラー（ループに戻す） エラーコード８のみ
    if [ ${SQLERROR} -eq 8 ]
    then
        # 接続断
        db2 terminate > /dev/null
        # 5秒間待ち、再接続、importコマンド実行
        sleep 5
        outlog_func IM-I01001 "${IMPORT_RETRY_CNT}"
        outlog_func IM-I01002 "${DB_NAME}"

        connectDB ${DB_NAME}

        if [ $? != '0' ]
        then
                # 異常の場合、次の処理を行う。
                IMPORT_RETRY_CNT=0
        fi
        SQLERROR=8
    else
        # 正常の場合、次の処理を行う。
        IMPORT_RETRY_CNT=0
    fi
done

# SQLエラーハンドリング
if [ ${SQLERROR} != '0' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01006 "${ERRORMSG}"
    exit 1
fi

# ----
# 一般集金(エラー処理)業務テーブルの帳票有無反映済みフラグを"N"に更新
# ----

# 帳票有無反映済みフラグがEのデータを更新
db2 +c "
UPDATE ${TABLE_GE} 
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE}
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} = 'E' 
AND ${COLUMN_PKEY_CD} NOT IN 
       (SELECT ${COLUMN_PKEY} 
        FROM ${TABLE_JIRAU_PKEY_LIST} 
        WHERE ${COLUMN_PKEY} LIKE 'GE%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01007 "${ERRORMSG}"
    exit 1
fi

# 帳票有無反映済みフラグがnullのデータを更新
db2 +c "
UPDATE ${TABLE_GE}
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE}
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} is null
AND ${COLUMN_PKEY_CD} NOT IN
       (SELECT ${COLUMN_PKEY}
        FROM ${TABLE_JIRAU_PKEY_LIST}
        WHERE ${COLUMN_PKEY} LIKE 'GE%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01014 "${ERRORMSG}"
    exit 1
fi

# ----
# 一般集金(手動消込)業務テーブルの帳票有無反映済みフラグを"N"に更新
# ----

# 帳票有無反映済みフラグがEのデータを更新
db2 +c "
UPDATE ${TABLE_GC} 
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}  
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE} 
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} = 'E'
AND ${COLUMN_PKEY_CD} NOT IN 
       (SELECT ${COLUMN_PKEY} 
        FROM ${TABLE_JIRAU_PKEY_LIST} 
        WHERE ${COLUMN_PKEY} LIKE 'GC%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01008 "${ERRORMSG}"
    exit 1
fi


# 帳票有無反映済みフラグがnullのデータを更新
db2 +c "
UPDATE ${TABLE_GC}
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE}
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} is null
AND ${COLUMN_PKEY_CD} NOT IN
       (SELECT ${COLUMN_PKEY}
        FROM ${TABLE_JIRAU_PKEY_LIST}
        WHERE ${COLUMN_PKEY} LIKE 'GC%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01015 "${ERRORMSG}"
    exit 1
fi
# ----
# 経費振替業務テーブルの帳票有無反映済みフラグを"N"に更新
# ----

# 帳票有無反映済みフラグがEのデータを更新
db2 +c "
UPDATE ${TABLE_CT} 
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}  
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE} 
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} ='E'
AND ${COLUMN_PKEY_CD} NOT IN 
       (SELECT ${COLUMN_PKEY} 
        FROM ${TABLE_JIRAU_PKEY_LIST} 
        WHERE ${COLUMN_PKEY} LIKE 'CT%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01009 "${ERRORMSG}"
    exit 1
fi

# 帳票有無反映済みフラグがnullのデータを更新
db2 +c "
UPDATE ${TABLE_CT}
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE}
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} is null
AND ${COLUMN_PKEY_CD} NOT IN
       (SELECT ${COLUMN_PKEY}
        FROM ${TABLE_JIRAU_PKEY_LIST}
        WHERE ${COLUMN_PKEY} LIKE 'CT%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01016 "${ERRORMSG}"
    exit 1
fi
# ----
# 入金データアンマッチ業務テーブルの帳票有無反映済みフラグを"N"に更新
# ----

# 帳票有無反映済みフラグがEのデータを更新
db2 +c "
UPDATE ${TABLE_UD} 
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}  
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE} 
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} ='E'
AND ${COLUMN_PKEY_CD} NOT IN 
       (SELECT ${COLUMN_PKEY} 
        FROM ${TABLE_JIRAU_PKEY_LIST} 
        WHERE ${COLUMN_PKEY} LIKE 'UD%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01010 "${ERRORMSG}"
    exit 1
fi


# 帳票有無反映済みフラグがnullのデータを更新
db2 +c "
UPDATE ${TABLE_UD}
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE}
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} is null
AND ${COLUMN_PKEY_CD} NOT IN
       (SELECT ${COLUMN_PKEY}
        FROM ${TABLE_JIRAU_PKEY_LIST}
        WHERE ${COLUMN_PKEY} LIKE 'UD%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01017 "${ERRORMSG}"
    exit 1
fi

# ----
# 入出金材料確認業務テーブルの帳票有無反映済みフラグを"N"に更新
# ----

# 帳票反映済みフラグがEのデータを更新
db2 +c "
UPDATE ${TABLE_CE} 
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}  
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE} 
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} = 'E'
AND ${COLUMN_PKEY_CD} NOT IN 
       (SELECT ${COLUMN_PKEY} 
        FROM ${TABLE_JIRAU_PKEY_LIST} 
        WHERE ${COLUMN_PKEY} LIKE 'CE%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01011 "${ERRORMSG}"
    exit 1
fi

# 帳票反映済みフラグがnullのデータを更新
db2 +c "
UPDATE ${TABLE_CE}
SET ${COLUMN_CHOHYO_UMU_HANEIZUMI} = ${CHOHYO_UMU_HANEIZUMI_SETVALUE},
      ${COLUMN_KOUSINSYA} = ${KOUSINSYA_SETVALUE},
      ${COLUMN_KOUSINNICHIJI} = ${KOUSINNICHIJI_SETVALUE}
WHERE ${COLUMN_JIRAHANEIZUMI} = ${JIRAHANEIZUMI_VALUE}
AND ${COLUMN_CHOHYO_UMU_HANEIZUMI} is null
AND ${COLUMN_PKEY_CD} NOT IN
       (SELECT ${COLUMN_PKEY}
        FROM ${TABLE_JIRAU_PKEY_LIST}
        WHERE ${COLUMN_PKEY} LIKE 'CE%')" > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
# ${SQLERROR}=1の場合は、更新対象の行数が0行であったことを意味する
if [ ${SQLERROR} != '0' -a ${SQLERROR} != '1' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01018 "${ERRORMSG}"
    exit 1
fi

# ----
# トランザクション コミット処理
# ----
db2 commit > ${SQLLOG_TMP} 2>&1

# SQL実行後の戻り値を変数SQLERRORに格納
SQLERROR=$?

# SQL実行後のメッセージ内容を、処理詳細ログに出力する
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 6` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${DETAIL_LOG}

# SQLエラーハンドリング
if [ ${SQLERROR} != '0' ]
then
    ERRORMSG=`cat ${SQLLOG_TMP}`
    outlog_func CH-E01012 "${ERRORMSG}"
    exit 1
fi

# ----
# main処理終了
# ----
outlog_func CH-I01013
exit 0
