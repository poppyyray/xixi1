export to /workflow/batch/tmp/S030101_tsuuban3.tmp of del 
SELECT 
	nyuusyukkinzairyoukakunin.tsuuban, 
	shohyo_data.shohyo_id 
FROM 
	nyuusyukkinzairyoukakunin, 
	shohyo_data 
WHERE 
	nyuusyukkinzairyoukakunin.tenshoCODE = shohyo_data.tenshoCODE AND 
	nyuusyukkinzairyoukakunin.kojinbangou = shohyo_data.kojinbangou AND 
	nyuusyukkinzairyoukakunin.chouhyouID = '0023' AND shohyo_data.chohyo_id = '0023' AND 
	nyuusyukkinzairyoukakunin.sagyoubi = shohyo_data.shohyo_date AND 
	nyuusyukkinzairyoukakunin.MATCHINGshouhyouID IS NULL;
