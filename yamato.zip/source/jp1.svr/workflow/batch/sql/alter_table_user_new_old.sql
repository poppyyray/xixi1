--user_data_jira_oldへカラム追加・削除--
alter table user_data_jira_old add column jira_group varchar(1);
reorg table user_data_jira_old;
alter table user_data_jira_old drop column system_code;
reorg table user_data_jira_old;
alter table user_data_jira_old drop column NINMEI_LEVEL;
reorg table user_data_jira_old;

--user_data_jira_newへカラム追加・削除--
alter table user_data_jira_new add column jira_group varchar(1);
reorg table user_data_jira_new;
alter table user_data_jira_new drop column system_code;
reorg table user_data_jira_new;
alter table user_data_jira_new drop column NINMEI_LEVEL;
reorg table user_data_jira_new;
