export to /workflow/batch/tmp/ichijifile_load_nyuukinDATAUNMATCH.csv.SJIS.txt of del 
select 
	nd.syukanCODE,
	nd.tsuuban,
	nd.sagyoubi,
	nd.tenshoCODE,
	nd.kojinbangou,
	nd.keijoukingaku,
	nd.nyuukinkingaku,
	nd.sagaku,
	nd.shimei,
	nd.koumoku
from 
	nyuukindataunmatch nd 
	inner join jigyosho_master j_m 
		on nd.tenshoCODE = j_m.tensho_cd 
where 
	nd.JIRAhaneizumi is null 
	and nd.asigngroupID is not null;
