export to /workflow/batch/tmp/SHIJISHO_BANGOU.tmp of del 
select 
	shohyo_id, 
	shijisho_bangou 
from 
	shohyo_data 
where 
	shijisho_bangou is not null AND 
	shijisho_flag is null AND 
	ronrisakujo is null;
