@
--------------------------------------------------------
-- ユーザー情報特殊文字変換関数
--------------------------------------------------------
CREATE FUNCTION FN_REPLACE (V varchar(100))
 RETURNS varchar(100)
 LANGUAGE SQL
 SPECIFIC FN_REPLACEVarcar
 DETERMINISTIC
 CONTAINS SQL
 NO EXTERNAL ACTION
 RETURN 
replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(V,'%','%25'),'<','%3C'),'>','%3E'),'[','%5B'),']','%5D'),'^','%5E'),'`','%60'),'{','%7B'),'|','%7C'),'}','%7D'),'&','%26'),'+','%2B'),'/','%2F')
@
