export to /workflow/batch/tmp/ichijifile_load_ginkoufurikomi_jidoukiekomi.csv.SJIS.txt of del 
select 
	g_j.syukanCODE,
	g_j.tsuuban,
	g_j.kihyounengappi,
	g_j.aeraCODE,
	g_j.kokyakuCODE,
	g_j.kokyakumeishou,
	g_j.bunruiCODE,
	g_j.kingaku,
	g_j.yotei,
	g_j.tekiyou,
	g_j.simukeginkou,
	g_j.simukesiten,
	g_j.koumoku,
	g_j.setsu,
	g_j.kubun,
	g_j.yobi,
	g_j.seiribusho,
	g_j.hasseitukihi,
	g_j.seiribangou
from 
	ginkoufurikomi_jidoukiekomi g_j 
	inner join jigyosho_master j_m 
		on g_j.syukanCODE = j_m.shukan_cd 
where 
	g_j.JIRAhaneizumi is null 
	and g_j.asigngroupID is not null 
	and j_m.shukan_cd = j_m.tensho_cd;
