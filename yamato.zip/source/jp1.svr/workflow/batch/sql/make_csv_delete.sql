export to /workflow/batch/csv/user_delete.csv of del
select a.kojinbangou,a.jira_group,a.kanji_simei,a.shukan_code,a.password
from user_data_jira_old a
where RONRISAKUJO is not null
;