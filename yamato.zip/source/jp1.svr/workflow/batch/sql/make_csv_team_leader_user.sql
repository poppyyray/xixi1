export to /workflow/batch/csv/team_leader_user_insert.csv of del
select a.kojinbangou
from user_data_jira_new a
where not exists (select * from user_data_jira_old b where a.kojinbangou=b.kojinbangou)
and jira_group in ('F')
;
