export to /workflow/batch/csv/user_update_password.csv of del
select a.kojinbangou,db2inst3.fn_replace(a.password),a.password,b.password
from user_data_jira_new a,user_data_jira_old b
where a.kojinbangou = b.kojinbangou
and ( a.password  <> b.password);
