INSERT INTO rp.tb_mishori_kensu_ichiran(
	sd_work_date,
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	output_date,
	status_id,
	status,
	has_form,
	count
)
SELECT 
	SUBSTR(sagyoubi,1,6),
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	current timestamp,
	status_id,
	status,
	has_form,
	COUNT(*)
 FROM rp.tb_issue_history 
WHERE id in 
	(SELECT MAX(id) FROM rp.tb_issue_history WHERE complete_flag = 'Y' GROUP BY Sequence_number)
AND status_id <> 'E01'
-- INSERT CONDITION
GROUP BY
	SUBSTR(sagyoubi,1,6),
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	status_id,
	status,
	has_form
;
