INSERT INTO rp.tb_tantousha_betsu_shorikensu_ichiran(
	output_date,
	owner_role_id,
	owner_role_name,
	owner_id,
	branch_office_code,
	region_code,
	region_name,
	service_name,
	count
)
SELECT
	current timestamp,
	owner_role_id,
	owner_role_name,
	owner_id,
	branch_office_code,
	region_code,
	region_name,
	service_name,
	COUNT(*)
FROM rp.tb_issue_history
		WHERE created_date BETWEEN rp.fn_run_date() AND TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-23.59.59.999999')
		AND create_type = '3'
		AND ( ( owner_role_id = 'A' AND status_id NOT LIKE 'A%' ) OR ( owner_role_id = 'B' AND status_id NOT LIKE 'B%' ) )
		AND complete_flag = 'Y'
group by
	owner_role_id,
	owner_role_name,
	owner_id,
	branch_office_code,
	region_code,
	region_name,
	service_name
;
