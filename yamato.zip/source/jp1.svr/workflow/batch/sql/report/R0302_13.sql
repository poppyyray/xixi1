INSERT INTO rp.tb_status_betsu_kensu_ichiran(
	sd_work_date,
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	output_date,
	status_id,
	status,
	has_form,
	second_flag,
	count
)
SELECT
	substr(sagyoubi,1,6),
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	current timestamp,
	status_id,
	status,
	has_form,
	second_flag,
	COUNT(*)
FROM
	(SELECT a1.sequence_number,a1.created_date,a2.second_flag FROM 
		(SELECT sequence_number,max(created_date) created_date FROM rp.tb_issue_history WHERE complete_flag = 'Y' and created_date BETWEEN rp.fn_first_business_date(rp.fn_run_date()) AND TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-13.00.00.000000') group by sequence_number) a1
			LEFT OUTER JOIN
			(SELECT DISTINCT sequence_number,'Y' AS second_flag FROM rp.tb_issue_history WHERE created_date < TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-13.00.00.000000') and ((owner_role_id = 'C' AND status_id in ('A02','A03','A04','A05','A08')) OR (owner_role_id = 'D' AND status_id in ('A02','A03')))) a2
			ON a1.sequence_number = a2.sequence_number) b1
INNER JOIN
	rp.tb_issue_history b2
	ON b1.sequence_number = b2.sequence_number
	AND b1.created_date = b2.created_date
GROUP BY
	substr(sagyoubi,1,6),
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	status_id,
	status,
	has_form,
	second_flag
;
