insert into rp.tb_qrcode_shuusei_meisai(
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	personal_number ,
	revised_date
)
select 
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	personal_number,
	created_date
from rp.tb_issue_history
where (sequence_number,created_date) in (
	select sequence_number,min(created_date)
	from rp.tb_issue_history
	where selected_form = 'Ex1'
	and created_date BETWEEN rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day AND rp.fn_last_business_date(rp.fn_run_date())
	and complete_flag = 'Y'
	group by sequence_number
	)
and sequence_number in (
                	select sequence_number
                	from rp.tb_issue_history 
                	where create_type='1' 
                	and created_date between rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day and rp.fn_last_date(rp.fn_run_date() - 1 months) + 1 day
                	and complete_flag = 'Y'
                	)
;
