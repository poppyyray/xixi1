insert into rp.TB_MISHORI_ANKEN_MEISAI(
	output_date,
	created_date,
	service_id,
	service_name,
	sequence_number,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	has_form,
	personal_number,
	owner_role_id,
	owner_role_name,
	owner_id,
	status_id,
	status,
	reason_id,
	reason,
	content_id,
	content,
	event_id,
	event,
	sagyoubi,
	issue_create_date,
	has_form_date,
	process_day_dairen,
	keika_day_dairen,
	keika_day_issue
)
select 
	CURRENT TIMESTAMP,
	created_date,
	service_id,
	service_name,
	sequence_number,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	has_form,
	personal_number,
	owner_role_id,
	owner_role_name,
	owner_id,
	status_id,
	status,
	reason_id,
	reason,
	content_id,
	content,
	event_id,
	event,
	sagyoubi,
	(select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number),
	(select created_date from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number),
	CASE 
		WHEN service_id = '4.4.1' THEN days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') order by created_date asc fetch first 1 rows only)) - 
			days((select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number))
		ELSE days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') order by created_date asc fetch first 1 rows only)) - 
			days((select created_date from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number))
		END,	
	CASE 
		WHEN service_id = '4.4.1' THEN days(rp.fn_run_date()) - days((select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number))
		ELSE days(rp.fn_run_date()) - days((select created_date from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number))
		END,
	days(rp.fn_run_date()) - days((select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number))
 from rp.tb_issue_history b
where (sequence_number,created_date) in 
	(select sequence_number,max(created_date) from rp.tb_issue_history a where not exists (select * from rp.tb_issue_history b where a.sequence_number = b.sequence_number and b.status_id = 'E01' and b.created_date < TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-10.00.00.000000')) and a.complete_flag = 'Y' and a.created_date < TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-10.00.00.000000') group by a.sequence_number)
;

update rp.TB_MISHORI_ANKEN_MEISAI set keika_day_dairen = null where process_day_dairen is not null
;
