insert into rp.tb_shijisho_hakkou_kensu_ichiran(
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	output_date,
	directions_type_value,
	directions_type,
	count
)
select 
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	CURRENT TIMESTAMP,
	directions_type_value,
	directions_type,
	count(*)
from
	rp.tb_issue_history
where
	status_id = 'A08'
	and (created_date between rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day and rp.fn_last_business_date(rp.fn_run_date()))
	and complete_flag = 'Y'
	and sequence_number in 
			(select sequence_number from rp.tb_issue_history 	where create_type='1' and created_date between rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day and rp.fn_last_date(rp.fn_run_date() - 1 months) + 1 day	and complete_flag = 'Y')
GROUP BY
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	directions_type_value,
	directions_type
;
