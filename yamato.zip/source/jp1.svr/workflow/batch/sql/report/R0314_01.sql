insert into rp.tb_shorichien_hassei_meisai(
	output_date,
	created_date,
	service_id,
	service_name,
	sequence_number,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	has_form,
	personal_number,
	owner_role_id,
	owner_role_name,
	owner_id,
	status_id,
	status,
	reason_id,
	reason,
	content_id,
	content,
	event_id,
	event,
	sagyoubi,
	issue_create_date,
	has_form_date,
	process_day_dairen,
	keika_day_issue
)
select * from (
	select 
		CURRENT TIMESTAMP,
		created_date,
		service_id,
		service_name,
		sequence_number,
		branch_office_code,
		region_code,
		region_name,
		delivery_center_code,
		delivery_center_name,
		has_form,
		personal_number,
		owner_role_id,
		owner_role_name,
		owner_id,
		status_id,
		status,
		reason_id,
		reason,
		content_id,
		content,
		event_id,
		event,
		sagyoubi,
		(select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number),
		(select created_date from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number),
		CASE 
			WHEN service_id = '4.4.1' THEN days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') order by created_date asc fetch first 1 rows only)) - 
				days((select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number))
			ELSE days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') order by created_date asc fetch first 1 rows only)) - 
				days((select created_date from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number))
			END as itaku_nissu,	
		days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and status_id = 'E01' and create_type = '3')) - days((select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number))
		from
			rp.tb_issue_history b
	 		where (sequence_number,created_date) in (
			select sequence_number,max(created_date) from rp.tb_issue_history
			where sequence_number in (select sequence_number from rp.tb_issue_history where create_type='1' and created_date between rp.fn_first_business_date(rp.fn_run_date()) and rp.fn_last_business_date(rp.fn_run_date()))
			and complete_flag = 'Y' group by sequence_number)
	)
where itaku_nissu >= 2
;
