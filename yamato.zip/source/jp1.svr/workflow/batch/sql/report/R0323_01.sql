INSERT INTO rp.tb_tantousha_betsu_shorikensu_ichiran(
	output_date,
	owner_role_id,
	owner_role_name,
	owner_id,
	branch_office_code,
	region_code,
	region_name,
	service_name,
	count
)
SELECT
	current timestamp,
	owner_role_id,
	owner_role_name,
	owner_id,
	branch_office_code,
	region_code,
	region_name,
	service_name,
	COUNT(*)
FROM rp.tb_issue_history
		WHERE created_date BETWEEN rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day AND rp.fn_last_business_date(rp.fn_run_date())
		AND create_type = '3'
		AND ( ( owner_role_id = 'A' AND status_id NOT LIKE 'A%' ) OR ( owner_role_id = 'B' AND status_id NOT LIKE 'B%' ) )
		AND complete_flag = 'Y'
		AND sequence_number in (
			select sequence_number 
			from rp.tb_issue_history 
			where create_type='1' 
			and created_date between rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day and rp.fn_last_date(rp.fn_run_date() - 1 months) + 1 day 
			and complete_flag = 'Y')
group by
	owner_role_id,
	owner_role_name,
	owner_id,
	branch_office_code,
	region_code,
	region_name,
	service_name
;
