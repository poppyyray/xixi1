ALTER SEQUENCE rp.sq_report_no RESTART;
