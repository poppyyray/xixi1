SELECT 1 FROM sysibm.sysdummy1 WHERE SUBSTR(CHAR(rp.fn_run_date()),1,10) = SUBSTR(CHAR(rp.fn_last_date(rp.fn_run_date())),1,10);
