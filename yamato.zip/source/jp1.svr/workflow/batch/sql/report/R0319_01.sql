INSERT INTO rp.tb_nyuusyukkinzairyoukakunin_meisai(
	wf_input_date,
	sagyoubi,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	personal_number
)
SELECT
	wf_input_date,
	sagyoubi,
	jm.sisya_cd,
	jm.shukan_cd,
	(SELECT tensho_ryakumei FROM rp.tb_jigyosho_master WHERE tensho_cd = (SELECT shukan_cd FROM rp.tb_jigyosho_master WHERE tensho_cd = sd.tenshocode)),
	jm.tensho_cd,
	jm.tensho_ryakumei,
	sd_number
FROM rp.tb_zenjitsukadou_sddata sd,rp.tb_jigyosho_master jm
WHERE sd.tenshocode = jm.tensho_cd
and sd.wf_input_date = (select replace(char(date(substr(run_date,1,4) || '-' || substr(run_date,5,2) || '-' || substr(run_date,7,2)) -1 day),'-','') from rp.tb_run_date)
;
COMMIT;


UPDATE rp.tb_nyuusyukkinzairyoukakunin_meisai nm SET has_form = 'Y'
WHERE exists (SELECT * FROM rp.tb_shohyo_data sr
			WHERE nm.delivery_center_code = sr.tenshocode
			AND nm.personal_number = sr.kojinbangou
			AND nm.sagyoubi = sr.shohyo_date
			AND sr.chohyo_id = '0002'
			AND sr.sakuseinichiji < TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-19.00.00.000000'))
AND has_form IS NULL;
COMMIT;

UPDATE rp.tb_nyuusyukkinzairyoukakunin_meisai nm SET has_form = 'N'
WHERE NOT EXISTS (SELECT * FROM rp.tb_shohyo_data sr
			WHERE nm.delivery_center_code = sr.tenshocode
			AND nm.personal_number = sr.kojinbangou
			AND nm.sagyoubi = sr.shohyo_date
			AND sr.chohyo_id = '0002'
			AND sr.sakuseinichiji < TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-19.00.00.000000'))
AND has_form IS NULL;
COMMIT;
