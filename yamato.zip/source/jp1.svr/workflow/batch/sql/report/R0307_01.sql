INSERT INTO rp.tb_hasseigenin_betsu_kensu_ichiran(
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	output_date,
	reason_id,
	reason,
	count
)
SELECT
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	CURRENT TIMESTAMP,
	reason_id,
	reason,
	count(*)
FROM
	rp.tb_issue_history
WHERE
(sequence_number,created_date) IN
	(SELECT sequence_number,MAX(created_date)
	FROM rp.tb_issue_history 
	WHERE sequence_number IN (
		select sequence_number from rp.tb_issue_history where create_type='1' and ((service_id = '4.4.1' and created_date between rp.fn_first_business_date(rp.fn_run_date()) and rp.fn_last_business_date(rp.fn_run_date())) or (service_id <> '4.4.1' and timestamp(substr(sagyoubi,1,4) || '-' || substr(sagyoubi,5,2) || '-' || substr(sagyoubi,7,2) || '-00.00.00.000000') between rp.fn_first_date(rp.fn_run_date() - 1 months) and rp.fn_last_date(rp.fn_run_date() - 1 months)))
	)
	GROUP BY sequence_number)
GROUP BY
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	reason_id,
	reason
;
