INSERT INTO rp.tb_shorinissuu_betsu_kensu_ichiran(
	summary_type,
	process_day,
	output_date,
	status,
	service_id,
	service_name,
	count
	)
SELECT
	'委託',
	process_day,
	CURRENT TIMESTAMP,
	status_id ||':'|| status,
	service_id,
	service_name,
	count(*)
FROM 
	(select 
		CASE 
		WHEN service_id = '4.4.1' THEN days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') order by created_date asc fetch first 1 rows only)) - 
			days((select created_date from rp.tb_issue_history a where create_type = '1' and a.sequence_number = b.sequence_number))
		ELSE days((select created_date from rp.tb_issue_history where sequence_number = b.sequence_number and (status_id like 'C%'or status_id like 'D%' or status_id like 'E%') order by created_date asc fetch first 1 rows only)) - 
			days((select created_date from rp.tb_issue_history a where create_type = '2' and a.sequence_number = b.sequence_number))
		END process_day,
		status_id,
		status,
		service_id,
		service_name
	from
		rp.tb_issue_history b
	where (sequence_number,created_date) in (
		select sequence_number,min(created_date) from rp.tb_issue_history
		where (status_id like 'C%'or status_id like 'D%' or status_id like 'E%')
		and sequence_number in (select sequence_number from rp.tb_issue_history where create_type='1' and ((service_id = '4.4.1' and created_date between rp.fn_first_business_date(rp.fn_run_date()) and rp.fn_last_business_date(rp.fn_run_date())) or (service_id <> '4.4.1' and timestamp(substr(sagyoubi,1,4) || '-' || substr(sagyoubi,5,2) || '-' || substr(sagyoubi,7,2) || '-00.00.00.000000') between rp.fn_first_date(rp.fn_run_date() - 1 months) and rp.fn_last_date(rp.fn_run_date() - 1 months))))
		and complete_flag = 'Y'
		group by sequence_number)
	)
GROUP BY
	process_day,
	status,
	status_id,
	service_id,
	service_name
;
