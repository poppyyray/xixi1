call rp.pr_r0104_01('1');
