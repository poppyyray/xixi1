insert into rp.tb_shijisho_hakkou_meisai(
	directions_number,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	personal_number,
	sagyoubi,
	directions_type,
	directions_type_value,
	directions_contents,
	directions_due_date,
	directions_amount,
	directions_issue_date,
	directions_close_date
)
select 
	directions_number,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	personal_number,
	sagyoubi,
	directions_type,
	directions_type_value,
	directions_contents,
	directions_due_date,
	directions_amount,
	created_date,
	(select created_date from rp.tb_issue_history b where b.status_id = 'A01' and b.sequence_number = a.sequence_number and b.directions_number = a.directions_number and b.create_type = '3' and b.created_date > a.created_date order by b.created_date fetch first 1 rows only)
from
	rp.tb_issue_history a
where
	status_id = 'A08'
	and create_type = '3'
	and created_date BETWEEN rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day AND rp.fn_last_business_date(rp.fn_run_date())
	and complete_flag = 'Y'
	and sequence_number in 
			(select sequence_number from rp.tb_issue_history 	where create_type='1' and created_date between rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day and rp.fn_last_date(rp.fn_run_date() - 1 months) + 1 day	and complete_flag = 'Y')

;

