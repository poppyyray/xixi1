INSERT INTO rp.tb_hasseibi_betsu_kensu_ichiran(
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	output_date,
	occur_date,
	count
)
SELECT
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	CURRENT TIMESTAMP,
	SUBSTR(CHAR(created_date),1,4) || SUBSTR(CHAR(created_date),6,2) || SUBSTR(CHAR(created_date),9,2),
	COUNT(*)
  FROM  rp.tb_issue_history
 WHERE  create_type = '2' 
   AND  service_id <> '4.4.1' 
   AND  created_date BETWEEN rp.fn_daily_report_start_date(rp.fn_run_date()) AND TIMESTAMP(SUBSTR(CHAR(rp.fn_run_date()),1,10) || '-08.00.00.000000')
   AND  complete_flag = 'Y'
GROUP BY
	branch_office_code,
	region_code,
	region_name,
	service_id,
	service_name,
	SUBSTR(CHAR(created_date),1,4) || SUBSTR(CHAR(created_date),6,2) || SUBSTR(CHAR(created_date),9,2)
;
