INSERT INTO rp.tb_hasseibi_betsu_sdkadousu_ichiran(
	wf_input_date,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	count
)
SELECT
	wf_input_date,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name,
	COUNT(*)
FROM (
	SELECT
		wf_input_date,
		sisya_cd branch_office_code,
		shukan_cd region_code,
		(SELECT tensho_ryakumei FROM rp.tb_jigyosho_master WHERE tensho_cd = (SELECT shukan_cd FROM rp.tb_jigyosho_master WHERE tensho_cd = sd.tenshocode)) region_name,
		tenshocode delivery_center_code,
		tensho_ryakumei delivery_center_name
	FROM rp.tb_zenjitsukadou_sddata sd,rp.tb_jigyosho_master jm
	WHERE sd.tenshocode = jm.tensho_cd
	AND timestamp(substr(sd.wf_input_date,1,4) || '-' || substr(sd.wf_input_date,5,2) || '-' || substr(sd.wf_input_date,7,2) || '-00.00.00.000000') between rp.fn_first_date(rp.fn_run_date() - 1 months) + 1 day and rp.fn_last_date(rp.fn_run_date() - 1 months) + 1 day
	)
GROUP BY
	wf_input_date,
	branch_office_code,
	region_code,
	region_name,
	delivery_center_code,
	delivery_center_name
;
