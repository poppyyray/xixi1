INSERT INTO rp.tb_tantousha_betsu_shorikensu_ichiran(
	output_date,
	owner_role_id,
	owner_role_name,
	owner_id,
	branch_office_code,
	region_code,
	region_name,
	service_name,
	count
)
SELECT
	current timestamp,
	owner_role_id,
	owner_role_name,
	owner_id,
	branch_office_code,
	region_code,
	region_name,
	service_name,
	COUNT(*)
FROM (
	SELECT * FROM rp.tb_issue_history
	WHERE (sequence_number,created_date) IN (
		SELECT sequence_number,MIN(created_date)
		FROM rp.tb_issue_history
		WHERE created_date > rp.fn_run_date()
		AND create_type = '3'
		AND owner_role_id = 'A' 
		AND status_id NOT LIKE 'A%'
		AND complete_flag = 'Y'
-- INSERT CONDITION
		GROUP BY sequence_number)
	UNION
	SELECT * FROM rp.tb_issue_history
	WHERE (sequence_number,created_date) IN (
		SELECT sequence_number,MIN(created_date)
		FROM rp.tb_issue_history
		WHERE created_date > rp.fn_run_date()
		AND create_type = '3'
		AND owner_role_id = 'B'
		AND status_id NOT LIKE 'B%'
		AND complete_flag = 'Y'
-- INSERT CONDITION
		GROUP BY sequence_number)
)
group by
	owner_role_id,
	owner_role_name,
	owner_id,
	branch_office_code,
	region_code,
	region_name,
	service_name
;
