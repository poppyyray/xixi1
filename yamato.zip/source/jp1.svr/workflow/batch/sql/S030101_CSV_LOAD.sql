export to /workflow/batch/tmp/ichijifile_load_nyuusyukkinzairyoukakunin.csv.SJIS.txt of del 
select 
	nz.syukanCODE,
	nz.tenshoCODE,
	j_m.tensho_ryakumei,
	nz.kojinbangou,
	nz.sagyoubi,
	nz.chouhyouID,
	nz.hanbaihyoubangou,
	nz.kihyounengappi,
	nz.kingaku,
	nz.tsuuban 
from 
	nyuusyukkinzairyoukakunin nz 
	inner join jigyosho_master j_m 
		on nz.tenshoCODE = j_m.tensho_cd 
where 
	nz.JIRAhaneizumi is null 
	and nz.asigngroupID is not null; 
