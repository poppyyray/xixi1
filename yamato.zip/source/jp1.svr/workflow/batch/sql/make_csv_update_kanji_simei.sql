export to /workflow/batch/csv/user_update_kanji_simei.csv of del
select a.kojinbangou,a.kanji_simei,b.kanji_simei
from user_data_jira_new a,user_data_jira_old b
where a.kojinbangou = b.kojinbangou
and ( a.kanji_simei  <> b.kanji_simei);
