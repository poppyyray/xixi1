update user_data_jirar_old set
RONRISAKUJO = 'Y' ,KOUSINNICHIJI = current_timestamp
where KOJINBANGOU not in (select kojinbangou from user_data_jirar_new)
and RONRISAKUJO is null
and KOUSINNICHIJI is null
;