export to /workflow/batch/tmp/WORK_ITEM_UPDATE_UNMATCH_SEL01.tmp of del 
select 
	PKEY_CD
from 
	NYUUKINDATAUNMATCH 
where 
	SHOUNINZUMI = 'Y';
