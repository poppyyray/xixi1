export to /workflow/batch/tmp/S040401_CSV_IMPORT.csv.SJIS of del 
select 
	ginkoufurikomi_jidoukiekomi.tsuuban,
	ginkoufurikomi_jidoukiekomi.gyoumuID,
	ginkoufurikomi_jidoukiekomi.syukanCODE,
	value(ginkoufurikomi_jidoukiekomi.aeraCODE,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.kihyounengappi,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.kokyakuCODE,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.bunruiCODE,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.kokyakumeishou,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.kingaku,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.yotei,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.tekiyou,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.simukeginkou,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.simukesiten,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.koumoku,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.setsu,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.kubun,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.yobi,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.seiribusho,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.hasseitukihi,'BLANK'),
	value(ginkoufurikomi_jidoukiekomi.seiribangou,'BLANK'),
	value(jigyosho_master.tensho_ryakumei,'BLANK') 
from 
	ginkoufurikomi_jidoukiekomi inner join jigyosho_master on 
	ginkoufurikomi_jidoukiekomi.syukanCODE = jigyosho_master.shukan_cd 
where 
	ginkoufurikomi_jidoukiekomi.JIRAhaneizumi is null and 
	ginkoufurikomi_jidoukiekomi.ASIGNGROUPID is not null and 
	jigyosho_master.shukan_cd = jigyosho_master.tensho_cd;
