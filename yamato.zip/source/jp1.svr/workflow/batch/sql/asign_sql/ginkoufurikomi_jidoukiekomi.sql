update ginkoufurikomi_jidoukiekomi set asigngroupid = 'A' where asigngroupid <> 'A' or asigngroupid is NULL;
