select distinct msb.user_name,pr.name                
from jiraschema.PROJECTROLEACTOR pra,jiraschema.projectrole pr,jiraschema.membershipbase msb                
where msb.user_name=pra.ROLETYPEPARAMETER                
and pr.id=pra.projectroleid                
and (msb.group_name='C' or msb.group_name='D')                
and msb.user_name not like 'g%'                
order by msb.user_name,pr.name                
