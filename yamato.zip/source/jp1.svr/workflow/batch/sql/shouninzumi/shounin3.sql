-- 経費振替
UPDATE keihifurikae a
SET a.furikaeplsdenpyoubangou = (SELECT b.furikaeplsdenpyoubangou FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    a.furikaeplsdenpyoutouchakuzumi = (SELECT case when a.furikaeplsdenpyoubangou <> b.furikaeplsdenpyoubangou then null else a.furikaeplsdenpyoutouchakuzumi end FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd)
WHERE exists (SELECT 1 FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd);

-- 入金アンマッチ
UPDATE nyuukindataunmatch a
SET furikaeplsdenpyoubangou = (SELECT b.furikaeplsdenpyoubangou FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    furikaeplsdenpyoutouchakuzumi = (SELECT case when a.furikaeplsdenpyoubangou <> b.furikaeplsdenpyoubangou then null else a.furikaeplsdenpyoutouchakuzumi end FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd)
WHERE exists (SELECT 1 FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd);

-- 一般集金エラー処理
UPDATE ippansyuukin_errortaiou a
SET furikaeplsdenpyoubangou = (SELECT b.furikaeplsdenpyoubangou FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    furikaeplsdenpyoutouchakuzumi = (SELECT case when a.furikaeplsdenpyoubangou <> b.furikaeplsdenpyoubangou then null else a.furikaeplsdenpyoutouchakuzumi end FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    nyuukinfurikaedenpyoubangou = (SELECT b.nyuukinfurikaedenpyoubangou FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    nyuukinfurikaedenpyoutouchakuzumi = (SELECT case when a.nyuukinfurikaedenpyoubangou <> b.nyuukinfurikaedenpyoubangou then null else a.nyuukinfurikaedenpyoutouchakuzumi end FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd)
WHERE exists (SELECT 1 FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd);

-- 一般集金手動消込
UPDATE ippansyuukin_shudoukeshikomi a
SET furikaeplsdenpyoubangou = (SELECT b.furikaeplsdenpyoubangou FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    furikaeplsdenpyoutouchakuzumi = (SELECT case when a.furikaeplsdenpyoubangou <> b.furikaeplsdenpyoubangou then null else a.furikaeplsdenpyoutouchakuzumi end FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    nyuukinfurikaedenpyoubangou = (SELECT b.nyuukinfurikaedenpyoubangou FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    nyuukinfurikaedenpyoutouchakuzumi = (SELECT case when a.nyuukinfurikaedenpyoubangou <> b.nyuukinfurikaedenpyoubangou then null else a.nyuukinfurikaedenpyoutouchakuzumi end FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd)
WHERE exists (SELECT 1 FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd);

-- 振込入金
UPDATE ginkoufurikomi_jidoukiekomi a
SET furikaeplsdenpyoubangou = (SELECT b.furikaeplsdenpyoubangou FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    furikaeplsdenpyoutouchakuzumi = (SELECT case when a.furikaeplsdenpyoubangou <> b.furikaeplsdenpyoubangou then null else a.furikaeplsdenpyoutouchakuzumi end FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    nyuukinfurikaedenpyoubangou = (SELECT b.nyuukinfurikaedenpyoubangou FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd),
    nyuukinfurikaedenpyoutouchakuzumi = (SELECT case when a.nyuukinfurikaedenpyoubangou <> b.nyuukinfurikaedenpyoubangou then null else a.nyuukinfurikaedenpyoutouchakuzumi end FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd)
WHERE exists (SELECT 1 FROM shounin_work b WHERE a.pkey_cd = b.pkey_cd);
