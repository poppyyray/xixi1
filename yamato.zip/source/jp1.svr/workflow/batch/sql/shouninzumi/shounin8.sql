export to /workflow/batch/csv/shounin_work_after.csv OF DEL SELECT * FROM shounin_work;
