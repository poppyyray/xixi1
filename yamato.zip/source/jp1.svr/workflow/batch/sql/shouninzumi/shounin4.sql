-- システムID "01"
UPDATE keihifurikae SET furikaeplsdenpyoutouchakuzumi = 'Y' WHERE (syukancode,furikaeplsdenpyoubangou) in (SELECT kihyou_busho,denpyo_bangou FROM shouninzumi_data WHERE system_id = '01' AND pp_kanrenzumi IS NULL) AND pkey_cd IN (select pkey_cd from shounin_work where pkey_cd like 'CT-%');
UPDATE nyuukindataunmatch SET furikaeplsdenpyoutouchakuzumi = 'Y' WHERE (syukancode,furikaeplsdenpyoubangou) in (SELECT kihyou_busho,denpyo_bangou FROM shouninzumi_data WHERE system_id = '01' AND pp_kanrenzumi IS NULL) AND pkey_cd IN (select pkey_cd from shounin_work where pkey_cd like 'UD-%');
UPDATE ippansyuukin_errortaiou SET furikaeplsdenpyoutouchakuzumi = 'Y' WHERE (syukancode,furikaeplsdenpyoubangou) in (SELECT kihyou_busho,denpyo_bangou FROM shouninzumi_data WHERE system_id = '01' AND pp_kanrenzumi IS NULL) AND pkey_cd IN (select pkey_cd from shounin_work where pkey_cd like 'GE-%');
UPDATE ippansyuukin_shudoukeshikomi SET furikaeplsdenpyoutouchakuzumi = 'Y' WHERE (syukancode,furikaeplsdenpyoubangou) in (SELECT kihyou_busho,denpyo_bangou FROM shouninzumi_data WHERE system_id = '01' AND pp_kanrenzumi IS NULL) AND pkey_cd IN (select pkey_cd from shounin_work where pkey_cd like 'GC-%');
UPDATE ginkoufurikomi_jidoukiekomi SET furikaeplsdenpyoutouchakuzumi = 'Y' WHERE (syukancode,furikaeplsdenpyoubangou) in (SELECT kihyou_busho,denpyo_bangou FROM shouninzumi_data WHERE system_id = '01' AND pp_kanrenzumi IS NULL) AND pkey_cd IN (select pkey_cd from shounin_work where pkey_cd like 'BT-%');

-- システムID "02"
UPDATE nyuukindataunmatch SET furikaeplsdenpyoutouchakuzumi = 'Y' WHERE (syukancode,furikaeplsdenpyoubangou) in (SELECT kihyou_busho,denpyo_bangou FROM shouninzumi_data WHERE system_id = '02' AND pp_kanrenzumi IS NULL) AND pkey_cd IN (select pkey_cd from shounin_work where pkey_cd like 'UD-%');

-- システムID "03"
UPDATE ippansyuukin_errortaiou SET nyuukinfurikaedenpyoutouchakuzumi = 'Y' WHERE (syukancode,nyuukinfurikaedenpyoubangou) in (SELECT kihyou_busho,denpyo_bangou FROM shouninzumi_data WHERE system_id = '03' AND pp_kanrenzumi IS NULL) AND pkey_cd IN (select pkey_cd from shounin_work where pkey_cd like 'GE-%');
UPDATE ippansyuukin_shudoukeshikomi SET nyuukinfurikaedenpyoutouchakuzumi = 'Y' WHERE (syukancode,nyuukinfurikaedenpyoubangou) in (SELECT kihyou_busho,denpyo_bangou FROM shouninzumi_data WHERE system_id = '03' AND pp_kanrenzumi IS NULL) AND pkey_cd IN (select pkey_cd from shounin_work where pkey_cd like 'GC-%');
UPDATE ginkoufurikomi_jidoukiekomi SET nyuukinfurikaedenpyoutouchakuzumi = 'Y' WHERE (syukancode,nyuukinfurikaedenpyoubangou) in (SELECT kihyou_busho,denpyo_bangou FROM shouninzumi_data WHERE system_id = '03' AND pp_kanrenzumi IS NULL) AND pkey_cd IN (select pkey_cd from shounin_work where pkey_cd like 'BT-%');

