export to /workflow/batch/csv/shonin_taishou.csv of del
SELECT
        issue.pkey,
        component.cname,
        value(decode(projectversion.vname,'0000','BLNK',projectversion.vname),'BLNK'),
        value(decode(char(issue.environment),'0000','BLNK',char(issue.environment)),'BLNK'
)
FROM
        jiraschema.jiraissue issue
INNER JOIN
        jiraschema.nodeassociation nodeassociation2 ON
        issue.id = nodeassociation2.source_node_id AND
        nodeassociation2.sink_node_entity = 'Component'
INNER JOIN
        jiraschema.component component ON
        nodeassociation2.sink_node_id = component.id
LEFT OUTER JOIN
        jiraschema.nodeassociation nodeassociation ON
        issue.id = nodeassociation.SOURCE_NODE_ID AND
        nodeassociation.sink_node_entity = 'Version' AND
        nodeassociation.association_type = 'IssueVersion'
LEFT OUTER JOIN
        jiraschema.projectversion projectversion ON
        nodeassociation.sink_node_id = projectversion.id
LEFT OUTER JOIN
        jiraschema.issuestatus issuestatus ON
        issuestatus.id = issue.issuestatus
LEFT OUTER JOIN
        jiraschema.project project ON
        project.id = issue.project
WHERE issuestatus.pname = 'D01' or issuestatus.pname = 'D02'
;
