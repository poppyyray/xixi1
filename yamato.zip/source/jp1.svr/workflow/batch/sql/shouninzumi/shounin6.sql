-- 経費振替
UPDATE shouninzumi_data a 
SET pp_kanrenzumi = 'Y',
    kousinnichiji = CURRENT TIMESTAMP
WHERE EXISTS (SELECT 1 FROM keihifurikae b WHERE a.kihyou_busho = b.syukancode AND a.denpyo_bangou = b.furikaeplsdenpyoubangou)
  AND system_id = '01'
  AND pp_kanrenzumi IS NULL;

-- 入金アンマッチ
UPDATE shouninzumi_data a 
SET pp_kanrenzumi = 'Y',
    kousinnichiji = CURRENT TIMESTAMP
WHERE EXISTS (SELECT 1 FROM nyuukindataunmatch b WHERE a.kihyou_busho = b.syukancode AND a.denpyo_bangou = b.furikaeplsdenpyoubangou)
  AND system_id in ('01','02')
  AND pp_kanrenzumi IS NULL;

-- 一般集金手動消込
UPDATE shouninzumi_data a 
SET pp_kanrenzumi = 'Y',
    kousinnichiji = CURRENT TIMESTAMP
WHERE EXISTS (SELECT 1 FROM ippansyuukin_shudoukeshikomi b WHERE a.kihyou_busho = b.syukancode AND a.denpyo_bangou = b.furikaeplsdenpyoubangou)
  AND system_id = '01'
  AND pp_kanrenzumi IS NULL;

UPDATE shouninzumi_data a 
SET pp_kanrenzumi = 'Y',
    kousinnichiji = CURRENT TIMESTAMP
WHERE EXISTS (SELECT 1 FROM ippansyuukin_shudoukeshikomi b WHERE a.kihyou_busho = b.syukancode AND a.denpyo_bangou = b.nyuukinfurikaedenpyoubangou)
  AND system_id = '03'
  AND pp_kanrenzumi IS NULL;

-- 一般集金エラー処理
UPDATE shouninzumi_data a 
SET pp_kanrenzumi = 'Y',
    kousinnichiji = CURRENT TIMESTAMP
WHERE EXISTS (SELECT 1 FROM IPPANSYUUKIN_ERRORTAIOU b WHERE a.kihyou_busho = b.syukancode AND a.denpyo_bangou = b.furikaeplsdenpyoubangou)
  AND system_id = '01'
  AND pp_kanrenzumi IS NULL;

UPDATE shouninzumi_data a 
SET pp_kanrenzumi = 'Y',
    kousinnichiji = CURRENT TIMESTAMP
WHERE EXISTS (SELECT 1 FROM IPPANSYUUKIN_ERRORTAIOU b WHERE a.kihyou_busho = b.syukancode AND a.denpyo_bangou = b.nyuukinfurikaedenpyoubangou)
  AND system_id = '03'
  AND pp_kanrenzumi IS NULL;

-- 振込入金
UPDATE shouninzumi_data a
SET pp_kanrenzumi = 'Y',
    kousinnichiji = CURRENT TIMESTAMP
WHERE EXISTS (SELECT 1 FROM ginkoufurikomi_jidoukiekomi b WHERE a.kihyou_busho = b.syukancode AND a.denpyo_bangou = b.furikaeplsdenpyoubangou)
  AND system_id = '01'
  AND pp_kanrenzumi IS NULL;

UPDATE shouninzumi_data a 
SET pp_kanrenzumi = 'Y',
    kousinnichiji = CURRENT TIMESTAMP
WHERE EXISTS (SELECT 1 FROM ginkoufurikomi_jidoukiekomi b WHERE a.kihyou_busho = b.syukancode AND a.denpyo_bangou = b.nyuukinfurikaedenpyoubangou)
  AND system_id = '03'
  AND pp_kanrenzumi IS NULL;

-- pp関連済みをNでアップデート
update SHOUNINZUMI_DATA set PP_KANRENZUMI = 'N' WHERE pp_kanrenzumi IS NULL;

