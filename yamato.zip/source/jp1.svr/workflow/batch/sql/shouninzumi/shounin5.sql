-- 経費振替
UPDATE keihifurikae SET shouninzumi = 'Y' WHERE shouninzumi IS NULL AND furikaeplsdenpyoutouchakuzumi = 'Y';

-- 入金アンマッチ
UPDATE nyuukindataunmatch SET shouninzumi = 'Y' WHERE shouninzumi IS NULL AND furikaeplsdenpyoutouchakuzumi = 'Y';

-- 一般集金手動消込
UPDATE ippansyuukin_shudoukeshikomi SET shouninzumi = 'Y' WHERE shouninzumi IS NULL AND ((furikaeplsdenpyoutouchakuzumi = 'Y' AND nyuukinfurikaedenpyoutouchakuzumi = 'Y') or (furikaeplsdenpyoutouchakuzumi = 'Y' AND nyuukinfurikaedenpyoubangou = 'BLNK') or (furikaeplsdenpyoubangou = 'BLNK' AND nyuukinfurikaedenpyoutouchakuzumi = 'Y'));

-- 一般集金エラー処理
UPDATE IPPANSYUUKIN_ERRORTAIOU SET shouninzumi = 'Y' WHERE shouninzumi IS NULL AND ((furikaeplsdenpyoutouchakuzumi = 'Y' AND nyuukinfurikaedenpyoutouchakuzumi = 'Y') or (furikaeplsdenpyoutouchakuzumi = 'Y' AND nyuukinfurikaedenpyoubangou = 'BLNK') or (furikaeplsdenpyoubangou = 'BLNK' AND nyuukinfurikaedenpyoutouchakuzumi = 'Y'));

-- 振込入金
UPDATE ginkoufurikomi_jidoukiekomi SET shouninzumi = 'Y' WHERE shouninzumi IS NULL AND ((furikaeplsdenpyoutouchakuzumi = 'Y' AND nyuukinfurikaedenpyoutouchakuzumi = 'Y') or (furikaeplsdenpyoutouchakuzumi = 'Y' AND nyuukinfurikaedenpyoubangou = 'BLNK') or (furikaeplsdenpyoubangou = 'BLNK' AND nyuukinfurikaedenpyoutouchakuzumi = 'Y'));

