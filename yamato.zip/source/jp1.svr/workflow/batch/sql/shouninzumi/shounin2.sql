import FROM /workflow/batch/csv/shonin_taishou.csv OF DEL REPLACE INTO shounin_work;
