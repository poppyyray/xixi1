UPDATE shounin_work SET shouninzumi = 'Y' WHERE pkey_cd in (SELECT pkey_cd FROM keihifurikae WHERE shouninzumi = 'Y');
UPDATE shounin_work SET shouninzumi = 'Y' WHERE pkey_cd in (SELECT pkey_cd FROM nyuukindataunmatch WHERE shouninzumi = 'Y');
UPDATE shounin_work SET shouninzumi = 'Y' WHERE pkey_cd in (SELECT pkey_cd FROM ippansyuukin_shudoukeshikomi WHERE shouninzumi = 'Y');
UPDATE shounin_work SET shouninzumi = 'Y' WHERE pkey_cd in (SELECT pkey_cd FROM IPPANSYUUKIN_ERRORTAIOU WHERE shouninzumi = 'Y');
UPDATE shounin_work SET shouninzumi = 'Y' WHERE pkey_cd in (SELECT pkey_cd FROM ginkoufurikomi_jidoukiekomi WHERE shouninzumi = 'Y');

