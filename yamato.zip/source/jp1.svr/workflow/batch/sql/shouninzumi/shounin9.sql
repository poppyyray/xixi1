import FROM /workflow/batch/csv/shounin_work_after.csv OF DEL REPLACE INTO shounin_work;

UPDATE jiraschema.jiraissue a 
SET issuestatus = '10039',
    assignee = 'ge' || (SELECT b.syukancode FROM shounin_work b WHERE a.pkey = b.pkey_cd AND b.shouninzumi = 'Y'),
    priority = '10',
    updated = CURRENT TIMESTAMP 
WHERE EXISTS (SELECT 1 FROM shounin_work b WHERE a.pkey = b.pkey_cd AND b.shouninzumi = 'Y');

