delete from USER_DATA_JIRA_OLD
where RONRISAKUJO is not null
;