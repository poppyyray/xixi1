export to /workflow/batch/tmp/S040202_CSV_IMPORT.csv.SJIS of del 
select 
	ippansyuukin_shudoukeshikomi.tsuuban,
	ippansyuukin_shudoukeshikomi.gyoumuID,
	ippansyuukin_shudoukeshikomi.tenshoCODE,
	ippansyuukin_shudoukeshikomi.kojinbangou,
	value(ippansyuukin_shudoukeshikomi.sagyoubi,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.chouhyouID,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.ryousyuushobangou,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.syukanCODE,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.aeraCODE,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.kingaku,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.tekiyou,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.koumoku,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.setsu,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.kubun,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.yobi,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.seiribusho,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.hasseitukihi,'BLANK'),
	value(ippansyuukin_shudoukeshikomi.seiribangou,'BLANK'),
	value(jigyosho_master.tensho_ryakumei,'BLANK') 
from 
	ippansyuukin_shudoukeshikomi inner join jigyosho_master on 
	ippansyuukin_shudoukeshikomi.tenshoCODE = jigyosho_master.tensho_cd 
where 
	ippansyuukin_shudoukeshikomi.JIRAhaneizumi is null and 
	ippansyuukin_shudoukeshikomi.ASIGNGROUPID is not null;
