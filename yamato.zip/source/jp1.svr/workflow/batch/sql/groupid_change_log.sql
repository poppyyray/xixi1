select id,assignee from jiraschema.jiraissue 
	where  (pkey like 'UD%' or pkey like 'GC%'
	or  pkey like 'GE%' or  pkey like 'CT%'
	or  pkey like 'CE%' or  pkey like 'BT%')
	and assignee not like 'g%'
;
