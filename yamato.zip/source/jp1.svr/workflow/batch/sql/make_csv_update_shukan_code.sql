export to /workflow/batch/csv/user_update_shukan_code.csv of del
select a.kojinbangou,a.shukan_code,b.shukan_code,a.jira_group,b.jira_group
from user_data_jira_new a,user_data_jira_old b
where a.kojinbangou = b.kojinbangou
and (a.shukan_code  <> b.shukan_code)
and (a.jira_group <> 'F')
and (b.jira_group <> 'F')
union
select a.kojinbangou,a.shukan_code,b.shukan_code,a.jira_group,b.jira_group
from user_data_jira_new a,user_data_jira_old b
where a.kojinbangou = b.kojinbangou
and (a.jira_group = 'F')
and (b.jira_group <> 'F')
union
select a.kojinbangou,a.shukan_code,b.shukan_code,a.jira_group,b.jira_group
from user_data_jira_new a,user_data_jira_old b
where a.kojinbangou = b.kojinbangou
and (b.jira_group = 'F')
and (a.jira_group <> 'F');
