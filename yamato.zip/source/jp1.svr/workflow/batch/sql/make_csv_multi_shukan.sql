SELECT distinct trim(udjn.kojinbangou), um.shukan_code           
FROM user_data_jira_new udjn, user_master um           
WHERE udjn.kojinbangou=um.kojinbangou           
AND udjn.jira_group in ('C','D')           
AND um.shukan_code IN ( SELECT shukan_cd FROM jigyosho_master           
         WHERE tensho_cd = shukan_cd       
         AND shukan_cd <> '032621'       
         AND sisya_cd NOT like '0M%')      
ORDER BY trim(udjn.kojinbangou), um.shukan_code           