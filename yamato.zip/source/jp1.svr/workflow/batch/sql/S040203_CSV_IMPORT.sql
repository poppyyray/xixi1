export to /workflow/batch/tmp/S040203_CSV_IMPORT.csv.SJIS of del 
select 
	ippansyuukin_errortaiou.tsuuban,
	ippansyuukin_errortaiou.gyoumuID,
	ippansyuukin_errortaiou.tenshoCODE,
	ippansyuukin_errortaiou.kojinbangou,
	value(ippansyuukin_errortaiou.sagyoubi,'BLANK'),
	value(ippansyuukin_errortaiou.chouhyouID,'BLANK'),
	value(ippansyuukin_errortaiou.ryousyuushobangou,'BLANK'),
	value(ippansyuukin_errortaiou.syukanCODE,'BLANK'),
	value(ippansyuukin_errortaiou.aeraCODE,'BLANK'),
	value(ippansyuukin_errortaiou.errorriyuu,'BLANK'),
	value(ippansyuukin_errortaiou.denpyoubangou,'BLANK'),
	value(ippansyuukin_errortaiou.nyuukinnengappi,'BLANK'),
	value(ippansyuukin_errortaiou.kihyoubusho,'BLANK'),
	value(ippansyuukin_errortaiou.kokyaku,'BLANK'),
	value(ippansyuukin_errortaiou.bunrui,'BLANK'),
	value(ippansyuukin_errortaiou.headerNO,'BLANK'),
	value(ippansyuukin_errortaiou.seiribusho,'BLANK'),
	value(ippansyuukin_errortaiou.seikyuuNO,'BLANK'),
	value(ippansyuukin_errortaiou.seikyuukingaku,'BLANK'),
	value(ippansyuukin_errortaiou.nyuukinkingaku,'BLANK'),
	value(ippansyuukin_errortaiou.seikyuuzangaku,'BLANK'),
	value(jigyosho_master.tensho_ryakumei,'BLANK') 
from 
	ippansyuukin_errortaiou inner join jigyosho_master on 
	ippansyuukin_errortaiou.tenshoCODE = jigyosho_master.tensho_cd 
where 
	ippansyuukin_errortaiou.JIRAhaneizumi is null and 
	ippansyuukin_errortaiou.ASIGNGROUPID is not null;
