export to /workflow/batch/csv/user_update_kanji_simei_jirar.csv of del
select a.kojinbangou,a.kanji_simei,b.kanji_simei
from user_data_jirar_new a,user_data_jirar_old b
where a.kojinbangou = b.kojinbangou
and ( a.kanji_simei  <> b.kanji_simei);
