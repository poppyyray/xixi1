IMPORT FROM /dev/null of del REPLACE INTO user_data_jira_new;
IMPORT FROM /dev/null of del REPLACE INTO user_data_jirar_new;

INSERT into user_data_jira_new(
kojinbangou,
kanji_simei,
shukan_code,
password,
jira_group
)
SELECT 
distinct
kojinbangou,
kanji_simei,
t1.shukan,
password,
case t1.ninmei WHEN '1' THEN 'C' WHEN '2' THEN 'C' WHEN '8' THEN 'D' WHEN '9' THEN 'D' END
FROM user_master,
(	SELECT kojinbangou as pn,max(ninmei_level) as ninmei,min(shukan_code) as shukan 
    FROM user_master
    WHERE kojinbangou NOT IN (
        SELECT kojinbangou from user_master 
        WHERE system_code = '00002'
        AND ninmei_level = '5'
        )
    AND shukan_code IN ( SELECT shukan_cd FROM jigyosho_master
    					WHERE tensho_cd = shukan_cd 
    					AND shukan_cd <> '032621' 
    					AND sisya_cd NOT like '0M%')
    GROUP BY kojinbangou) t1
WHERE kojinbangou=t1.pn
UNION
SELECT 
distinct
kojinbangou,
kanji_simei,
shukan_code,
password,
'F'
FROM user_master 
WHERE system_code = '00002'
AND ninmei_level = '5'
;

INSERT into user_data_jirar_new(
                               SELECT * 
                               FROM user_data_jira_new
                               )
;
UPDATE user_data_jirar_new SET jira_group = 'F';