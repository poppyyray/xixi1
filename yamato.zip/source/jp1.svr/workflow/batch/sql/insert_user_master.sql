import from /dev/null of del replace into user_master;

insert into user_master(
kojinbangou,
idourireki_code,
system_code,
seq,
kanji_simei,
kana_simei,
tantou_code,
shain_kubun,
siten_code,
shukan_code,
kanriten_code,
password,
password_kari,
password_yukou_kigen,
password_keikoku_hyouji_kaishibi,
shozoku_code,
yakushoku_code,
ninmei_level
)
select
a.kojinbangou,
a.idourireki_code,
c.system_code,
b.seq,
a.kanji_simei,
a.kana_simei,
a.tantou_code,
a.shain_kubun,
a.siten_code,
d.shukan_cd,
a.kanriten_code,
a.password,
a.password_kari,
a.password_yukou_kigen,
a.password_keikoku_hyouji_kaishibi,
b.shozoku_code,
b.yakushoku_code,
c.ninmei_level
from shain_master a,shain_shozoku_master b,shain_ninmei_level c,jigyosho_master d
where a.kojinbangou      = b.kojinbangou
  and a.idourireki_code  = b.idourireki_code
  and b.kojinbangou      = c.kojinbangou
  and b.idourireki_code  = c.idourireki_code
  and b.seq              = c.seq
  and a.idourireki_code  = '0'
  and ((c.system_code      = '00001' and c.ninmei_level     in ('1','8'))
    or (c.system_code      = '00002' and c.ninmei_level     in ('1','2','8')))
  and b.shozoku_code like '%004'
  and b.shozoku_code     = d.tensho_cd
  and d.shukan_cd is not null
union
select
a.kojinbangou,
a.idourireki_code,
c.system_code,
b.seq,
a.kanji_simei,
a.kana_simei,
a.tantou_code,
a.shain_kubun,
a.siten_code,
a.shukan_code,
a.kanriten_code,
a.password,
a.password_kari,
a.password_yukou_kigen,
a.password_keikoku_hyouji_kaishibi,
b.shozoku_code,
b.yakushoku_code,
c.ninmei_level
from shain_master a,shain_shozoku_master b,shain_ninmei_level c
where a.kojinbangou      = b.kojinbangou
  and a.idourireki_code  = b.idourireki_code
  and b.kojinbangou      = c.kojinbangou
  and b.idourireki_code  = c.idourireki_code
  and b.seq              = c.seq
  and a.idourireki_code  = '0'
  and c.system_code      = '00002'
  and c.ninmei_level     = '5'
  and b.shozoku_code     in (SELECT distinct b.shozoku_code
                             FROM shain_shozoku_master b
                             WHERE b.shozoku_code like '0BB%'
                             OR b.shozoku_code like '0A%'
                             OR b.shozoku_code like '0L%'
)
union
select
a.kojinbangou,
a.idourireki_code,
c.system_code,
b.seq,
a.kanji_simei,
a.kana_simei,
a.tantou_code,
a.shain_kubun,
a.siten_code,
d.shukan_cd,
a.kanriten_code,
a.password,
a.password_kari,
a.password_yukou_kigen,
a.password_keikoku_hyouji_kaishibi,
b.shozoku_code,
b.yakushoku_code,
c.ninmei_level
from shain_master a,shain_shozoku_master b,shain_ninmei_level c,jigyosho_master d
where a.kojinbangou      = b.kojinbangou
  and a.idourireki_code  = b.idourireki_code
  and b.kojinbangou      = c.kojinbangou
  and b.idourireki_code  = c.idourireki_code
  and b.shozoku_code     = d.tensho_cd
  and b.seq              = c.seq
  and a.idourireki_code  = '0'
  and c.system_code      in ('00001','00002')
  and (b.shozoku_code like '%004' or b.shozoku_code like '%000' or b.shozoku_code='000010')
  and c.ninmei_level     = '9'
  and d.shukan_cd is not null
;