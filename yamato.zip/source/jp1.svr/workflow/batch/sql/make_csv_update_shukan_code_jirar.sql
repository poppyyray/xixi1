export to /workflow/batch/csv/user_update_shukan_code_jirar.csv of del
select a.kojinbangou,a.shukan_code,b.shukan_code
from user_data_jirar_new a,user_data_jirar_old b
where a.kojinbangou = b.kojinbangou
and (a.shukan_code  <> b.shukan_code);
