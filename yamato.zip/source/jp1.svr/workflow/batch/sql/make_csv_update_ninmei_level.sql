export to /workflow/batch/csv/user_update_ninmei_level.csv of del
select a.kojinbangou,a.jira_group,b.jira_group
from user_data_jira_new a,user_data_jira_old b
where a.kojinbangou = b.kojinbangou
and (a.jira_group <> b.jira_group);
