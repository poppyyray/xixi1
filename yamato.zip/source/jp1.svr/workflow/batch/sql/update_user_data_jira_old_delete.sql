update user_data_jira_old set
RONRISAKUJO = 'Y' ,KOUSINNICHIJI = current_timestamp
where KOJINBANGOU not in (select kojinbangou from user_data_jira_new)
and RONRISAKUJO is null
and KOUSINNICHIJI is null
;