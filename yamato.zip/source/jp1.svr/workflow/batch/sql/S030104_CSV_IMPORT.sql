export to /workflow/batch/tmp/S030104_CSV_IMPORT.csv.SJIS of del 
SELECT
    nyuukindataunmatch.tsuuban,
    nyuukindataunmatch.gyoumuID,
    nyuukindataunmatch.tenshoCODE,
    nyuukindataunmatch.kojinbangou,
    value(nyuukindataunmatch.sagyoubi,'BLANK'),
    value(nyuukindataunmatch.chouhyouID,'BLANK'),
    nyuukindataunmatch.syukanCODE,
    value(nyuukindataunmatch.aeraCODE,'BLANK'),
    value(nyuukindataunmatch.shimei,'BLANK'),
    value(nyuukindataunmatch.keijoukingaku,'BLANK'),
    value(nyuukindataunmatch.nyuukinkingaku,'BLANK'),
    value(nyuukindataunmatch.sagaku,'BLANK'),
    value(nyuukindataunmatch.koumoku,'BLANK'),
    value(nyuukindataunmatch.setsu,'BLANK'),
    value(nyuukindataunmatch.kubun,'BLANK'),
    value(nyuukindataunmatch.yobi,'BLANK'),
    value(nyuukindataunmatch.seiribusho,'BLANK'),
    value(nyuukindataunmatch.hasseitukihi,'BLANK'),
    value(nyuukindataunmatch.seiribangou,'BLANK'),
	value(jigyosho_master.tensho_ryakumei,'BLANK')
from 
	nyuukindataunmatch inner join jigyosho_master on 
	nyuukindataunmatch.tenshoCODE = jigyosho_master.tensho_cd 
where 
	nyuukindataunmatch.JIRAhaneizumi is null and 
	nyuukindataunmatch.ASIGNGROUPID is not null;
