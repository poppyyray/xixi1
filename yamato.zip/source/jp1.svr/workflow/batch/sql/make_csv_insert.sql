export to /workflow/batch/csv/user_insert.csv of del
select a.kojinbangou,a.jira_group,a.kanji_simei,a.shukan_code,db2inst3.fn_replace(a.password),a.password
from user_data_jira_new a
where not exists (select * from user_data_jira_old b where a.kojinbangou=b.kojinbangou)
;
