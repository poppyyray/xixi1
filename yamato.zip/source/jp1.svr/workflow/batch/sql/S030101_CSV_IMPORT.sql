export to /workflow/batch/tmp/S030101_CSV_IMPORT.csv.SJIS of del 
select 
	nyuusyukkinzairyoukakunin.tsuuban,
	nyuusyukkinzairyoukakunin.gyoumuID,
	nyuusyukkinzairyoukakunin.tenshoCODE,
	nyuusyukkinzairyoukakunin.sagyoubi,
	nyuusyukkinzairyoukakunin.chouhyouID,
	nyuusyukkinzairyoukakunin.kojinbangou,
	value(nyuusyukkinzairyoukakunin.hanbaihyoubangou,'BLANK'),
	nyuusyukkinzairyoukakunin.syukanCODE,
	value(nyuusyukkinzairyoukakunin.aeraCODE,'BLANK'),
	value(nyuusyukkinzairyoukakunin.kihyounengappi,'BLANK'),
	value(nyuusyukkinzairyoukakunin.kingaku,'BLANK'),
	value(jigyosho_master.tensho_ryakumei,'BLANK') 
from 
	nyuusyukkinzairyoukakunin inner join jigyosho_master on 
	nyuusyukkinzairyoukakunin.tenshoCODE = jigyosho_master.tensho_cd 
where 
	nyuusyukkinzairyoukakunin.JIRAhaneizumi is null and 
	nyuusyukkinzairyoukakunin.ASIGNGROUPID is not null;
