export to /workflow/batch/csv/team_leader_user_insert_jirar.csv of del
select a.kojinbangou
from user_data_jirar_new a
where not exists (select * from user_data_jirar_old b where a.kojinbangou=b.kojinbangou)
and shukan_code not in (
                    (SELECT shukan_cd 
                     FROM jigyosho_master jm ,user_data_jirar_new
                     WHERE user_data_jirar_new.shukan_code = jm.shukan_cd 
                     AND jm.tensho_cd = jm.shukan_cd 
                     AND jm.shukan_cd <> '032621' 
                     AND jm.sisya_cd NOT like '0M%')
                     )
;
