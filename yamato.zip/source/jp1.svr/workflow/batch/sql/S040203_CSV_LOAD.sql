export to /workflow/batch/tmp/ichijifile_load_ippansyuukin_errortaiou.csv.SJIS.txt of del 
select 
	ippansyuukin_errortaiou.tsuuban,
	ippansyuukin_errortaiou.gyoumuID,
	ippansyuukin_errortaiou.tenshoCODE,
	ippansyuukin_errortaiou.kojinbangou,
	ippansyuukin_errortaiou.sagyoubi,
	ippansyuukin_errortaiou.chouhyouID,
	ippansyuukin_errortaiou.ryousyuushobangou,
	ippansyuukin_errortaiou.syukanCODE,
	ippansyuukin_errortaiou.aeraCODE,
	ippansyuukin_errortaiou.errorriyuu,
	ippansyuukin_errortaiou.denpyoubangou,
	ippansyuukin_errortaiou.nyuukinnengappi,
	ippansyuukin_errortaiou.kihyoubusho,
	ippansyuukin_errortaiou.kokyaku,
	ippansyuukin_errortaiou.bunrui,
	ippansyuukin_errortaiou.headerNO,
	ippansyuukin_errortaiou.seiribusho,
	ippansyuukin_errortaiou.seikyuuNO,
	ippansyuukin_errortaiou.seikyuukingaku,
	ippansyuukin_errortaiou.nyuukinkingaku,
	ippansyuukin_errortaiou.seikyuuzangaku,
	jigyosho_master.tensho_ryakumei
from 
	ippansyuukin_errortaiou inner join jigyosho_master on 
	ippansyuukin_errortaiou.tenshoCODE = jigyosho_master.tensho_cd 
where 
	ippansyuukin_errortaiou.JIRAhaneizumi is null and 
	ippansyuukin_errortaiou.ASIGNGROUPID is not null;
