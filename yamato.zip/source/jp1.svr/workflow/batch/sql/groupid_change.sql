update jiraschema.jiraissue ji set updated = current timestamp,ASSIGNEE = 'g' || (
	select lower(substr(po.pname,1,1)) || substr(co.cname,1,6)
	from jiraschema.priority po,jiraschema.nodeassociation na,jiraschema.component co
	where ji.priority = po.id
	and ji.id = na.source_node_id
	and na.sink_node_id = co.id
	and na.sink_node_entity = 'Component')
where (pkey like 'UD%' or pkey like 'GC%'
	or  pkey like 'GE%' or  pkey like 'CT%'
	or  pkey like 'CE%' or  pkey like 'BT%') and ASSIGNEE not like 'g%'
;
