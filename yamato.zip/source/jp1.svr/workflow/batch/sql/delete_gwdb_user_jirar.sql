delete from USER_DATA_JIRAR_OLD
where RONRISAKUJO is not null
;