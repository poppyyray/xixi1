#!/usr/bin/perl

$shname = "S040202_DATA_INSERT.sh";
$ID_S040202 = "SD";

# 第一引数　入力ファイル名
$IN_FILE_NAME = $ARGV[0];

# 第二引数　出力ファイル名
$OUT_FILE_NAME = $ARGV[1];

$FILE_NAME = $ARGV[2];

# 入力ファイルをリードモードでオープン
open( INFILE, "${IN_FILE_NAME}" ) or die( "${IN_FILE_NAME} open error" );

# 出力ファイルを上書きモードでオープン
open( OUTFILE, ">${OUT_FILE_NAME}" ) or die( "${OUT_FILE_NAME} open error" );

while(<INFILE>) {
# 1行目のファイル名が正しいかチェック 
  if ($. == 1) {
    ($filename) = $_ =~ /(\S+)/;
    if ($filename ne $FILE_NAME) {
        printf("GC-E02003 %s\n", $IN_FILE_NAME);
        exit(1);
    }
  }

# 2行目の件数が正しいかチェック
  if ($. == 2) {
    ($count) = $_ =~ /(\S+)/;
    $count = $count + 0;
#    $_line_cnt=`wc -l ${filename} | cut -d " " -f 1`;
    $_line_cnt=`wc -l ${IN_FILE_NAME} | cut -d " " -f 1`;
    $_line_cnt = $_line_cnt - 3;
    if ($count != $_line_cnt) {
        printf("GC-E02004 %s\n", $IN_FILE_NAME);
        exit(1);
    }
  }

# 1-3行目はパターンマッチを行わない
  if ($. < 4 ) {
     next;
  }

# 入力データパーシング
  ($keihi_id, $file_id, $shop_cd, $sd_number, $work_day, $tyouhyou_id, $kanren_tyouhyou, $syukan_cd, $eria_cd, $money, $tekiyou, $koumoku, $setu, $kubun, $yobi, $seiri_busyo, $hassei, $seiri ) =
     unpack("a14 a7 a6 a8 a8 a4 a10 a6 a6 a12 a50 a3 a2 a1 a1 a6 a4 a4", $_);

# 金額の "+0" をなくす
   $money = $money + 0;

# 摘要の後ろスペースをなくす
   $tekiyou =~ s/ *$//;

# 時刻取得 (プロセス起動方式では遅かったので変更)
#  $timestmp=`date +%Y-%m-%d-%H.%M.%S`;
  ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
  $timestamp = sprintf( "%04d-%02d-%02d-\%02d.%02d.%02d", $year+1900, $mon+1, $mday, $hour, $min, $sec) . ".000000";  

# 出力用文字列作成
   $outline = "";
   $outline .= "${ID_S040202}-${keihi_id},";
   $outline .= "${file_id},";
   $outline .= "${shop_cd},";
   $outline .= "${sd_number},";
   $outline .= "${work_day},";
   $outline .= "${tyouhyou_id},";
   $outline .= "${kanren_tyouhyou},";
   $outline .= "${syukan_cd},";
   $outline .= "${eria_cd},";
   $outline .= "${money},";
   $outline .= "${tekiyou},";
   $outline .= "${koumoku},";
   $outline .= "${setu},";
   $outline .= "${kubun},";
   $outline .= "${yobi},";
   $outline .= "${seiri_busyo},";
   $outline .= "${hassei},";
   $outline .= "${seiri},,,,,,,,,,";
   $outline .= "${shname},";
   $outline .= "${timestamp},,,";
   $outline .= "\n";
   print OUTFILE $outline;
}

close(OUTFILE);
close(INFILE);

