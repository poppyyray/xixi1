#!/usr/bin/perl

# 第一引数　入力ファイル名
$IN_FILE_NAME = $ARGV[0];

# 出力ファイル名
$OUT_FILE_NAME = $ENV{"CSV_OUT_DIR"} . "/" . $ENV{"FILE_Shohyo"} . ".csv";

# 入力ファイルをリードモードでオープン
open(INFILE, "${IN_FILE_NAME}") or die("${IN_FILE_NAME} open error");

# 出力ファイルを上書きモードでオープン
open(OUTFILE, ">${OUT_FILE_NAME}") or die("${OUT_FILE_NAME} open error");

#カウント変数初期化
$_Shohyo_cnt = 0;

while (<INFILE>) {
    if (substr($_, 0, 2) eq "HD") {
        ($id, $dummy) = unpack("a2 a14", substr($_, 0, 16));

        # ユニークID作成のため日付を取得
        ($second, $minute, $hour, $day, $month, $year) = localtime(time);
        $_date = sprintf("%04d%02d%02d%02d%02d%02d", $year + 1900, $month + 1, $day, $hour, $minute, $second);
    }
    else {
        # ヘッダ以外の行は業務データのcsvファイルを作成
        # 件数をカウント
        ++$_Shohyo_cnt;

        ($_tyouhyou_id, $_shop_cd, $_kojin_no, $_tyouhyou_day, $_number, $_tyouhyou_time,
         $_seisan_cd, $_tyouhyou_kin, $_tyouhyou_num, $_inji_syubetu, $_sinkoku_tensyo,
         $_yomitori_day, $_yomitori_time, $_scansyukan_cd, $_yomitori_souti, $_yomitori_no,
         $_yobi)
            = unpack("a4 a6 a8 a8 a6 a4 a4 a8 a12 a2 a6 a8 a6 a6 a15 a6 a20", substr($_, 0, 129));

        # 以下はShellに合わせる、行末スペース削除。
        #
        #_tyouhyou_num=`echo ${_tyouhyou_num} |  sed -e "s/ *$//"`
        #
        # これは一見、行末スペースの削除に見えるが、${_tyouhyou_num}の
        # 前後が、""で囲まれていないので、行頭、行末スペース削除、およ
        # び、途中の2個上のスペースを1個にするという処理となる。

        $_tyouhyou_num =~ s/ +$//;
        $_tyouhyou_num =~ s/^ +//;
        $_tyouhyou_num =~ s/  +/ /g;

        $_yomitori_souti =~ s/ +$//;
        $_yomitori_souti =~ s/^ +//;
        $_yomitori_souti =~ s/  +/ /g;

        $_yobi =~ s/ +$//;
        $_yobi =~ s/^ +//;
        $_yobi =~ s/  +/ /g;

        # 以下はShellに合わせ、前置0を削除。
        $_number += 0;
        $_seisan_cd += 0;
        $_tyouhyou_kin += 0;

        $_timestmp = sprintf("%04d-%02d-%02d-%02d.%02d.%02d", $year + 1900, $month + 1, $day, $hour, $minute, $second). ".000000";  

        # 以下の変数を毎回初期化する
        $_hanbaihyo_id = "";
        $_ryoshusho_id = "";
        $_shijisho_id = "";

        # 帳票IDが0004なら販売票番号に帳票番号を設定
        if (${_tyouhyou_id} eq $ENV{"HANBAIHYO_ID"}) {
            $_hanbaihyo_id = ${_tyouhyou_num};
        }
        elsif (${_tyouhyou_id} eq $ENV{"RYOSHUUSHO_ID"}) {
            $_ryoshusho_id = ${_tyouhyou_num};
        }
        elsif (${_tyouhyou_id} eq $ENV{"SHIJISHO_ID_1"} ||
               ${_tyouhyou_id} eq $ENV{"SHIJISHO_ID_2"} ||
               ${_tyouhyou_id} eq $ENV{"SHIJISHO_ID_3"})
        {
            $_shijisho_id = ${_tyouhyou_num};
        }
        
#        printf OUTFILE "${_date}-%05d,${_tyouhyou_id},${_tyouhyou_day},${_scansyukan_cd},${_shop_cd},${_kojin_no},${_tyouhyou_kin},${_hanbaihyo_id},${_ryoshusho_id},${_shijisho_id},,," . $ENV{"_shname"} . ",${_timestmp},,,\n", $_Shohyo_cnt;
        printf OUTFILE "${_date}%06d,${_tyouhyou_id},${_tyouhyou_day},${_scansyukan_cd},${_shop_cd},${_kojin_no},${_tyouhyou_kin},${_hanbaihyo_id},${_ryoshusho_id},${_shijisho_id},,," . $ENV{"_shname"} . ",${_timestmp}," . $ENV{"_shname"} . ",${_timestmp},\n", $_Shohyo_cnt;
    }
}

close(OUTFILE);
close(INFILE);

