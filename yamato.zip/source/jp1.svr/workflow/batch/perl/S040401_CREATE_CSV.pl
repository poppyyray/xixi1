#!/usr/bin/perl

$shname = "S040401_DATA_INSERT.sh";
$ID_S040401 = "SF";

# 第一引数　入力ファイル名
$IN_FILE_NAME = $ARGV[0];

# 第二引数　出力ファイル名
$OUT_FILE_NAME = $ARGV[1];

$FILE_NAME = $ARGV[2];

# 入力ファイルをリードモードでオープン
open( INFILE, "${IN_FILE_NAME}" ) or die( "${IN_FILE_NAME} open error" );

# 出力ファイルを上書きモードでオープン
open( OUTFILE, ">${OUT_FILE_NAME}" ) or die( "${OUT_FILE_NAME} open error" );

while(<INFILE>) {
# 1行目のファイル名が正しいかチェック 
  if ($. == 1) {
    ($filename) = $_ =~ /(\S+)/;
    if ($filename ne $FILE_NAME) {
        printf("BT-E02003 %s\n", $IN_FILE_NAME);
        exit(1);
    }
  }

# 2行目の件数が正しいかチェック
  if ($. == 2) {
    ($count) = $_ =~ /(\S+)/;
    $count = $count + 0;
#    $_line_cnt=`wc -l ${filename} | cut -d " " -f 1`;
    $_line_cnt=`wc -l ${IN_FILE_NAME} | cut -d " " -f 1`;
    $_line_cnt = $_line_cnt - 3;
    if ($count != $_line_cnt) {
        printf("BT-E02004 %s\n", $IN_FILE_NAME);
        exit(1);
    }
  }

# 1-3行目はパターンマッチを行わない
  if ($. < 4 ) {
     next;
  }

# 入力データパーシング
  ($keihi_id, $file_id, $syukan_cd, $eria_cd, $kihyou, $kokyaku_cd, $bunrui_cd, $kokyaku_meisyou, $money, $yotei, $tekiyou, $simuke_ginkou, $simuke_siten, $koumoku, $setu, $kubun, $yobi, $seiri_busyo, $hassei, $seiri ) =
     unpack("a14 a7 a6 a6 a8 a12 a3 a20 a12 a2 a40 a28 a28 a3 a2 a1 a1 a6 a4 a4", $_);

# 金額の "+0" をなくす
   $money = $money + 0;

   $kokyaku_meisyou =~ s/^0*//;
   $tekiyou =~ s/^0*//;
   $simuke_ginkou =~ s/^0*//;
   $simuke_siten =~ s/^0*//;

# 時刻取得 (プロセス起動方式では遅かったので変更)
#  $timestmp=`date +%Y-%m-%d-%H.%M.%S`;
  ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
  $timestamp = sprintf( "%04d-%02d-%02d-\%02d.%02d.%02d", $year+1900, $mon+1, $mday, $hour, $min, $sec) . ".000000";  

# 出力用文字列作成
   $outline = "";
   $outline .= "${ID_S040401}-${keihi_id},";
   $outline .= "${file_id},";
   $outline .= "${syukan_cd},";
   $outline .= "${eria_cd},";
   $outline .= "${kihyou},";
   $outline .= "${kokyaku_cd},";
   $outline .= "${bunrui_cd},";
   $outline .= "${kokyaku_meisyou},";
   $outline .= "${money},";
   $outline .= "${yotei},";
   $outline .= "${tekiyou},";
   $outline .= "${simuke_ginkou},";
   $outline .= "${simuke_siten},";
   $outline .= "${koumoku},";
   $outline .= "${setu},";
   $outline .= "${kubun},";
   $outline .= "${yobi},";
   $outline .= "${seiri_busyo},";
   $outline .= "${hassei},";
   $outline .= "${seiri},,,,,,,,";
   $outline .= "${shname},";
   $outline .= "${timestamp},,,";
   $outline .= "\n";
   print OUTFILE $outline;
}

close(OUTFILE);
close(INFILE);

