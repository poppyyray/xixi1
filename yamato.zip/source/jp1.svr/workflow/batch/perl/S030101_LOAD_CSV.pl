#!/usr/bin/perl

# カウンタを取り込み
$_customfield_valueid_max_jiraid = $ENV{"_customfield_valueid_max_jiraid"};
$_jiraissueid_max_jiraid = $ENV{"_jiraissueid_max_jiraid"};
$_workflowid_max_jiraid = $ENV{"_workflowid_max_jiraid"};
$_pkey_max_jiraid = $ENV{"_pkey_max_jiraid"};
$_os_currentstepid_max_jiraid = $ENV{"_os_currentstepid_max_jiraid"};

sub outlog_func {
    print join("\n", @_), "\n\n";
}

# 第一引数　入力ファイル名
$IN_FILE_NAME = $ARGV[0];

# 入力ファイルをリードモードでオープン
open( INFILE, "${IN_FILE_NAME}" ) or die( "${IN_FILE_NAME} open error" );

# 出力ファイルをライトモードでオープン
open(JIRAISSUE_FILE, ">" . $ENV{"jiraissue_file"}) or die($ENV{"jiraissue_file"} . " open error");
open(OS_WFENTRY_FILE, ">" . $ENV{"os_wfentry_file"}) or die($ENV{"os_wfentry_file"} . " open error");
open(OS_CURRENTSTEP_FILE, ">" . $ENV{"os_currentstep_file"}) or die($ENV{"os_currentstep_file"} . " open error");
open(NODEASSOCIATION_FILE, ">" . $ENV{"nodeassociation_file"}) or die($ENV{"nodeassociation_file"} . " open error");
open(CUSTOMFIELD_FILE, ">" . $ENV{"customfield_file"}) or die($ENV{"customfield_file"} . " open error");
open(UPDATE_PKEY_CD_FILE, ">" . $ENV{"update_pkey_cd_file"}) or die($ENV{"update_pkey_cd_file"} . " open error");

# 環境変数引き渡し用ファイルの生成
open(ENV_CONVEY_FILE, ">" . $ENV{"env_convey_file"}) or die($ENV{"env_convey_file"} . " open error");

$created_updatedid = 0; # 6桁0パディングで表示

# component_idテーブルを事前に作成。
open( COMPONENT_FILE, $ENV{"component_id_file"} ) or die( $ENV{"component_id_file"} . " open error" );
while (<COMPONENT_FILE>) {
    ($val, $key) = split;
    unless ($component_id_table{$key}) {
        $component_id_table{$key} = $val;
    }
}

# formidテーブルを事前に作成。
open( PROJECT_VER_FILE, $ENV{"projectversion_id_file"} ) or die( $ENV{"projectversion_id_file"} . " open error" );
while (<PROJECT_VER_FILE>) {
    ($val, $key) = split;
    unless ($formid_table{$key}) {
        $formid_table{$key} = $val;
    }
}

while (<INFILE>) {
    chop;
    ($syukanCODE, $tenshoCODE, $tensho_meishou, $kojinbangou, $sagyoubi,
     $chouhyouID, $hanbaihyoubangou, $kihyounengappi, $kingaku, $tsuuban) = split(/,/);

    ($second, $minute, $hour, $day, $month, $year) = localtime(time);
    $created = sprintf("%04d-%02d-%02d-%02d.%02d.%02d", $year + 1900, $month + 1, $day, $hour, $minute, $second);
    $updated = $created;
    $startdate = $created;

    ++$created_updatedid;

    if ($syukanCODE =~ /^\s*$/) {
        outlog_func("CM-W05082", "主管コード", "通番「${tsuuban}」 主管コード「${syukanCODE}」");
        next;
    }
    else {
        $component = $component_id_table{$syukanCODE};
        if ($component =~ /^\s*$/) {
            outlog_func("CM-W05083", "主管コード", "通番「${tsuuban}」 主管コード「${syukanCODE}」");
            next;
        }
    }

    # 店所コード(GWDBから取得した値をそのまま使用:tenshoCODE)
    # 店所名称(GWDBから取得した値をそのまま使用:tensho_meishou)
    # 個人番号(GWDBから取得した値をそのまま使用:kojinbangou)
    # 作業日(sagyoubi)
    if ($sagyoubi =~ /^\s*$/) {
        $dudate = "";
    }
    else {
        ($Year1, $Month1, $Day1) = unpack("a4 a2 a2", $sagyoubi);
        # 行末に1つ以上のスペースがあれば、それを1つのスペースに。無け
        # れば無しとする。(元のShellと同じ動きとするため)
        $Year1 =~ s/\s+$/ /;
        $Month1 =~ s/\s+$/ /;
        $Day1 =~ s/\s+$/ /;
        $duedate = "${Year1}-${Month1}-${Day1}-00.00.00.000000";
    }

    # 帳票有無(固定値(batch_load_common.confにて定義:reporter))
    # 帳票ID(chouhyouID)
    if ($chouhyouID =~ /^\s*$/) {
        outlog_func("CM-W05258", "帳票ID", "通番「${tsuuban}」 帳票ID「${chouhyouID}」");
        next
    }
    else {
        $formid = $formid_table{$chouhyouID};
        if ($formid =~ /^\s*$/) {
            outlog_func("CM-W05267", "帳票ID", "通番「${tsuuban}」 帳票ID「${chouhyouID}」");
            next;
        }
    }

    # 確認帳票(Null固定)
    $selectedForm = "";
    # 帳票検索キー(Null固定)
    $formSearchKey = "";
    
    # 関連帳票番号(GWDBから取得した値をそのまま使用:hanbaihyoubangou)
    # 起票年月日(kihyounengappi)
    if ($kihyounengappi =~ /^\s*$/) {
        $issueddate = "";
    }
    else {
        ($Year2, $Month2, $Day2) = unpack("a4 a2 a2", $kihyounengappi);
        # 行末に1つ以上のスペースがあれば、それを1つのスペースに。無け
        # れば無しとする。(元のShellと同じ動きとするため)
        $Year2 =~ s/\s+$/ /;
        $Month2 =~ s/\s+$/ /;
        $Day2 =~ s/\s+$/ /;
        $issueddate = "\"${Year2}-${Month2}-${Day2}-00.00.00.000000\"";
    }

    # 金額(GWDBから取得した値をそのまま使用:kingaku)
    # JIRAISSUE.ID採番
    unless ($_jiraissueid_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05024");
        exit(1);
    }
    ++$_jiraissueid_max_jiraid;

    # JIRAISSUE.PKEY採番
    unless ($_pkey_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05025");
        exit(1);
    }
    ++$_pkey_max_jiraid;

    # PKEY値設定
    $_pkey_cd = sprintf("%s-%s%06d", $ENV{"gyomu_id2"}, $ENV{"_TODAY"}, $_pkey_max_jiraid);

    # JIRAISSUE.WORKFLOW_ID採番
    unless ($_workflowid_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05026");
        exit(1);
    }
    ++$_workflowid_max_jiraid;

    # OS_CURRENTSTEP.ID採番
    unless ($_os_currentstepid_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05069");
        exit(1);
    }
    ++$_os_currentstepid_max_jiraid;

    # CUSTOMFIELDVALUE.ID採番
    unless ($_customfield_valueid_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05032");
        exit(1);
    }
    ++$_customfield_valueid_max_jiraid;

    ###############################################################################
    # JIRAISSUE用CSV作成
    ###############################################################################
    $rc = printf JIRAISSUE_FILE "${_jiraissueid_max_jiraid},\"${_pkey_cd}\"," . $ENV{"serviceID"} . ",\"" . $ENV{"reporter"} . "\",\"" . $ENV{"assignee_initial"} . "${syukanCODE}\",\"" . $ENV{"issuetype"} . "\",\"${kojinbangou}\",\"${tenshoCODE}\",,\"" . $ENV{"priority"} . "\",\"" . $ENV{"resolution"} . "\",\"" . $ENV{issuestatus} . "\",\"${created}.%06d\",\"${updated}.%06d\",\"${duedate}\"," . $ENV{"JIRAISSUE_VOTES"} . ",,,,${_workflowid_max_jiraid},,,\n", $created_updatedid, $created_updatedid;
    if ($rc == 0) {
        outlog_func("CM-E05027");
        exit(1);
    }

    ###############################################################################
    # OS_WFENTRY用CSV作成
    ###############################################################################
    $rc = print OS_WFENTRY_FILE "${_workflowid_max_jiraid},\"" . $ENV{"_wf_project_name"} . "\",," . $ENV{OS_WFENTRY_STATE} . "\n";
    if ($rc == 0) {
        outlog_func("CM-E05028");
        exit(1);
    }

    ###############################################################################
    # OS_CURRENTSTEP用CSV作成
    ###############################################################################
    $rc = printf OS_CURRENTSTEP_FILE "${_os_currentstepid_max_jiraid},${_workflowid_max_jiraid}," . $ENV{OS_CURRENTSTEP_STEP_ID} . "," . $ENV{OS_CURRENTSTEP_ACTION_ID} . ",\"\",\"${startdate}.%06d\",,,\"" . $ENV{OS_CURRENTSTEP_STATUS} . "\",\n", $created_updatedid;
    if ($rc == 0) {
        outlog_func("CM-E05029");
        exit(1);
    }

    ###############################################################################
    # NODEASSOCIATION用CSV作成
    ###############################################################################
    # 主管コード(regionCode)フィールド作成・値設定
    $rc = print NODEASSOCIATION_FILE "${_jiraissueid_max_jiraid},\"" . $ENV{"NODEASSOCIATION_SOURCE_NODE_ENTITY"} . "\",${component},\"" . $ENV{NODEASSOCIATION_SINK_NODE_ENTITY_regionCode} . "\",\"" . $ENV{"NODEASSOCIATION_ASSOCIATION_TYPE_regionCode"} . "\",\n";
    if ($rc == 0) {
        outlog_func("CM-E05030", "主管コード(regionCode)");
        exit(1);
    }

    # 帳票ID(formId)フィールド作成・値設定
    $rc = print NODEASSOCIATION_FILE "${_jiraissueid_max_jiraid},\"" . $ENV{"NODEASSOCIATION_SOURCE_NODE_ENTITY"} . "\",${formid},\"" . $ENV{"NODEASSOCIATION_SINK_NODE_ENTITY_formId"} . "\",\"" . $ENV{"NODEASSOCIATION_ASSOCIATION_TYPE_formId"} . "\",\n";
    if ($rc == 0) {
        outlog_func("CM-E05114", "帳票ID(formId)");
        exit(1);
    }

    ###############################################################################
    # CUSTOMFIELD用CSV作成
    ###############################################################################
    # 店所名称(deliveryCenterName)フィールド作成・値設定
    $rc = print CUSTOMFIELD_FILE "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid}," . $ENV{"CUSTOMFIELD_ID_deliveryCenterName"}. ",,\"${tensho_meishou}\",,,,\n";
    if ($rc == 0) {
        outlog_func("CM-E05031", "店所名称(deliveryCenterName)");
        exit(1);
    }

    unless ($_customfield_valueid_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05187");
        exit(1);
    }
    ++$_customfield_valueid_max_jiraid;
    
    # 確認帳票(selectedForm)フィールド作成・値設定(Null固定)
    #   ${selectedForm}はNull固定のためダブルクォーテーションは不要
    $rc = print CUSTOMFIELD_FILE "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid}," . $ENV{"CUSTOMFIELD_ID_selectedForm"} . ",,${selectedForm},,,,\n";
    if ($rc == 0) {
        outlog_func("CM-E05127", "確認帳票(selectedForm)");
        exit(1);
    }

    unless ($_customfield_valueid_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05188");
        exit(1);
    }
    ++$_customfield_valueid_max_jiraid;

    # 帳票検索キー(formSearchKey)フィールド作成・値設定(Null固定)
    #   ${formSearchKey}はNull固定のためダブルクォーテーションは不要
    $rc = print CUSTOMFIELD_FILE "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid}," . $ENV{"CUSTOMFIELD_ID_formSearchKey"} . ",,,,${formSearchKey},,\n";
    if ($rc == 0) {
        outlog_func("CM-E05128", "帳票検索キー(formSearchKey)");
        exit(1);
    }

    unless ($_customfield_valueid_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05189");
        exit(1);
    }
    ++$_customfield_valueid_max_jiraid;

    # 関連帳票番号(relevantFormID)フィールド作成・値設定
    $rc = print CUSTOMFIELD_FILE "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid}," . $ENV{"CUSTOMFIELD_ID_relevantFormID"} . ",,\"${hanbaihyoubangou}\",,,,\n";
    if ($rc == 0) {
        outlog_func("CM-E05129", "関連帳票番号(relevantFormID)");
        exit(1);
    }

    unless ($_customfield_valueid_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05190");
        exit(1);
    }
    ++$_customfield_valueid_max_jiraid;

    # 起票年月日(issuedDate)フィールド作成・値設定
    $rc = print CUSTOMFIELD_FILE "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid}," . $ENV{"CUSTOMFIELD_ID_issuedDate"} . ",,,,,${issueddate},\n";
    if ($rc == 0) {
        outlog_func("CM-E05130", "起票年月日(issuedDate)");
        exit(1);
    }

    unless ($_customfield_valueid_max_jiraid =~ /^\s*\d*\s*$/) {
        outlog_func("CM-E05191");
    }
    ++$_customfield_valueid_max_jiraid;

    # 金額(amount)フィールド作成・値設定
    $rc = print CUSTOMFIELD_FILE "${_customfield_valueid_max_jiraid},${_jiraissueid_max_jiraid}," . $ENV{"CUSTOMFIELD_ID_amount"} . ",,,${kingaku},,,\n";
    if ($rc == 0) {
        outlog_func("CM-E05131", "金額(amount)");
        exit(1);
    }

    ###############################################################################
    # GWサーバpkey_cd,JIRAhaneizumiアップデート用CSV作成
    ###############################################################################
    $rc = print UPDATE_PKEY_CD_FILE "${tsuuban} ${_pkey_cd} " . $ENV{"JIRAhaneizumi"} . "\n";
    if ($rc == 0) {
        outlog_func("CM-E05236");
        exit(1);
    }
}

close(INFILE);
close(JIRAISSUE_FILE);
close(OS_WFENTRY_FILE);
close(OS_CURRENTSTEP_FILE);
close(NODEASSOCIATION_FILE);
close(CUSTOMFIELD_FILE);
close(UPDATE_PKEY_CD_FILE);

# カウンタの環境変数への書き戻し。
print ENV_CONVEY_FILE "_customfield_valueid_max_jiraid=$_customfield_valueid_max_jiraid\n";
print ENV_CONVEY_FILE "_jiraissueid_max_jiraid=$_jiraissueid_max_jiraid\n";
print ENV_CONVEY_FILE "_workflowid_max_jiraid=$_workflowid_max_jiraid\n";
print ENV_CONVEY_FILE "_pkey_max_jiraid=$_pkey_max_jiraid\n";
print ENV_CONVEY_FILE "_os_currentstepid_max_jiraid=$_os_currentstepid_max_jiraid\n";

close(ENV_CONVEY_FILE);
