#!/usr/bin/perl

$shname = "S030104_DATA_INSERT.sh";
$ID_S030104 = "SC";

# 第一引数　入力ファイル名
$IN_FILE_NAME = $ARGV[0];

# 第二引数　出力ファイル名
$OUT_FILE_NAME = $ARGV[1];

$FILE_NAME = $ARGV[2];

# 入力ファイルをリードモードでオープン
open( INFILE, "${IN_FILE_NAME}" ) or die( "${IN_FILE_NAME} open error" );

# 出力ファイルを上書きモードでオープン
open( OUTFILE, ">${OUT_FILE_NAME}" ) or die( "${OUT_FILE_NAME} open error" );

while(<INFILE>) {
# 1行目のファイル名が正しいかチェック 
  if ($. == 1) {
    ($filename) = $_ =~ /(\S+)/;
    if ($filename ne $FILE_NAME) {
        printf("UD-E02003 %s\n", $IN_FILE_NAME);
        exit(1);
    }
  }

# 2行目の件数が正しいかチェック
  if ($. == 2) {
    ($count) = $_ =~ /(\S+)/;
    $count = $count + 0;
#    $_line_cnt=`wc -l ${filename} | cut -d " " -f 1`;
    $_line_cnt=`wc -l ${IN_FILE_NAME} | cut -d " " -f 1`;
    $_line_cnt = $_line_cnt - 3;
    if ($count != $_line_cnt) {
        printf("UD-E02004 %s\n", $IN_FILE_NAME);
        exit(1);
    }
  }

# 1-3行目はパターンマッチを行わない
  if ($. < 4 ) {
     next;
  }

# 入力データパーシング
  ($keihi_id, $file_id, $shop_cd, $sd_number, $work_day, $tyouhyou_id, $syukan_cd, $eria_cd, $name, $keijyou_kin, $nyukin_kin, $sagaku, $koumoku, $setu, $kubun, $yobi, $seiri_busyo, $hassei, $seiri ) =
     unpack("a14 a7 a6 a8 a8 a4 a6 a6 a1 a12 a12 a12 a3 a2 a1 a1 a6 a4 a4", $_);

# 計上金額の "+0" をなくす
   $keijyou_kin = $keijyou_kin + 0;

# 入金金額の "+0" をなくす
   $nyukin_kin = $nyukin_kin + 0;

# 差額の "+0" をなくす
   $sagaku = $sagaku + 0;

# 時刻取得 (プロセス起動方式では遅かったので変更)
#  $timestmp=`date +%Y-%m-%d-%H.%M.%S`;
  ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
  $timestamp = sprintf( "%04d-%02d-%02d-\%02d.%02d.%02d", $year+1900, $mon+1, $mday, $hour, $min, $sec) . ".000000";  

# 出力用文字列作成
   $outline = "";
   $outline .= "${ID_S030104}-${keihi_id},";
   $outline .= "${file_id},";
   $outline .= "${shop_cd},";
   $outline .= "${sd_number},";
   $outline .= "${work_day},";
   $outline .= "${tyouhyou_id},";
   $outline .= "${syukan_cd},";
   $outline .= "${eria_cd},";
   $outline .= "${name},";
   $outline .= "${keijyou_kin},";
   $outline .= "${nyukin_kin},";
   $outline .= "${sagaku},";
   $outline .= "${koumoku},";
   $outline .= "${setu},";
   $outline .= "${kubun},";
   $outline .= "${yobi},";
   $outline .= "${seiri_busyo},";
   $outline .= "${hassei},";
   $outline .= "${seiri},,,,,,,,,,";
   $outline .= "${shname},";
   $outline .= "${timestamp},,,,";
   $outline .= "\n";
   print OUTFILE $outline;
}

close(OUTFILE);
close(INFILE);

