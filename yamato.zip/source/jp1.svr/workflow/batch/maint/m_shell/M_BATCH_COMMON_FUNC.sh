#!/bin/sh
###########################################################
# 関数名:m_outlog_func
#
# 機能:指定されたパスにシェル名.logの名前でログを作成し出力する
#
# 引数
# $1 MSGID
#
# $2 MSG引数
#
# 戻り値
#  0:正常
#  1:異常
#
# 前提条件:ログ出力パス環境変数${M_LOG_DIR}にパスが指定されていること
#
###########################################################
function m_outlog_func
{
	# ログ名が設定されていない場合呼ばれているシェルをログ名に使用
	if [ ! "${log_name}" ]; then
		shname=`basename ${0}`
		log_name=`echo ${shname} | sed "s/.sh//g"`
	fi

	shname=`basename ${0}`

	# ログが存在しない場合作成し権限を変更
	if [ ! -f ${M_LOG_DIR}/${log_name}.log ]; then
		touch ${M_LOG_DIR}/${log_name}.log
		chmod 777 ${M_LOG_DIR}/${log_name}.log
	fi

	error_id=`echo ${1} | cut -b4`

	if [ ${error_id} == "E" ]; then
		errorlevel="ERROR  "
	elif [ ${error_id} == "W" ]; then
	        errorlevel="WARNING"
	elif [ ${error_id} == "I" ]; then
		errorlevel="INFO   "
	elif [ ${error_id} == "F" ]; then
		errorlevel="FATAL  "
	elif [ ${error_id} == "D" ]; then
		errorlevel="DEBUG  "
	else
		echo "エラー出力関数の第一引数に誤りがあります。シェル名[${0}] 第一引数[${1}]"
		return 1
	fi

	logdate=`date "+%Y-%m-%d %H:%M:%S"`

	log_id_msg=`cat ${M_CONF_DIR}/m_message.conf | grep ${1}`
	if [ -z "${log_id_msg}" ]; then
		echo ${logdate} ${errorlevel} ${shname} "CM-W01001" "メッセージID[${1}]が存在しません。" >> ${M_LOG_DIR}/${log_name}.log
		return 1
	fi

	PARM_CNT=$#
	# 引数の2個目から取得するために初期値を2としている
	MSG_CNT=2
	while (( ${MSG_CNT} <= ${PARM_CNT} ))
	do
		PARM_MSG=`eval echo "\\${${MSG_CNT}}"`

		#%sを引数に変換
		log_id_msg=`echo ${log_id_msg} | sed s@%s@"${PARM_MSG}"@`

		MSG_CNT=`expr $MSG_CNT + 1`
	done

	printf "%-s %-7s %-s %-s\n" "${logdate}" "${errorlevel}" "${shname}" "${log_id_msg}"  >> ${M_LOG_DIR}/${log_name}.log

	return 0
}

###########################################################
# 関数名:m_createlogfile
#
# 機能:実行するシェルが出力するログファイル名を設定
#
# 引数
# $1 ログファイル名
#
# 戻り値
#  0:正常
#  1:異常
#
# 前提条件:ログ出力パス環境変数${M_LOG_DIR}にパスが指定されていること
#
###########################################################
function m_createlogfile
{
	# ログ名の設定
	local sh_name=`basename ${0}`
	local log_main_name=`echo ${sh_name} | sed "s/.sh//g"`

	# ログが存在しない場合作成し権限を変更
	if [ ! -f ${M_LOG_DIR}/${log_main_name}.log ]; then
   		touch ${M_LOG_DIR}/${log_main_name}.log
    	chmod 777 ${M_LOG_DIR}/${log_main_name}.log
	fi

	return 0
}

###############################################################################
# 関数名：　m_func_connectDB
#
# 機能：　引数で指定したDBに接続する
#
# 引数：　DB名（"db2 connect to"に続くコマンド）
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：　当関数内で使用している全変数に適切な値が設定されていること
#
###############################################################################
function m_func_connectDB
{
    # DB接続
    db2 connect to "$*" > ${SQLLOG_TMP} 2>&1
	SQLERROR=$?
	echo -e "日付:`date` || shell名:M_BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${M_DETAIL_LOG}

	# コマンド判定
	if [ ${SQLERROR} != ${RC_NOR} ]; then
		# エラーログ出力
		m_outlog_func MC-E00002

		return ${RC_ERR}
	fi

	return ${RC_NOR}
}

###########################################################
# 関数名:　m_func_login_jiraui
#
# 機能:　管理用JIRAUIログイン関数
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件:なし
#
###########################################################
function m_func_login_jiraui
{
	LOGIN_COOKIES=login_cookies.txt

	# cookie初期化
	cat /dev/null > ${M_TMP_DIR}/${LOGIN_COOKIES}
	. /workflow/auth_mgr/decrypt/ASCA_DECRYPT_MANAGER.sh USER5
	wget -q --save-cookies ${LOGIN_COOKIES} --keep-session-cookies --header="Proxy-Connection: keep-alive" --post-data "os_username=${A_USER5_ID}&os_password=${A_USER5_PWD}&os_cookie=true" ${JIRA_IP}/login.jsp
	_ret=$?
	echo -e "日付:`date` || shell名:M_BATCH_COMMON_FUNC.sh || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${M_TMP_DIR}/login.jsp`" >>${M_DETAIL_LOG}

	if [ ${_ret} != ${RC_NOR} ] ;then
		m_outlog_func MC-E00001

		return ${RC_ERR}
	fi

	return ${RC_NOR}
}
