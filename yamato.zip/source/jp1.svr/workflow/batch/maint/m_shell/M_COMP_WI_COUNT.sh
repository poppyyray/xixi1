#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： M_COMP_WI_COUNT.sh
# 業 務 名       ： バッチ取込件数比較処理
# 処理概要       ： ワークアイテム件数比較ログをバッチ取込件数と比較する。
#　　　　　　　　比較結果を生成する。
# 特記事項       ：
# パラメータ     ： 1 - UD以外
#							2 - UD
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Tang.XD
#
# 作成日付       ： 2015-09-15
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2015-09-15 Tang.XD                新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません"
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# 保守用共通環境変数設定
# ----
_exec_m_sh=/workflow/batch/maint/m_ini/m_batch_common.conf

if [ ! -f ${_exec_m_sh} ]; then
	echo "保守用環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_m_sh}

# ----
# 保守用共通関数ファイルの存在チェック
# ----
if [ ! -f ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh ]; then
	echo "保守用共通関数ファイルが存在しません"
	exit 1
fi
. ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" ]
then
	m_outlog_func MA-E01014 "$1"
	exit 1
fi

# IF物理ファイル名
ITEMS=("S030101" "S030102" "S040202" "S040203" "S040401" "ShoninZumi" "Jigyosho" 
			"ZenjituKadoSD" "GenkinFutai" "USERIN01" "USERIN02" "USERIN03" "S030104")
# IF業務名
NAMES=("入出金材料確認" "経費振替" "一般集金（手動消込）" "一般集金（エラー処理）" "振込入金" "承認済み" "事業所" 
			"前日稼動ＳＤ" "現金附帯計上" "社員マスタ" "所属マスタ" "任命レベルマスタ" "入金アンマッチ")
# レポート出力フラグ
RPT=("1" "1" "1" "1" "1" "0" "0" "0" "0" "0" "0" "0" "0")
# 実行日付
runDate=`date +%Y%m%d`
# ワークアイテム件数比較ログファイル
CHK_CNT_LG=${M_LOG_DIR}/${M_CHECK_WI_COUNT_LOG}.log
# バッチ取込件数IFファイル
IF_KENSU=${M_IF_DIR}/IFKENSU$1.${runDate}
# バッチ取込件数比較結果ファイル
IF_KEKKA="IFKEKKA"$1
# レポートファイル
R0327_REPORT_FILENAME=`echo ${R0327_REPORT_FILENAME} | sed -e s/rundate/${runDate}/`
# HULFT件数ディレクトリ
HULFT_COUNT_PATH=/shared/hulft/count
# IFKEKKA1ファイルID
FILE_ID_IFKEKKA1="WFS022"
# IFKEKKA2ファイルID
FILE_ID_IFKEKKA2="WFS024"
LOG_DIR=${M_LOG_DIR}
TMP_DIR=${M_TMP_DIR}

###############################################################################
# main処理開始
###############################################################################
# 開始メッセージ
m_outlog_func MA-I01015

# ワークアイテム件数比較ログファイルの存在チェック
if [ ! -f ${CHK_CNT_LG} ]
then
	m_outlog_func MA-E01016 ${CHK_CNT_LG}
	exit 1
fi

# バッチ取込件数IFファイルの存在チェック
if [ ! -f ${IF_KENSU} ]
then
	m_outlog_func MA-E01016 ${IF_KENSU}
	exit 1
fi

# 比較結果ファイルのヘッダ出力
echo -e ${IF_KEKKA}"                   \\r" > ${M_IF_DIR}/${IF_KEKKA}
echo -e `date +%Y%m%d%H%M%S`"             \\r" >> ${M_IF_DIR}/${IF_KEKKA}
echo -e "                           \\r" >>  ${M_IF_DIR}/${IF_KEKKA}

# レポートファイルの削除
rm -f ${OUT_REPORT_DIR}/${R0327_REPORT_FILENAME}

# チェック対象指定
if [ $1 = '1' ]
then
	i=0
	end=11
	fileId=${FILE_ID_IFKEKKA1}
elif [ $1 = '2' ]
then
	i=12
	end=12
	fileId=${FILE_ID_IFKEKKA2}
fi

# ファイル読取、比較開始
logDate=`date +%Y-%m-%d`
error=0
for(( ; ${i} <= ${end} ; i=`expr ${i} + 1` ))
do
	# バッチ取込件数IFファイルから明細件数を取得する
	str1=`cat ${IF_KENSU} | grep ${ITEMS[i]}`
	if [ -z "${str1}" ]
	then
		m_outlog_func MA-E01018 ${ITEMS[i]}
		error=1
		continue
	fi
	kensu=${str1:31:7}
	
	# ワークアイテム件数比較ログファイルからJIRA件数を取得する
	str2=`cat ${CHK_CNT_LG} | grep ${logDate} | grep ${NAMES[i]} | tail -n 1`
	if [ -z "${str2}" ]
	then
		m_outlog_func MA-E01017 ${logDate} ${NAMES[i]}
		error=1
		continue
	fi
	tmpStr=`echo ${str2} | grep JIRA=`
	if [ -n "${tmpStr}" ]
	then
		jiraCnt=${str2#*JIRA=}
		jiraCnt=${jiraCnt%% *}
	else
		jiraCnt=${str2#*IF件数=}
		jiraCnt=${jiraCnt%%]]}
	fi
	
	# 件数比較
	if [ ${kensu} -ne ${jiraCnt} ]
	then
		m_outlog_func MA-E01019 ${ITEMS[i]} ${jiraCnt} ${kensu}
		error=1
	else
		m_outlog_func MA-I01020 ${ITEMS[i]} ${jiraCnt} ${kensu}
	fi
	
	# 物理ファイル名
	ifName="${ITEMS[i]}              "
	ifName=${ifName:0:14}
	
	# 取込処理終了時刻
	importTime=${str2#*取込時刻=}
	importTime=${importTime%% *}
	importTime=${importTime//:/}
	
	# 比較結果ファイルの明細出力
	echo -e "${ifName}${kensu}${importTime}\\r" >>  ${M_IF_DIR}/${IF_KEKKA}
	
	# 容量
	capacity=${str1:14:10}
	capacity=`expr ${capacity} + 0`
	
	# 配信件数
	sentCnt=${str1:24:7}
	sentCnt=`expr ${sentCnt} + 0`
	
	# レポート出力
	if [ "${RPT[i]}" = "1" ]
	then
		echo "${ITEMS[i]},${NAMES[i]},容量,${capacity},配信件数,${sentCnt},明細件数,${jiraCnt}" >>  ${OUT_REPORT_DIR}/${R0327_REPORT_FILENAME}
	fi
	
done

# レポートファイル生成ログ出力
if [ -f ${OUT_REPORT_DIR}/${R0327_REPORT_FILENAME} ]
then
	m_outlog_func MA-I01022 ${OUT_REPORT_DIR}/${R0327_REPORT_FILENAME}
fi

# 比較結果不一致がある場合、異常で終了する
if [ "${error}" = "1" ]
then
	m_outlog_func MA-E01026
	exit 1
fi

m_outlog_func MA-I01021 ${M_IF_DIR}/${IF_KEKKA}

# 比較結果ファイルをHULFTサーバへ転送する
REMOTE_COPY ${M_IF_DIR}/${IF_KEKKA} ${HULFT_CIP}:${HULFT_COUNT_PATH}/${IF_KEKKA}
if [ $? = 0 ]
then
	m_outlog_func MA-I01023 ${M_IF_DIR}/${IF_KEKKA} ${HULFT_CIP}:${HULFT_COUNT_PATH}/${IF_KEKKA}
else
	exit 1
fi

# リモートで送信する
REMOTE_EXEC_SH ${HULFT_CIP} "/usr/local/HULFT/bin/utlsend -f ${fileId}"
if [ $? = 0 ]
then
	m_outlog_func MA-I01024 ${fileId}
else
	exit 1
fi

mv -f ${IF_KENSU} ${IF_KENSU}.OK

# 終了
m_outlog_func MA-I01025
exit 0
