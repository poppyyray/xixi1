#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： M_CHECK_WI_COUNT.sh
# 業 務 名       ： 日次ワークアイテム件数比較処理
# 処理概要       ：
# 特記事項       ： 起動トリガー：JP1
# パラメータ     ： 起動タイプ（1:アンマッチ以外を取得、2:アンマッチのみを取得）
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： H.Someya
#
# 作成日付       ： 2010-03-29
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.1 2010-03-29 H.Someya               新規作成
# 2 1.0.2 2015-03-19 Tang                   HULFTとJP1サーバの切り分け対応
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

###########################################################
# 関数内変数
###########################################################
# ----
# 入出金材料確認用変数
# ----
NAME_CE="入出金材料確認　　　　"
PID_CE=10021
GID_CE="S030101"
LOG_CE="S030101_MAIN_FLOW.log"
EID_CE="CM-I05002"

# ----
# 経費振替用変数
# ----
NAME_CT="経費振替　　　　　　　"
PID_CT=10022
GID_CT="S030102"
LOG_CT="S030102_MAIN_FLOW.log"
EID_CT="CT-I04002"

# ----
# 一般集金（手動消込）用変数
# ----
NAME_GC="一般集金（手動消込）　"
PID_GC=10031
GID_GC="S040202"
LOG_GC="S040202_MAIN_FLOW.log"
EID_GC="GC-I04002"

# ----
# 一般集金（エラー処理）
# ----
NAME_GE="一般集金（エラー処理）"
PID_GE=10032
GID_GE="S040203"
LOG_GE="S040203_MAIN_FLOW.log"
EID_GE="CM-I05256"

# ----
# 振込入金用変数
# ----
NAME_BT="振込入金　　　　　　　"
PID_BT=10033
GID_BT="S040401"
LOG_BT="S040401_MAIN_FLOW.log"
EID_BT="CM-I05257"

# ----
# 入金アンマッチ
# ----
NAME_UD="入金アンマッチ　　　　"
PID_UD=10030
GID_UD="S030104"
LOG_UD="S030104_MAIN_FLOW.log"
EID_UD="UD-I04002"


NAME_O1="承認済み　　　　"
GID_O1="ShoninZumi"
LOG_O1="SHONINZUMI_MAIN_FLOW.log"
EID_O1="SZ-I07002"

NAME_O2="事業所　　　　　"
GID_O2="Jigyosho"
LOG_O2="JIGYOSHO_MAIN_FLOW.log"
EID_O2="JM-I02002"

NAME_O3="前日稼動ＳＤ　　"
GID_O3="ZenjituKadoSD"
LOG_O3="ZENJITUKADOSD_MAIN_FLOW.log"
EID_O3="SD-I02002"

NAME_O4="現金附帯計上　　"
GID_O4="GenkinFutai"
LOG_O4="GENKINFUTAI_MAIN_FLOW.log"
EID_O4="GF-I01006"

NAME_O5="社員マスタ　　　"
GID_O5="USERIN01"
LOG_O5="USER_MAIN_FLOW.log"
EID_O5="UM-I02002"

NAME_O6="所属マスタ　　　"
GID_O6="USERIN02"
LOG_O6="USER_MAIN_FLOW.log"
EID_O6="UM-I02002"

NAME_O7="任命レベルマスタ"
GID_O7="USERIN03"
LOG_O7="USER_MAIN_FLOW.log"
EID_O7="UM-I02002"

# 取込時刻計算用基準値
CREATED_TIME=-6h

# 一時ログ出力ファイル設定
TMP_LOG=/workflow/batch/maint/m_logs/M_CHECK_WI_COUNT.log

# ログが存在しない場合作成し権限を変更
if [ ! -f ${TMP_LOG} ]; then
	touch ${TMP_LOG}
	chmod 777 ${TMP_LOG}
fi

# LOGIN Cookiesファイル名
LOGIN_COOKIES=login_cookies.txt

# OUTPUT一時データファイル名
TMP_OUTPUT_DATA=tmp_issue_data.txt

# UI件数取得一時文字列
TMP_STRING=""

# ログ出力メッセージ格納用変数
log_msg=""

# ログ出力日用変数
date=`date +%Y-%m-%d`

# 取込ログファイル対象日用変数
filedate=`date +%Y%m%d`

# 起動タイプ
OPE_TYPE_1=1	# アンマッチ以外取得
OPE_TYPE_2=2	# アンマッチのみ取得

###########################################################
# 共通環境変数設定
###########################################################
# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf

if [ ! -f ${_exec_ksh} ]; then
	echo `date +%Y%m%d%H%M%S` "ERROR" `basename ${0}` "MA-E00000" "共通ファイルが存在しませんでした[${_exec_sh}]" >> ${TMP_LOG}
	exit 1
fi
. ${_exec_ksh}

# ----
# 保守用共通環境変数設定
# ----
_exec_m_sh=/workflow/batch/maint/m_ini/m_batch_common.conf

if [ ! -f ${_exec_m_sh} ]; then
	echo `date +%Y%m%d%H%M%S` "ERROR" `basename ${0}` "MA-E00001" "共通ファイルが存在しませんでした[${_exec_m_sh}]" >> ${TMP_LOG}
	exit 1
fi
. ${_exec_m_sh}

# ----
# 保守用共通関数ファイルの存在チェック
# ----
if [ ! -f ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh ]; then
	echo `date +%Y%m%d%H%M%S` "ERROR" `basename ${0}` "MA-E00003" "共通ファイルが存在しませんでした[${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh]" >> ${TMP_LOG}
	exit 1
fi
. ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh

cd ${M_TMP_DIR}

###############################################################################
# 機能：　詳細ログ出力
# 処理概要：
# 　詳細ログを出力する
#
# 引数1：　実行コマンド
# 引数2：　コマンド結果
#
# 戻り値：　0:正常
#
# 前提条件：パラメータが必ず2つあること
#           環境設定ファイル読み込み済みであること
#
###############################################################################
function fnc_outdetaillog
{
	echo -e "日付:`date` || shell名:`basename ${0}` \n コマンド:${1}\n コマンド結果:\n${2}" >> ${M_DETAIL_LOG}

	return ${RC_NOR}
}

###############################################################################
# 機能：　JIRADBおよびIFファイルのワークアイテムカウント関数
# 処理概要：
# 　JIRADBおよびIFファイルのワークアイテム数を取得
#
# 引数1：　業務名
# 引数2：　JIRA通番
# 引数3：　ログ名
# 引数4：　各業務終了メッセージID
# 引数5：　IFファイル名
# 引数6：　業務ID
# 引数7：　起動タイプ
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：環境設定ファイル読み込み済みであること
#
###############################################################################
function fnc_count_wi
{
	# アンマッチ以外表示起動時に、アンマッチ業務の場合、関数終了
	if [ ${7} -eq ${OPE_TYPE_1} -a "${1}" = "${NAME_UD}" ]; then
		return ${RC_NOR}
	fi

	# アンマッチのみ表示起動時に、アンマッチ業務以外の場合、関数終了
	if [ ${7} -eq ${OPE_TYPE_2} -a "${1}" != "${NAME_UD}" ]; then
		return ${RC_NOR}
	fi

	_sqlcmd="select count(*) from jiraschema.jiraissue where pkey like '${2}' with ur"
	db2 ${_sqlcmd} > ${M_TMP_DIR}/IF_CHECK/tmp.txt
	_ret=$?

	fnc_outdetaillog "db2 ${_sqlcmd}" "`cat ${M_TMP_DIR}/IF_CHECK/tmp.txt`"

	if [ $_ret != ${RC_NOR} ] ;then
		m_outlog_func MA-E01005 ${1}
		return ${RC_ERR}
	fi

	head -4  ${M_TMP_DIR}/IF_CHECK/tmp.txt | tail -1 > ${M_TMP_DIR}/IF_CHECK/tmp2.txt

	cnt_db_wi=`cat ${M_TMP_DIR}/IF_CHECK/tmp2.txt`
	cnt_db_wi=`printf ${cnt_db_wi} | sed -e "s/\r//" | sed -e "s/\n//"`
	cnt_db_wi=`expr ${cnt_db_wi} + 0`

	# OUTPUT一時データファイル初期化
	cat /dev/null > ${M_TMP_DIR}/${TMP_OUTPUT_DATA}

	wget -q --load-cookies ${LOGIN_COOKIES} --post-data "refreshFilter=false&reset=update&show=View+%3E%3E&pid=${6}&query=&summary=true&description=true&reporterSelect=&assigneeSelect=&created%3Aafter=&created%3Abefore=&created%3Aprevious=${CREATED_TIME}&created%3Anext=&updated%3Aafter=&updated%3Abefore=&updated%3Aprevious=&updated%3Anext=" ${JIRA_IP}/secure/IssueNavigator.jspa -O ${TMP_OUTPUT_DATA}
	_ret=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${TMP_OUTPUT_DATA}`" >>${M_DETAIL_LOG}

	if [ $_ret != ${RC_NOR} ] ;then
		m_outlog_func MA-E01005 ${1}
		return ${RC_ERR}
	fi

	TMP_STRING=`grep matching ${TMP_OUTPUT_DATA} |grep -v No`
	_ret=$?

	if [ $_ret = ${RC_NOR} ] ;then
		cnt_ui_wi=`echo ${TMP_STRING} |awk '{ print $7}' |sed -e "s/<b>//g" |sed -e "s/<\/b>//g"`
	else
		cnt_ui_wi=0
	fi
	cnt_ui_wi=`expr ${cnt_ui_wi} + 0`

	# ログファイルの存在チェック
	if [ ! -f /workflow/batch/logs/${3} ]; then
		m_outlog_func MA-E01007 "/workflow/batch/logs/${3}"
		return ${RC_ERR}
	fi

	# 取込時刻取得
	get_date=`cat /workflow/batch/logs/${3} |grep ${date}|grep ${4}|cut -f2 -d' '`

	# IFファイルの存在チェック
	tmp_filename=`ls /workflow/batch/pp_bak/${5}.${filedate}* 2>&1`
	_ret=$?

	if [ $_ret != ${RC_NOR} ]; then
		m_outlog_func MA-E01008 "${tmp_filename}"
		return ${RC_ERR}
	fi

	cnt_if_wi=`head -2 ${tmp_filename} 2> /dev/null|tail -1 | sed -e "s/\r//" | sed -e "s/\n//" | sed -e "s/ //"`
	cnt_if_wi=`expr ${cnt_if_wi} + 0`

	#----------------------------
	# ReportDBから件数取得 START
	#----------------------------
	# 日付取得
	creat_date=`date +%Y%m%d`
	#--------------------
	# 入金アンマッチ以外
	#--------------------
	if [ "${1}" != "${NAME_UD}" ]
	then
		#ZIPファイル解凍
		unzip -oq -P ${ZIP_FILE_PASSWORD} -d ${OUT_REPORT_TMPDIR} ${ASCA_DIR}/BD0701_${creat_date}_ASCA.zip
		if [ $? != 0 ]
		then
			# エラーログ出力
			m_outlog_func MA-E01010 "BD0701_${creat_date}_ASCA.zip"
			
			# エラー終了
			exit 1
		fi
		#CSVファイル存在確認
		if [ ! -f ${OUT_REPORT_TMPDIR}/BD0701_${creat_date}_ASCA.csv ]
		then
			m_outlog_func MA-E01011 "BD0701_${creat_date}_ASCA.csv"
			
			# エラー終了
			exit 1	
		fi
		#件数取得
		str=${2}
		cnt_re_wi=`cat ${OUT_REPORT_TMPDIR}/BD0701_${creat_date}_ASCA.csv | grep ${str%\%} | awk -F\, '{print $4}'`
	fi
	#----------------
	# 入金アンマッチ
	#----------------
	if [ "${1}" = "${NAME_UD}" ]
	then
		#ZIPファイル解凍
		unzip -oq -P ${ZIP_FILE_PASSWORD} -d ${OUT_REPORT_TMPDIR} ${ASCA_DIR}/BD0702_${creat_date}_ASCA.zip
		if [ $? != 0 ]
		then
			# エラーログ出力
			m_outlog_func MA-E01012 "BD0702_${creat_date}_ASCA.zip"
			
			# エラー終了
			exit 1
		fi
		#CSVファイル存在確認
		if [ ! -f ${OUT_REPORT_TMPDIR}/BD0702_${creat_date}_ASCA.csv ]
		then
			m_outlog_func MA-E01013 "BD0702_${creat_date}_ASCA.csv"
			
			# エラー終了
			exit 1	
		fi
		#件数取得
		str=${2}
		cnt_re_wi=`cat ${OUT_REPORT_TMPDIR}/BD0702_${creat_date}_ASCA.csv | grep ${str%\%} | awk -F\, '{print $4}'`
	fi
	cnt_re_wi=`expr ${cnt_re_wi} + 0`
	#--------------------------
	# ReportDBから件数取得 END
	#--------------------------

	log_msg=`printf "[%-30s] %-s %-s %s" "${1}" "|" "取込時刻=${get_date}" "| IF件数=${cnt_if_wi} | JIRA=${cnt_db_wi} | JIRAUI=${cnt_ui_wi} | REPORT=${cnt_re_wi}"`

#	if [ "${1}" = "${NAME_UD}" ]; then
#		# 入金アンマッチの場合、件数一致チェックなし
#		m_outlog_func MA-I01006 "${log_msg}"
#	else
		# 入金アンマッチ以外の業務の場合
		# 件数一致チェック
		if [ ${cnt_db_wi} = ${cnt_if_wi} -a ${cnt_if_wi} = ${cnt_ui_wi} -a ${cnt_ui_wi} = ${cnt_re_wi} ]; then
			m_outlog_func MA-I01003 "${log_msg}"
		else
			m_outlog_func MA-E01004 "${log_msg}"
		fi
#	fi

	# OUTPUT一時データファイル初期化
	cat /dev/null > ${M_TMP_DIR}/${TMP_OUTPUT_DATA}

	return ${RC_NOR}
}

###############################################################################
# 機能：　その他のアイテムカウント関数
# 処理概要：
# 　その他のアイテム数を取得
#
# 引数1：　件数対象項目名
# 引数2：　ログ名
# 引数3：　各業務終了メッセージID
# 引数4：　IFファイル名
#
# 戻り値：　0:正常
#           1:異常
#
# 前提条件：環境設定ファイル読み込み済みであること
#
###############################################################################
function fnc_count_other
{
	# 現金附帯計上
	if [ "${4}" == "${GID_O4}" ]; then
		
		# ログファイルの存在チェック
		lgfile=`ssh ${HULFT_CIP} ls ${LOG_DIR}/${2}`
		if [ "${lgfile}" != "${LOG_DIR}/${2}" ]; then
			m_outlog_func MA-E01009 "${HULFT_CIP}:${LOG_DIR}/${2}"
			return ${RC_ERR}
		fi
		get_date=`ssh ${HULFT_CIP} cat ${LOG_DIR}/${2} |grep ${date}|grep ${3}|cut -f2 -d' '`

	# その他
	else
		
		# ログファイルの存在チェック
		if [ ! -f ${LOG_DIR}/${2} ]; then
			m_outlog_func MA-E01009 "${LOG_DIR}/${2}"
			return ${RC_ERR}
		fi
		get_date=`cat /workflow/batch/logs/${2} |grep ${date}|grep ${3}|cut -f2 -d' '`
	fi
	
	# IFファイルの存在チェック
	tmp_filename=`ls /workflow/batch/pp_bak/${4}.${filedate}* 2>&1`
	_ret=$?

	if [ $_ret != ${RC_NOR} ]; then
		m_outlog_func MA-E01008 "${tmp_filename}"
		return ${RC_ERR}
	fi

	kensuu=`head -2 ${tmp_filename} 2> /dev/null|tail -1 | sed -e "s/\r//" | sed -e "s/\n//" | sed -e "s/ //"`
	kensuu=`expr ${kensuu} + 0`

	log_msg=`printf "[%-16s] %-s" "${1}" "| 取込時刻=${get_date} | IF件数=${kensuu}"`

	m_outlog_func MA-I01006 "${log_msg}"

	return ${RC_NOR}
}

###############################################################################
# main処理
#
# 引数1：　起動タイプ（1:アンマッチ以外を取得、2:アンマッチのみを取得）
#
# 戻り値：　0:正常
#           1:異常
###############################################################################
# 出力ログ名設定
export log_name=${M_CHECK_WI_COUNT_LOG}

# ログファイル名拡張子付き
log_file="${M_LOG_DIR}/${log_name}.log"

# 処理開始ログ出力
m_outlog_func MA-I01001

# JIRADBに接続
m_func_connectDB ${JIRA_DB_NAME}
_ret=$?
if [ $_ret != ${RC_NOR} ]; then
	exit ${RC_ERR}
fi

# JIRAサーバにログイン
m_func_login_jiraui
_ret=$?
if [ $_ret != ${RC_NOR} ]; then
	exit ${RC_ERR}
fi

###########################################################
# ワークアイテムカウント
###########################################################
ARRAY_WI_NAME=(${NAME_CE} ${NAME_CT} ${NAME_GC} ${NAME_GE} ${NAME_BT} ${NAME_UD})
ARRAY_JIRANO=("CE-${filedate}%" "CT-${filedate}%" "GC-${filedate}%" "GE-${filedate}%" "BT-${filedate}%" "UD-${filedate}%")
ARRAY_WI_LOG=(${LOG_CE} ${LOG_CT} ${LOG_GC} ${LOG_GE} ${LOG_BT} ${LOG_UD})
ARRAY_WI_EID=(${EID_CE} ${EID_CT} ${EID_GC} ${EID_GE} ${EID_BT} ${EID_UD})
ARRAY_WI_GID=(${GID_CE} ${GID_CT} ${GID_GC} ${GID_GE} ${GID_BT} ${GID_UD})
ARRAY_WI_PID=(${PID_CE} ${PID_CT} ${PID_GC} ${PID_GE} ${PID_BT} ${PID_UD})

wi_count=0
while [ ${wi_count} -lt "${#ARRAY_WI_NAME[*]}" ]
do
	fnc_count_wi ${ARRAY_WI_NAME[wi_count]} ${ARRAY_JIRANO[wi_count]} ${ARRAY_WI_LOG[wi_count]} ${ARRAY_WI_EID[wi_count]} ${ARRAY_WI_GID[wi_count]} ${ARRAY_WI_PID[wi_count]} ${1}
	_ret=$?
	if [ $_ret != ${RC_NOR} ]; then
		exit ${RC_ERR}
	fi
	wi_count=`expr ${wi_count} + 1`
done

###########################################################
# その他アイテムカウント
###########################################################
if [ ${1} -eq ${OPE_TYPE_1} ]; then
	ARRAY_OT_NAME=(${NAME_O1} ${NAME_O2} ${NAME_O3} ${NAME_O4} ${NAME_O5} ${NAME_O6} ${NAME_O7})
	ARRAY_OT_LOG=(${LOG_O1} ${LOG_O2} ${LOG_O3} ${LOG_O4} ${LOG_O5} ${LOG_O6} ${LOG_O7})
	ARRAY_OT_EID=(${EID_O1} ${EID_O2} ${EID_O3} ${EID_O4} ${EID_O5} ${EID_O6} ${EID_O7})
	ARRAY_OT_GID=(${GID_O1} ${GID_O2} ${GID_O3} ${GID_O4} ${GID_O5} ${GID_O6} ${GID_O7})

	ot_count=0
	while [ ${ot_count} -lt "${#ARRAY_OT_NAME[*]}" ]
	do
		fnc_count_other ${ARRAY_OT_NAME[ot_count]} ${ARRAY_OT_LOG[ot_count]} ${ARRAY_OT_EID[ot_count]} ${ARRAY_OT_GID[ot_count]}
		_ret=$?
		if [ $_ret != ${RC_NOR} ]; then
			exit ${RC_ERR}
		fi
		ot_count=`expr ${ot_count} + 1`
	done
fi

# 後処理(login.jsp削除)
if [ -f ${M_TMP_DIR}/login.jsp ]; then
	rm -f ${M_TMP_DIR}/login.jsp
fi

cat /dev/null > ${M_TMP_DIR}/${LOGIN_COOKIES}

# DB切断
db2 +o connect reset > ${M_TMP_DIR}/IF_CHECK/tmp.txt
SQLERROR=$?
fnc_outdetaillog "db2 +o connect reset" "`cat ${M_TMP_DIR}/IF_CHECK/tmp.txt`"
# コマンド判定
if [ ${SQLERROR} != ${RC_NOR} ]; then
	# エラーログ出力
	m_outlog_func MC-E00003
	exit ${RC_ERR}
fi

# 処理終了ログ出力
m_outlog_func MA-I01002

# 処理終了
exit ${RC_NOR}
