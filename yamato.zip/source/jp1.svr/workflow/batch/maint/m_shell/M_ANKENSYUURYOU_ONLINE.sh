#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ANKENSYUURYOU_WORK.sh
# 業 務 名       ： 案件終了処理
# 処理概要       ： 案件通番を別ファイルから読み込むようにする。
#　　　　　　　　： 処理日付にPGM実行日時を更新、通信欄に文言を追加
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Yang Xi
#
# 作成日付       ： 2010-10-22
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2010-10-22 Yang Xi                新規作成
# 2更新   2011-08-03 Tang Xiao Dong         入金振替伝票番号と承認日時を追加
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません"
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# 保守用共通環境変数設定
# ----
_exec_m_sh=/workflow/batch/maint/m_ini/m_batch_common.conf

if [ ! -f ${_exec_m_sh} ]; then
	echo "保守用環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_m_sh}

# ----
# 保守用共通関数ファイルの存在チェック
# ----
if [ ! -f ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh ]; then
	echo "保守用共通関数ファイルが存在しません"
	exit 1
fi
. ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh


###############################################################################
# main処理開始
###############################################################################
# 開始メッセージ
m_outlog_func MA-I00201

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    m_outlog_func MA-E00210 "${_errmsg}"

    # エラー終了
    exit 1
fi

#カウンタ初期化
skipcount=0
succount=0

#案件終了対象ＣＳＶファイルの存在チェック
if [ ! -s ${M_CSV_DIR}/ankensyuuryou_taishou.csv ]
then
	# エラーログ出力
	m_outlog_func MA-E00203 "${M_CSV_DIR}/ankensyuuryou_taishou.csv"
	
	# エラー終了
	exit 1
fi

while read line
do	
	pkey=`echo ${line} | awk -F, '{print $1}'`
	newstatus=`echo ${line} | awk -F, '{print $2}'`
	slipnumber=`echo ${line} | awk -F, '{print $3}'`
	approvedate=`echo ${line} | awk -F, '{print $4}'`
	ud_slipnumber=`echo ${line} | awk -F, '{print $5}'`
	ud_approvedate=`echo ${line} | awk -F, '{print $6}'`
	
	#遷移ステータスチェック
	if [ "${newstatus}" != "D01E01" ] 
	then
			skipcount=`expr ${skipcount} + 1`
			m_outlog_func MA-W00204 "${pkey}"
			continue
	fi
	
	#承認日のチェック
	if [ -z "${approvedate}" -a -z "${ud_approvedate}" ]
	then
			skipcount=`expr ${skipcount} + 1`
			m_outlog_func MA-W00213 "${pkey}"
			continue
	fi
	
	#案件存在のチェック
	_tmp=`db2 -x "select 1 from JIRASCHEMA.JIRAISSUE where pkey='${pkey}'"`
	if [ -z ${_tmp} ]
	then
			skipcount=`expr ${skipcount} + 1`
			m_outlog_func MA-W00211 "${pkey}"
			continue
	fi
	
	#案件の現在状態D01のチェック
	_tmp=`db2 -x "select 1 from JIRASCHEMA.JIRAISSUE where pkey='${pkey}' and ISSUESTATUS='10037'"`
	if [ -z ${_tmp} ]
	then
			skipcount=`expr ${skipcount} + 1`
			m_outlog_func MA-W00212 "${pkey}"
			continue
	fi
			
	serviceid=`echo ${pkey} | cut -b1-2`
	#経費振替業務
	if [ "${serviceid}" = "CT" ]
	then
			serviceid="S030102"
	#入金データアンマッチ
	elif [ "${serviceid}" = "UD" ]
	then
			serviceid="S030104"
	#一般集金（手動消込）
	elif [ "${serviceid}" = "GC" ]
	then
			serviceid="S040202"
	#一般集金（エラー処理）
	elif [ "${serviceid}" = "GE" ]
	then
			serviceid="S040203"
	#振込入金（自動消込）
	elif [ "${serviceid}" = "BT" ]
	then
			serviceid="S040401"
	else
			serviceid=""	
	fi
	
	#通信欄に伝票承認日時の文言を追加する
	correspondencehistory=""
	if [ ! -z "${approvedate}" ]
	then
		if [ ! -z "${slipnumber}" ] 
		then
			correspondencehistory="伝票承認日時（振替伝票番号${slipnumber}）：${approvedate}"
		else
			correspondencehistory="伝票承認日時：${approvedate}"
		fi
	fi
	if [ ! -z "${ud_approvedate}" ]
	then
		if [ ! -z "${correspondencehistory}" ]
		then
			enter=$'\n'
			correspondencehistory="${correspondencehistory}${enter}"
		fi
		if [ ! -z "${ud_slipnumber}" ] 
		then
			correspondencehistory="${correspondencehistory}伝票承認日時（入金振替伝票番号${ud_slipnumber}）：${ud_approvedate}"
		else
			correspondencehistory="${correspondencehistory}伝票承認日時：${ud_approvedate}"
		fi
	fi

	# JIRA ワークアイテム終了
	java -classpath "${JAVA_CLASSPATH}" com.ibm.jirax.batch.CloseWorkitemBatch "${serviceid}" "${pkey}" "${newstatus}" "${correspondencehistory}" > ${DETAIL_LOG_TMP} 2>&1
	RC=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${M_DETAIL_LOG}
	case ${RC} in
				0)			m_outlog_func MA-I00205 ${pkey}
								succount=`expr ${succount} + 1`
								continue;;	    
        10)     m_outlog_func MA-W00206 ${pkey}
								skipcount=`expr ${skipcount} + 1`
								continue;;
        20)     m_outlog_func MA-W00214 ${pkey}
								skipcount=`expr ${skipcount} + 1`
								continue;;
        *)      m_outlog_func MA-E00207 ${pkey}
                exit 1;;
	esac
done < ${M_CSV_DIR}/ankensyuuryou_taishou.csv

m_outlog_func MA-I00208 "${skipcount}"
m_outlog_func MA-I00209 "${succount}"

# JIRADB切断
db2 terminate > /dev/null

m_outlog_func MA-I00202

exit 0
