#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： M_CHECK_ASCA_COUNT.sh
# 業 務 名       ： 業務別件数一覧(月次)CSVデータ受付件数チェック
# 処理概要       ： １か月分の業務別件数一覧(日次)マージし、
#                    マージ後業務別件数一覧(日次)CSVデータ受付件数
#                    と業務別件数一覧(月次)CSVデータ受付件数が一致
#                    すると判断する
# 特記事項       ： 未定
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： YangXi 
#
# 作成日付       ： 2010-07-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-07-08 YangXi              新規作成
# 2 
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません"
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# 保守用共通環境変数設定
# ----
_exec_m_sh=/workflow/batch/maint/m_ini/m_batch_common.conf

if [ ! -f ${_exec_m_sh} ]; then
	echo "保守用環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_m_sh}

# ----
# 保守用共通関数ファイルの存在チェック
# ----
if [ ! -f ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh ]; then
	echo "保守用共通関数ファイルが存在しません"
	exit 1
fi
. ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh

# ----
# 変数定義領域
# ----
#レポーティングZIPファイルの格納先
REPORT_ZIP_DIR=${ASCA_DIR}
#レポーティングZIPファイルの解凍先
REPORT_UNZIP_DIR=${OUT_REPORT_TMPDIR}

# ----
# 関数「日時ファイルを読み込み処理」
# ----
function read_daily_file
{
	read occur_date_d service_id_d service_name_d count_d  <&4
	rc=$?
	if [ $rc != 0 ]
	then
		return 1
	fi
	return 0
}

# ----
#関数「月次ファイルを読み込み処理」
# ----
function read_monthly_file
{
	read occur_date_m service_id_m service_name_m count_m <&5
	rc=$?
	if [ $rc != 0 ]
	then
		return 1
	fi	
	return 0
}

# ----
# 関数「レポート受付件数チェック処理」
# ----
function report_csv_count_check
{
	#業務別件数一覧(日次)ファイルを読み込み
	read_daily_file
	read_daily_file_rc=$?

	#業務別件数一覧(月次)ファイルを読み込み	
	read_monthly_file
	read_monthly_file_rc=$? 
	
	key_d=${occur_date_d}${service_id_d}
	key_m=${occur_date_m}${service_id_m}
	
	while [ ${read_daily_file_rc} = 0 -a ${read_monthly_file_rc} = 0 ]
	do
		#マッチングした場合、件数チェック
		if [ "${key_d}" = "${key_m}" ]
		then
			if [ "${count_d}" != "${count_m}" ]
			then
				m_outlog_func MR-E00113 "${occur_date_d}" "${service_id_d}" "${count_d}" "${count_m}"
			else
				m_outlog_func MR-I00114 "${occur_date_d}" "${service_id_d}" "${count_d}" "${count_m}"
			fi
			read_daily_file
			read_daily_file_rc=$?
			read_monthly_file
			read_monthly_file_rc=$?
			key_d=${occur_date_d}${service_id_d}
			key_m=${occur_date_m}${service_id_m}
			continue
		fi
		
		#日次に存在しない、月次に存在の場合
		if [ "${key_d}" \< "${key_m}" ]
		then
			m_outlog_func MR-E00117 "${occur_date_d}" "${service_id_d}"
			read_daily_file
			read_daily_file_rc=$?
			key_d=${occur_date_d}${service_id_d}
			continue
		fi
		
		#日次に存在、月次に存在しないの場合
		if [ "${key_d}" \> "${key_m}" ]
		then
			m_outlog_func MR-E00116 "${occur_date_m}" "${service_id_m}"
			read_monthly_file
			read_monthly_file_rc=$?
			key_m=${occur_date_m}${service_id_m}
			continue
		fi
	done
	
	#マッチング後処理
	if [ ${read_monthly_file_rc} != 0 ]
	then
		while [ ${read_daily_file_rc} = 0 ]
		do
			m_outlog_func MR-E00117 "${occur_date_d}" "${service_id_d}"
			read_daily_file
			read_daily_file_rc=$?
		done
	fi
	
	if [ ${read_daily_file_rc} != 0 ]
	then
		while [ ${read_monthly_file_rc} = 0 ]
		do
			m_outlog_func MR-E00116 "${occur_date_m}" "${service_id_m}"
			read_monthly_file
			read_monthly_file_rc=$?
		done
	fi	
	return 0
}

# ----
# 関数「業務別件数一覧ZIPファイル解凍」
# ----
function report_csv_uncompress
{
	# 業務別件数一覧_入金アンマッチ以外(日次)ZIPファイル名取得
	file_list=`ls ${REPORT_ZIP_DIR}/${R0701_01_REPORT_FILENAME}.zip`
	if [ -z "${file_list}" ]
	then
		m_outlog_func MR-E00108
		return 1
	fi
	
	# 業務別件数一覧_入金アンマッチ以外(日次)ZIPファイル解凍
	for i in ${file_list}
	do
		unzip -P ${ZIP_FILE_PASSWORD} -qo ${i} -d ${REPORT_UNZIP_DIR} >${DETAIL_LOG_TMP}  2>&1
		rc=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${M_DETAIL_LOG}
		if [ $rc != '0' ]
		then
			m_outlog_func MR-E00109 "${i}"
			return 1
		fi
	done
	
	# 業務別件数一覧_入金アンマッチ(日次)ZIPファイル名取得
	file_list=`ls ${REPORT_ZIP_DIR}/${R0701_02_REPORT_FILENAME}.zip`
	if [ -z "${file_list}" ]
	then
		m_outlog_func MR-E00106
		return 1
	fi
	
	# 業務別件数一覧_入金アンマッチ(日次)ZIPファイル解凍
	for i in ${file_list}
	do
		unzip -P ${ZIP_FILE_PASSWORD} -qo ${i} -d ${REPORT_UNZIP_DIR} >${DETAIL_LOG_TMP}  2>&1
		rc=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${M_DETAIL_LOG}
		if [ $rc != '0' ]
		then
			m_outlog_func MR-E00107 "${i}"
		return 1
		fi
	done
	

	# 業務別件数一覧(月次)ZIPファイル名取得
	file_list=`ls ${REPORT_ZIP_DIR}/${R0701_03_REPORT_FILENAME}.zip`
	if [ -z "${file_list}" ]
	then
		m_outlog_func MR-E00110
		return 1
	fi

	# 業務別件数一覧(月次)ZIPファイル解凍
	unzip -P ${ZIP_FILE_PASSWORD} -qo ${REPORT_ZIP_DIR}/${R0701_03_REPORT_FILENAME}.zip -d ${REPORT_UNZIP_DIR}  >${DETAIL_LOG_TMP}  2>&1
	rc=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${M_DETAIL_LOG}
	if [ $rc != '0' ]
	then
		m_outlog_func MR-E00111 "${REPORT_ZIP_DIR}/${R0304_10_REPORT_FILENAME}.zip"
		return 1
	fi

	return 0
}


###############################################################################
# main処理開始
###############################################################################
# 開始メッセージ
m_outlog_func MR-I00101

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${M_DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    m_outlog_func MR-E00103 "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# エラー終了
	exit 1
fi

_run_date=`date +%Y%m%d`

# JIRADB切断
db2 terminate > /dev/null

_run_date_yyyymm=`echo ${_run_date} | cut -c1-6`
R0701_01_REPORT_FILENAME=`echo ${R0701_01_REPORT_FILENAME%.*} | sed -e s/rundate/${_run_date_yyyymm}"*"/`
R0701_02_REPORT_FILENAME=`echo ${R0701_02_REPORT_FILENAME%.*} | sed -e s/rundate/${_run_date_yyyymm}"*"/`
R0701_03_REPORT_FILENAME=`echo ${R0701_03_REPORT_FILENAME%.*} | sed -e s/rundate/${_run_date}/`

# 業務別件数一覧ZIPファイル解凍
report_csv_uncompress
if [ $? != 0 ]
then
	m_outlog_func MR-E00105
	exit 1
fi

# ファイル読み込み時、セパレートを設定
IFS_org=${IFS}
IFS=,

# 業務別件数一覧(日次)CSVファイルソート処理
sort -t"${IFS}" -k1,2 ${REPORT_UNZIP_DIR}/${R0701_01_REPORT_FILENAME}.csv ${REPORT_UNZIP_DIR}/${R0701_02_REPORT_FILENAME}.csv > ${REPORT_UNZIP_DIR}/BD0701_BD0702_ASCA_SORT.csv 2>${DETAIL_LOG_TMP}
rc=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${M_DETAIL_LOG}
if [ $rc != 0 ]
then
	m_outlog_func MR-E00112
	exit 1
fi

# 業務別件数一覧(月次)CSVファイルソート処理
sort -t"${IFS}" -k1,2 ${REPORT_UNZIP_DIR}/${R0701_03_REPORT_FILENAME}.csv | grep -v "TOTAL" > ${REPORT_UNZIP_DIR}/BD0703_ASCA_SORT.csv 2>${DETAIL_LOG_TMP}
rc=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 1` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${M_DETAIL_LOG}
if [ $rc != 0 ]
then
	m_outlog_func MR-E00115
	exit 1
fi


# 業務別件数一覧(日次)CSVファイルをオープンする
exec 4<${REPORT_UNZIP_DIR}/BD0701_BD0702_ASCA_SORT.csv

# 業務別件数一覧(月次)CSVファイルをオープンする
exec 5<${REPORT_UNZIP_DIR}/BD0703_ASCA_SORT.csv

# 業務別件数一覧CSVデータの受付件数チェック処理
report_csv_count_check

# 業務別件数一覧(日次)CSVファイルをクローズする
exec 4<&-

# 業務別件数一覧(月次)CSVファイルをクローズする
exec 5<&-

# ファイル読み込み終了時、セパレートを戻り
IFS=${IFS_org}

# 終了メッセージ
m_outlog_func MR-I00102

exit 0