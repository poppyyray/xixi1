#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： M_ACCESS_BUTTING_CHK.sh
# 業 務 名       ： 排他制御暫定対応処理
# 処理概要       ： APIログから、同時アクセスエラー(同時更新など)が
#                   発生している可能性があるワークアイテムを検出し、
#                   検出結果ログとして出力する。
#                   APIログの検索範囲は、現在時刻から引数指定時刻前
#                   までの間を検索する。
#                   ※指定がなければ検索範囲は全てとする。
#
# 特記事項       ： 実行環境はGWサーバ
# 引数           ： 整数(指定がなければAPIログ検索範囲全て)
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
# INPUT          ： 更新JIRA(通常1号機、切替時2号機)のAPIログ
#                   /opt/atlassian/jira/logs/workitem.log
# OUTPUT         ： GWにBATCHログファイル出力
#                   /workflow/batch/maint/m_log/M_ACCESS_BUTTING_CHK.log
#                   GWに検出結果ログファイル出力
#                   /workflow/batch/maint/m_logs/DETECTED_ACCESS_BUTTING_yyyymmddHHMMSS.log
#
################### モジュール説明 ########################

################### 改定履歴       ########################
# 作成者         ： S.Tsuruha
#
# 作成日付       ： 2010-02-09
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-02-09 S.Tsuruha                新規作成
# 2                  LiuJian                  IP集約管理
# 3       2014-09-02 LiuJian                  509.[開発] 本番JIRAパラメータ書
# 4       2014-09-02 LiuJian                  510.[開発] SSH関連調査
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

###########################################################
# 外部参照ファイル存在チェック
###########################################################
# ----
# 共通環境変数設定
# ----
_exec_sh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_sh} ]
then
        echo `date "+%Y-%m-%d %H:%M:%S"` "ERROR" `basename ${0}` "MA-E00000" "共通ファイルが存在しませんでした[${_exec_sh}]" >>/workflow/batch/maint/m_logs/M_ACCESS_BUTTING_CHK.log
        exit 1
fi
. ${_exec_sh}

# ----
# 保守用共通環境変数設定
# ----
_exec_m_sh=/workflow/batch/maint/m_ini/m_batch_common.conf
if [ ! -f ${_exec_m_sh} ]
then
        echo `date "+%Y-%m-%d %H:%M:%S"` "ERROR" `basename ${0}` "MA-E00001" "共通ファイルが存在しませんでした[${_exec_m_sh}]" >>/workflow/batch/maint/m_logs/M_ACCESS_BUTTING_CHK.log
        exit 1
fi
. ${_exec_m_sh}

# ----
# 保守用メッセージファイル存在確認
# ----
m_message_file=/workflow/batch/maint/m_ini/m_message.conf
if [ ! -f ${m_message_file} ]
then
        echo `date "+%Y-%m-%d %H:%M:%S"` "ERROR" `basename ${0}` "MA-E00002" "共通ファイルが存在しませんでした[${m_message_file}]" >>/workflow/batch/maint/m_logs/M_ACCESS_BUTTING_CHK.log
        exit 1
fi

###########################################################
# 外部参照プログラム存在チェック
###########################################################
# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
        echo `date "+%Y-%m-%d %H:%M:%S"` "ERROR" `basename ${0}` "MA-E00004" "共通ファイルが存在しませんでした[${m_message_file}]" >>/workflow/batch/maint/m_logs/M_ACCESS_BUTTING_CHK.log
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

###########################################################
# 外部参照プログラム存在チェック
###########################################################
# ----
# 共通関数呼び出し
# ----
if [ ! -f ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh ]
then
        echo `date "+%Y-%m-%d %H:%M:%S"` "ERROR" `basename ${0}` "MA-E00003" "共通関数ファイルが存在しません[${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh}]" >>/workflow/batch/maint/m_logs/M_ACCESS_BUTTING_CHK.log
        exit 1
fi
. ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh

###########################################################
# 出力ログ名の設定
###########################################################
# 出力ログ名設定
export log_name=${M_ACCESS_BUTTING_CHK_LOG}

###########################################################
# 変数定義
###########################################################
# JIRAU1号機の更新日時
JIRAU1_DATE=""
# JIRAU2号機の更新日時
JIRAU2_DATE=""
# 取得するJIRAサーバのIP
M_GET_JIRA_IP=${JIRAU1_IP}
# APIが出力するワークアイテムへのアクセスログ
API_AC_BUT_LOG=/opt/atlassian/jira/logs/workitem.log
# sshエラーハンドリング結果
SSH_RESULT=""
# ログ検索範囲の指定時刻
DETECTED_TIME=""
# ループカウント確認
COUNT=0
# 最大リトライ回数
RETRY=30
# APIログの検索開始行番号
LINE_NO=""
# APIログの検索開始行からの全ログ
API_SELECT_TIME_LOG=${M_TMP_DIR}/workitem_get.log
# ログ検索範囲の指定時刻(DETECTED_TIMEのYYYYMMDDhhmmss版)
SELECT_TIME=""
# APIログに記載の最古の時刻
LOG_MAX_TIME=""
# ログ検索範囲の指定時刻とAPIログに記載の最古の時刻の比較(正の値ならば、APIログの時刻のほうが新しい)
TIME_COMPARE=""
# ループ条件判定用フラグ(0:ループに入る、１:ループに入らない)
LOOP_IN_FLAG=0
# 現在時刻
NOW_TIME=""
# 指定時間分抽出ファイルのサイズ
GET_SIZE=""
# APIのログ1行分
API_LOG_RECORD=""
# 更新中か更新完了か確認用(更新中：START、更新完了：END)
START_END_CHK=""
# 検出判定用
DETECTED_DECISION_TMP=""
# 検出行数カウント
DETECTED_WC=""
# 検出ログのヘッダー1
DETECTEC_LOG_HEADER1="####################################################################################################"
# 検出ログのヘッダー2
DETECTEC_LOG_HEADER2="同時アクセスが発生しました。"
# 更新完了したレコードを検知対象から外すための一時記録変数
DETECTED_EXCEPTION_TMP=""

###########################################################
# 関数定義
###########################################################
# ----
# JIRAサーバのAPIログの更新日時チェック関数
# ----
# 関数名         ：api_log_exist_chk
# 処理概要       ：GWサーバから更新JIRAサーバ(1号機、2号機)へSSHコマンドでファイル存在と更新日時を確認
#                ：ファイルの更新日時が新しいJIRAサーバのログを取得するため(切替時の対応のため)に
#                ：更新日時を比較し、取得すべきサーバのIPを設定する
# 引数           ：なし
# リターンコード ：0(正常)
#                ：1(異常)
# 対象DB         ：なし
function api_log_exist_chk
{
REMOTE_EXEC_SH ${JIRAU1_IP} "stat -c  '%y' ${API_AC_BUT_LOG}"
JIRAU1_DATE=`cat ${REMOTE_EXEC_FILE} | cut -d ' ' -f1-2 |sed -e 's/-//g' | sed -e 's/ //g' | sed -e 's/://g' | awk -F. '{print $1}'`

REMOTE_EXEC_SH ${JIRAU2_IP} "stat -c  '%y' ${API_AC_BUT_LOG}"
JIRAU2_DATE=`cat ${REMOTE_EXEC_FILE} | cut -d ' ' -f1-2 |sed -e 's/-//g' | sed -e 's/ //g' | sed -e 's/://g' | awk -F. '{print $1}'`

if [ -z "${JIRAU1_DATE}" -o -z "${JIRAU2_DATE}" ]
then
        if [ -z "${JIRAU1_DATE}" -a -n "${JIRAU2_DATE}" ]
        then
                M_GET_JIRA_IP=${JIRAU2_IP}
                m_outlog_func MA-I00111 ${M_GET_JIRA_IP}
        elif [ -n "${JIRAU1_DATE}" -a -z "${JIRAU2_DATE}" ]
        then
                M_GET_JIRA_IP=${JIRAU1_IP}
                m_outlog_func MA-I00112 ${M_GET_JIRA_IP}
        elif [ -z "${JIRAU1_DATE}" -a -z "${JIRAU2_DATE}" ]
        then
                m_outlog_func MA-I00113
                return 1
        fi
else
        if [ ${JIRAU1_DATE} -lt ${JIRAU2_DATE} ]
        then
                M_GET_JIRA_IP=${JIRAU2_IP}
                m_outlog_func MA-I00102 ${M_GET_JIRA_IP}
        else
                M_GET_JIRA_IP=${JIRAU1_IP}
                m_outlog_func MA-I00114 ${M_GET_JIRA_IP}        
        fi
fi
}

# ----
# JIRAサーバのAPIログのサイズチェック関数
# ----
# 関数名         ：api_log_size_chk
# 処理概要       ：GWサーバからJIRAサーバへSSHコマンドでファイルサイズを確認
# 引数           ：なし
# リターンコード ：1(正常、サイズが０バイトの場合もありうるため)
# 対象DB         ：なし
function api_log_size_chk
{
REMOTE_EXEC_SH ${M_GET_JIRA_IP} "ls -l ${API_AC_BUT_LOG}"
SSH_RESULT=`cat ${REMOTE_EXEC_FILE} | awk '{print $5}'`
if [ "${SSH_RESULT}" = "0" ]
then
        m_outlog_func MA-I00103 ${API_AC_BUT_LOG}
        return 1
fi
}

# ----
# GWサーバに存在するAPIログを削除関数
# ----
# 関数名         ：gw_api_log_delete
# 処理概要       ：GWサーバに存在するAPIログを削除
# 引数           ：なし
# リターンコード ：0(正常)
#                ：1(異常)
# 対象DB         ：なし
function gw_api_log_delete
{
rm -f ${M_TMP_DIR}/workitem.log
if [ -f "${M_TMP_DIR}/workitem.log" ]
then
        m_outlog_func MA-E00104 ${M_TMP_DIR}/workitem.log
        return 1
fi
}

# ----
# JIRAサーバAPIログコピー関数
# ----
# 関数名         ：api_log_cp
# 処理概要       ：GWサーバにJIRAサーバのAPIログをscp
# 引数           ：なし
# リターンコード ：0(正常)
#                ：1(異常)
# 対象DB         ：なし
function api_log_cp
{
REMOTE_COPY ${M_GET_JIRA_IP}:${API_AC_BUT_LOG} ${M_TMP_DIR}/workitem.log
if [ ! -f "${M_TMP_DIR}/workitem.log" ]
then
        m_outlog_func MA-E00105 ${M_TMP_DIR}/workitem.log
        return 1
fi
}

# ----
# 指定時間分ログ抽出関数
# ----
# 関数名         ：api_log_get
# 処理概要       ：指定時間分のAPIログを抽出(指定時間がない場合は、全行抽出)
# 引数           ：シェル実行時の第一引数の値
# リターンコード ：0(正常)
#                ：1(異常)
#                ：2(正常、指定時間付近(前30分の間)のログが存在しない場合はshell終了)
# 対象DB         ：なし
function api_log_get
{
if [ ! -z "${1}" ]
then    
        SELECT_TIME=`date -d "$1 hours ago" "+%Y%m%d%H%M%S"`
        LOG_MAX_TIME=`head -1 ${M_TMP_DIR}/workitem.log | awk '{print $1$2}'| sed s/-//g | sed s/://g | awk -F, '{print $1}'`
        TIME_COMPARE=`expr ${LOG_MAX_TIME} - ${SELECT_TIME}`
        if [ ${TIME_COMPARE} -gt 0 ]
        then
            LINE_NO=1
            LOOP_IN_FLAG=1
        fi
else
        LINE_NO=1
        LOOP_IN_FLAG=1
fi

if [ ${LOOP_IN_FLAG} != 1 ]
then
        DETECTED_TIME=`date -d "$1 hours ago" "+%Y-%m-%d %H:%M"`
        grep "${DETECTED_TIME}" ${M_TMP_DIR}/workitem.log  >/dev/null 2>&1
        RC=$?
        if [ "${RC}" != "0" ]
        then
            while [ ${COUNT} -lt ${RETRY} ]
            do
                COUNT=`expr ${COUNT} + 1`
                DETECTED_TIME=`date -d "$1 hours ago ${COUNT} minutes ago" "+%Y-%m-%d %H:%M"`
                grep "${DETECTED_TIME}" ${M_TMP_DIR}/workitem.log >/dev/null 2>&1
                RC=$?
                if [ "${RC}" = "0" ]
                then
                    LINE_NO=`grep -n "${DETECTED_TIME}" ${M_TMP_DIR}/workitem.log | head -1 | awk -F: '{print $1}'`
                    break
                fi
            done
            if  [ "${RC}" != "0" ]
            then
                m_outlog_func MA-I00106 "${DETECTED_TIME}" 
                return 2
            fi
        else
            LINE_NO=`grep -n "${DETECTED_TIME}" ${M_TMP_DIR}/workitem.log | head -1 | awk -F: '{print $1}'`
        fi
fi
NOW_TIME=`date "+%Y%m%d%H%M%S"`
tail -n +${LINE_NO} ${M_TMP_DIR}/workitem.log > ${API_SELECT_TIME_LOG}_${NOW_TIME}
RC=$?
if  [ "${RC}" != "0" ]
then
    m_outlog_func MA-E00107 ${API_SELECT_TIME_LOG}_${NOW_TIME}
    return 1
fi
}

# ----
# 指定時間分抽出ファイルのサイズチェック関数
# ----
# 関数名         ：workitem_get_log_size_chk
# 処理概要       ：指定時間分抽出ファイルのサイズが、0より大きい場合は正常
# 引数           ：なし
# リターンコード ：0(正常)
#                ：1(異常)
# 対象DB         ：なし
function workitem_get_log_size_chk
{
GET_SIZE=`ls -l ${API_SELECT_TIME_LOG}_${NOW_TIME} | awk '{print $5}'`
if [ "${GET_SIZE}" = "0" ]
then
        m_outlog_func MA-E00108 ${API_SELECT_TIME_LOG}_${NOW_TIME}
        return 1
fi
}

# ----
# 同時アクセス判定用一時記録ファイル削除関数
# ----
# 関数名         ：rm_ac_but_chk_memory
# 処理概要       ：同時アクセス判定用一時記録ファイルをrmコマンドで削除する
# 引数           ：なし
# リターンコード ：0(正常)
#                ：1(異常)
# 対象DB         ：なし
function rm_ac_but_chk_memory
{
rm -f ${M_TMP_DIR}/ac_but_chk_memory.tmp
if [ -e "${M_TMP_DIR}/ac_but_chk_memory.tmp" ]
then
        m_outlog_func MA-E00109 ${M_TMP_DIR}/ac_but_chk_memory.tmp
        return 1
fi
}

# ----
# 同時アクセスチェック関数
# ----
# 関数名         ：ac_but_chk
# 処理概要       ：同時アクセスチェック。
#                  指定時間分抽出ファイルからSTARTを検出すれば、
#                  同時アクセス判定用一時記録ファイルに追記。
#                  指定時間分抽出ファイルからENDを検出すれば、
#                  同時アクセス判定用一時記録ファイルから該当行削除。
#                  もし、追記の際にすでに同じワークアイテムに対して
#                  STARTしている行があれば検出し、該当行と
#                  すでにSTARTしていた行をすべてログに出力する。
# 引数           ：なし
# リターンコード ：0(正常)
#                ：1(異常)
# 対象DB         ：なし
function ac_but_chk
{
while read API_LOG_RECORD
do
    START_END_CHK=`echo "${API_LOG_RECORD}" | awk '{print $10}' | awk -F] '{print $2}'`
    if [ "${START_END_CHK}" = "START" ]
    then
        echo "${API_LOG_RECORD}" >> ${M_TMP_DIR}/ac_but_chk_memory.tmp
        DETECTED_DECISION_TMP=`echo "${API_LOG_RECORD}" | awk '{print $10}' | awk -F[ '{print $2}' | awk -F, '{print $1}'`
        DETECTED_WC=`grep "${DETECTED_DECISION_TMP}" ${M_TMP_DIR}/ac_but_chk_memory.tmp | wc -l`
        if [ ${DETECTED_WC} -gt 1 ]
        then
            echo "${DETECTEC_LOG_HEADER1}" >> ${M_LOG_DIR}/DETECTED_ACCESS_BUTTING_${NOW_TIME}.log
            echo "${DETECTEC_LOG_HEADER2}" >> ${M_LOG_DIR}/DETECTED_ACCESS_BUTTING_${NOW_TIME}.log
            grep "${DETECTED_DECISION_TMP}" ${M_TMP_DIR}/ac_but_chk_memory.tmp >> ${M_LOG_DIR}/DETECTED_ACCESS_BUTTING_${NOW_TIME}.log
        fi
    elif [ "${START_END_CHK}" = "END" ]
    then
        DETECTED_EXCEPTION_TMP=`echo "${API_LOG_RECORD}" | awk '{print $10}' | awk -F[ '{print $2}' | awk -F] '{print $1}'`
        sed -i '/'${DETECTED_EXCEPTION_TMP}'/d' ${M_TMP_DIR}/ac_but_chk_memory.tmp > /dev/null 2>&1
    fi
done < ${API_SELECT_TIME_LOG}_${NOW_TIME}
}

###########################################################
# main処理開始
###########################################################
m_outlog_func MA-I00101

###########################################################
# JIRAサーバのAPIログの存在チェック
###########################################################
api_log_exist_chk
RC=$?
if [ "${RC}" != "0" ]
then
        exit 0
fi

###########################################################
# JIRAサーバのAPIログのサイズチェック
###########################################################
api_log_size_chk
RC=$?
if [ "${RC}" != "0" ]
then
        exit 0
fi

###########################################################
# GWサーバに存在するAPIログを削除
###########################################################
gw_api_log_delete
RC=$?
if [ "${RC}" != "0" ]
then
        exit 1
fi

###########################################################
# JIRAサーバAPIログコピー
###########################################################
api_log_cp
RC=$?
if [ "${RC}" != "0" ]
then
        exit 1
fi

###########################################################
# 現在時刻から指定時間分のAPIログを抽出
###########################################################
api_log_get $1
RC=$?
if [ "${RC}" = "1" ]
then
        exit 1
elif [ "${RC}" = "2" ]
then
        exit 0
fi

###########################################################
# 指定時間分抽出ファイルのサイズチェック
###########################################################
workitem_get_log_size_chk
RC=$?
if [ "${RC}" != "0" ]
then
        exit 1
fi

###########################################################
# 同時アクセス判定用一時記録ファイルを削除
###########################################################
rm_ac_but_chk_memory
RC=$?
if [ "${RC}" != "0" ]
then
        exit 1
fi

###########################################################
# 同時アクセスチェック
###########################################################
ac_but_chk

###########################################################
# 終了
###########################################################
m_outlog_func MA-I00110
