#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： M_ANKENSAKUJYO_ONLINE.sh
# 業 務 名       ： 案件削除処理
# 処理概要       ： 案件削除対象ファイルより案件を削除する。
#　　　　　　　　： 
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Yang Xi
#
# 作成日付       ： 2011-04-12
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2011-04-12 Yang Xi                新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません"
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# 保守用共通環境変数設定
# ----
_exec_m_sh=/workflow/batch/maint/m_ini/m_batch_common.conf

if [ ! -f ${_exec_m_sh} ]; then
	echo "保守用環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_m_sh}

# ----
# 保守用共通関数ファイルの存在チェック
# ----
if [ ! -f ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh ]; then
	echo "保守用共通関数ファイルが存在しません"
	exit 1
fi
. ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh


###############################################################################
# main処理開始
###############################################################################
# 開始メッセージ
m_outlog_func MA-I00301

#パラメータは数字以外のチェック
expr ${1} + 0  1>/dev/null 2>&1
if [ $? != 0 ]
then
	  # エラーログ出力
	  m_outlog_func MA-E00311 "${1}"
	  
	  # エラー終了
	  exit 1
fi

#パラメータは負の数のチェック
if [ ${1} -le 0 ]
then
		# エラーログ出力
	  m_outlog_func MA-E00311 "${1}"
	  
	  # エラー終了
	  exit 1
fi	

#案件削除対象ＣＳＶファイル0バイトまた存在しないのチェック
if [ ! -s ${M_CSV_DIR}/ankensakujyo_taishou.csv ]
then
	  # エラーログ出力
	  m_outlog_func MA-E00304 "${M_CSV_DIR}/ankensakujyo_taishou.csv"
	  
	  # エラー終了
	  exit 1
fi

if [ -s ${M_TMP_DIR}/syorizumi_count ]
# 処理再開モード
then
  # 合計処理件数を取得
	syorizumi_count=`cat ${M_TMP_DIR}/syorizumi_count | awk -F, '{print $1}'`
	succount_jira=`cat ${M_TMP_DIR}/syorizumi_count | awk -F, '{print $2}'`
	skipcount_jira=`cat ${M_TMP_DIR}/syorizumi_count | awk -F, '{print $3}'`
	succount_history=`cat ${M_TMP_DIR}/syorizumi_count | awk -F, '{print $4}'`
	skipcount_history=`cat ${M_TMP_DIR}/syorizumi_count | awk -F, '{print $5}'`
	# 処理再開メッセージ
	m_outlog_func MA-I00313 "${syorizumi_count}"
# 処理開始モード
else
	# 合計件数の初期化
  syorizumi_count=0
  succount_jira=0
  skipcount_jira=0
	succount_history=0
	skipcount_history=0
	
	# MD5ファイルを生成
	md5sum -t ${M_CSV_DIR}/ankensakujyo_taishou.csv > ${M_TMP_DIR}/ankensakujyo_taishou.csv.md5
	RC=$?
	if [ ${RC} != 0 ]
	then
		# エラーログ出力
		m_outlog_func MA-E00316
		
		# エラー終了
	  exit 1
	fi
fi

# 案件削除対象ＣＳＶファイルを改竄されたかどうかとチェックする
if [ -s ${M_TMP_DIR}/ankensakujyo_taishou.csv.md5 ]
then
	md5sum -c ${M_TMP_DIR}/ankensakujyo_taishou.csv.md5 > ${DETAIL_LOG_TMP} 2>&1
	RC=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${M_DETAIL_LOG}
	if [ ${RC} != 0 ]
	then
		# エラーログ出力
		m_outlog_func MA-E00314 "${M_CSV_DIR}/ankensakujyo_taishou.csv"
		
		# エラー終了
	  exit 1
	fi
else
		# エラーログ出力
		m_outlog_func MA-E00315 "${M_TMP_DIR}/ankensakujyo_taishou.csv.md5"
		
		# エラー終了
	  exit 1
fi

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
    # エラーログ出力
    _errmsg=`cat ${SQLLOG_TMP}`
    m_outlog_func MA-E00303 "${_errmsg}"

    # エラー終了
    exit 1
fi

# システムタイムの取得
_date_dem=`date +%s`

# カウンタ初期化
read_count=0
succount_jira_t=0
skipcount_jira_t=0
succount_history_t=0
skipcount_history_t=0

while read pkey
do
	# リードしたデータの行数をカウントする
	read_count=`expr ${read_count} + 1`
	
	if [ ${read_count} -le ${syorizumi_count} ]
	then
		  continue
	fi
	
	# 処理時間の判断
	_date_now=`date +%s`
	_second=$(($_date_now-$_date_dem))
 	if [ ${_second} -ge $(expr ${1} \* 60) ] 
	then
		  # 処理一時停止
		  m_outlog_func MA-I00309 "${skipcount_jira_t}" "${skipcount_jira}" "更新系JIRA"
		  m_outlog_func MA-I00310 "${succount_jira_t}" "${succount_jira}" "更新系JIRA"
		  m_outlog_func MA-I00309 "${skipcount_history_t}" "${skipcount_history}" "変更履歴テーブル"
		  m_outlog_func MA-I00310 "${succount_history_t}" "${succount_history}" "変更履歴テーブル"
		  m_outlog_func MA-I00312
		  # JIRADB切断
			db2 terminate > /dev/null
		  exit 0
	fi
	
	# 更新系JIRAに案件存在のチェック
	_tmp=`db2 -x "select 1 from JIRASCHEMA.JIRAISSUE where pkey='${pkey}'"`
	if [ -z ${_tmp} ]
	then
			skipcount_jira=`expr ${skipcount_jira} + 1`
			skipcount_jira_t=`expr ${skipcount_jira_t} + 1`
			m_outlog_func MA-W00307 "更新系JIRA" "${pkey}"
	else
		# 更新系JIRA ワークアイテム削除
		java -classpath "${JAVA_CLASSPATH}" com.ibm.jirax.batch.DeleteWorkItemBatch "${pkey}" > ${DETAIL_LOG_TMP} 2>&1
		RC=$?
		echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${DETAIL_LOG_TMP}`" >>${M_DETAIL_LOG}
		case ${RC} in
					0)			m_outlog_func MA-I00308 "更新系JIRA" "${pkey}"
									succount_jira=`expr ${succount_jira} + 1`
									succount_jira_t=`expr ${succount_jira_t} + 1`;;
	        10)     m_outlog_func MA-W00305 ${pkey}
									skipcount_jira=`expr ${skipcount_jira} + 1`
									skipcount_jira_t=`expr ${skipcount_jira_t} + 1`;;
	        *)      m_outlog_func MA-E00306 "更新系JIRA" "${pkey}"
	                m_outlog_func MA-I00309 "${skipcount_jira_t}" "${skipcount_jira}" "更新系JIRA"
									m_outlog_func MA-I00310 "${succount_jira_t}" "${succount_jira}" "更新系JIRA"
									m_outlog_func MA-I00309 "${skipcount_history_t}" "${skipcount_history}" "変更履歴テーブル"
									m_outlog_func MA-I00310 "${succount_history_t}" "${succount_history}" "変更履歴テーブル"
									# エラー終了
	                exit 1;;
		esac
	fi
				
	
	# 変更履歴テーブル削除
	db2 "delete from rp.tb_issue_history where sequence_number = '${pkey}'"  > ${SQLLOG_TMP}
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${M_DETAIL_LOG}
	case ${SQLERROR} in
				0)			m_outlog_func MA-I00308 "変更履歴テーブル" "${pkey}"
								succount_history=`expr ${succount_history} + 1`
								succount_history_t=`expr ${succount_history_t} + 1`;;
        1)      m_outlog_func MA-W00307 "変更履歴テーブル" "${pkey}"
								skipcount_history=`expr ${skipcount_history} + 1`
								skipcount_history_t=`expr ${skipcount_history_t} + 1`;;
        *)      _errmsg=`cat ${SQLLOG_TMP}`
        				m_outlog_func MA-E00306 "変更履歴テーブル" "${pkey}"
        				m_outlog_func MA-I00309 "${skipcount_jira_t}" "${skipcount_jira}" "更新系JIRA"
								m_outlog_func MA-I00310 "${succount_jira_t}" "${succount_jira}" "更新系JIRA"
								m_outlog_func MA-I00309 "${skipcount_history_t}" "${skipcount_history}" "変更履歴テーブル"
								m_outlog_func MA-I00310 "${succount_history_t}" "${succount_history}" "変更履歴テーブル"
        				# 一時ファイル等の削除
								rm -f  ${SQLLOG_TMP}
								# エラー終了
                exit 1;;
  esac
  
  # カウンタを記録
  syorizumi_count=`expr ${syorizumi_count} + 1`
  echo "${syorizumi_count},${succount_jira},${skipcount_jira},${succount_history},${skipcount_history}" > ${M_TMP_DIR}/syorizumi_count
  
done < ${M_CSV_DIR}/ankensakujyo_taishou.csv

m_outlog_func MA-I00309 "${skipcount_jira_t}" "${skipcount_jira}" "更新系JIRA"
m_outlog_func MA-I00310 "${succount_jira_t}" "${succount_jira}" "更新系JIRA"
m_outlog_func MA-I00309 "${skipcount_history_t}" "${skipcount_history}" "変更履歴テーブル"
m_outlog_func MA-I00310 "${succount_history_t}" "${succount_history}" "変更履歴テーブル"

# JIRADB切断
db2 terminate > /dev/null

# 一時ファイルを削除
rm -f ${M_TMP_DIR}/syorizumi_count
# MD5ファイルを削除
rm -f ${M_TMP_DIR}/ankensakujyo_taishou.csv.md5

m_outlog_func MA-I00302

exit 0
