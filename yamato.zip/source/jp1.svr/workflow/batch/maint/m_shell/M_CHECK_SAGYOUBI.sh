#!/bin/sh
################        モジュール説明  ########################
# モジュール名  : M_CHECK_SAGYOUBI.sh
# 業務名        : 作業日異常チェックツール
# 処理概要      : 作業日異常チェック
# 特記事項      : 無し
# 自動化頻度    : 無し
# パラメータ    : 無し
# 前提条件      : 無し
# リターンコード: 0     正常終了
#               : 1     処理異常
# 処理対象      : 
# 実行ユーザー  : root
#
################        モジュール説明  ########################
#                                                              
################        改定履歴        ########################
# 作成者        : Yuan Zhiwei
#
# 作成日付      : 2014-08-13
#
# =V.R.M=       ==DATE==        =担当者=        =準拠文書=      ====内容====
# 1 1.0.0       2014-08-13      Yuan Zhiwei        新規作成
# 2
# =V.R.M=       ==DATE==        =担当者=        =準拠文書=      ====内容====
#
################        改定履歴        ########################


# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません"
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# 保守用共通環境変数設定
# ----
_exec_m_sh=/workflow/batch/maint/m_ini/m_batch_common.conf

if [ ! -f ${_exec_m_sh} ]; then
	echo "保守用環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_m_sh}

# ----
# 保守用共通関数ファイルの存在チェック
# ----
if [ ! -f ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh ]; then
	echo "保守用共通関数ファイルが存在しません"
	exit 1
fi
. ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh

###############################################################################
# main処理開始
###############################################################################
# 開始メッセージ
m_outlog_func MS-I00101


timestamp=`date "+%Y%m%d%H%M%S"`
gwdata_name="M_CHECK_SAGYOUBI_NYUUKINDATAUNMATCH_${timestamp}.csv"
jiradata_name="M_CHECK_SAGYOUBI_JIRAISSUE_${timestamp}.csv"
result_name="M_CHECK_SAGYOUBI_result_${timestamp}.txt"

# GWDBに接続
db2 connect to ${DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド返却値:$SQLERROR || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${M_DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	m_outlog_func MS-E00104 "GWDB" "${_errmsg}"
	
	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# エラー終了
	exit 1
fi
# GWDBのデータをエクスポート
db2 "export to ${M_TMP_DIR}/${gwdata_name} of del select pkey_cd,sagyoubi from db2inst3.NYUUKINDATAUNMATCH where SUBSTR(pkey_cd,4,8)= REPLACE(CHAR(current date,ISO),'-','') order by pkey_cd,sagyoubi" > ${SQLLOG_TMP} 2>&1
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド返却値:$SQLERROR || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${M_DETAIL_LOG}
if [ $SQLERROR != '0' ]
then
    m_outlog_func MS-E00105 "db2inst3.NYUUKINDATAUNMATCH"
    exit 1
fi

# GWDB切断
db2 terminate > /dev/null

# JIRADBに接続
db2 connect to ${JIRA_DB_NAME} > ${SQLLOG_TMP}
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド返却値:$SQLERROR || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${M_DETAIL_LOG}
# DBエラー
if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
then
	# エラーログ出力
	_errmsg=`cat ${SQLLOG_TMP}`
	 m_outlog_func MS-E00104 "JIRADB" "${_errmsg}"

	# 一時ファイル等の削除
	rm -f  ${SQLLOG_TMP}

	# エラー終了
	exit 1
fi
# JIRADBのデータをエクスポート
db2 "export to ${M_TMP_DIR}/${jiradata_name} of del select pkey,replace(substr(char(duedate),1,10),'-','') sagyoubi from jiraschema.jiraissue where substr(pkey,4,8)= replace(char(current date,ISO),'-','') and pkey like 'UD%' order by  pkey,sagyoubi" > ${SQLLOG_TMP} 2>&1
SQLERROR=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド返却値:$SQLERROR || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${M_DETAIL_LOG}
if [ $SQLERROR != '0' ]
then
    m_outlog_func MS-E00105 "jiraschema.jiraissue"
    exit 1
fi

# JIRADB切断
db2 terminate > /dev/null

#差分を作り
diff -y --suppress-common-line ${M_TMP_DIR}/${gwdata_name} ${M_TMP_DIR}/${jiradata_name} > ${M_TMP_DIR}/${result_name}
RC=$?
echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド返却値:$RC " >>${M_DETAIL_LOG}
if [ $RC -eq '2' ]
then
    m_outlog_func MS-E00106
    exit 1
fi

#差分結果チェック
if [ -s ${M_TMP_DIR}/${result_name} ]; then
	m_outlog_func	MS-E00103
	cat ${M_TMP_DIR}/${result_name} >>${M_LOG_DIR}/M_CHECK_SAGYOUBI.log
	exit 1
fi

# テンプファイル削除する
rm -f ${M_TMP_DIR}/${gwdata_name}
rm -f ${M_TMP_DIR}/${jiradata_name}
rm -f ${M_TMP_DIR}/${result_name}

# 終了メッセージ
m_outlog_func	MS-I00102

exit 0