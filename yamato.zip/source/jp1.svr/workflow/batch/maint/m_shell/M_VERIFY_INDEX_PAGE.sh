#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： M_VERIFY_INDEX_PAGE.sh
# 業 務 名       ： なし
# 処理概要       ： index.jsp内容チェック
# パラメータ     ： 1:朝8時後実行（利用時間内）
#                ： 2:夜23時後実行（利用時間外）
# 特記事項       ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： LiuJian 
#
# 作成日付       ： 2011-11-09
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2011-11-09 LiuJian              新規作成
# 2       2014-06-24 LiuJian              IP集約管理
# 3       2014-09-02 LiuJian              510.[開発] SSH関連調査
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC.sh ]
then
	echo "共通関数ファイルが存在しません" 
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC.sh

# ----
# 保守用共通環境変数設定
# ----
_exec_m_sh=/workflow/batch/maint/m_ini/m_batch_common.conf

if [ ! -f ${_exec_m_sh} ]; then
	echo "保守用環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_m_sh}

# ----
# 保守用共通関数ファイルの存在チェック
# ----
if [ ! -f ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh ]; then
	echo "保守用共通関数ファイルが存在しません"
	exit 1
fi
. ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh

###############################################################################
# main処理開始
###############################################################################

# 開始メッセージ
m_outlog_func MV-I00001

# 相関変数設定
_page_save=''
_key_word=''

# 引数チェック
if [ "$1" != "1" -a "$1" != "2" ]
then
	m_outlog_func MV-E00008
	exit 1
fi

# 引数にってキーワード設定
if [ $1 = '1' ]
then 
	# 引数1:朝8時で実行、システム利用可。
	_key_word='ログインメニューへ'
elif [ $1 = '2' ]
then
	# 引数2:夜23時で実行、システム利用不可。
	_key_word='時間外'
fi

# 日付を取得
_timestmp=`date +%Y%m%d%H%M%S`

# tmpファイル名設定
_page_save=${M_TMP_DIR}/`basename ${0} | sed "s/.sh//g"`_${_timestmp}.tmp

# URLアクセスする
wget -t 3 -T 15 -qO ${_page_save} ${JIRA_BIZ_IP}
if [ $? -ne 0 ]
then
	# エラーログ出力
	m_outlog_func MV-E00003
	# エラー終了
	exit 1
fi

# tmpファイルエンコード変換する
nkf -w $_page_save > ${_page_save}.utf8
if [ $? -ne 0 ]
then
	# tmpファイル削除
	rm -f ${_page_save}
	# エラーログ出力	
	m_outlog_func MV-E00009
	# エラー終了
	exit 1
fi

# tmpファイル削除
rm -f ${_page_save}

# utf8のtmpファイル内容チェックする
grep -sq ${_key_word} ${_page_save}.utf8
CHECK_RESULT=$?

if [ $CHECK_RESULT -eq 0 ]			# キーワード有る
then
	rm -f ${_page_save}.utf8
	# 終了メッセージ
	m_outlog_func MV-I00002
	exit 0
elif [ $CHECK_RESULT -eq 1 ]		# キーワードなし
then
	# 想定内容ではない、JIRAU_1でのキャッシュファイル削除する(index.jsp,index.classファイル削除する)
	REMOTE_EXEC_SH ${JIRAU1_IP} "rm -f ${JIRA_DIR}/work/Catalina/localhost/jwf/org/apache/jsp/index_jsp.*"
	export _result1=$?

	# 想定内容ではない、JIRAU_2でのキャッシュファイル削除する
	REMOTE_EXEC_SH ${JIRAU2_IP} "rm -f ${JIRA_DIR}/work/Catalina/localhost/jwf/org/apache/jsp/index_jsp.*"
	export _result2=$?

	# JIRAU_1とJIRAU_2でのキャッシュファイル削除結果を確認する
	if [[ $_result1 != '0' || $_result2 != '0' ]]
	then
    	m_outlog_func MV-E00007 ${_result1} ${JIRAU1_IP} ${_result2} ${JIRAU2_IP}
    	exit 1
	fi
	m_outlog_func MV-I00005
else 								# エラー発生
	# エラーログ出力
	m_outlog_func MV-E00004
	# エラー終了
	exit 1
fi

# 一回目のURLアクセスで、想定なキーワードは無し、再アクセス確認する。
sleep 10
wget -t 3 -T 15 -qO ${_page_save} ${JIRA_BIZ_IP}
if [ $? -ne 0 ]
then
    # エラーログ出力
    m_outlog_func MV-E00003
	# エラー終了
	exit 1
fi

# tmpファイルエンコードUTF-8変換する
nkf -w ${_page_save} > ${_page_save}.utf8
if [ $? -ne 0 ]
then
	# tmpファイル削除
	rm -f ${_page_save}
	# エラーログ出力	
	m_outlog_func MV-E00009
	# エラー終了
	exit 1
fi

# tmpファイル削除
rm -f ${_page_save}

# tmpファイル内容チェックする
grep -sq ${_key_word} ${_page_save}.utf8
CHECK_RESULT=$?

if [ $CHECK_RESULT -eq 0 ]			# キーワード有る
then
	rm -f ${_page_save}.utf8
elif [ $CHECK_RESULT -eq 1 ]
then
	# 二回目確認で想定内容なし、エラー出して、退出する。
	m_outlog_func MV-E00006
	exit 1
else 								# エラー発生
	# エラーログ出力
	m_outlog_func MV-E00004
	# エラー終了
	exit 1
fi

# 終了メッセージ
m_outlog_func MV-I00002

exit 0
