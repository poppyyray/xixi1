#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： M_CHECK_MIX.sh
# 業 務 名       ： データチェックMIX処理
# 処理概要       ：
# 特記事項       ： 起動トリガー：CRON
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： JIRADB
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Tang.XD
#
# 作成日付       ： 2015-09-09
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.1 2015-09-09 Tang.XD               新規作成
# 2 
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

###########################################################
# 変数定義
###########################################################

TITLE=("1.入金アンマッチ業務で「差額-消込金額=残高」となっていない件数" 
			"2.担当とステータスが不整合をおこしている件数" 
			"3.入金アンマッチ　泣き別れを起こしている件数" 
			"4.ステータスが「問合せ審査待ち」(B01)で同一な問合せ番号の通番の件数"
			"5.ステータスが「回答待ち」(C01)で同一な問合せ番号の通番の件数" 
)
			
SQLFILE=("CHECK_MIX_10.sql" 
			"CHECK_MIX_20.sql" 
			"CHECK_MIX_30.sql" 
			"CHECK_MIX_40.sql" 
			"CHECK_MIX_50.sql")

SQLTMPFILE=("check_mix_report_10.tmp" 
			"check_mix_report_20.tmp" 
			"check_mix_report_30.tmp" 
			"check_mix_report_40.tmp" 
			"check_mix_report_50.tmp")

###########################################################
# 共通環境変数設定
###########################################################
# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common.conf

if [ ! -f ${_exec_ksh} ]; then
	echo `date +%Y%m%d%H%M%S` "ERROR" `basename ${0}` "MA-E00000" "共通ファイルが存在しませんでした[${_exec_sh}]" >> ${TMP_LOG}
	exit 1
fi
. ${_exec_ksh}

# ----
# 保守用共通環境変数設定
# ----
_exec_m_sh=/workflow/batch/maint/m_ini/m_batch_common.conf

if [ ! -f ${_exec_m_sh} ]; then
	echo `date +%Y%m%d%H%M%S` "ERROR" `basename ${0}` "MA-E00001" "共通ファイルが存在しませんでした[${_exec_m_sh}]" >> ${TMP_LOG}
	exit 1
fi
. ${_exec_m_sh}

# ----
# 保守用共通関数ファイルの存在チェック
# ----
if [ ! -f ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh ]; then
	echo `date +%Y%m%d%H%M%S` "ERROR" `basename ${0}` "MA-E00003" "共通ファイルが存在しませんでした[${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh]" >> ${TMP_LOG}
	exit 1
fi
. ${M_SHELL_DIR}/M_BATCH_COMMON_FUNC.sh

cd ${M_TMP_DIR}

###############################################################################
# main処理
#
# 引数：　なし
#
# 戻り値：　0:正常
#           1:異常
###############################################################################

# 処理開始ログ出力
m_outlog_func MA-I00501

# JIRADBに接続
m_func_connectDB ${JIRA_DB_NAME} > ${SQLLOG_TMP} 2>&1
_ret=$?
if [ $_ret != ${RC_NOR} ]; then
	m_outlog_func MA-E00504 ${_ret}
	exit ${RC_ERR}
fi

result=${RC_NOR}

report_file=${M_TMP_DIR}/check_mix_report.`date +%Y%m%d`.txt
cat /dev/null > ${report_file}

# データチェックを行う
count=0
while [ ${count} -lt "${#TITLE[*]}" ]
do
	#検索
	db2 -tf "${M_HOME}/m_sql/${SQLFILE[count]}" > ${SQLLOG_TMP} 2>&1
	SQLERROR=$?
	echo -e "日付:`date` || shell名:`basename ${0}` || 行番号:`expr ${LINENO} - 2` || コマンド結果:\n`cat ${SQLLOG_TMP}`" >>${M_DETAIL_LOG}
	# DBエラー
	if [ ${SQLERROR} -eq 4  -o ${SQLERROR} -eq 8 ]
	then
		# エラー
		m_outlog_func MA-E00505 ${M_HOME}/m_sql/${SQLFILE[count]} ${SQLERROR}
		result=${RC_ERR}
		let "count=count+1"
		continue
	fi

	#検索件数を取得
	rs_count=`cat ${M_TMP_DIR}/${SQLTMPFILE[count]} | wc -l`
	echo ${TITLE[count]}  >>${report_file}
	echo "  ⇒ " ${rs_count} 件  >>${report_file}
	
	#一件以上の場合
	if [ ${rs_count} != 0 ]
	then
		m_outlog_func MA-E00506 ${TITLE[count]} ${rs_count}
		cat ${M_TMP_DIR}/${SQLTMPFILE[count]} >> ${report_file}
	fi

	echo "" >> ${report_file}
	let "count=count+1"
done

m_outlog_func MA-I00507 ${report_file}
# DB切断
db2 terminate > /dev/null 2>&1

# 処理終了ログ出力
m_outlog_func MA-I00502

# 処理終了
exit ${result}
