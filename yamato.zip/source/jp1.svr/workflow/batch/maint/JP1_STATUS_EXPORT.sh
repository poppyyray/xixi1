#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： JP1_STATUS_EXPORT.sh
# 業 務 名       ： JP1実行系ステータス抽出
# 処理概要       ： 実行系GWサーバからJP1のデータを共有ファイルに退避する
# 特記事項       ： JIRAがオンライン稼働中でない場合に起動する
# パラメータ     ： なし
# ログファイル   ： 
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： 実行系GWサーバ
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Y.Otsuka
#
# 作成日付       ： 2009-10-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-10-08 Y.Otsuka              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
#env_file_list="/workflow/batch/ini/batch_common.conf"
#for x in ${env_file_list}
#do
#        if [[ -r ${x} ]]
#        then
#            . ${x}
#        else
#            echo "Cannot read common env file. ( ${x} )."
#            exit 1
#        fi
#done
## ----
## 共通関数読み込み
## ----
#conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
#for y in ${conf_file_list}
#do
#        if [[ -r ${y} ]]
#        then
#            . ${y}
#        else
#            echo "Cannot read common conf file. ( ${y} )."
#            exit 1
#        fi
#done
#
# ---- 
# 業務別環境変数設定
# ----

JP1_STATUS_EXPORT=/workflow/batch/maint/jp1_status.txt
JOB_STATUS_EXPORT=/workflow/batch/maint/job_status.txt

#########################################################################
#MAIN関数
#########################################################################

function JP1_STATUS_EXPORT {

	# JP1の定義情報を取得する
	/opt/jp1base/bin/jbsgetcnf > ${JP1_STATUS_EXPORT}
	JP1_STATUS=$?
	# 戻り値が0以外の場合はエラーのため、return 1を返す
	if [ ${JP1_STATUS} != '0'  ]
	then
		echo JP1定義抽出処理に失敗しました
		echo ReturnCode=${JP1_STATUS}
		return 1
		
	else
		echo JP1定義抽出処理に成功しました
		echo ReturnCode=${JP1_STATUS}
	fi

	# JP1/AJS3-ManagerのJOB定義を取得する
	/opt/jp1ajs2/bin/ajsprint -a '/*' > ${JOB_STATUS_EXPORT}
	JOB_STATUS=$?
	# 戻り値が0以外の場合はエラーのため、return 1を返す
	if [ ${JOB_STATUS} != '0'  ]
	then
		echo JP1_JOB定義抽出処理に失敗しました
		echo ReturnCode=${JOB_STATUS}
		return 1
	else
		echo JP1_JOB定義抽出処理に成功しました
		echo ReturnCode=${JOB_STATUS}
	fi

	return 0

}

#########################################################################
#MAIN処理
#########################################################################

# 処理開始
echo JP1定義情報抽出処理を開始します。

# MAIN処理開始 
JP1_STATUS_EXPORT
if [ $? != '0'  ]
then
	echo JP1定義情報抽出処理に失敗しました
	exit 1
fi

# 処理終了
echo JP1定義情報抽出処理を終了します。

exit 0
