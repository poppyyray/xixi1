EXPORT to /workflow/batch/maint/m_tmp/check_mix_report_10.tmp OF del modified by nochardel
SELECT  '  通番: '|| (SUBSTR(CHAR(ji.pkey),1,17))
	    ||' 主管コード: ' || SUBSTR(CHAR(cp.cname),1,6)
        ||' ステータス: ' || sm.VALUE
 FROM jiraschema.jiraissue ji,
     jiraschema.issuestatus is,
     jiraschema.customfieldvalue cv,
     jiraschema.nodeassociation na,
     jiraschema.component cp,
     rp.TB_STATUS_MASTER sm,
     (SELECT (SUBSTR(CHAR(ji.pkey),1,17)) as pkey,
             BIGINT(cv.numbervalue) as keshikomikingaku
      FROM jiraschema.CUSTOMFIELDVALUE cv,
           jiraschema.jiraissue ji,
           jiraschema.issuestatus is
      WHERE cv.issue = ji.id
      AND ji.issuestatus = is.id
      AND cv.customfield = 10017
      AND ji.pkey like 'UD-%'
      ORDER BY ji.pkey
      ) keshi,
      (SELECT (SUBSTR(CHAR(ji.pkey),1,17)) as pkey,
              BIGINT(RTRIM(SUBSTR(CHAR(actionbody),1,11))) as zandakakingaku
      FROM jiraschema.jiraaction ja,
           jiraschema.jiraissue ji,
           jiraschema.issuestatus is
      WHERE ji.id = ja.issueid
      AND ji.issuestatus = is.id
      AND
              (ja.issueid,ja.created) IN (
              SELECT issueid,MIN(created)
              FROM jiraschema.jiraaction
              WHERE issueid IN
                      (SELECT id
                      FROM jiraschema.jiraissue
                      WHERE pkey LIKE 'UD-%')
              GROUP BY issueid)
      ) zandaka
 WHERE ji.pkey like 'UD-%'
 AND ji.issuestatus = is.id
 AND cv.issue = ji.id
 AND cv.customfield = 10070
 AND na.source_node_id = ji.id
 AND sink_node_entity = 'Component'
 AND cp.id = na.sink_node_id
 AND keshi.pkey = ji.pkey
 AND zandaka.pkey = ji.pkey
 AND BIGINT(cv.NUMBERVALUE)-BIGINT(keshi.keshikomikingaku) <> BIGINT(zandaka.zandakakingaku)
 AND sm.CODE = SUBSTR(CHAR(is.pname),1,3)
with ur;
