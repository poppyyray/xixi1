EXPORT to /workflow/batch/maint/m_tmp/check_mix_report_20.tmp OF del modified by nochardel
SELECT  '  通番: '|| (SUBSTR(CHAR(ji.pkey),1,17))
	    ||' 主管コード: ' || SUBSTR(CHAR(cp.cname),1,6)
        ||' ステータス: ' || sm.VALUE
from 
    jiraschema.JIRAISSUE JI,
    jiraschema.PRIORITY PR,
    jiraschema.ISSUESTATUS IS,
    jiraschema.NODEASSOCIATION NA,
    jiraschema.COMPONENT CP,
    rp.TB_STATUS_MASTER sm
where
    JI.priority=PR.id
    and JI.issuestatus=IS.id
    and PR.pname<>substr(IS.pname,1,1)
    and NA.source_node_id = JI.id
    and sink_node_entity = 'Component'
    and CP.id = NA.sink_node_id
    and sm.CODE = 	SUBSTR(CHAR(IS.pname),1,3)
    ;
