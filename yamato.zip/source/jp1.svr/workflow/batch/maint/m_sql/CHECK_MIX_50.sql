EXPORT to /workflow/batch/maint/m_tmp/check_mix_report_50.tmp OF del modified by nochardel
SELECT  '  通番: '|| substr(ji.pkey,1,17)
	    ||' 主管コード: ' || substr(CHAR(cp.cname),1,6)
        ||' 組合せ番号: ' || substr(char(ji.environment),1,30)
from
       jiraschema.jiraissue ji,
       jiraschema.issuestatus is,
       jiraschema.nodeassociation na,
       jiraschema.component cp
where
       ji.issuestatus = is.id
and na.source_node_id = ji.id
and cp.id = na.sink_node_id
and ji.environment in
(select
       substr(char(ji.environment),1,30) as env
 from
       jiraschema.jiraissue ji,
       jiraschema.issuestatus is
 where
       is.id = ji.issuestatus
and pkey like 'UD%'
and ji.environment is not null
and is.pname = 'C01'
group by substr(char(ji.environment),1,30)
having count(ji.environment) > 1
)
with ur;