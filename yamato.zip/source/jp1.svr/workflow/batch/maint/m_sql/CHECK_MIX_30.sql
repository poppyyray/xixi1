EXPORT to /workflow/batch/maint/m_tmp/check_mix_report_30.tmp OF del modified by nochardel
SELECT  '  通番: '|| substr(ji.pkey,1,20)
	    ||' 主管コード: ' || SUBSTR(CHAR(cp.cname),1,6)
        ||' ステータス: ' || sm.VALUE
from
        jiraschema.jiraissue ji,
        jiraschema.issuestatus is,
        jiraschema.nodeassociation na,
        jiraschema.component cp,
        rp.TB_STATUS_MASTER sm
where is.id = ji.issuestatus
        and CHAR(ji.ENVIRONMENT) not in
        (
                select
                substr(CHAR(ji.ENVIRONMENT),1,30)
                from
                jiraschema.jiraissue ji,
                jiraschema.issuestatus is
                where is.id = ji.issuestatus
                and pkey like 'UD%'
                and is.pname <> 'B02'
                and is.pname <> 'C02'
                and ji.ENVIRONMENT is not null
        )
and pkey like 'UD%'
and na.source_node_id = ji.id
and sink_node_entity = 'Component'
and cp.id = na.sink_node_id
and sm.CODE = substr(is.pname,1,3)
with ur;