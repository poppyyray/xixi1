#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： JP1_STATUS_IMPORT.sh
# 業 務 名       ： JP1ステータス適用
# 処理概要       ： 共有ファイルからJP1の定義情報をIMPORTする
# 特記事項       ： GWサーバ障害時、コールド機にて運用を行う際に使用
# パラメータ     ： なし
# ログファイル   ： 
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： 待機系GWサーバ
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Y.Otsuka
#
# 作成日付       ： 2009-10-08
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-10-08 Y.Otsuka              新規作成
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
# ----
# 共通環境変数読み込み
# ----
#env_file_list="/workflow/batch/ini/batch_common.conf"
#for x in ${env_file_list}
#do
#        if [[ -r ${x} ]]
#        then
#            . ${x}
#        else
#            echo "Cannot read common env file. ( ${x} )."
#            exit 1
#        fi
#done
## ----
## 共通関数読み込み
## ----
#conf_file_list="/workflow/batch/shell/BATCH_COMMON_FUNC.sh"
#for y in ${conf_file_list}
#do
#        if [[ -r ${y} ]]
#        then
#            . ${y}
#        else
#            echo "Cannot read common conf file. ( ${y} )."
#            exit 1
#        fi
#done
#
# ---- 
# 業務別環境変数設定
# ----

JP1_STATUS_IMPORT=/workflow/batch/maint/jp1_status.txt
JOB_STATUS_IMPORT=/workflow/batch/maint/job_status.txt

#########################################################################
#MAIN関数
#########################################################################

function JP1_STOP {

	# JP1/AJS3-Managerの起動を確認する
	/opt/jp1ajs2/bin/jajs_spmd_status > /dev/null 2>&1
	STATUS=$?
	# 戻り値が8（停止）以外の場合は
	# JP1/AJS3-Managerの停止を行う
	if [ ${STATUS} != "8" ]
	then
		echo JP1_AJS3_Managerを停止します。
		# JP1/AJS3-Managerの停止を行う
		/etc/opt/jp1ajs2/jajs_stop > /dev/null 2>&1
		AJS_STATUS=$?
		if [ ${AJS_STATUS} = "0" ]
		then
			echo JP1/AJS3-Managerの停止に成功しました。
			echo ReturnCode=${AJS_STATUS}
		else
			echo JP1/AJS3-Managerの停止に失敗しました。
			echo ReturnCode=${AJS_STATUS}
			return 1
		fi
	else
		echo JP1_AJS3_Managerは停止しています。
		echo ReturnCode=${STATUS}
	fi
	
	#戻り値初期化
	STATUS=0
	
	# JP1/BASEの起動を確認する
	/opt/jp1base/bin/jbs_spmd_status > /dev/null 2>&1
	STATUS=$?
	# 戻り値が8（停止）以外の場合は
	# JP1/BASEの停止を行う
	if [ ${STATUS} != "8" ]
	then
		echo JP1/BASEを停止します。
		echo ReturnCode=${STATUS}
		# JP1/BASEの停止を行う
		/etc/opt/jp1base/jbs_stop > /dev/null 2>&1
		BASE_STATUS=$?
		if [ ${BASE_STATUS} = "0" ]
		then
			echo JP1/BASEの停止に成功しました。
			echo ReturnCode=${BASE_STATUS}
		else
			echo JP1/BASEの停止に失敗しました。
			echo ReturnCode=${BASE_STATUS}
			return 1
		fi
	else
		echo JP1/BASEは停止しています。
		echo ReturnCode=${STATUS}
	fi
	
	return 0

}

function JP1_STATUS_IMPORT {

	# JP1/AJS3-Managerの定義情報を適用する
	/opt/jp1base/bin/jbssetcnf > ${JP1_STATUS_IMPORT} > /dev/null 2>&1
	JP1_STATUS=$?
	# 戻り値が0以外の場合はエラーのため、return 1を返す
	if [ ${JP1_STATUS} != '0'  ]
	then
		echo JP1定義適用処理に失敗しました。
		echo ReturnCode=${JP1_STATUS}
		return 1
	else
		echo JP1定義適用処理に成功しました。
		echo ReturnCode=${JP1_STATUS}
	fi

	return 0

}

function JP1_START {

	# JP1/BASEの起動を確認する
	/opt/jp1base/bin/jbs_spmd_status > /dev/null 2>&1
	STATUS=$?
	# 戻り値が0（起動）以外の場合は
	# JP1/BASEの起動を行う
	if [ ${STATUS} != "0" ]
	then
		echo JP1/BASEを起動します。
		echo ReturnCode=${STATUS}
		# JP1/BASEの起動を行う
		/etc/opt/jp1base/jbs_start > /dev/null 2>&1
		BASE_STATUS=$?
		if [ ${BASE_STATUS} = "0" ]
		then
			echo JP1/BASEの起動に成功しました。
			echo ReturnCode=${BASE_STATUS}
		else
			echo JP1/BASEの起動に失敗しました。
			echo ReturnCode=${BASE_STATUS}
			return 1
		fi
	else
		echo JP1/BASEは起動しています。
		echo ReturnCode=${STATUS}
	fi

	
	#戻り値初期化
	STATUS=0

	# JP1/AJS3-Managerの起動を確認する
	/opt/jp1ajs2/bin/jajs_spmd_status > /dev/null 2>&1
	STATUS=$?
	# 戻り値が0（起動）以外の場合は
	# JP1/AJS3-Managerの起動を行う
	if [ ${STATUS} != "0" ]
	then
		echo JP1_AJS3_Managerを起動します。
		echo ReturnCode=${STATUS}
		# JP1/AJS3-Managerの起動を行う
		/etc/opt/jp1ajs2/jajs_start > /dev/null 2>&1
		AJS_STATUS=$?
		if [ ${AJS_STATUS} = "0" ]
		then
			echo JP1/AJS3-Managerの起動に成功しました。
			echo ReturnCode=${AJS_STATUS}
		else
			echo JP1/AJS3-Managerの起動に失敗しました。
			echo ReturnCode=${AJS_STATUS}
			return 1
		fi
	else
		echo JP1_AJS3_Managerは起動しています。
		echo ReturnCode=${STATUS}
	fi

	return 0

}

function JP1_JOB_STATUS_IMPORT {

	# JP1/AJS3-ManagerのJOB定義を適用する
	/opt/jp1ajs2/bin/ajsdefine -f -F AJSROOT1 ${JOB_STATUS_IMPORT} > /dev/null 2>&1
	JOB_STATUS=$?
	# 戻り値が0以外の場合はエラーのため、return 1を返す
	if [ ${JOB_STATUS} != '0'  ]
	then
		echo JP1_JOB定義適用処理に失敗しました。
		echo ReturnCode=${JOB_STATUS}
		return 1
	else
		echo JP1_JOB定義適用処理に成功しました。
		echo ReturnCode=${JOB_STATUS}
	fi

	return 0

}

#########################################################################
#MAIN処理
#########################################################################

# 処理開始
echo JP1定義情報適用処理を開始します。

# MAIN処理開始
# JP1停止確認/停止処理実行
JP1_STOP
if [ $? != '0'  ]
then
	echo JP1停止処理に失敗しました。
	exit 1
fi

# JP1定義適用処理実行
JP1_STATUS_IMPORT
if [ $? != '0'  ]
then
	echo JP1定義適用処理に失敗しました。
	exit 1
fi

# JP1起動確認/起動処理実行
JP1_START
if [ $? != '0'  ]
then
	echo JP1起動処理に失敗しました。
	exit 1
fi

# JP1_JOB定義適用処理実行
JP1_JOB_STATUS_IMPORT
if [ $? != '0'  ]
then
	echo JP1_JOB定義適用処理に失敗しました。
	exit 1
fi

# 処理終了
echo JP1定義情報適用処理を終了します。

exit 0
