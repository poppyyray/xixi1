#!/bin/sh
###########################################################
# 関数名:outlog_func
#
# 機能:指定されたパスにシェル名.logの名前でログを作成し出力する
#
# 引数
# $1 MSGID
#
# $2 MSG引数
#
# 戻り値
#  0:正常
#  1:異常
#
# 前提条件:ログ出力パス環境変数${LOG_DIR}にパスが指定されていること
#
###########################################################
function outlog_func
{

    # ログ名が設定されていない場合呼ばれているシェルをログ名に使用
    if [ ! "${log_name}" ]; then
            shname=`basename ${0}`
            log_name=`echo ${shname} | sed "s/.sh//g"`
    fi

	shname=`basename ${0}`

    # ログが存在しない場合作成し権限を変更
    if [ ! -f ${LOG_DIR}/${log_name}.log ]; then
            touch ${LOG_DIR}/${log_name}.log
            chmod 777 ${LOG_DIR}/${log_name}.log
    fi

	error_id=`echo ${1} | cut -b4`

	if [ ${error_id} == "E" ]
	then
	        errorlevel="ERROR"
	elif [ ${error_id} == "W" ]
	then
	        errorlevel="WARNING"
	elif [ ${error_id} == "I" ]
	then
	        errorlevel="INFO"
	elif [ ${error_id} == "F" ]
	then
	        errorlevel="FATAL"
	elif [ ${error_id} == "D" ]
	then
	        errorlevel="DEBUG"
	else
	        echo "エラー出力関数の第一引数に誤りがあります。シェル名[${0}] 第一引数[${1}]"
		return 1
	fi

	logdate=`date "+%Y-%m-%d %H:%M:%S"`

	log_id_msg=`cat ${CONF_DIR}/message_jirau.conf | grep ${1}`
	if [ -z "${log_id_msg}" ]
	then
		echo ${logdate} ${errorlevel} ${shname} "CM-W01001" "メッセージID[${1}]が存在しません。" >> ${LOG_DIR}/${log_name}.log
		return 1
	fi

	PARM_CNT=$#
	# 引数の2個目から取得するために初期値を2としている
	MSG_CNT=2
	while (( ${MSG_CNT} <= ${PARM_CNT} ))
	do
		PARM_MSG=`eval echo "\\${${MSG_CNT}}"`

		#%sを引数に変換
		log_id_msg=`echo ${log_id_msg} | sed s@%s@"${PARM_MSG}"@`

		MSG_CNT=`expr $MSG_CNT + 1`
	done

	logmsg="${logdate} ${errorlevel} ${shname} ${log_id_msg}"

	echo ${logmsg} >> ${LOG_DIR}/${log_name}.log

	return 0
}

