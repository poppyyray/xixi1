#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ATTACHEMENT_ZIP.sh
# 業 務 名       ： なし
# 処理概要       ： FILEATTACHMENTファイルを圧縮する
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0             正常
#                   1             エラー
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： 
#
# 作成日付       ： 
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1       20014-07-29  LiuJian                規範化
# 2
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common_jirau.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC_JIRAU.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC_JIRAU.sh

outlog_func CM-I20001

export ATTACHEMENT_FILELIST_PATH=${TMP_DIR}

#tarディレクトリ名
export TAR_DIR_NAME=attachment

#作業ディレクトリ
export WORK_DIR=${TMP_DIR}/${TAR_DIR_NAME}

#mvコマンド実行結果を保存用一時ファイル
export RUN_RESULT=run_rtn.tmp
cat /dev/null > ${TMP_DIR}/${RUN_RESULT}

#入出金材料
if [ ! -d ${WORK_DIR}/CE ]
then
        mkdir -p ${WORK_DIR}/CE
fi
file_cnt=`cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep CE|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRAU_CSV_DIR}/CE
	mv -f `cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep CE|cut -f2 -d,` ${WORK_DIR}/CE >>${TMP_DIR}/${RUN_RESULT} 2>&1
	RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E20010 "CE" ${RC}
	fi
fi

#経費振替
if [ ! -d ${WORK_DIR}/CT ]
then
        mkdir -p ${WORK_DIR}/CT
fi
file_cnt=`cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep CT|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRAU_CSV_DIR}/CT
    mv -f `cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep CT|cut -f2 -d,` ${WORK_DIR}/CT >>${TMP_DIR}/${RUN_RESULT} 2>&1
	RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E20010 "CT" ${RC}
	fi
fi

#一般集金(手動)
if [ ! -d ${WORK_DIR}/GC ]
then
        mkdir -p ${WORK_DIR}/GC
fi
file_cnt=`cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep GC|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRAU_CSV_DIR}/GC
    mv -f `cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep GC|cut -f2 -d,` ${WORK_DIR}/GC >>${TMP_DIR}/${RUN_RESULT} 2>&1
	RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E20010 "GC" ${RC}
	fi
fi

#一般集金(エラー)
if [ ! -d ${WORK_DIR}/GE ]
then
        mkdir -p ${WORK_DIR}/GE
fi
file_cnt=`cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep GE|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRAU_CSV_DIR}/GE
    mv -f `cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep GE|cut -f2 -d,` ${WORK_DIR}/GE >>${TMP_DIR}/${RUN_RESULT} 2>&1
	RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E20010 "GE" ${RC}
	fi
fi

#入金データアンマッチ
if [ ! -d ${WORK_DIR}/UD ]
then
        mkdir -p ${WORK_DIR}/UD
fi
file_cnt=`cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep UD|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRAU_CSV_DIR}/UD
    mv -f `cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep UD|cut -f2 -d,` ${WORK_DIR}/UD >>${TMP_DIR}/${RUN_RESULT} 2>&1
	RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E20010 "UD" ${RC}
	fi
fi

#振込入金
if [ ! -d ${WORK_DIR}/BT ]
then
        mkdir -p ${WORK_DIR}/BT
fi
file_cnt=`cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep BT|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRAU_CSV_DIR}/BT
    mv -f `cat ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST}|grep BT|cut -f2 -d,` ${WORK_DIR}/BT >>${TMP_DIR}/${RUN_RESULT} 2>&1
	RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E20010 "BT" ${RC}
	fi
fi

cd ${TMP_DIR}

#ファイルをアーカイブする
tar -cpf ${ATTACHEMENT_JIRA_TAR} ${TAR_DIR_NAME}
RC=$?
if [ ${RC} != 0 ]
then
	outlog_func CM-E20005 ${RC}
	exit 1
fi

#ファイルを圧縮する
gzip -f ${ATTACHEMENT_JIRA_TAR}
RC=$?
if [ ${RC} != 0 ]
then
	outlog_func CM-E20006 ${RC}
	exit 1
fi

#圧縮ファイルを日付でコピー
cp -p ${ATTACHEMENT_JIRA_TAR}.gz ${ATTACH_BAK_DIR}/${ATTACHEMENT_JIRA_TAR}.gz.`date +%Y%m%d%H%M`
RC=$?
if [ ${RC} != 0 ]
then
	outlog_func CM-E20007 ${RC}
	exit 1
fi

#アーカイブの対象ファイルをバックアップする
cp -p ${ATTACHEMENT_FILELIST_PATH}/${ATTACHEMENT_FILELIST} ${ATTACH_BAK_DIR}/${ATTACHEMENT_FILELIST}.`date +%Y%m%d%H%M`
RC=$?
if [ ${RC} != 0 ]
then
	outlog_func CM-E20008 ${RC}
	exit 1
fi

#既存保存ディレクトリを削除
if [ -d ${WORK_DIR} ]
then
	rm -rf ${WORK_DIR}/CE/*
	rm -rf ${WORK_DIR}/CT/*
	rm -rf ${WORK_DIR}/GC/*
	rm -rf ${WORK_DIR}/GE/*
	rm -rf ${WORK_DIR}/UD/*
	rm -rf ${WORK_DIR}/BT/*
fi

outlog_func CM-I20002
