#!/bin/sh
#-----------------------------------------------------------------------
# (C) COPYRIGHT International Business Machines Corp. 2009
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#-----------------------------------------------------------------------
#
################################################################
# reindex.sh
# This script is called from jirau_start.sh.
#
# 1. Send a reindex request to the local JIRA.
#
# [ Update logs ]
# 2014/10/13 Yuan Zhiwei Initial
################################################################

################################
# SET PARAMETER
################################
. `dirname $0`/env

START_DIR=`echo $(cd $(dirname $0) && pwd)`
PROG_NAME=`basename $0`

if [[ "$VERBOSE" == "verbose" ]]; then
   # Output a detail log
   exec >> ${VERBOSE_LOG_DIR}/`basename $0`.log
   exec 2>&1
   set -x
else
   # Close stdout and stderr
   exec   2> /dev/null
   exec   1> /dev/null
   set +x
fi

echo "################################################################"
date
echo "################################################################"

################################
# MAIN
################################

RC=$SUCCESS

##########################################
# RE-INDEX
##########################################
cd ${REINDEX_WORK_DIR}

logger -i -p ${LOG_INFO} -t $PROG_NAME "[INFO] Re-index starts."

# Remove the wget download directory
if [ -d "${SERVER_PORT}" ]; then
   rm -rf "${SERVER_PORT}"
fi

# Remove the wget temporary files
if [ -f "cookies.txt" ]; then
   rm -f "cookies.txt"
fi

if [ -f "login.jsp" ]; then
   rm -f "login.jsp"
fi

wget --save-cookies cookies.txt --keep-session-cookies --post-data "os_username=${USER}&os_password=${PASSWORD}&os_cookie=true" ${LOGIN_URL}

rc=$?
if [ $rc != 0 ]; then
  logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Failed to execute wget(rc=$rc) for ${LOGIN_URL} (Please check at catalina.out)."
  RC=$FAIL
  exit $RC
fi

grep "seraph.os.cookie" "cookies.txt"
rc=$?
if [ $rc != 0 ]; then
  logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Failed to login correctly (Please check at catalina.out)."
  RC=$FAIL
  exit $RC
fi

wget --load-cookies cookies.txt --post-data 'Re-Index=Re-Index' --timeout=3600 --tries=1 -p "${REINDEX_URL}"

rc=$?
if [ $rc != 0 ]; then
  logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Failed to execute wget(rc=$rc) for ${REINDEX_URL} (Please check at catalina.out)."
  RC=$FAIL
  exit $RC
fi

ls ${REINDEX_RESULT_FILE}
rc=$?
if [ $rc = 0 ]; then
  # Succeeded to re-index
  proc_time_msec=`ls ${REINDEX_RESULT_FILE} | sed 's/.\+=\([0-9]\+\)/\1/'`
  # reindex異常場合(proc_time_msec = 0)
  if [ $proc_time_msec = 0 ]; then
     logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Failed to re-index (Please check at catalina.out)."
     RC=$FAIL
  else
     logger -i -p ${LOG_INFO} -t $PROG_NAME "[INFO] Re-index finished(${proc_time_msec} ms)."
  fi
else
  # Failed to re-index
  logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Failed to re-index (Please check at catalina.out)."
  RC=$FAIL
fi

logger -i -p ${LOG_INFO} -t $PROG_NAME "[INFO] Re-index ends."

exit $RC

