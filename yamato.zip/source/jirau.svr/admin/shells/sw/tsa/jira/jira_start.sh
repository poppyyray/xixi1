#!/bin/sh
#-----------------------------------------------------------------------
# (C) COPYRIGHT International Business Machines Corp. 2009
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#-----------------------------------------------------------------------
#
################################################################
# jira_start.sh
# This script is executed when jira-rg starts.
#
# 1. Start the JIRA.
# 2. Execute a jira indexing process.
#
# [ Update logs ]
# 2014/10/13 Yuan Zhiwei Initial
################################################################
# function: start reindex
startReindex() {  
   # Suppress duplicated reindex_checker
   # So if already reindex_checker process is running, kill it
   stopReindex
   
   sh ${START_DIR}/reindex.sh
}

# function: stop reindex
stopReindex() {
   pid=`ps aux | grep "reindex.sh" | grep -v grep | awk '{print $2}'`
   if [ ! -z "${pid:-}" ]; then
        kill -9 $pid
   fi
}

# function: delete lock files
deleteLockFiles() {
   for i in ${LOCK_FILES}; do
      if [ -f "$i" ]; then
         rm -f "$i"
      fi
   done
}

################################
# SET PARAMETER
################################
. `dirname $0`/env
export CT_MANAGEMENT_SCOPE=2

PROG_NAME=`basename $0`
START_DIR=`echo $(cd $(dirname $0) && pwd)`

logger -i -p ${LOG_INFO} -t ${PROG_NAME} "[INFO] Starting jira_start.sh"

if [[ "${VERBOSE}" == "verbose" ]]; then
   # Output a detail log
   exec >> ${VERBOSE_LOG_DIR}/`basename $0`.log
   exec 2>&1
   set -x
else
   # Close stdout and stderr
   exec   2> /dev/null
   exec   1> /dev/null
   set +x
fi

echo "################################################################"
date
echo "################################################################"

################################
# MAIN
################################
export JIRA_STARTUP_ERR_LOG=/admin/logs/ope/jira-startup-error.log
RC=$SUCCESS

##########################################
# START THE JIRA
##########################################

pid=`ps aux | grep org.apache.catalina.startup.Bootstrap | grep -v grep | awk '{print $2}'`
if [ -n "${pid:-}" ]; then 
    # Jira is already running.
    logger -i -p ${LOG_INFO} -t ${PROG_NAME} "[INFO] Start called. Jira(Update) is already running."
    echo "${PROG_NAME} Jira(Update) is already running."
    RC=$SUCCESS
    exit $RC
else
    deleteLockFiles
    cd "${JIRA_HOME}"/bin
    set -m
    JAVA_HOME="$JAVA_HOME" ./startup.sh 2>&1
    
    # startup.sh result check
    if [ $? -eq 1 ]; then
       logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Jira start failed"
       RC=$FAIL
       exit $RC
    fi
    
    sleep ${JIRA_STARTUP_WAIT_TIME}
    set +m
    
    #set error log name
    timestamp=`date "+%Y%m%d%H%M%S"`
    JIRA_STARTUP_ERR_LOG=${JIRA_STARTUP_ERR_LOG}_${timestamp}
    
    # MONITOR_URL access check
    wget_result=`wget -t1 -T ${TIMEOUT_SEC} -O /dev/null ${MONITOR_URL} 2>&1`
    return_code=$?
    
    case "$return_code" in
        "0" )
            echo $wget_result | grep "200 OK"
            cat_result=$?
            if [ $cat_result -eq 0 ]; then
                 
                 # system error check (MONITOR_ERROR_URL)
                 http_error_check_result=`wget -t1 -T ${TIMEOUT_SEC} -O /dev/null ${MONITOR_ERROR_URL}  2>&1`
                 http_error_check_rc=$?
                 
                 # http response code check
                 echo $http_error_check_result | grep "200 OK"
                 http_error_check_result_200=$?
                 
                # wget return code = 0 and http response code = 200
                if [  $http_error_check_rc -eq 0  ] && [ $http_error_check_result_200 -eq 0 ]; then
                    logger -i -p ${LOG_INFO} -t ${PROG_NAME} "[INFO] Started successfully."
                    RC=$SUCCESS

                else 
                    # output wget access log 
                    echo $http_error_check_result >> ${JIRA_STARTUP_ERR_LOG}
                    
                    # output error content of MONITOR_ERROR_URL
                    curl ${MONITOR_ERROR_URL} >> ${JIRA_STARTUP_ERR_LOG}
                    
                    logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Jira start failed"
                    RC=$FAIL
                fi

            else
                echo $wget_result >> ${JIRA_STARTUP_ERR_LOG}
                logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Jira start failed"
                RC=$FAIL
            fi
            ;;
        
        #other
        * )
            # output wget access log 
            echo $wget_result >> ${JIRA_STARTUP_ERR_LOG}
            
            logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Jira start failed"
            RC=$FAIL
            ;;
    esac
fi

##########################################
# RE-INDEX
##########################################
if [ $RC -eq 0 ] && [ $REINDEX_FLG -eq 1 ]; then
    startReindex
    RC=$?
fi

logger -i -p ${LOG_INFO} -t ${PROG_NAME} "[INFO] Endding jira_start.sh rc=$RC"

exit $RC