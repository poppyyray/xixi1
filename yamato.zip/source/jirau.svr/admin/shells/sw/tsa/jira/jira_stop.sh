#!/bin/sh
#-----------------------------------------------------------------------
# (C) COPYRIGHT International Business Machines Corp. 2009
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#-----------------------------------------------------------------------
#
################################################################
# jira_stop.sh
# This script is called when jira-rg stops.
# 1. Kill the JIRA
#
# [ Update logs ]
# 2014/10/13 Yuan Zhiwei Initial
################################################################

################################
# SET PARAMETER
################################
. `dirname $0`/env
export CT_MANAGEMENT_SCOPE=2

PROG_NAME=`basename $0`
logger -i -p ${LOG_INFO} -t $PROG_NAME "[INFO] Starting jira_stop.sh"

if [[ "$VERBOSE" == "verbose" ]]; then
   # Output a detail log
   exec >> ${VERBOSE_LOG_DIR}/`basename $0`.log
   exec 2>&1
   set -x
else
   # Close stdout and stderr
   exec   2> /dev/null
   exec   1> /dev/null
   set +x
fi

################################
# MAIN
################################

RC=$SUCCESS

##########################################
# STOP THE JIRA
##########################################
pid=`ps aux | grep org.apache.catalina.startup.Bootstrap | grep -v grep | awk '{print $2}'`
if [ -z "${pid:-}" ]; then
    logger -i -p ${LOG_INFO} -t $PROG_NAME "[INFO] Stop called. Jira is not running."
    echo "${PROG_NAME} Jira is not running."
    RC=$SUCCESS
    exit $RC
fi

if [ -f "${JIRA_HOME}/logs/gc.log" ]; then
    gc_log=${JIRA_HOME}/logs/gc.log.`/bin/date "+%Y%m%d%H%M%S"`
    cp ${JIRA_HOME}/logs/gc.log ${gc_log}
    logger -i -p ${LOG_INFO} -t $PROG_NAME "[INFO] GC log(${gc_log}) was copied."
fi

# Output java thread dump
pid=`ps aux | grep org.apache.catalina.startup.Bootstrap | grep -v grep | awk '{print $2}'` 
kill -3 $pid 

retry=6
JAVA_HOME="$JAVA_HOME" "$JIRA_HOME"/bin/shutdown.sh > /dev/null 2>&1
if [ $? -eq 0 ]; then
    pid=`ps aux | grep org.apache.catalina.startup.Bootstrap | grep -v grep | awk '{print $2}'`
    while [ ! -z "${pid:-}" -a "$retry" -gt 0 ]; do
	sleep 10
	retry=$(($retry -1))
	pid=`ps aux | grep org.apache.catalina.startup.Bootstrap | grep -v grep | awk '{print $2}'`
    done

    pid=`ps aux | grep org.apache.catalina.startup.Bootstrap | grep -v grep | awk '{print $2}'`
    if [ ! -z "${pid:-}" ]; then
        logger -i -p ${LOG_WARN} -t $PROG_NAME "[WARN] Kill Jira (Update: $pid)."
        kill -9 $pid > /dev/null 2>&1
    fi
    logger -i -p ${LOG_INFO} -t $PROG_NAME "[INFO] Stopped successfully."
    echo "${PROG_NAME} Stopped successfully."
    RC=$SUCCESS
else
    logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Failed to stop."
    echo "${PROG_NAME} Failed to stop."
    RC=$FAIL
fi

logger -i -p ${LOG_INFO} -t ${PROG_NAME} "[INFO] Endding jira_stop.sh"

exit $RC
