#!/bin/sh
#-----------------------------------------------------------------------
# (C) COPYRIGHT International Business Machines Corp. 2009
# All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#-----------------------------------------------------------------------
#
################################################################
# jira_monitor.sh
# This script is defined as a monitor script of JIRA_RG.
# 
# 1.Monitor the JIRA process
#
# [ Updated logs ]
# 2014/10/13 Yuan Zhiwei Initial
################################################################

################################
# SET PARAMETER
################################
. `dirname $0`/env
export CT_MANAGEMENT_SCOPE=2
export HTTP_CHECK_RESULT_LOG=/admin/logs/ope/http-request-time.log

PROG_NAME=`basename $0`
START_DIR=`echo $(cd $(dirname $0) && pwd)`

logger -i -p ${LOG_DEBUG} -t $PROG_NAME "[DEBUG] Starting jira_monitor.sh"

if [[ "$VERBOSE" == "verbose" ]]; then
   # Output a detail log
   exec >> ${VERBOSE_LOG_DIR}/`basename $0`.log
   exec 2>&1
   set -x
else
   # Close stdout and stderr
   exec   2> /dev/null
   exec   1> /dev/null
   set +x
fi

echo "################################################################"
echo `basename $0`
date
echo "################################################################"

RC=$ONLINE

############################
# JIRA STARTUP CHECK
############################
pid=`ps aux | grep ${START_DIR}/jira_start.sh | grep -v grep | awk '{print $2}'`
if [ -n "${pid:-}" ]; then 
    logger -i -p ${LOG_INFO} -t $PROG_NAME "[INFO] Jira is currently starting up(RC=5)."
    exit $PENDING_ONLINE
fi

############################
# JIRA STOP CHECK
############################
pid=`ps aux | grep ${START_DIR}/jira_stop.sh | grep -v grep | awk '{print $2}'`
if [ -n "${pid:-}" ]; then 
    logger -i -p ${LOG_INFO} -t $PROG_NAME "[INFO] Jira is currently stopping(RC=6)."
    exit $PENDING_OFFLINE
fi

############################
# GET JIRA STATUS
############################
pid=`ps aux | grep org.apache.catalina.startup.Bootstrap | grep -v grep | awk '{print $2}'`
if [ -n "${pid:-}" ]; then 
    logger -i -p ${LOG_DEBUG} -t $PROG_NAME "[DEBUG] Jira is running."
else
    logger -i -p ${LOG_DEBUG} -t $PROG_NAME "[DEBUG] Jira is not running. RG status is Offline(RC=2)."
    exit $OFFLINE
fi

##########################################
# HTTP CHECK
##########################################
echo -n `date '+%Y/%m/%d %H:%M:%S'` >> ${HTTP_CHECK_RESULT_LOG}

#check MONITOR_URL
wget_result=`wget -t1 -T ${TIMEOUT_SEC} -O /dev/null ${MONITOR_URL} 2>&1`
return_code=$?

echo $wget_result >> ${HTTP_CHECK_RESULT_LOG}

echo ' - '`date '+%H:%M:%S'` >> ${HTTP_CHECK_RESULT_LOG}

case "$return_code" in
    '0')
        # http response code check
        echo $wget_result | grep "200 OK"
        cat_result=$?
        
        if [ $cat_result -eq 0 ]; then
            logger -i -p ${LOG_DEBUG} -t $PROG_NAME "[DEBUG] Jira returns valid response code. RG status is Online(RC=1)."
            RC=$ONLINE   
        else
            logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Jira returns error response data. RG status is Failed offline(RC=3)."
            RC=$FAILED_OFFLINE
        fi
        ;;
        
    #system error (500..)
    '8')
        logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Jira returns invalid response data. RG status is Failed offline(RC=3)."
        RC=$FAILED_OFFLINE
        ;;
        
    #access fail (404..)
    '4')
        logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] Jira returns no data...timeout. RG status is Failed offline(RC=3)."
        RC=$FAILED_OFFLINE
        ;;

    #other   
    *)
        logger -i -p ${LOG_ERR} -t $PROG_NAME "[ERR] wget error occurred. RG status is Unknown(RC=0)."
        RC=$UNKNOWN
        ;;
esac

exit $RC
