#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： version_up_biz.sh
# 業 務 名       ： バージョン管理
# 処理概要       ： バージョン管理用ファイルの作成
# 特記事項       ：
# パラメータ     ： 0 バージョン番号
#                   1 /t
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Yang Xi
#
# 作成日付       ： 2011-03-04
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2011-03-04 Yang Xi                新規作成
# 2       2014-09-02 Liu Jian               20140409_ヤマト次期システム移行調査 
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#出力ディレクトリ
output_path='/shared/jira_u/bizbrowser/crs/integrationBiz/'

#パラメータのチェック
if [ $# -ne 1  -a $# -ne 2 ]
then
	echo "パラメータ不正[入力したパラメータの個数不正]"
	exit 1
fi

#入力可能な文字チェック
_tmp=`echo $1 | sed s/[A-Za-z0-9]//g`
_tmp=`echo ${_tmp} | sed s/'\-'//g`
_tmp=`echo ${_tmp} | sed s/'\*'//g`
_tmp=`echo ${_tmp} | sed s/'\,'//g`
_tmp=`echo ${_tmp} | sed s/'\.'//g`
_tmp=`echo ${_tmp} | sed s/'\~'//g`
if [ "${_tmp}" != ""  ]
then
	echo "パラメータ不正[英字A-Z、英字a-z、数字0-9、符号-*,.~を入力してください]"
	exit 1
fi

#パラメータの長さチェック
_len=`expr length $1`
if [ ${_len} -gt 20  ]
then
	echo "パラメータ不正[パラメータの長さは２０桁を超えました]"
	exit 1
fi

#パターン１
if [ $# -eq 1 ]
then
	echo "<%@page contentType=\"Application/crs; charset=Windows-31J\" %>" > "${output_path}version.jsp"
	echo "String cacheVersion=\"${1}\";" >> "${output_path}version.jsp"
	echo "String cacheVersion=\"${1}\";" > "${output_path}version.crs"
fi

#パターン２
dt=`date "+%m%d%H%M"`
if [ $# -eq 2  ]
then
	if [ $2 != "/t" ] 
	then
		echo "パラメータ不正[二つ目パラメータに/tを入力してください]"
		exit 1
	else
		echo "String cur_version = \"${1}.${dt}\";" > "${output_path}version.jsp"
		echo "String cacheVersion=\"${1}.${dt}\";" > "${output_path}version.crs"
	fi
fi

exit 0


