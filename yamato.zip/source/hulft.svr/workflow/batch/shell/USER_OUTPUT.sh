#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： USER_OUTPUT.sh
# 業 務 名       ： 送信ファイル生成処理（ユーザエクスポート）
# 処理概要       ： ユーザエクスポートの送信ファイル生成処理を行う
# 特記事項       ： なし
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： J.Yamada
#
# 作成日付       ： 2009-07-23
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-23 J.Yamada                新規作成
# 2 2014-07-29 Yuan Zhiwei                   HULFTとJP1サーバの切り分け
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
# 環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common_hulft.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC_HULFT.sh ]
then
	echo "共通関数ファイルが存在しません" 
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC_HULFT.sh

#########################################################################
# OUTPUT処理を行う前に対象のファイルを削除する
#########################################################################
# 出力ログ名設定
export log_name=${USER_OUTPUT_LOG}

outlog_func UM-I03001

cp -f ${CONF_DIR}/USEROUT01 ${MASTER_FILE_PATH}/USEROUT01
if [ $? != '0' ]
then
	outlog_func UM-E03003 "${CONF_DIR}/USEROUT01"
	exit 1
fi
cp -f ${CONF_DIR}/USEROUT02 ${MASTER_FILE_PATH}/USEROUT02
if [ $? != '0' ]
then
	outlog_func UM-E03004 "${CONF_DIR}/USEROUT02"
	exit 1
fi
cp -f ${CONF_DIR}/USEROUT03 ${MASTER_FILE_PATH}/USEROUT03
if [ $? != '0' ]
then
	outlog_func UM-E03005 "${CONF_DIR}/USEROUT03"
	exit 1
fi
/usr/local/HULFT/bin/utlsend -f WFS015
if [ $? != '0' ]
then
	outlog_func UM-E03006
	exit 1
fi
/usr/local/HULFT/bin/utlsend -f WFS016
if [ $? != '0' ]
then
	outlog_func UM-E03007
	exit 1
fi
/usr/local/HULFT/bin/utlsend -f WFS017
if [ $? != '0' ]
then
	outlog_func UM-E03008
	exit 1
fi

outlog_func UM-I03002

exit 0