#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： USERIN01_MAIN_FLOW.sh
# 業 務 名       ： フロー処理（ユーザエクスポート）
# 処理概要       ： ユーザエクスポートの処理を行うメインフロー
# 特記事項       ： なし
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################

#
################### 改定履歴       ########################
# 作成者         ： J.Yamada
#
# 作成日付       ： 2009-07-23
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2009-07-23 J.Yamada                新規作成
# 2 1.2.0 2010-06-28 JingWei.Zhou            ファイル受信完了確認処理追加
# 3 1.3.0 2014-07-29 Yuan Zhiwei             HULFTとJP1サーバの切り分け
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
# 環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common_hulft.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC_HULFT.sh ]
then
	echo "共通関数ファイルが存在しません" 
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC_HULFT.sh


# 出力ログ名設定
export log_name=${USER_MAIN_FLOW_LOG}

# PPバックファイル設定
USERIN01BK=${PPFILE_BACKUP_DIR}/${IF_syain_master}.`date +%Y%m%d%H%M`
USERIN02BK=${PPFILE_BACKUP_DIR}/${IF_shain_shozoku_master}.`date +%Y%m%d%H%M`
USERIN03BK=${PPFILE_BACKUP_DIR}/${IF_ninmei_level}.`date +%Y%m%d%H%M`

outlog_func UM-I01001

#########################################################################
# I/Fファイル受信カウンタファイル生成および受信完了確認
#########################################################################
touch ${TMP_DIR}/USERIN01_TRANSFER_OVER.`date +%Y%m%d`
if [ ! -f ${TMP_DIR}/USERIN02_TRANSFER_OVER.`date +%Y%m%d` ]
then
	outlog_func UM-I01220 ${IF_shain_shozoku_master}
	exit 0
fi
if [ ! -f ${TMP_DIR}/USERIN03_TRANSFER_OVER.`date +%Y%m%d` ]
then
	outlog_func UM-I01220 ${IF_ninmei_level}
	exit 0
fi

#########################################################################
# I/Fファイルの有無確認
#########################################################################

# 社員マスタファイルの存在確認
if [ ! -f "${MASTER_FILE_PATH}/${IF_syain_master}" ]
then
	outlog_func UM-I01003 ${IF_syain_master}
	exit 0
fi

# 社員所属マスタファイルの存在確認
if [ ! -f "${MASTER_FILE_PATH}/${IF_shain_shozoku_master}" ]
then
	outlog_func UM-I01009 ${IF_shain_shozoku_master}
	exit 0
fi

# 任命レベル情報ファイルの存在確認
if [ ! -f "${MASTER_FILE_PATH}/${IF_ninmei_level}" ]
then
	outlog_func UM-I01010 ${IF_ninmei_level}
	exit 0
fi



########################################################################
# USERIN01ファイル転送関数(共通関数)
#
# 引数１:HULFT送信先のフォルダパス、及びファイル名
# 引数２:バックアップフォルダパス、及びバックアップファイル名
#########################################################################
IF_FILE_TRANSMISSION ${MASTER_FILE_PATH}/${IF_syain_master} ${USERIN01BK}
RC=$?
if [ ${RC} != '0' ]
then
	outlog_func UM-E01016
	exit 1
fi
########################################################################
# USERIN02ファイル転送関数(共通関数)
#
# 引数１:HULFT送信先のフォルダパス、及びファイル名
# 引数２:バックアップフォルダパス、及びバックアップファイル名
#########################################################################
IF_FILE_TRANSMISSION ${MASTER_FILE_PATH}/${IF_shain_shozoku_master} ${USERIN02BK}
RC=$?
if [ ${RC} != '0' ]
then
	outlog_func UM-E01017
	exit 1
fi
########################################################################
# USERIN03ファイル転送関数(共通関数)
#
# 引数１:HULFT送信先のフォルダパス、及びファイル名
# 引数２:バックアップフォルダパス、及びバックアップファイル名
#########################################################################
IF_FILE_TRANSMISSION ${MASTER_FILE_PATH}/${IF_ninmei_level} ${USERIN03BK}
RC=$?
if [ ${RC} != '0' ]
then
	outlog_func UM-E01018
	exit 1
fi


# 社員マスタファイルのファイル名チェック
REMOTE_EXEC ${JP1_CIP} "head -1 ${USERIN01BK}"
if [ $? != '0' ]
then
    outlog_func UM-E01222 ${JP1_CIP} ${USERIN01BK}
    exit 1
fi
file_name_01=`cat ${REMOTE_EXEC_FILE}`
file_name_01=`echo ${file_name_01} | sed -e "s/\r//"`
file_name_01=`echo ${file_name_01} | sed -e "s/ //"`
if [ "${file_name_01}" != "${IF_syain_master}" ]
then
	outlog_func UM-E01007 ${IF_syain_master}
	exit 1
fi

# 社員所属マスタファイルのファイル名チェック
REMOTE_EXEC ${JP1_CIP} "head -1 ${USERIN02BK}"
if [ $? != '0' ]
then
    outlog_func UM-E01222 ${JP1_CIP} ${USERIN02BK}
    exit 1
fi
file_name_02=`cat ${REMOTE_EXEC_FILE}`
file_name_02=`echo ${file_name_02} | sed -e "s/\r//"`
file_name_02=`echo ${file_name_02} | sed -e "s/ //"`
if [ "${file_name_02}" != "${IF_shain_shozoku_master}" ]
then
	outlog_func UM-E01012 ${IF_shain_shozoku_master}
	exit 1
fi

# 任命レベル情報ファイルのファイル名チェック
REMOTE_EXEC ${JP1_CIP} "head -1 ${USERIN03BK}"
if [ $? != '0' ]
then
    outlog_func UM-E01222 ${JP1_CIP} ${USERIN03BK}
    exit 1
fi
file_name_03=`cat ${REMOTE_EXEC_FILE}`
file_name_03=`echo ${file_name_03} | sed -e "s/\r//"`
file_name_03=`echo ${file_name_03} | sed -e "s/ //"`
if [ "${file_name_03}" != "${IF_ninmei_level}" ]
then
	outlog_func UM-E01013 ${IF_ninmei_level}
	exit 1
fi

# 社員マスタファイルの件数チェック
REMOTE_EXEC ${JP1_CIP} "head -2 ${USERIN01BK} | tail -1"
if [ $? != '0' ]
then
    outlog_func UM-E01222 ${JP1_CIP} ${USERIN01BK}
    exit 1
fi
file_lines_01=`cat ${REMOTE_EXEC_FILE}`
file_lines_01=`echo ${file_lines_01} | sed -e "s/\r//"`
file_lines_01=`echo ${file_lines_01} | sed -e "s/ //"`   
file_lines_01=`expr ${file_lines_01} + 0`
REMOTE_EXEC ${JP1_CIP} "wc -l ${USERIN01BK} | cut -d ' ' -f 1"
if [ $? != '0' ]
then
    outlog_func UM-E01222 ${JP1_CIP} ${USERIN01BK}
    exit 1
fi
_line_cnt=`cat ${REMOTE_EXEC_FILE}`
_line_cnt=`expr ${_line_cnt} - 3`
if [ ${file_lines_01} != ${_line_cnt} ]
then
	outlog_func UM-E01008 ${IF_syain_master}
	exit 1
fi

# 社員所属マスタファイルの件数チェック
REMOTE_EXEC ${JP1_CIP} "head -2 ${USERIN02BK} | tail -1"
if [ $? != '0' ]
then
    outlog_func UM-E01222 ${JP1_CIP} ${USERIN02BK}
    exit 1
fi
file_lines_02=`cat ${REMOTE_EXEC_FILE}`
file_lines_02=`echo ${file_lines_02} | sed -e "s/\r//"`
file_lines_02=`echo ${file_lines_02} | sed -e "s/ //"`   
file_lines_02=`expr ${file_lines_02} + 0` 
REMOTE_EXEC ${JP1_CIP} "wc -l ${USERIN02BK} | cut -d ' ' -f 1"
if [ $? != '0' ]
then
    outlog_func UM-E01222 ${JP1_CIP} ${USERIN02BK}
    exit 1
fi
_line_cnt=`cat ${REMOTE_EXEC_FILE}`
_line_cnt=`expr ${_line_cnt} - 3`
if [ ${file_lines_02} != ${_line_cnt} ]
then
	outlog_func UM-E01014 ${IF_shain_shozoku_master}
	exit 1
fi

# 任命レベル情報ファイルの件数チェック
REMOTE_EXEC ${JP1_CIP} "head -2 ${USERIN03BK} | tail -1"
if [ ${RC} != '0' ]
then
    outlog_func UM-E01222 ${JP1_CIP} ${USERIN03BK}
    exit 1
fi
file_lines_03=`cat ${REMOTE_EXEC_FILE}`
file_lines_03=`echo ${file_lines_03} | sed -e "s/\r//"`
file_lines_03=`echo ${file_lines_03} | sed -e "s/ //"`    
file_lines_03=`expr ${file_lines_03} + 0`
REMOTE_EXEC ${JP1_CIP} "wc -l ${USERIN03BK} | cut -d ' ' -f 1"
if [ $? != '0' ]
then
    outlog_func UM-E01222 ${JP1_CIP} ${USERIN03BK}
    exit 1
fi
_line_cnt=`cat ${REMOTE_EXEC_FILE}`
_line_cnt=`expr ${_line_cnt} - 3`
if [ ${file_lines_03} != ${_line_cnt} ]
then
	outlog_func UM-E01015 ${IF_ninmei_level}
	exit 1
fi

#########################################################################
# JP1起動トリガーファイル作成
#########################################################################
# JP1起動トリガーファイルの生成
# 引数1トリガーファイル名
# 引数2エラーコード
# 引数3インフォメーションコード
JP1_TRIGER_FL ${JP1_TRIGER_FL_UM} UM-E01020 UM-I01019
if [ $? != '0' ]
then
	outlog_func UM-E01021
	exit 1
fi

#########################################################################
# # I/Fファイル受信カウンタファイル削除
#########################################################################
rm -f ${TMP_DIR}/USERIN01_TRANSFER_OVER.`date +%Y%m%d`
rm -f ${TMP_DIR}/USERIN02_TRANSFER_OVER.`date +%Y%m%d`
rm -f ${TMP_DIR}/USERIN03_TRANSFER_OVER.`date +%Y%m%d`

outlog_func UM-I01002

exit 0

