#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： USER_OUTPUT_CHECK.sh
# 業 務 名       ： ログチェック処理
# 処理概要       ： CSV定義ファイルから必要なチェック項目を読込め、
#                   パラメタにより、指定ログの想定文言が存在するか
#                   どうかチェックする
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0　　         正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： Tang Xiaodong
#
# 作成日付       ： 2011-11-03
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1初版   2011-11-03 Tang Xiaodong          新規作成
# 2改修   2014-07-29 Yuan Zhiwei            HULFTとJP1サーバの切り分け
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# ----
# 共通環境変数設定
# ----
_exec_ksh=/workflow/batch/ini/batch_common_hulft.conf
if [ ! -f ${_exec_ksh} ]
then
	echo "環境設定ファイルが存在しません"
	exit 1
fi
. ${_exec_ksh}

# ----
# 共通関数呼び出し
# ----
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC_HULFT.sh ]
then
	echo "共通関数ファイルが存在しません"
	exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC_HULFT.sh

###############################################################################
# main処理開始
###############################################################################
# 開始メッセージ
outlog_func MA-I00401

# シェル名を取得する
shname="USER_OUTPUT.sh"

# ログファイル名を取得する
logfile="/workflow/batch/logs/USER_OUTPUT.log"

# チェック文言を取得する
text="UM-I03002"
	
# 時間帯を取得する
minutes="20"

# ログファイルのチェック
if [ ! -s ${logfile} ]
then
	outlog_func MA-E00403 "${logfile}"
	exit 1
fi

logtext=`tail -n 1 ${logfile}`

# ログ日時のチェック（ログ日時が今の時刻前＜minutes＞分より早い場合、エラー）
time1=`date +%s --date="-$minutes minute"`
logtimetext="${logtext:0:19}"
logtime=`date -d "${logtimetext}" +%s`
if [ $logtime -lt $time1 ]
then
	# 想定文言不存在メッセージ
	outlog_func MA-E00404 "${shname}"
    exit 1
fi

# ログ文言のチェック
if [ "${logtext/$text}" = "${logtext}" ]
then
	# 想定文言不存在メッセージ
	outlog_func MA-E00404 "${shname}"
	exit 1
fi

# 想定文言存在メッセージ
outlog_func MA-I00402 "${shname}" "${logtimetext}"


# 終了メッセージ
outlog_func MA-I00403

exit 0