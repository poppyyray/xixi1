#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： SHOHYO_MAIN_FLOW_TEMP.sh
# 業 務 名       ： 証憑データ登録
# 処理概要       ：   1. 証憑データファイルの個人番号が6桁から8桁に変換する。
#				    2.証憑データ登録ファイルSCANディレクトリ
#                     からSCANBKディレクトリに移動
#                   3.JP1起動トリガーファイルの生成
# 特記事項       ： 起動トリガー：HULFTにより起動
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#                   1             処理異常
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： yuanrui
#
# 作成日付       ： 2016-11-10
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2016-11-10 yuanrui               新規作成
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common_hulft.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
. ${SHELL_DIR}/BATCH_COMMON_FUNC_HULFT.sh

# ログファイル設定
createlogfile ${0}
log_main_name=`basename ${0} | sed "s/.sh//g"`

#########################################################################

# ---- 
# 業務別環境変数設定
# ----

_FILE_Shohyo_BAK=${SCANFILE_BACKUP_DIR}/${FILE_Shohyo}.`date +%Y%m%d%H%M%S%N`	#証憑SCANBKファイル名

#########################################################################
#MAIN関数
#########################################################################
function MAIN {

	# 証憑データファイルの存在確認をし、証憑データが存在する場合は
	# 証憑データファイルのバックアップを作成する
	if [ -f ${SCAN_FILE_PATH}/${FILE_Shohyo} ]
	then
		
		# 証憑データファイルの2行目の長さを取得
		length=`sed -n '2p' ${SCAN_FILE_PATH}/${FILE_Shohyo} | wc -L`
		
		if [ ${length} == 127 ]					
		then					
			# 証憑データファイルの個人番号が6桁から8桁に変換する。	
			sed -i 's/^\([0-9]\{4\}......\)\([0-9]\{6\}\)/\100\2/' ${SCAN_FILE_PATH}/${FILE_Shohyo}
			sed -i 's/^\([0-9]\{4\}......\)\([ ]\{6\}\)/\1  \2/' ${SCAN_FILE_PATH}/${FILE_Shohyo}
			if [ $? -eq 0 ]
			then
				echo `date "+%Y-%m-%d %H:%M:%S"` INFO SHOHYO_MAIN_FLOW_TEMP.sh SH-I01003 [[証憑データフロー処理] 証憑データの個人番号が8桁に変換されました。]  >> ${LOG_DIR}/${log_name}.log
			else
				echo `date "+%Y-%m-%d %H:%M:%S"` INFO SHOHYO_MAIN_FLOW_TEMP.sh SH-E01023 [[証憑データフロー処理] 証憑データの個人番号の8桁に変換失敗しました。] >> ${LOG_DIR}/${log_name}.log
			fi
		fi					
		
		# 証憑データファイルのSCANディレクトリからSCANBKディレクトリに
		# %Y%m%d%H%M形式にてMV
		IF_FILE_TRANSMISSION ${SCAN_FILE_PATH}/${FILE_Shohyo} ${_FILE_Shohyo_BAK}
		STATUS=$?	# 戻り値
		# 戻り値が0以外の場合はエラーのため、return 1を返す
		if [ ${STATUS} != '0'  ]
		then
			outlog_func SH-E01024 ${_FILE_Shohyo_BAK}
			return 1
		fi
	else
		# 証憑データファイルが存在しない場合はメッセージを出力し処理終了
    		outlog_func SH-W02003 ${FILE_Shohyo}
    		return 0
	fi
	return 0
}

#########################################################################
#MAIN処理
#########################################################################
#出力ログ名設定
export log_name=${SHOHYO_MAIN_FLOW_LOG}

# 処理開始
outlog_func SH-I01001

# MAIN処理開始 
MAIN
if [ $? != '0'  ]
then
	outlog_func SH-E01003
	exit 1
fi

# JP1起動トリガーファイルの生成
# 引数1トリガーファイル名
# 引数2エラーコード
# 引数3インフォメーションコード
JP1_TRIGER_FL ${JP1_TRIGER_FL_SH} SH-E01026 SH-I01025
if [ $? != '0'  ]
then
	outlog_func SH-E01003
	exit 1
fi

# 処理完了
outlog_func SH-I01002

exit 0

