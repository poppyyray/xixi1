#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： BATCH_COMMON_FUNC_HULFT.sh
# 業 務 名       ： 共通処理
# 処理概要       ： 共通処理
# 特記事項       ： 
# パラメータ     ： なし
# リターンコード ： なし
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： 
#
# 作成日付       ：
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0                                   新規作成
# 2 1.0.1 2014-07-30 Yuan Zhiwei            HULFTとJP1サーバの切り分け
# 3
# 4
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################
#
###########################################################
# 関数名:outlog_func
#
# 機能:指定されたパスにシェル名.logの名前でログを作成し出力する
#
# 引数
# $1 MSGID
#
# $2 MSG引数
#
# 戻り値
#  0:正常
#  1:異常
#
# 前提条件:ログ出力パス環境変数${LOG_DIR}にパスが指定されていること
#
###########################################################
function outlog_func
{

    # ログ名が設定されていない場合呼ばれているシェルをログ名に使用
    if [ ! "${log_name}" ]; then
            shname=`basename ${0}`
            log_name=`echo ${shname} | sed "s/.sh//g"`
    fi

	shname=`basename ${0}`

    # ログが存在しない場合作成し権限を変更
    if [ ! -f ${LOG_DIR}/${log_name}.log ]; then
            touch ${LOG_DIR}/${log_name}.log
            chmod 777 ${LOG_DIR}/${log_name}.log
    fi

	error_id=`echo ${1} | cut -b4`

	if [ ${error_id} == "E" ]
	then
	        errorlevel="ERROR"
	elif [ ${error_id} == "W" ]
	then
	        errorlevel="WARNING"
	elif [ ${error_id} == "I" ]
	then
	        errorlevel="INFO"
	elif [ ${error_id} == "F" ]
	then
	        errorlevel="FATAL"
	elif [ ${error_id} == "D" ]
	then
	        errorlevel="DEBUG"
	else
	        echo "エラー出力関数の第一引数に誤りがあります。シェル名[${0}] 第一引数[${1}]"
		return 1
	fi

	logdate=`date "+%Y-%m-%d %H:%M:%S"`

	log_id_msg=`cat ${CONF_DIR}/message_hulft.conf | grep ${1}`
	if [ -z "${log_id_msg}" ]
	then
		echo ${logdate} ${errorlevel} ${shname} "CM-W01001" "メッセージID[${1}]が存在しません。" >> ${LOG_DIR}/${log_name}.log
		return 1
	fi

	PARM_CNT=$#
	# 引数の2個目から取得するために初期値を2としている
	MSG_CNT=2
	while (( ${MSG_CNT} <= ${PARM_CNT} ))
	do
		PARM_MSG=`eval echo "\\${${MSG_CNT}}"`

		#%sを引数に変換
		log_id_msg=`echo ${log_id_msg} | sed s@%s@"${PARM_MSG}"@`

		MSG_CNT=`expr $MSG_CNT + 1`
	done

	logmsg="${logdate} ${errorlevel} ${shname} ${log_id_msg}"

	echo ${logmsg} >> ${LOG_DIR}/${log_name}.log

	return 0
}



###############################################################################
# MAIN_FLOW用 ログファイル作成関数
# 引数１：実行プログラム名
###############################################################################
function createlogfile
{
	# ログ名の設定
	local sh_name=`basename ${0}`
	local log_main_name=`echo ${sh_name} | sed "s/.sh//g"`

	# ログが存在しない場合作成し権限を変更
	if [ ! -f ${LOG_DIR}/${log_main_name}.log ]; then
   		touch ${LOG_DIR}/${log_main_name}.log
    	chmod 777 ${LOG_DIR}/${log_main_name}.log
	fi

	return 0
}

################################################################################
# TRIGER_FL（アーカイブ処理使用）
# 引数１：JP1起動トリガーファイル名を指定
################################################################################
function JP1_TRIGER_FL {

	# JP1起動ファイル
	TRIGER_FL=$1

	# ERR_ID
	ERR_ID=$2

	# INF_ID
	INF_ID=$3

	# JP1起動トリガーファイル生成
	REMOTE_EXEC ${JP1_CIP} "touch ${TRIGER_FL}"
	STATUS=$?
	# 戻り値が0以外の場合はエラーのため、return 1を返す
	if [ ${STATUS} != '0'  ]
	then
		outlog_func ${ERR_ID} ${TRIGER_FL}
		return 1
	else
		outlog_func ${INF_ID} ${TRIGER_FL}
	fi

	return 0
}

#########################################################################
# I/Fファイル転送関数
#
# 関数名： IF_FILE_TRANSMISSION
#
# 機能： HULFTから送信されたI/Fファイルをバックアップフォルダへ転送する
#
# 戻り値：  0:正常
#           1:異常
#
# 引数１：HULFT送信先のフォルダパス、及びファイル名
#
# 引数２：バックアップフォルダパス、及びバックアップファイル名
#
#########################################################################
function IF_FILE_TRANSMISSION {
	HULFT_IF_FILE=$1
	BKUP_IF_FILE=$2

	# I/Fファイルの存在確認をし、I/Fファイルが存在する場合は
	# I/Fファイルのバックアップを作成する
	if [ -f "${HULFT_IF_FILE}" ]
	then
		# HULFT送信先のファイルパスからバックアップフォルダパスに
		# %Y%m%d%H%M形式にてMV
		REMOTE_COPY ${HULFT_IF_FILE} ${JP1_CIP}:${BKUP_IF_FILE}
		STATUS=$?	# 戻り値
		# 戻り値が0以外の場合はエラーのため、return 1を返す
		if [ ${STATUS} != '0'  ]
		then
			outlog_func CM-E01001 ${BKUP_IF_FILE}
			return 1
		fi
		outlog_func CM-I01003 ${HULFT_IF_FILE} ${BKUP_IF_FILE}
		rm -f ${HULFT_IF_FILE}
		STATUS=$? # 戻り値
		if [ ${STATUS} != '0'  ]
		then
			outlog_func CM-W01004 ${BKUP_IF_FILE}
		fi
	else
		# I/Fファイルが存在しない場合はメッセージを出力し処理終了
    	outlog_func CM-E01002 ${HULFT_IF_FILE}
    	return 0
	fi
	return 0
}

#########################################################################
# rshコマンドはsshで置き換える
# 関数名：REMOTE_EXEC
# 機能：リモートでシェルを実行する
# 引数１：対象IP
# 引数２：パスとシェル名
# 戻り値：０－正常
#	 	1－異常
#########################################################################
function REMOTE_EXEC {

	# 対象IP
	IP=$1
	
	# シェル名
	SH_NAME=$2
	
	# 臨時メッセージ出力ログ
	export REMOTE_EXEC_FILE=${TMP_DIR}/`basename ${0}`_ssh_result_`date +%Y%m%d`.txt
	
	# リモートシェル実行
	ssh ${IP} "${SH_NAME}" > ${REMOTE_EXEC_FILE} 2>&1
	RC=$?
	
	# 戻り値が0以外の場合はエラー
	if [ ${RC} != '0' ]
	then
		outlog_func CM-E99028 ${IP} ${SH_NAME} ${RC} "${REMOTE_EXEC_FILE}"
	fi

	return ${RC}
}

#########################################################################
# rcpコマンドはscpで置き換える
# 関数名：REMOTE_COPY
# 機能：リモートでファイルをコピーする
# 引数１：コピー元（[<IP>]:<パス><ファイル名>）
# 引数２：コピー先（[<IP>]:<パス>）
# 戻り値：０－正常
#		   1－異常
#########################################################################
function REMOTE_COPY {

	# コピー元
	SCP_FROM=$1
	
	# コピー先
	SCP_TO=$2
	
	# リモートファイルコピー
	scp -p ${SCP_FROM} ${SCP_TO}
	RC=$?
	
	# 戻り値が0以外の場合はエラー
	if [ ${RC} != '0' ]
	then
		outlog_func CM-E99029 ${SCP_FROM} ${SCP_TO} ${RC}
	fi
	
	return ${RC}
}

