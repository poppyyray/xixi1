#!/bin/sh
################### モジュール説明 ########################
# モジュール名   	： NINUSI_MAIN_FLOW.sh
# 業 務 名       ：一荷主一覧表ファイル受信時の処理
# 処理概要       	：Uドライブ配信用ディレクトリーに移す
# 特記事項      	： 
# パラメータ     ： なし
# リターンコード ： 0             正常終了
#            1             処理異常
# 対象DB         ： なし
#################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： 草野 
#
# 作成日付       ： 2010-11-09
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2010-11-09 草野                 新規作成
# 2 1.0.1 2015-02-04 Yuan Rui            HULFTとJP1サーバの切り分け
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
# 環境設定を行う
#########################################################################
# 共通変数呼び出し
_exec_ksh=/workflow/batch/ini/batch_common_hulft.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

# 共通関数呼び出し
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC_HULFT.sh ]
then
    echo "共通関数ファイルが存在しません" 
    exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC_HULFT.sh


# 出力ログ名設定
export log_name=${NINUSI_MAIN_FLOW_LOG}

#
# 受信ファイル
#
_ninusi_in=${PP_FILE_PATH}/NINUSI
#
# 配信ファイル・ディレクトリー
#
_ninusi_out_dir=${COUNT_FILE_PATH}/
_ninusi_out="${_ninusi_out_dir}NINUSI"

#
# 受信ファイルが普通のファイルで、サイズ０でない場合のみ、
# Uドライブ配信用ディレクトリーに移す
# 日付名シグナルファイルをtouchコマンドで作成し更新日を示す
#
# 開始ログ
outlog_func NM-I01001 

# 転送ファイルが存在しないまたファイルのサイズがゼロの場合異常終了
if [ ! -f ${_ninusi_in} ] || [ ! -s ${_ninusi_in} ]
then
	outlog_func NM-E01001
	exit 1
fi

# 既存のトリガーを削除する。
_ninusi_old_signal_file="${_ninusi_out_dir}*_NINUSI_Updated"
rm -f ${_ninusi_old_signal_file}
RC1=$?
# ファイルを転送する。
mv -f ${_ninusi_in} ${_ninusi_out}
RC2=$?
# トリガーを作成する。
_ninusi_updated_date=`date +%F`
_ninusi_signal_file="${_ninusi_out_dir}${_ninusi_updated_date}_NINUSI_Updated"
touch ${_ninusi_signal_file}
RC3=$?

# 上記コマンドの戻り値が全て0の場合正常終了、異常の場合エラログを出力する
if [ ${RC1} != "0" -o ${RC2} != "0" -o ${RC3} != "0" ]
then
	outlog_func NM-E01002 "${RC1}" "${RC2}" "${RC3}"
	exit 1
fi

# 終了ログ
outlog_func NM-I01002
exit 0



