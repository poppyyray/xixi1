#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： AUDIT_ANALYSIS_PROCESS.sh
# 業 務 名          ： なし
# 処理概要       ： DB2Auditログ分析用ツール
# 特記事項       ：
# パラメータ         ： 無し
# 前提条件       ：なし
# リターンコード  ： 0             正常終了
#               ： 1             処理異常
# 対象DB    ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： IBM.顧
#
# 作成日付    ： 2011-09-20
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2011-09-20 IBM.顧              新規作成
# 2
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#環境設定を行う
_exec_audit_sh=/admin/shells/asca/audit_log_analysis/environment/audit_analysis_common.conf
if [ ! -f ${_exec_audit_sh} ]
then
    echo "共通ファイルが存在しません[${_exec_audit_sh}]"
    exit 1
fi
. ${_exec_audit_sh}

# ----
# 共通関数ファイルの存在チェック
# ----
if [ ! -f ${AUDIT_ENV_DIR}/AUDIT_ANALYSIS_COMMON_FUNC.sh ]; then
	echo "共通関数ファイルが存在しません[${_exec_audit_sh}]"
	exit 1
fi
. ${AUDIT_ENV_DIR}/AUDIT_ANALYSIS_COMMON_FUNC.sh

#出力ログファイル名
export audit_log_name=${AUDIT_ANALYSIS_PROCESS_LOG}

##########################################################
# メインプロセス
##########################################################

# 開始ログ
outlog_audit_func A0-I00001

#1.作業用tar filesを共有folderから作業folderへ移動する
outlog_audit_func A0-I00008
mv -f ${SHARED_FOLDER_DIR}/* ${WORK_FOLDER_DIR} >> ${AUDIT_LOG_DIR}/${audit_log_name}.log 2>&1
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A0-E00005 ${RC}
	exit 1
fi

#2.作業用fileリストを取得する
file_list=`ls ${WORK_FOLDER_DIR}` >> ${AUDIT_LOG_DIR}/${audit_log_name}.log 2>&1
tar_file_count=`ls ${WORK_FOLDER_DIR} | wc -l`
outlog_audit_func A0-I00009 ${tar_file_count}


#3.作業用fileリストを一つずつで、分析する
for i in ${file_list}
do
	#3-1.該当作業用Logファイルを臨時folderへ解凍する
	outlog_audit_func A0-I00010 ${i}
	tar -zxvf ${WORK_FOLDER_DIR}/${i} -C ${TMP_FOLDER_DIR} >> ${AUDIT_LOG_DIR}/${audit_log_name}.log 2>&1
	RC=$?
	if [ ${RC} != '0' ]
	then
		outlog_audit_func A0-E00006 ${RC}
		exit 1
	fi

	#3-2.txtファイル名を取得する
	txtFileName=`ls ${TMP_FOLDER_DIR}` >> ${AUDIT_LOG_DIR}/${audit_log_name}.log 2>&1
	if [ "${txtFileName%\.txt}" == "${txtFileName}" -a "${txtFileName%\.TXT}" == "${txtFileName}" ]
		then
		outlog_audit_func A0-E00003 TXT
		exit 1
	fi

	#3-3.比較できるファイルを生成する
	/bin/sh ${AUDIT_HOME}/analysis_tool/AUDIT_FILE_TRANSITION.sh ${TMP_FOLDER_DIR}/${txtFileName} >> ${AUDIT_LOG_DIR}/${audit_log_name}.log 2>&1
	RC=$?
	if [ ${RC} != '0' ]
	then
		outlog_audit_func A0-E00001 ${RC}
		exit 1
	fi

	#3-4.Auditデータファイルをチェックする
	/bin/sh ${AUDIT_HOME}/analysis_tool/AUDIT_CHECK.sh ${TMP_FOLDER_DIR}/${txtFileName} ${SUSPECTABLE_RECORD_DIR}/${i} >> ${AUDIT_LOG_DIR}/${audit_log_name}.log 2>&1
	RC=$?
	if [ ${RC} != '0' ]
	then
		outlog_audit_func A0-E00002 ${RC}
		exit 1
	fi

	#3-5.該当処理完了のtarファイルを完了フォルダに移動する
	outlog_audit_func A0-I00011 ${i}
	mv -f ${WORK_FOLDER_DIR}/${i} ${COMPLETE_FOLDER_DIR} >> ${AUDIT_LOG_DIR}/${audit_log_name}.log 2>&1
	RC=$?
	if [ ${RC} != '0' ]
	then
		outlog_audit_func A0-E00007 ${RC}
		exit 1
	fi

	#3-6.該当Import完了の臨時ファイルを臨時folderから削除する
	if [ "${REMOVE_TEMP_FILES}" == "Y" ]
	then
		outlog_audit_func A0-I00012
		rm -f ${TMP_FOLDER_DIR}/* >> ${AUDIT_LOG_DIR}/${audit_log_name}.log 2>&1
		RC=$?
		if [ ${RC} != '0' ]
		then
			outlog_audit_func A0-E00008 ${RC}
			exit 1
		fi
	fi

done

# 終了ログ
outlog_audit_func A0-I00002
