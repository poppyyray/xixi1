#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： AUDIT_CHECK.sh
# 業 務 名          ： なし
# 処理概要       ：
# 特記事項       ：
# パラメータ         ： 1．TXTファイル名
#             2. 出力チェック結果ファイル名
# 前提条件       ：なし
# リターンコード  ： 0             正常終了
#               ： 1             処理異常
# 対象DB    ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： IBM.顧
#
# 作成日付    ： 2011-09-20
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2011-09-20 IBM.顧              新規作成
# 2
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# パラメータチェック
if [ $# != 2 ]
then
	echo "二つのパラメータが必要です。"
	exit 1
fi

#環境設定を行う
_exec_audit_sh=/admin/shells/asca/audit_log_analysis/environment/audit_analysis_common.conf
if [ ! -f ${_exec_audit_sh} ]
then
    echo "共通ファイルが存在しません[${_exec_audit_sh}]"
    exit 1
fi
. ${_exec_audit_sh}

# ----
# 共通関数ファイルの存在チェック
# ----
if [ ! -f ${AUDIT_ENV_DIR}/AUDIT_ANALYSIS_COMMON_FUNC.sh ]; then
	echo "共通関数ファイルが存在しません[${_exec_audit_sh}]"
	exit 1
fi
. ${AUDIT_ENV_DIR}/AUDIT_ANALYSIS_COMMON_FUNC.sh

#出力ログファイル名
export audit_log_name=${AUDIT_CHECK_LOG}


##########################################################
# メインプロセス
##########################################################

# 開始ログ
outlog_audit_func A2-I00001

TXT_FILE_NAME=$1
TO_FILE_NAME=$2

# 1.入力ファイルをチェックする
if [ ! -f ${TXT_FILE_NAME}.a07${TRANSFORMED_FILE} ]
then
	outlog_audit_func A0-E00003 ${TXT_FILE_NAME}.a07${TRANSFORMED_FILE}
	exit 1
fi


# 2.パターン定義ファイルを取得・チェックする
pattern_def="${AUDIT_PATTERN_DIR}/pattern_legal_definition.conf"
if [ ! -f ${pattern_def} ]
then
	outlog_audit_func A0-E00003 ${pattern_def}
	exit 1
fi

# 3.差分ファイルを生成する
#diff -e ${pattern_def} ${TXT_FILE_NAME}.a07${TRANSFORMED_FILE} | grep "^  " > ${TXT_FILE_NAME}.b01.diff
grep -Fvxf ${pattern_def} ${TXT_FILE_NAME}.a07${TRANSFORMED_FILE} > ${TXT_FILE_NAME}.b01.diff
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A2-I00002 0
	exit 0
fi
outlog_audit_func A0-I00007 ${TXT_FILE_NAME}.b01.diff


# 4.スキップバターンファイルファイルで定義したパターンを外す。
skip_def="${AUDIT_PATTERN_DIR}/pattern_skip_definition.conf"
if [ ! -f ${pattern_def} ]
then
	outlog_audit_func A0-E00003 ${pattern_def}
	exit 1
fi

grep -Evxf ${skip_def} ${TXT_FILE_NAME}.b01.diff > ${TXT_FILE_NAME}.b02${SKIPPED_FILE}
RC=$?
outlog_audit_func A0-I00007 ${TXT_FILE_NAME}.b02${SKIPPED_FILE}
if [ $[RC] == '1' ]
then
	outlog_audit_func A2-I00002
	exit 0
fi
cp -f ${TXT_FILE_NAME}.b02${SKIPPED_FILE} ${TO_FILE_NAME}.b02${SKIPPED_FILE}

# 5.不正なauditデータファイルを生成する
grep -Ff ${TXT_FILE_NAME}.b02${SKIPPED_FILE} ${TXT_FILE_NAME}.a05${DATA_FILE} > ${TXT_FILE_NAME}.b03${RESULT_FILE}
RC=$?
outlog_audit_func A0-I00007 ${TXT_FILE_NAME}.b03${RESULT_FILE}
if [ $[RC] == '1' ]
then
	outlog_audit_func A2-I00002
	exit 0
fi
cp -f ${TXT_FILE_NAME}.b03${RESULT_FILE} ${TO_FILE_NAME}.b03${RESULT_FILE}


# 6.不正なアクセスの件数を取得する
count=`cat ${TXT_FILE_NAME}.b03${RESULT_FILE} | wc -l`
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A2-E00001  ${RC}
	exit 1
fi
outlog_audit_func A2-E00002 ${count} ${TO_FILE_NAME}

# 7.詳細の不正なアクセスレコードファイルの生成かどうかを判断する
if [ "${CREATE_FROM_RAW}" == "N" ]
then
	outlog_audit_func A2-I00002
	exit 0
fi

# 8.不正なアクセスtimestampリストファイルを生成する。
timestamp_str="timestamp=2011-10-31-03.25.18.698353"
cut -c-${#timestamp_str} ${TXT_FILE_NAME}.b03${RESULT_FILE} > ${TXT_FILE_NAME}.b04.suspectableTSList
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A0-E00004 ${TXT_FILE_NAME}.b04.suspectableTSList ${RC}
	exit 1
fi
outlog_audit_func A0-I00007 ${TXT_FILE_NAME}.b04.suspectableTSList


# 9.不正なアクセス詳細レコードファイルを生成する。
while read line
do
	sed -n '/'${line}'/,/^\x20*$/p' ${TXT_FILE_NAME} >> ${TXT_FILE_NAME}.b05${DETAIL_RESULT}
	RC=$?
	if [ ${RC} != '0' ]
	then
		outlog_audit_func A0-E00004 ${TXT_FILE_NAME}.b05${DETAIL_RESULT} ${RC}
		exit 1
	fi
done < ${TXT_FILE_NAME}.b04.suspectableTSList

cp -f ${TXT_FILE_NAME}.b05${DETAIL_RESULT} ${TO_FILE_NAME}.b05${DETAIL_RESULT}
outlog_audit_func A0-I00007 ${TO_FILE_NAME}.b05${DETAIL_RESULT}


# 終了ログ
outlog_audit_func A2-I00002

exit 0