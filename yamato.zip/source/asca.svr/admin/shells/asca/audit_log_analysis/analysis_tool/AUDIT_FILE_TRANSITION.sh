#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： AUDIT_FILE_TRANSITION.sh
# 業 務 名          ： なし
# 処理概要       ：
# 特記事項       ：
# パラメータ         ： １．Auditログ（txt）ファイル名
# 前提条件       ：なし
# リターンコード  ： 0             正常終了
#               ： 1             処理異常
# 対象DB    ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： IBM.顧
#
# 作成日付    ： 2011-09-20
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1 1.0.0 2011-09-20 IBM.顧              新規作成
# 2
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

# パラメータチェック
if [ $# != 1 ]
then
	echo "一つのパラメータ（Auditログ（txt）ファイル名）が必要です。"
	exit 1
fi

#環境設定を行う
_exec_audit_sh=/admin/shells/asca/audit_log_analysis/environment/audit_analysis_common.conf
if [ ! -f ${_exec_audit_sh} ]
then
    echo "共通ファイルが存在しません[${_exec_audit_sh}]"
    exit 1
fi
. ${_exec_audit_sh}

# ----
# 共通関数ファイルの存在チェック
# ----
if [ ! -f ${AUDIT_ENV_DIR}/AUDIT_ANALYSIS_COMMON_FUNC.sh ]; then
	echo "共通関数ファイルが存在しません[${_exec_audit_sh}]"
	exit 1
fi
. ${AUDIT_ENV_DIR}/AUDIT_ANALYSIS_COMMON_FUNC.sh

#出力ログファイル名
export audit_log_name=${AUDIT_FILE_TRANSITION_LOG}


##########################################################
# メインプロセス
##########################################################

# 開始ログ
outlog_audit_func A1-I00001

FROM_FILE_NAME=$1

# 入力ファイルをチェックする
if [ ! -f ${FROM_FILE_NAME} ]
then
	outlog_audit_func A0-E00003 ${FROM_FILE_NAME}
	exit 1
fi

# 1.カラム定義ファイルを取得・チェックする
def_file="${AUDIT_PATTERN_DIR}/pattern_extraction_definition.conf"
if [ ! -f ${def_file} ]
then
	outlog_audit_func A0-E00003 ${def_file}
	exit 1
fi

# 2.定義したカラムのauditファイルを生成する
extraction_pattern=`cat ${def_file}`
cat ${FROM_FILE_NAME} | grep -E "${extraction_pattern}" > ${FROM_FILE_NAME}.a01.extracted
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A0-E00004 ${FROM_FILE_NAME}.a01.extracted ${RC}
	exit 1
fi
outlog_audit_func A0-I00007 ${FROM_FILE_NAME}.a01.extracted


# 3.「application id」からユーザコードと実行時刻の部分を削除する
sed 's/\(application id=.*\?\..*\?\..*\?\..*\?\)\..*\?\..*\?\(;\)/\1\2/' ${FROM_FILE_NAME}.a01.extracted > ${FROM_FILE_NAME}.a02.appidModified
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A0-E00004 ${FROM_FILE_NAME}.a02.appidModified ${RC}
	exit 1
fi
outlog_audit_func A0-I00007 ${FROM_FILE_NAME}.a02.appidModified



# 4.全てのテキストを一つの行にする
cat ${FROM_FILE_NAME}.a02.appidModified | tr -d '\n' > ${FROM_FILE_NAME}.a03.singleLine
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A0-E00004 ${FROM_FILE_NAME}.a03.singleLine ${RC}
	exit 1
fi
outlog_audit_func A0-I00007 ${FROM_FILE_NAME}.a03.singleLine



# 5.行でブロックを分かる。
sed 's/\(.\)\(timestamp=\)/\1\n\2/g' ${FROM_FILE_NAME}.a03.singleLine > ${FROM_FILE_NAME}.a04.blocks

RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func ${FROM_FILE_NAME}.a04.blocks A0-E00004 ${RC}
	exit 1
fi
outlog_audit_func A0-I00007 ${FROM_FILE_NAME}.a04.blocks



# 6.timestampのテキストをフォーマットに転換して、auditデータファイルを生成する。
sed "s/'[0-9]\{4\}\-[0-9]\{2\}\-[0-9]\{2\}\-[0-9]\{2\}\.[0-9]\{2\}\.[0-9]\{2\}\.[0-9]\{6\}'/'yyyy-MM-dd-HH.mm.SS.ssssss'/g" ${FROM_FILE_NAME}.a04.blocks > ${FROM_FILE_NAME}.a05${DATA_FILE}
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A0-E00004 ${FROM_FILE_NAME}.a05${DATA_FILE} ${RC}
	exit 1
fi
outlog_audit_func A0-I00007 ${FROM_FILE_NAME}.a05${DATA_FILE}



# 7.timestampを削除する
timestamp_str="timestamp=2011-10-31-03.25.18.698353; "
cut -c${#timestamp_str}- ${FROM_FILE_NAME}.a05${DATA_FILE} > ${FROM_FILE_NAME}.a06.timestampRemoved
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A0-E00004 ${FROM_FILE_NAME}.a06.timestampRemoved ${RC}
	exit 1
fi
outlog_audit_func A0-I00007 ${FROM_FILE_NAME}.a06.timestampRemoved



# 8.重複なくてソートする
sort -u ${FROM_FILE_NAME}.a06.timestampRemoved > ${FROM_FILE_NAME}.a07${TRANSFORMED_FILE}
RC=$?
if [ ${RC} != '0' ]
then
	outlog_audit_func A0-E00004 ${FROM_FILE_NAME}.a07${TRANSFORMED_FILE} ${RC}
	exit 1
fi
outlog_audit_func A0-I00007 ${FROM_FILE_NAME}.a07${TRANSFORMED_FILE}


# 終了ログ
outlog_audit_func A1-I00002

exit 0