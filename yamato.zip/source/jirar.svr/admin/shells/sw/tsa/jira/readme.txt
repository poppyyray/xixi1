参照jira起停シェールとmonitorは更新jiraと共用する
/jirau.svr/admin/shells/sw/tsa/jira/jira_start.sh
/jirau.svr/admin/shells/sw/tsa/jira/jira_stop.sh
/jirau.svr/admin/shells/sw/tsa/jira/jira_monitor.sh