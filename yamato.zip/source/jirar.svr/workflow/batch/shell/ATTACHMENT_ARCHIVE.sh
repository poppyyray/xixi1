#!/bin/sh
################### モジュール説明 ########################
# モジュール名   ： ATTACHMENT_ARCHIVE.sh
# 業 務 名       ： なし
# 処理概要       ： ATTACHMENTファイルをアーカイブする
# 特記事項       ：
# パラメータ     ： なし
# リターンコード ： 0             正常
#                   1             エラー
# 対象DB         ： なし
#
################### モジュール説明 ########################
#
################### 改定履歴       ########################
# 作成者         ： 
#
# 作成日付       ： 
#
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
# 1       2014-07-29  LiuJian                規範化
# 2       2014-09-29  LiuJian                505.[開発] 更新と参照JIRA Attachment同期と退避 (JP1関連)
# 3
# 4
# 5
# =V.R.M= == DATE == = 担当者  = =準拠文書= ==== 内容 =======
#
################### 改定履歴       ########################

#########################################################################
#環境設定を行う
#########################################################################
_exec_ksh=/workflow/batch/ini/batch_common_jirar.conf
if [ ! -f ${_exec_ksh} ]
then
    echo "環境設定ファイルが存在しません"
    exit 1
fi
. ${_exec_ksh}

#########################################################################
# 共通関数呼び出し
#########################################################################
if [ ! -f ${SHELL_DIR}/BATCH_COMMON_FUNC_JIRAR.sh ]
then
        echo "共通関数ファイルが存在しません"
        exit 1
fi
. ${SHELL_DIR}/BATCH_COMMON_FUNC_JIRAR.sh

outlog_func CM-I30006

#作業ディレクトリ
export MOUNT_DIR=${ATTACH_BK_MNT_DIR}
export ATTACHMENT_FILELIST_PATH=${TMP_DIR}
export TAR_DIR_NAME=attachment
export ATTACHMENT_TMP_DIR=${TMP_DIR}/${TAR_DIR_NAME}
export ATTACHEMENT_JIRA_GZ=${TMP_DIR}/attachment_jira_`date +%Y%m%d`.tar.gz

if [ ! -d ${ATTACHMENT_TMP_DIR} ]
then
	mkdir -p ${ATTACHMENT_TMP_DIR}
fi

#mvコマンド実行結果を保存用一時ファイル
export RUN_RESULT=run_rtn.tmp
cat /dev/null > ${TMP_DIR}/${RUN_RESULT}

#入出金材料
if [ ! -d ${ATTACHMENT_TMP_DIR}/CE ]
then
        mkdir -p ${ATTACHMENT_TMP_DIR}/CE
fi
file_cnt=`cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep CE|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRA_CSV_DIR}/CE
	mv -f `cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep CE|cut -f2 -d,` ${ATTACHMENT_TMP_DIR}/CE >>${TMP_DIR}/${RUN_RESULT} 2>&1
	RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E30011 "CE" ${RC}
	fi
fi

#経費振替
if [ ! -d ${ATTACHMENT_TMP_DIR}/CT ]
then
        mkdir -p ${ATTACHMENT_TMP_DIR}/CT
fi
file_cnt=`cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep CT|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRA_CSV_DIR}/CT
    mv -f `cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep CT|cut -f2 -d,` ${ATTACHMENT_TMP_DIR}/CT >>${TMP_DIR}/${RUN_RESULT} 2>&1
    RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E30011 "CT" ${RC}
	fi    
fi

#一般集金(手動)
if [ ! -d ${ATTACHMENT_TMP_DIR}/GC ]
then
        mkdir -p ${ATTACHMENT_TMP_DIR}/GC
fi
file_cnt=`cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep GC|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRA_CSV_DIR}/GC
    mv -f `cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep GC|cut -f2 -d,` ${ATTACHMENT_TMP_DIR}/GC >>${TMP_DIR}/${RUN_RESULT} 2>&1
    RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E30011 "GC" ${RC}
	fi
fi

#一般集金(エラー)
if [ ! -d ${ATTACHMENT_TMP_DIR}/GE ]
then
        mkdir -p ${ATTACHMENT_TMP_DIR}/GE
fi
file_cnt=`cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep GE|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRA_CSV_DIR}/GE
    mv -f `cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep GE|cut -f2 -d,` ${ATTACHMENT_TMP_DIR}/GE >>${TMP_DIR}/${RUN_RESULT} 2>&1
    RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E30011 "GE" ${RC}
	fi
fi

#入金データアンマッチ
if [ ! -d ${ATTACHMENT_TMP_DIR}/UD ]
then
        mkdir -p ${ATTACHMENT_TMP_DIR}/UD
fi
file_cnt=`cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep UD|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRA_CSV_DIR}/UD
    mv -f `cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep UD|cut -f2 -d,` ${ATTACHMENT_TMP_DIR}/UD >>${TMP_DIR}/${RUN_RESULT} 2>&1
    RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E30011 "UD" ${RC}
	fi
fi

#振込入金
if [ ! -d ${ATTACHMENT_TMP_DIR}/BT ]
then
        mkdir -p ${ATTACHMENT_TMP_DIR}/BT
fi
file_cnt=`cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep BT|wc -l`
if [ ${file_cnt} != '0' ]
then
	cd ${JIRA_CSV_DIR}/BT
    mv -f `cat ${ATTACHMENT_FILELIST_PATH}/${ATTACHMENT_FILELIST}|grep BT|cut -f2 -d,` ${ATTACHMENT_TMP_DIR}/BT >>${TMP_DIR}/${RUN_RESULT} 2>&1
    RC=$?
	if [ ${RC} != 0 ]
		then
		outlog_func CM-E30011 "BT" ${RC}
	fi
fi

# ${TMP_DIR}へ、${ATTACHMENT_TMP_DIR}を圧縮して、tar.gzファイルを生成する。ファイル名を日付をつける。
cd ${ATTACHMENT_FILELIST_PATH}

# attachmentフォルダを圧縮する。
tar -czf ${ATTACHEMENT_JIRA_GZ} ${TAR_DIR_NAME}
RC=$?
if [[ "${RC}" != "0" ]]
then
	outlog_func CM-E30012 ${RC}
	exit 1
fi

# マウント実施
mount ${MOUNT_DIR}
RC=$?
if [ ${RC} != 0 ]
then
	outlog_func CM-E30008 ${RC}
	exit 1
fi

# 圧縮ファイルをmountディレクトリに移動
mv -f ${ATTACHEMENT_JIRA_GZ} ${MOUNT_DIR}
MVRC=$?
if [[ "${MVRC}" != "0" ]]
then
	outlog_func CM-E30013 ${RC}
fi

# アンマウント実施
umount ${MOUNT_DIR}
RC=$?
if [ ${RC} != 0 ]
then
	outlog_func CM-E30009 ${RC}
	exit 1
fi

if [[ "${MVRC}" != "0" ]]
then
	exit 1
fi

# 臨時退避ファイル削除する
rm -fr ${ATTACHMENT_TMP_DIR}
RC=$?
if [ ${RC} != 0 ]
then
	outlog_func E30014 ${RC}
	exit 1
fi

outlog_func CM-I30007

exit 0
