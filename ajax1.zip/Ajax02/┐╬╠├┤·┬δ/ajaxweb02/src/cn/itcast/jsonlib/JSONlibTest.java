package cn.itcast.jsonlib;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

import org.junit.Test;

import cn.itcast.servlet.demo2.Product;

public class JSONlibTest {
	@Test
	public void demo1(){
		// 转换数组 到 json格式字符串
		String[] arr = {"sada","fdssd","dfsd","sadas"};
		JSONArray jsonArray =  JSONArray.fromObject(arr);
		System.out.println(jsonArray.toString());
	}
	
	@Test
	public void demo2(){
		// 转换list到json
		List<Product> products = new ArrayList<Product>();
		Product p1 = new Product();
		p1.setName("三星手机");
		p1.setPrice(3999);
		
		Product p2 = new Product();
		p2.setName("联想笔记本");
		p2.setPrice(5000);
		
		products.add(p1);
		products.add(p2);
		
		JSONArray jsonArray = JSONArray.fromObject(products);
		System.out.println(jsonArray);
	}
	
	@Test
	public void demo3(){
		// 转换对象 到 json
		Product p1 = new Product();
		p1.setName("三星手机");
		p1.setPrice(3999);
		
		JSONObject jsonObject = JSONObject.fromObject(p1);
		System.out.println(jsonObject);
	}
	
	@Test
	public void demo4(){
		// 通过JSONConfig对象 配置对象哪些属性不参与转换 
		Product p1 = new Product();
		p1.setName("三星手机");
		p1.setPrice(3999);
		// 不想手机 价格存在 于 结果json中
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setExcludes(new String[]{"price"});
		
		JSONObject jsonObject = JSONObject.fromObject(p1, jsonConfig);
		System.out.println(jsonObject);
	}
}
