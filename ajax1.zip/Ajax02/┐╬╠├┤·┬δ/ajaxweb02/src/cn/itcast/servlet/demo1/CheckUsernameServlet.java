package cn.itcast.servlet.demo1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
// 判断用户是否已经存在

public class CheckUsernameServlet extends HttpServlet {
	
	private List<String> exietNames = new ArrayList<String>();
	@Override
	public void init() throws ServletException {
		exietNames.add("abc");
		exietNames.add("def");
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 获得请求参数
		String username = request.getParameter("username");
		// get提交
		username = new String(username.getBytes("ISO-8859-1"),"utf-8");
		
		// 判断是否存在
		response.setContentType("text/html;charset=utf-8");
		if(exietNames.contains(username)){
			// 已经存在
			response.getWriter().print("<font color='red'>用户名已经存在！</font>");
		}else{
			// 不存在
			response.getWriter().print("<font color='green'>用户名不存在，可以使用！</font>");
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
