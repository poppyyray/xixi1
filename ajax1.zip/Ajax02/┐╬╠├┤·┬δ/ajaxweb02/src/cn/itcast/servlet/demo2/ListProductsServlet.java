package cn.itcast.servlet.demo2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * 查询数据库 获得商品信息，传递jsp显示
 * @author seawind
 *
 */
public class ListProductsServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Product> products = new ArrayList<Product>();
		Product p1 = new Product();
		p1.setName("三星手机");
		p1.setPrice(3999);
		
		Product p2 = new Product();
		p2.setName("联想笔记本");
		p2.setPrice(5000);
		
		products.add(p1);
		products.add(p2);
		
		request.setAttribute("products", products);
		request.getRequestDispatcher("/demo2/product.jsp").forward(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
