package cn.itcast.servlet.demo3;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import cn.itcast.servlet.demo2.Product;
/**
 * 返回json格式数据
 * @author seawind
 *
 */
public class ListProductsServlet2 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Product> products = new ArrayList<Product>();
		Product p1 = new Product();
		p1.setName("三星手机");
		p1.setPrice(3999);
		
		Product p2 = new Product();
		p2.setName("联想笔记本");
		p2.setPrice(5000);
		
		products.add(p1);
		products.add(p2);
		
		// 返回json
		JSONArray jsonArray = JSONArray.fromObject(products);
		response.setContentType("text/json;charset=utf-8");
		response.getWriter().print(jsonArray);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
