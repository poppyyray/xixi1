package cn.itcast.xstream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.thoughtworks.xstream.XStream;

import cn.itcast.domain.City;

public class XStreamTest {
	@Test
	public void demo4(){
		// 基于注解的序列化 
		List<City> cities = new ArrayList<City>();
		City city = new City();
		city.setName("北京");
		city.setDescription("国家的心脏");
		
		City city2 = new City();
		city2.setName("上海");
		city2.setDescription("东方明珠");
		
		cities.add(city);
		cities.add(city2);
		
		// 序列化
		XStream xStream = new XStream();
		// 使注解生效
		xStream.autodetectAnnotations(true);
		
		System.out.println(xStream.toXML(cities));
	}
	
	@Test
	public void demo3() throws FileNotFoundException{
		// 将cities.xml 解析 List<City>对象
		XStream xStream = new XStream();
		xStream.alias("city", City.class);
		xStream.alias("cities", List.class);
		
		List<City> cities =(List<City>) xStream.fromXML(new FileInputStream("cities.xml"));
		for (City city : cities) {
			System.out.println(city.getName() +"," +city.getDescription());
		}
	}
	
	@Test
	public void demo2(){
		// 转换list 到xml
		List<City> cities = new ArrayList<City>();
		City city = new City();
		city.setName("北京");
		city.setDescription("国家的心脏");
		
		City city2 = new City();
		city2.setName("上海");
		city2.setDescription("东方明珠");
		
		cities.add(city);
		cities.add(city2);
		
		// 转换
		XStream xStream = new XStream();
		xStream.alias("city", City.class);
		xStream.alias("cities", List.class);
		
		String xml = xStream.toXML(cities);
		System.out.println(xml);
	}
	
	@Test
	public void demo1(){
		// 将java对象 序列化 xml
		City city = new City();
		city.setName("北京");
		city.setDescription("国家的心脏");
		
		// 使用Xstream
		XStream xStream= new XStream();
		// 不要显示类名标签，显示city标签 ，通过别名指定
		xStream.alias("city", City.class);
		
		String xml = xStream.toXML(city);
		
		System.out.println(xml);
	}
}
