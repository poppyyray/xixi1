package cn.itcast.servlet.xmldemo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.thoughtworks.xstream.XStream;

import cn.itcast.domain.City;
import cn.itcast.domain.Province;

public class ShowProvinceDataServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 造省市假数据 
		Province province1 = new Province("河北省");
		City city1_1 = new City("石家庄", "河北省会");
		City city1_2 = new City("承德", "避暑山庄");
		
		Province province2 = new Province("山东省");
		City city2_1 = new City("济南", "山东省会");
		City city2_2 = new City("蓬莱", "仙岛");
		
		List<City> cities1 = new ArrayList<City>();
		cities1.add(city1_1);
		cities1.add(city1_2);
		province1.setCities(cities1);
		
		List<City> cities2 = new ArrayList<City>();
		cities2.add(city2_1);
		cities2.add(city2_2);
		province2.setCities(cities2);
		
		List<Province> provinces = new ArrayList<Province>();
		provinces.add(province1);
		provinces.add(province2);
		
		// 序列化
		XStream xStream = new XStream();
		// 支持注解
		xStream.autodetectAnnotations(true);
		String xml = xStream.toXML(provinces);
		System.out.println(xml);
		
		response.setContentType("text/xml;charset=utf-8");
		response.getWriter().print(xml);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
