package cn.itcast.domain;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

@XStreamAlias(value="city")
public class City {
	
	@XStreamAlias(value="name")
	@XStreamAsAttribute
	//@XStreamOmitField  // 不生成到xml
	private String name;
	
	@XStreamAsAttribute
	private String description;
	
	
	public City() {
	}
	
	public City(String name, String description) {
		super();
		this.name = name;
		this.description = description;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
