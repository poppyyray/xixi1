class Demo1
{
	public static void main(String[] args) 
	{
		//System.out.println("Hello World!");
		Single s1=Single.getIns();
		Single s2=Single.getIns();
		System.out.println(s1==s2);
		//Single s2=Single.getIns();
	}
}

class Single{
	private static Single s1=null;
	private Single(){
	}
	public static Single getIns(){
		if(s1==null){
			synchronized(Single.class){
				if(s1==null){
					s1=new Single();
				}
			}
		}
		return s1;
	}
}
