/*
�������⡣

1������������⡣

2����������� Ů����������⡣

3����������Ż���name sexӦ��˽�С�

*/

class Resource
{
	String name;
	String sex;
	boolean flag = true;
}
class Locker
{
	public static final Object key = new Object();
	public static boolean flag = true;
}
class Input  implements Runnable
{
	
	public Resource r;
	Input(Resource r)
	{
		this.r = r;
	}
	public  void run()
	{
			int x = 0;

			while(true)
			{
				synchronized(r){
					if(!r.flag){
						try{r.wait();}catch(InterruptedException ex){}
					}

					if( x == 0 )
					{
						r.name = "����";
						r.sex = "��";
					}
					else
					{
						r.name = "rose";
						r.sex = "ŮŮŮŮŮ";
					}
					x = (x+1)%2;
					r.flag=false;
					r.notify();
				}
			}
		
	}
}

class Output implements Runnable
{
	public Resource r;
	Output(Resource r)
	{
		this.r = r;
	}
	public void run()
	{
		while(true)
		{
			
			synchronized(r){
				if(r.flag){try{r.wait();}catch(InterruptedException ex){}}
				System.out.println(r.name+"....."+r.sex);
				r.flag=true;
				r.notify();
			}
		}
	}
}

public class ThreadTest 
{
	public static void main(String[] args) 
	{
		Resource r = new Resource();

		new Thread(new Input(r)).start();
		new Thread(new Output(r)).start();
	}
}
