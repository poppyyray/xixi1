package yr01.y1205.test;

import java.io.IOException;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws  Exception{
		// TODO Auto-generated method stub
		char[] ch = new char[] { 'a', 'b', 'c' };
		ch=null;
		
		String str = "abc";
		System.out.println(getIndex(ch, '3'));
		System.out.println(getIndex(str, 'c'));
	}

	public static int getIndex(char[] ch, char key) throws  Exception{

		if (ch == null) {
			throw new IOException("����Ĳ���������Ϊ��");
		}
		
		for (int i = 0; i < ch.length; i++) {
			if (ch[i] == key) {
				return i;
			}
		}

		return -1;
	}

	public static int getIndex(String str, char key) {
		char[] ch = str.toCharArray();
		return getIndex(ch, key);
	}

}
