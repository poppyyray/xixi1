
package packfu;

public class DemoFu
{
	protected/*����Ȩ��*/ void method()
	{
		System.out.println("demofu method run");
	}
}
