package packa;
public class DemoA extends packfu.DemoFu
{
	public void show()
	{
		method();
		System.out.println("demoa show run");
	}
}
