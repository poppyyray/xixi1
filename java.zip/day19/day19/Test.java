//�����⡣
class Test
{
	public static void main(String[] args)
	{
		new Thread(new Runnable(){
			public void run(){
				System.out.println("runnable run");
			}
		}){
			public void run(){
				System.out.println("thread run");
			}
		}.start();

		/*
		new Thread(new Runnable()
		{
			public void run()
			{
				System.out.println("runnable run");
			}
		})
		{
			public void run()
			{
				public void run()
				{
					System.out.println("thread run");
				}
			}
		}.start();
		*/
	}
}

