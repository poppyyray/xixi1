class  ThreadDemo22
{
	public static void main(String[] args) 
	{
		//˵�������˵��ԭ��
		new Thread(new Runnable()
		{
			public void run()
			{
				System.out.println("runnable run");
			}
		})
		{
			public void run()
			{
				System.out.println("subthread run");
			}
		}.start();


		new Thread()
		{
			public void run()
			{
				for (int a=1; a<=50 ; a++ )
				{
					System.out.println(Thread.currentThread().getName()+"....a....."+a);
				}
			}
		}.start();
		
		Runnable r = new Runnable()
		{
			public void run()
			{
				for (int a=1; a<=50 ; a++ )
				{
					System.out.println(Thread.currentThread().getName()+"....b....."+a);
				}
			}
		};
		new Thread(r).start();
		

		for (int a=1; a<=50 ; a++ )
		{
			System.out.println(Thread.currentThread().getName()+"....c....."+a);
		}
	}
}
