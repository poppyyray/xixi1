package cn.itcast.string;

public class StringTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		String s1 = "hello";
		String s2 = "java";
		method(s1,s2);
		System.out.println(s1+","+s2);
		
	}

	public static void method(String s1,String s2){
		s2.replace('a', 'o');
		s1 = s2;
	}
}
