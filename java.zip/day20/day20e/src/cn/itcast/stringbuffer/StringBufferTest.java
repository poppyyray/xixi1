package cn.itcast.stringbuffer;

public class StringBufferTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		��ҵ��"abcd" --> "dcba" ������ʹ��reverse��
		/*
		 * ���⣺sb.append(new Object()); ���?Ϊʲô��
		 * 
		 */
		
		StringBuffer s1 = new StringBuffer("hello");
		StringBuffer s2 = new StringBuffer("java");
		
		method(s1,s2);
		System.out.println(s1+",,"+s2);

	}

	public static void method(StringBuffer s1, StringBuffer s2) {
		s1.append(s2);
		s1 = s2;
		
	}

}
