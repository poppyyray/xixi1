package cn.itcast.thread;

public class MyThreadTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		new Thread(new SubThread()).start();
		
		for (int i = 1; i <= 5; i++) {//����
//			synchronized(MyLock.lock)
//			{
//				if(!MyFlag.flag)
//					try {
//						MyLock.lock.wait();
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
				for (int j = 1; j <= 10; j++) {
					System.out.println("��"+i+"��..."+Thread.currentThread().getName()+".......��"+j+"��");
				}
//				//�ı��ǡ�
//				MyFlag.flag = false;
//				MyLock.lock.notify();
//			}
		}

	}
}
class MyLock{
	public static final Object lock = new Object();
}
class MyFlag{
	public static boolean flag = false;
}
class SubThread implements Runnable{

	@Override
	public void run() {
		
		for (int i = 1; i <= 5; i++) {//����
			
//			synchronized(MyLock.lock){
//				if(MyFlag.flag)
//					try {
//						MyLock.lock.wait();
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
				for (int j = 1; j <= 5; j++) {
					System.out.println("��"+i+"��..."+Thread.currentThread().getName()+".............��"+j+"��");
				}
//				//�ı��ǡ�
//				MyFlag.flag = true;
//				MyLock.lock.notify();
//			}
		}
		
	}
}

