package cn.itcast.string;

public class MyTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// * ��ϰһ��"dsitcastajfitcastlkitcastds"
		// * ��ȡÿ��itcast���ֵ�λ�á�
		String str="dsitcastajfitcastlkitcastds";
//		System.out.println(str.indexOf("itcast",17));
		int i=0;
		//int index=0;
		while(str.indexOf("itcast",i)!=-1){
		//	index=str.indexOf("itcast",i);
		//	System.out.println(index);
			System.out.println(str.indexOf("itcast",i));
			i=(str.indexOf("itcast",i)+"itcast".length());
			
		}
		

	}



}
