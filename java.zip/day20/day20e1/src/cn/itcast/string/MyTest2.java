package cn.itcast.string;

public class MyTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		 * ��ϰ����"dsitcastajfitcastlkitcastds"
//		 * ��ȡitcast���ֵĴ�����
		String str="dsitcastajfitcastlkitcastds";
//		System.out.println(str.indexOf("itcast",17));
		int i=0;
		int index=0;
		int count=0;
		while(str.indexOf("itcast",i)!=-1){
			index=str.indexOf("itcast",i);
			//System.out.println(index);
			i=(index+"itcast".length());
			count++;
		}
		System.out.println(count);
	}

}
