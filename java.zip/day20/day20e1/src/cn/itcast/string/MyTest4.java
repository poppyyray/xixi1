package cn.itcast.string;

public class MyTest4 {
	public static void main(String[] args) {
		// * ��ϰ�ģ�"sdjflsitcastkdjfdsf" "ertitcastkewtr"
		// * ��ȡ�����ַ����������ͬ���Ӵ���
		// *

		String str1 = "sdjflsitcastkdjfdsf";
		String str2 = "ertitcastkewtr";
		String temp=null;
		getIndex(str1,str2, temp);
		
		// for(int i=str2.length();i>0;i--){
		// for(int j=0;j<str2.length();j+=i)
		// {
		// if((j)<=str2.length()){
		// System.out.println(str2.substring(j, j+i));
		// }
		// }
		// }
		
		abc:
		for (int i = 0; i < str2.length(); i++) {
			for (int j = 0, z = str2.length() - i; z <= str2.length(); z++, j++) {
				if(str1.indexOf(str2.substring(j, z))>0){
					System.out.println(str2.substring(j, z));
					break ;
				};
			}

		}
				//get();
	}

	private static void getIndex(String str1,String str2,String temp) {
		// TODO Auto-generated method stub
		temp=str1;
		str1=str2;
		str2=temp;
		
	}

}
